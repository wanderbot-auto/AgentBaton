from pathlib import Path
import datetime,hashlib,json,subprocess,sys
ROOT=Path('/workspace/.worktrees/factory-child-goal-native-harness');OUT=Path(__file__).resolve().parent
SOURCE='46a27a575b97f15e58a82956d6ced5f2a4990832';BASE='a57d647e49190fa795f655ed102c0ad29275370a'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
sha=lambda r:hashlib.sha256(r).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
paths=git('diff','--name-only',BASE,SOURCE).decode().splitlines()
before={p:{'sha256':sha((ROOT/p).read_bytes()),'bytes':(ROOT/p).stat().st_size} for p in paths}
for p in paths:assert (ROOT/p).read_bytes()==git('show',SOURCE+':'+p)
python_paths=[p for p in paths if p.endswith('.py')]
commands=[('pure-final',['python','-B',str(OUT/'run_pure.py')]),('static-final',['python','-B',str(OUT/'check_static.py')]),('Python-compile',['python','-B','-c','import sys;from pathlib import Path;[compile(Path(p).read_text(),p,"exec") for p in sys.argv[1:]]',*python_paths]),('shell-syntax',['bash','-n','scripts/native-macos-smoke.sh']),('rustfmt',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check','apps/desktop/src-tauri/src/bin/native_smoke.rs']),('diffcheck',['git','diff','--check',BASE,SOURCE])]
results=[]
for name,argv in commands:
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=ROOT,capture_output=True)
 row={'name':name,'argv':argv,'cwd':str(ROOT),'start_UTC':stamp,'exit':p.returncode}
 for suffix,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  target=OUT/(name+'.'+suffix);target.write_bytes(raw);row[suffix]={'path':target.name,'sha256':sha(raw),'bytes':len(raw)}
 results.append(row);assert p.returncode==0,name
after={p:{'sha256':sha((ROOT/p).read_bytes()),'bytes':(ROOT/p).stat().st_size} for p in paths};assert before==after and not git('status','--porcelain')
for p in paths:
 destination=OUT/'source'/p;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((ROOT/p).read_bytes())
(OUT/'SOURCE.patch').write_bytes(git('diff',BASE,SOURCE,'--',*paths))
record={'source_commit':SOURCE,'base':BASE,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'before':before,'after':after,'source_before_after_equal':True,'commands':results,'python_version':sys.version,'actual_results':{'pure':json.loads((OUT/'PURE_RESULT.json').read_text()),'static':30},'not_run':['5 actual Core/daemon Owner tests listed in TEST_SELECTION.json','Native Rust30 unit/type/Clippy','real same-head15 prepare/probe/SIGTERM Core chain','Node/browser','macOS/AppKit Grant/planning/execution GUI','CI','Provider/accounts','packages'],'integration_notes':['Root owns workflow labels still schema14-tools; change centrally without treating names as schema proof.','All older14 raw logs/archives/Core migration fixtures unchanged.','Actual preparation requires same checkout normal15 pair, not any historic14 tools.','DefaultGrant/planning false capabilities unchanged; execution NativeOS is unverified.']}
(OUT/'SOURCE_SNAPSHOT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'source':SOURCE,'exits':[r['exit'] for r in results],'source_before_after_equal':True,'pure':94,'actual_Core_NOT_RUN':5,'static':30,'snapshot_sha256':sha((OUT/'SOURCE_SNAPSHOT.json').read_bytes())}))
