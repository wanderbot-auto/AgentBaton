"""Check schema15 harness source contracts; no Cargo/Core/GUI execution."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
ROOT=Path('/workspace/.worktrees/factory-child-goal-native-harness');OUT=Path(__file__).resolve().parent
BASE='a57d647e49190fa795f655ed102c0ad29275370a'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
sha=lambda r:hashlib.sha256(r).hexdigest()
checks=[]
def check(name,ok,detail=None):
 checks.append({'name':name,'passed':bool(ok),'detail':detail});assert ok,name
allowed=['apps/desktop/src-tauri/src/bin/native_smoke.rs','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','apps/desktop/src-tauri/tests/test_native_runner.py','scripts/native-macos-smoke.sh','scripts/native-owner-dialog-smoke.py','scripts/native-run.py','scripts/prepare-factory-test-tools.py','tests/infrastructure/test_factory_test_tools.py']
changed=git('diff','--name-only',BASE).decode().splitlines()
check('only_eight_allowed_source_paths',changed==allowed,changed)
for path in ['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs','scripts/native-audit-release.sh']:
 check('readonly_dependency_byte_equal:'+path,(ROOT/path).read_bytes()==git('show',BASE+':'+path))
inputs={}
for path in ['crates/core/src/storage.rs','crates/core/src/factory.rs','crates/core/src/factory_store.rs','crates/core/src/factory_child_goal.rs']:
 raw=git('show',BASE+':'+path);p=OUT/('INPUT-'+Path(path).name);p.write_bytes(raw);inputs[path]={'path':p.name,'sha256':sha(raw),'bytes':len(raw)}
factory=(OUT/'INPUT-factory.rs').read_text();store=(OUT/'INPUT-factory_store.rs').read_text();storage=(OUT/'INPUT-storage.rs').read_text()
body=re.search(r'pub struct FactoryRecordCounts \{(.*?)\n\}',factory,re.S)[1]
authority_fields=re.findall(r'pub (\w+): u64',body)
check('authority_has_exact12_independent_counts',len(authority_fields)==12 and 'child_goal_runs' in authority_fields,authority_fields)
check('authority_child_goal_count_real_root_SQL','SELECT count(*) FROM factory_child_goal_runs WHERE root_task_id=?1' in store)
check('storage_current_schema15_bound','if version > 15 {' in storage and 'if version > 0 && version < 15 {' in storage)
rust=(ROOT/allowed[0]).read_text();rust_old=git('show',BASE+':'+allowed[0]).decode()
rust_fields=re.findall(r'"(\w+)"',re.search(r'const FACTORY_COUNT_FIELDS: \[&str; 12\] = \[(.*?)\];',rust,re.S)[1])
check('Native_Rust_count_fields_match_authority',set(rust_fields)==set(authority_fields))
check('Rust_strict15_three_readonly_snapshots',rust.count('value["schema_version"].as_u64() == Some(15)')==3)
check('Rust_record_has12plusSchemaSequence', 'record.len() == 14' in rust)
check('Rust_actual_table_drift_control_source_added','("child_goal_runs","INSERT INTO factory_child_goal_runs' in rust)
check('Rust_missing_table_control_source_added','"DROP TABLE factory_child_goal_runs"' in rust)
check('Rust_30_tests_preserved_SOURCE_ONLY',len(re.findall(r'#\[test\]',rust))==len(re.findall(r'#\[test\]',rust_old))==30)
def tree(path,old=False):return ast.parse(git('show',BASE+':'+path).decode() if old else (ROOT/path).read_text())
def functions(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def dump(n):return ast.dump(n,include_attributes=False)
owner='scripts/native-owner-dialog-smoke.py';a,b=functions(tree(owner,True)),functions(tree(owner))
changed_functions={k for k in a if dump(a[k])!=dump(b[k])}
expected={'pending_error','approved_error','factory_pending_error','factory_approved_error','_run_factory_pinned'}
check('Owner_only_schema_error_functions_AST_change',changed_functions==expected,sorted(changed_functions))
check('Owner_prepare_and_complete_policy_captions_untouched',dump(a['prepare_factory'])==dump(b['prepare_factory']))
check('Owner_run_OS_click_page_cancel_lifecycle_AST_unchanged',all(dump(a[k])==dump(b[k]) for k in a if k not in expected))
preparer='scripts/prepare-factory-test-tools.py';a,b=functions(tree(preparer,True)),functions(tree(preparer))
old_probe=ast.unparse(a['probe']).replace("'ab14-'","'ab15-'")
check('probe_only_short_prefix_changed_no_timeouts_cleanup_relaxed',old_probe==ast.unparse(b['probe']))
check('private_singlelink0500_validation_implemented',all(s in ast.unparse(b['verify_private_tool']) for s in ['st_nlink != 1','0o500','stat.S_ISREG','os.geteuid()']))
preservation=[]
def canonical(name):return name.replace('schema14','schema15').replace('all_eleven','all_twelve')
for path in [allowed[1],allowed[2],allowed[-1]]:
 def methods(t):return {canonical(n.name):n for cls in t.body if isinstance(cls,ast.ClassDef) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
 old,new=methods(tree(path,True)),methods(tree(path))
 check('no_existing_tests_removed:'+path,set(old)<=set(new),{'old':len(old),'new':len(new)})
 for name,n in old.items():
  other=new[name];same=dump(n)==dump(other)
  preservation.append({'path':path,'canonical_name':name,'AST_identical':same,'original_sha256':sha(ast.unparse(n).encode()),'current_sha256':sha(ast.unparse(other).encode())})
check('only_two_new_test_functions',sum(len([n for cls in tree(p).body if isinstance(cls,ast.ClassDef) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]) for p in [allowed[1],allowed[2],allowed[-1]])==99)
runner=(ROOT/'scripts/native-run.py').read_text();owner_text=(ROOT/owner).read_text();prepare_text=(ROOT/preparer).read_text()
check('Python_field_sets_include_new_table',"'child_goal_runs')" in runner and "'factory_child_goal_runs')" in owner_text and "'factory_child_goal_runs'," in prepare_text)
for p in [allowed[1],allowed[2],allowed[-1]]:
 s=(ROOT/p).read_text()
 check('old14_and_future16_negative_sources:'+p,all(x in s for x in ['14','16']))
check('old_float_bool_unknown_negative_forms_retained',all(x in (ROOT/allowed[1]).read_text() for x in ['14.0','15.0','True',"'15'",'None']))
check('no_Core_or_GUI_selected',json.loads((OUT/'PURE_RESULT.json').read_text())=={'tests_run':94,'failures':0,'errors':0,'skipped':0,'selected':94,'not_run_actual_Core':5,'success':True,'dimension':'Pure Python/generated SQLite/inert owned child controls, NOT Core/GUI/Provider'})
selection=json.loads((OUT/'TEST_SELECTION.json').read_text())
matrix={'old_schema14_positive':'Current synthetic/fresh-Store expectations move to15. Historical14 logs/migrations untouched.','current15':'Strict integer only','old14_future16':'Both rejected, with older10–13 retained where present','typed_counts':'12 exact Factory fields, before/after, each missing/nonzero/bool/float/string/null/unknown denied','Goal_Graph_counts':'Original3 and6 counts, independent before/after sequence checks retained','Owner_counts':'Original19+Factory12=31; originalGrant/otherproposal/document/result/CAS/receipt and exactOS page predicates unchanged except current schema guard','tool_prepare':'Private0700/short103byte socket/0500singlelink/fullsameheadtwohashes/probe5s/SIGTERMwait5s/forcedkill or nonzero reject; generated inert controls only executed','actual_Core_NOT_RUN':selection['not_run_actual_Core'],'Native_Rust30_tests':'Source only; not compiled or run','newexecutionScope_OS':'NOT_RUN: existingGrant/planning false permissions unchanged, no execution approval claimed'}
(OUT/'NEGATIVE_PRESERVATION_MATRIX.json').write_text(json.dumps(matrix,indent=2)+'\n')
(OUT/'TEST_AST_PRESERVATION.json').write_text(json.dumps(preservation,indent=2)+'\n')
result={'base':BASE,'checks':checks,'count':len(checks),'authority_inputs':inputs,'source':{p:sha((ROOT/p).read_bytes()) for p in allowed},'dimension':'STATIC_ONLY_NO_RUST_CORE_MAC'}
(OUT/'STATIC_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'static_checks':len(checks),'all_pass':True,'product_execution':False}))
