"""Run only pure/generated-file/owned-inert-child tests; no Core or GUI."""
from pathlib import Path
import ast,importlib.util,json,sys,unittest
ROOT=Path('/workspace/.worktrees/factory-child-goal-native-harness')
OUT=Path(__file__).resolve().parent
paths=['apps/desktop/src-tauri/tests/test_native_runner.py',
       'apps/desktop/src-tauri/tests/test_native_owner_dialog.py',
       'tests/infrastructure/test_factory_test_tools.py']
suite=unittest.TestSuite();selected=[];not_run=[]
for index,path in enumerate(paths):
 tree=ast.parse((ROOT/path).read_text());forbidden=set()
 for cls in [x for x in tree.body if isinstance(x,ast.ClassDef)]:
  methods={f.name:f for f in cls.body if isinstance(f,ast.FunctionDef)}
  daemon_helpers={name for name,f in methods.items() if any(isinstance(n,ast.Constant) and n.value=='AGENTBATON_OWNER_FIXTURE_DAEMON' for n in ast.walk(f))}
  for name,f in methods.items():
   if not name.startswith('test_'):continue
   direct=name in daemon_helpers
   indirect=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='self' and n.func.attr in daemon_helpers for n in ast.walk(f))
   if direct or indirect:forbidden.add(cls.name+'.'+name)
 spec=importlib.util.spec_from_file_location('native_harness_pure_'+str(index),ROOT/path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 for name in unittest.defaultTestLoader.getTestCaseNames if False else []:pass
 for clsname in sorted(x.name for x in tree.body if isinstance(x,ast.ClassDef)):
  cls=getattr(module,clsname)
  if not isinstance(cls,type) or not issubclass(cls,unittest.TestCase):continue
  for testname in unittest.defaultTestLoader.getTestCaseNames(cls):
   ident=clsname+'.'+testname
   if ident in forbidden:not_run.append({'path':path,'test':ident,'reason':'Actual Core/daemon requires separate Root lease; unchanged/preserved in source.'})
   else:suite.addTest(cls(testname));selected.append({'path':path,'test':ident})
assert len(not_run)==5,not_run
assert len(selected)==94,len(selected)
(OUT/'TEST_SELECTION.json').write_text(json.dumps({'selected_pure_or_inert_child_tests':selected,'not_run_actual_Core':not_run,'scope':'No skip decorators added. Actual Core tests not scheduled in this restricted run; full suite requires Root lease.'},indent=2)+'\n')
result=unittest.TextTestRunner(verbosity=2).run(suite)
(OUT/'PURE_RESULT.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'selected':len(selected),'not_run_actual_Core':len(not_run),'success':result.wasSuccessful(),'dimension':'Pure Python/generated SQLite/inert owned child controls, NOT Core/GUI/Provider'},indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
