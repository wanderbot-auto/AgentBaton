from pathlib import Path
import re,ast,json,sqlite3,subprocess,tempfile,hashlib
R=Path('/workspace/.worktrees/factory-child-planning-native');O=Path(__file__).parent;src=(R/'apps/desktop/src-tauri/src/bin/native_smoke.rs').read_text();old=(O/'before-native-smoke.rs').read_text();checks=[];queries=[]
def check(n,v):
 assert v,n
 checks.append(n)
def rawsql(s,name):return re.search(r'const '+name+r': &str = r#"(.*?)"#;',s,re.S).group(1)
def function(s,name):return re.search(r'^fn '+name+r'\(.*?^}',s,re.S|re.M).group(0)
def array(s,name):return re.findall(r'"([a-z_]+)"',re.search(r'const '+name+r': \[&str; \d+\] = \[(.*?)\];',s,re.S).group(1))
fields=array(src,'FACTORY_COUNT_FIELDS');oldfields=array(old,'FACTORY_COUNT_FIELDS');graphfields=array(src,'GOAL_GRAPH_COUNT_FIELDS');codes={n:rawsql(src,n) for n in ['FACTORY_READONLY_SQL','GOAL_EXECUTION_READONLY_SQL','GOAL_GRAPH_READONLY_SQL']};oldcode=rawsql(old,'FACTORY_READONLY_SQL')
tree=ast.parse(codes['FACTORY_READONLY_SQL']);assign={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['tables','fields']};tables=assign['tables'];check('SQL names and11Native fields agree',list(assign['fields'])==fields and len(fields)==len(tables)==11);check('original9fields preserved in order',fields[:9]==oldfields);check('new exact2 names',[*fields[9:]]==['child_plan_heads','child_plan_revisions'] and list(tables[9:])==['factory_child_plan_heads','factory_child_plan_revisions'])
dto=(O/'factory-DTO-v2.rs').read_text();part=dto.split('pub struct FactoryRecordCounts {',1)[1].split('\n}',1)[0];check('formal Core v2 countfields match',sorted(re.findall(r'pub (\w+): u64',part))==sorted(fields))
for name in ['valid_goal_execution_counts','valid_goal_graph_counts','valid_factory_counts']:
 body=function(src,name);check('exact schema14 Rust source '+name,'Some(14)' in body and 'Some(13)' not in body and '>= ' not in body)
 reverted=body.replace('Some(14)','Some(13)')
 if name=='valid_factory_counts':reverted=reverted.replace('record.len() == 13','record.len() == 11')
 check('all original scalar/zero shape guards retained '+name,reverted==function(old,name))
for name,code in codes.items():check('readonly mode/query_only/snapshot retained '+name,all(v in code for v in ['?mode=ro','PRAGMA query_only=ON',"db.execute('BEGIN')"]));check('fixed SQL syntax '+name,bool(compile(code,name,'exec')))
check('old Goal execution SQL bytes unchanged',codes['GOAL_EXECUTION_READONLY_SQL']==rawsql(old,'GOAL_EXECUTION_READONLY_SQL'));check('old Graph SQL bytes unchanged',codes['GOAL_GRAPH_READONLY_SQL']==rawsql(old,'GOAL_GRAPH_READONLY_SQL'))
for test in ['execution_readonly_schema_and_each_actual_table_drift_fail_closed','graph_readonly_wrong_schema_and_each_real_table_drift_fail_closed']:
 body=function(src,test);check('old13 and future15 added '+test,'PRAGMA user_version=13' in body and 'PRAGMA user_version=15' in body and 'PRAGMA user_version=12' in body)
check('new table drop negatives authored',all('DROP TABLE '+t in src for t in tables[9:]));check('new table row drift negatives authored',all('INSERT INTO '+t+' VALUES' in src for t in tables[9:]))
# Projection documents the exact Rust-source predicate; it is not compiled Rust behavior.
def projection(v,kind='factory'):
 fs=fields if kind=='factory' else graphfields if kind=='graph' else ['run_count','node_count','reservation_count']
 return isinstance(v,dict) and set(v)==set(['schema_version','sequence',*fs]) and type(v.get('schema_version')) is int and v['schema_version']==14 and type(v.get('sequence')) is int and 0<=v['sequence']<=2**64-1 and all(type(v.get(k)) is int and v[k]==0 for k in fs)
def query(db,code,tag):
 before=hashlib.sha256(db.read_bytes()).hexdigest();p=subprocess.run(['python3','-I','-S','-c',code,str(db)],capture_output=True);after=hashlib.sha256(db.read_bytes()).hexdigest();check('actual readonly file unchanged '+tag,before==after);queries.append({'tag':tag,'argv':['python3','-I','-S','-c','<embeddedSQL>','<generatedDB>'],'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'DB_sha256_before_after':before});return p
oldtables=tables[:9];goal_tables=['goal_runs','goal_run_nodes','goal_run_reservations','goal_graph_capabilities','goal_graph_jobs','goal_graph_candidates','goal_graph_validations','goal_graph_owner_decisions','goal_graph_acceptances']
def create(path,version=14,plans=True):
 c=sqlite3.connect(path);c.execute('CREATE TABLE events(sequence INTEGER PRIMARY KEY)');c.execute('CREATE TABLE tasks(id TEXT PRIMARY KEY)')
 for name in [*oldtables,*goal_tables]:c.execute('CREATE TABLE '+name+'(id TEXT PRIMARY KEY)')
 if plans:c.executescript((O/'schema14-plan-tables.sql').read_text())
 c.execute('PRAGMA user_version='+str(version));c.commit();c.close()
with tempfile.TemporaryDirectory(prefix='native14-sql-') as tmp:
 root=Path(tmp)
 for version in [12,13,14,15]:
  db=root/('v'+str(version)+'.sqlite3');create(db,version)
  for name,code in codes.items():
   p=query(db,code,str(version)+'/'+name);check('actual query complete '+str(version)+'/'+name,p.returncode==0);v=json.loads(p.stdout);kind='factory' if name=='FACTORY_READONLY_SQL' else 'graph' if name=='GOAL_GRAPH_READONLY_SQL' else 'execution';check('source-derived strict version projection '+str(version)+'/'+kind,projection(v,kind) is (version==14))
 db=root/'baseline.sqlite3';create(db);base=json.loads(query(db,codes['FACTORY_READONLY_SQL'],'baseline').stdout)
 for k in fields:
  for value in [None,True,False,0.0,'0',-1,1]:
   v=dict(base);v[k]=value;check('source-derived typedzero '+k+' '+repr(value),not projection(v))
  v=dict(base);del v[k];check('source-derived missing field '+k,not projection(v))
 for value in [13,15,14.0,True,'14',None]:
  v=dict(base);v['schema_version']=value;check('source-derived schema scalar '+repr(value),not projection(v))
 v=dict(base);v['unexpected']=0;check('source-derived extra field refusal',not projection(v))
 for table,field in zip(tables[9:],fields[9:]):
  db=root/(field+'.sqlite3');create(db);c=sqlite3.connect(db);check('negative fixture defaultFKoff '+field,c.execute('PRAGMA foreign_keys').fetchone()[0]==0);sql=re.search(r'\("'+field+r'","([^"]+)"\)',src).group(1);c.execute(sql);c.commit();c.close();new=query(db,codes['FACTORY_READONLY_SQL'],'drift/'+field);v=json.loads(new.stdout);check('actual SQL observes nonzero '+field,new.returncode==0 and v[field]==1 and not projection(v));previous=query(db,oldcode,'oldquery-ignores/'+field);oldv=json.loads(previous.stdout);check('old9SQL demonstrably omits '+field,field not in oldv and all(oldv[k]==0 for k in oldfields))
 for table in tables:
  db=root/('missing-'+table+'.sqlite3');create(db);c=sqlite3.connect(db);c.execute('DROP TABLE '+table);c.commit();c.close();p=query(db,codes['FACTORY_READONLY_SQL'],'missing/'+table);check('actual missingtable query fails '+table,p.returncode!=0 and 'no such table' in p.stderr.decode())
 db=root/'real-shape-old13-no-plan-tables.sqlite3';create(db,13,False);p=query(db,codes['FACTORY_READONLY_SQL'],'old13-missing-plan-tables');check('actual old13 missingplan tables not fakedzero',p.returncode!=0)
(O/'sql-queries.json').write_text(json.dumps(queries,indent=2)+'\n');(O/'pure-results.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'embedded_SQL_subprocess_runs':len(queries),'source_derived_Rust_predicate_only':True,'actual_Rust_or_Core_tests':False,'SQLite_version':sqlite3.sqlite_version,'scope':'actual embedded readonlySQL on generated SQLite; source-derived guard projections explicitly not Rust execution','not_run':['Cargo/Nativecompiled tests','actual Core14 migration/counters','GUI/Mac/CI']},indent=2)+'\n');print(json.dumps({'passed_controls':len(checks),'actual_embeddedSQL_queries':len(queries),'source_derived_guard_not_Rust':True},indent=2))
