from pathlib import Path
R=Path('/workspace/.worktrees/factory-child-planning-native');O=Path(__file__).parent;p=R/'apps/desktop/src-tauri/src/bin/native_smoke.rs';old=p.read_bytes();assert old==(O/'before-native-smoke.rs').read_bytes()
s=old.decode().replace('Some(13)','Some(14)').replace('schema13','schema14').replace('"schema_version":13','"schema_version":14')
s=s.replace('const FACTORY_COUNT_FIELDS: [&str; 9]', 'const FACTORY_COUNT_FIELDS: [&str; 11]')
needle='''    "budget_reservations",
];
const FACTORY_READONLY_SQL''';assert needle in s;s=s.replace(needle,'''    "budget_reservations",
    "child_plan_heads",
    "child_plan_revisions",
];
const FACTORY_READONLY_SQL''',1)
s=s.replace("'factory_handoffs','factory_budget_reservations')","'factory_handoffs','factory_budget_reservations','factory_child_plan_heads','factory_child_plan_revisions')",1).replace("'handoffs','budget_reservations')","'handoffs','budget_reservations','child_plan_heads','child_plan_revisions')",1)
start=s.index('fn valid_factory_counts');end=s.index('fn factory_database_snapshot',start);part=s[start:end];assert 'record.len() == 11' in part;s=s[:start]+part.replace('record.len() == 11','record.len() == 13')+s[end:]
s=s.replace('nine independently empty tables','eleven independently empty tables').replace('all_nine_typed_counts','all_eleven_typed_counts')
s=s.replace('("schema_version","PRAGMA user_version=14",14),','("schema_version","PRAGMA user_version=13",13),\n            ("schema_version","PRAGMA user_version=15",15),')
s=s.replace('("schema_version", "PRAGMA user_version=14", 14),','("schema_version", "PRAGMA user_version=13", 13),\n            ("schema_version", "PRAGMA user_version=15", 15),')
s=s.replace('for schema in [11, 12, 14]','for schema in [11, 12, 13, 15]').replace('assert_eq!(before["schema_version"], 13);','assert_eq!(before["schema_version"], 14);').replace('assert_eq!(projection.as_object().unwrap().len(), 9);','assert_eq!(projection.as_object().unwrap().len(), 11);')
needle='''            ("budget_reservations",r#"INSERT INTO factory_budget_reservations VALUES('attempt','scope','root','project','{"authority_kind":"factory_task"}')"#),
''';assert needle in s;s=s.replace(needle,needle+'''            ("child_plan_heads","INSERT INTO factory_child_plan_heads VALUES('scope','run','task',1,'revision')"),
            ("child_plan_revisions","INSERT INTO factory_child_plan_revisions VALUES('revision','scope','run','task',1,'{}','raw','plan',1,'record','{}')"),
''',1)
needle='''            "PRAGMA user_version=12",
            "PRAGMA user_version=14",
            "DROP TABLE factory_scopes",
            "DROP TABLE factory_budget_reservations",
''';assert needle in s;s=s.replace(needle,'''            "PRAGMA user_version=12",
            "PRAGMA user_version=13",
            "PRAGMA user_version=15",
            "DROP TABLE factory_scopes",
            "DROP TABLE factory_budget_reservations",
            "DROP TABLE factory_child_plan_heads",
            "DROP TABLE factory_child_plan_revisions",
''',1)
p.write_text(s)
