from pathlib import Path
import re,json,hashlib,subprocess
R=Path('/workspace/.worktrees/factory-child-planning-native');O=Path(__file__).parent;BASE='6d666ed3a52ad14889440b84a903c58e050fa24c';rows=[]
def check(name,condition):
 assert condition,name
 rows.append(name)
def function(text,name):
 start=re.search(r'^(?:pub )?(?:async )?fn '+re.escape(name)+r'\(',text,re.M).start()
 end=re.search(r'^}\s*$',text[start:],re.M).end()+start
 return text[start:end]
def fields(text):
 a=re.search(r'exact_fields\(\s*\w+,\s*&\[(.*?)\]',text,re.S)
 return re.findall(r'"([a-z_]+)"',a.group(1))
def struct_fields(src,name):
 body=src.split('pub struct '+name+' {',1)[1].split('\n}',1)[0]
 return re.findall(r'^\s*pub (\w+):',body,re.M)
a=(R/'apps/desktop/src-tauri/src/approval.rs').read_text();b=(R/'apps/desktop/src-tauri/src/lib.rs').read_text();old_a=(O/'base-approval.rs').read_text();old_b=(O/'base-lib.rs').read_text();dto=(O/'factory-dto-v1.rs').read_text()
check('policy Native fields equal frozen DTO',fields(function(a,'factory_planning_policy'))==struct_fields(dto,'FactoryChildPlanningPolicy'))
check('resolved binding Native fields equal frozen DTO',fields(function(a,'factory_planning_binding'))==struct_fields(dto,'FactoryChildPlanningBinding'))
check('frozen DTO actual SHA811',hashlib.sha256((O/'factory-dto-v1.rs').read_bytes()).hexdigest()=='811db32b84fbd6ec5ef86367c587014bac354a041885afa962029e9ba81edd86')
check('listRefs comment-only update exact',dto.replace('list returns all bounded revisions.','list returns all bounded revision refs.')==(O/'factory-dto-v1-listrefs.rs').read_text())
for name in ['factory_ids','factory_safe','factory_budget','factory_artifacts','factory_contract_matches','graph_review_pages','graph_server_error']:
 check('old review/pin helper unchanged '+name,function(a,name)==function(old_a,name))
for name in ['factory_scope_proposal_frame','factory_scope_frame','factory_scope_approve','factory_runs_start','factory_runs_get','factory_runs_cancel']:
 check('old Factory bridge unchanged '+name,function(b,name)==function(old_b,name))
old_confirm=function(old_a,'confirm_factory_and_finalize');confirm=function(a,'confirm_factory_and_finalize');loop='    for (index, page) in pages.iter().enumerate() {'
check('old complete-page cancel/final/CAS/receipt tail byte-identical',old_confirm.split(loop,1)[1]==confirm.split(loop,1)[1])
action=re.search(r'let action\s*=\s*"(Review INDEPENDENT.*?不恢复原生上下文。)";',old_confirm,re.S).group(1)
check('false capability old bilingual action literal unchanged',action in confirm)
check('new true action explicitly planning only/nonexecution',all(x in confirm for x in ['PLAN STORAGE ONLY','does NOT start a run or execute a plan/validator','不授予子Goal执行、工作区创建、任务验收']))
check('true capability requires policy and binding',all(x in a for x in ['"child_planning_policy",\n        planning','factory_planning_policy(&value["child_planning_policy"], value)','factory_planning_binding(&b["child_planning"], selection, b)']))
for expr in ['value["capabilities"]["child_goal_execution"] == false','value["capabilities"]["create_workspace"] == false','binding["goal_execution_authorized"] != false','binding["new_workspace_authorized"] != false']:
 check('execution/workspace authority remains false '+expr,expr in a)
check('no digest verification claim/dependency added','Core independently' not in function(a,'factory_planning_binding') and 'Native independently checks shape' in function(a,'factory_planning_binding'))
new_methods=['factory_child_plans_'+n for n in ['context','get','list','submit']]
for name in new_methods:
 check('fixed Tauri command registered exactly once '+name,len(re.findall(r'^        '+name+r',$',b,re.M))==1 and ('async fn '+name+'(') in b)
 command=function(b,name);check('no per-plan Native finalize/approval '+name,'confirm_' not in command and 'approvals.finalize' not in command and 'false' in command)
for name in ['context','get','list']:
 check('fixed daemon query method '+name,'"factory_child_plans.'+name+'"' in function(b,'factory_child_plans_'+name))
submit=function(b,'factory_child_plan_submit_frame')
check('submit exact narrow params plus scopeCAS/key',re.findall(r'"(\w+)":',submit)==['method','params','scope_id','task_id','plan_json','expected_plan_revision','expected_revision','idempotency_key'])
check('raw plan text not parsed/normalized','serde_json::from_str' not in submit and '"plan_json":plan_json' in submit)
check('list only references, no aggregate body','Core returns bounded ascending references' in function(b,'factory_child_plans_list') and 'Vec' not in function(b,'factory_child_plans_list'))
for new,old,label in [(a,old_a,'approval'),(b,old_b,'bridge')]:
 oldtests=re.findall(r'#\[test\]\s*fn\s+(\w+)',old);newtests=re.findall(r'#\[test\]\s*fn\s+(\w+)',new);check('all old Rust tests retained '+label,[n for n in newtests if n in oldtests]==oldtests)
check('six new planning and two bridge tests authored',len(re.findall(r'#\[test\]\s*fn\s+planning_',a))==6 and len(re.findall(r'#\[test\]\s*fn\s+factory_child_plan_',b))==2)
fixture='apps/desktop/src-tauri/tests/fixtures/factory-wire-bundle-0c6fbd065df4a49997acca4fc898a3f952721bfbc60b57229ca36571db0c0c64.json';raw=(R/fixture).read_bytes();check('actual old false Factory fixture byte-preserved',raw==subprocess.check_output(['git','show',BASE+':'+fixture],cwd=R));wire=json.loads(raw);check('old fixture omits both new Option fields','child_planning_policy' not in wire['selection'] and 'child_planning' not in wire['scope']['bindings'])
changed=subprocess.check_output(['git','diff','--name-only',BASE,'8d82dc789347fcc3bdbc0187cea53007324bf07a'],cwd=R,text=True).splitlines();check('only two allowed production files changed',changed==['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs'] and all((R/p).read_bytes()==subprocess.check_output(['git','show','8d82dc789347fcc3bdbc0187cea53007324bf07a:'+p],cwd=R) for p in changed))
result={'passed':len(rows),'checks':rows,'scope':'pure static/shape/mechanical checks; standalone Rustfmt parses Rust, no Native behavior execution','new_Rust_tests_authored':8,'new_Rust_tests_run':False,'not_run':['Cargo/Native unit tests and clippy','Core runtime/real IPC','browser/macOS/CI'],'source_hashes':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in changed}};(O/'pure-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':len(rows),'scope':result['scope']},indent=2))
