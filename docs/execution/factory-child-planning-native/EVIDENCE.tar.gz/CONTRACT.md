# Factory 下一能力：独立只读契约审阅

**建议先实现单元1：真实、持久、有界的 child_planning；单元2为其后的 child_goal_execution 纵切。** 两者都属于既定完整产品，不是重新申请研发授权，也不是把总目标改成规划器/MVP。单元1应立即进入真实 Core+scoped MCP+Native批准+UI历史+正常/失败验证的编码闭环；完成后继续单元2及其余需求。本报告没有修改产品，也没有运行产品测试。

## 固定基线与已批准语义

审阅冻结在 Factory `27224864479fb574d1f6abaca5d16189df5ec172`。生产46源仍等价于 db949；Core `cabf5a3cd9eca2ce2ea4c5a6b0d78c46f1c5ed53` 是历史schema测试helper/测试变更，不是新的 Factory 产品权限。AGENTS/gate/GOAL、批准记录、MASTER_PROMPT/RUNBOOK/OWNER_INBOX及27题追踪均已读取；机器可读decisions的21条决策恰好覆盖题1–27，D07仍deferred_optional。Specs的specified不是执行禁令，也不是实现完成证明。

准确依据（所有行号指固定272基线）：

- `docs/01-prd.md` §2，行18–24：Git/非Git工作区、一等数据目录、写任务默认隔离；§Tasks，行52–54：目标/权限/预算/验收批准后自主拆解，三入口共用Router。
- `docs/06-orchestration.md` §2行9–13、§3行15–21：规划组件复用批准连接，无隐含额外模型；完整版本化TaskRequest、输入/输出/身份/预算绑定。§6行35–41：复用同一工作流模型，不造第二DSL；DAG、write set、固定模板。§7行43–51：scoped caller、父子关系、handle/status/result、释放等待槽、真实新attempt恢复。§8–10行53–80：取消/unknown/失败/硬预算与诚实enforcement。§12行88–99：批准范围内自动推进，子任务不重置根/项目预算、不能自降验收。
- `docs/08-security.md` §4行21–25：权限不超根、范围内不反复询问、session/root/project/method/TTL scoped credential；§5：原生等价预授权；§8：产物和工具描述不是新权限。
- `docs/14-api-contracts.md` §4行54–60：MCP包装同一Task API，只开必要窄工具；workspace/provider/network均为请求，不是授权。
- `docs/11-engineering-program.md` §2行17–25：WP05/08/09/11/12依赖；§3行30–34：纵切需跨契约、实现、界面和验证，不只脚手架。
- 决定：D03/题1（范围内目标自动化），D12/题9（同模型版本计划及可调整），D11/题10（项目预算与任务覆盖），D15/题14（范围内最小数据交接），D18/题3（隔离写），D19/题4、21（批准规则验收/开发交付、生产另批），D01/D10/题18、19、25（单入口、中英/分层），D20/题12（固定具名连接），D21/题5（项目/Agent内容不是授权）。D06/题15的真实Provider目标保留，当前生成ACP测试不能冒充三家真实接入。

## 当前实际实现与阻断点

| 固定源位置 | 已有事实及下一步必须保留的边界 |
|---|---|
| `crates/core/src/factory.rs:13–39` | FactoryCapabilities确有5个字段；delegate_task/resume以外3项不是已实现能力。Scope绑定真实Grant/工作区/输入/companion，TaskHandle/Result已有父子、attempt、artifact和validation refs。 |
| `factory_store.rs:128–192` | 两个已实现能力必须true；child_planning/child_goal_execution/create_workspace任一true即CAPABILITY_UNSUPPORTED（155–159）。现有选择仅1个已批准工作区，根/项目预算、连接、recipient均取子集；不允许未知token/cost硬保证。 |
| `factory_store.rs:295–330,375–405,479–502,641–735` | 子任务不能冒新根；原Factory未知/活跃不能靠撤销重置；local customACP和既有Grant真实核验。独立Factory Native proposal是完整selection/bindings/digest；批准不启动。已有活跃scope不能原地替换；finalize重新核输入/CAS。 |
| `factory_companion.rs:165–175,225–241`；`ipc.rs:2058–2113` | 当前恰好4个固定scoped工具：delegate_task/get_task_status/get_task_result/cancel_task。没有Goal计划/执行或工作区创建通道；没有global daemon token/Owner finalize/generic shell。 |
| `factory_runtime.rs:574–630,633–837` | caller从私有handle/token/session/attempt/fencing/lease派生；委派目标/输入/输出/预算收窄；同key幂等、深度/祖先/总量限制；子任务记录使用同原root Grant，事件明确new_grant=false。 |
| `factory_runtime.rs:1009–1125`；`factory_budget.rs:1–96` | 已有Factory与legacy/Goal共享计费origin，保留root/project累计；排队时间、祖先预算、unknown耗用不能重置。nullable legacy reservation不等于Factory权限。 |
| `apps/desktop/src/factory-form.ts:25–29`；`factory-guards.ts:22`；`FactoryRuntime.tsx:118–124` | UI明确把三能力设false，只允许现有工作区；折叠显示已批准selection/预算/历史；pending exactkey/floors及unknown停止新动作不能因新增能力放松。 |
| `apps/desktop/src-tauri/src/approval.rs:1418–1498,1767–1808` | Native严格核false capability及全量Factory快照；action文字明确“No child planning/Goal execution/workspace creation”。不能只改JS复选框绕过。 |
| `goal_store.rs:645–715,814–817,1033–1042,1093–1107,1925–2007` | 既有Goal批准只解析一个root Grant，重建Native Goal批准，且会更新Grant max_children/max_depth；计划存储依赖真实scope、CAS和原始plan_json。这条Owner路径不能转发给scoped Agent当作Factory子权限。 |
| `goal_plan.rs:14–15,370–416,635` | 现成同一GoalPlanProposal/验证/修订模型可复用，但ApprovedGoalScope构造仍依赖原Grant的children/depth并绑定Native Goal approval。合法Factory根Grant可children=0；不得临时篡改它、伪造Goal approval或把root_task_id改成child来让验证通过。 |

### 一次明确产品批准与研发授权的区别

当前研发继续由AB-START-001授权，**不向本次负责人重复请求确认**。下述Native批准是产品用户操作的必要实现及测试场景：旧FactoryScope已经明确拒授三能力，不能追溯升级为true。新版本必须通过固定Native Factory路线明确批准新增能力及完整窄政策；旧scope/旧receipt仍按旧合同解释。旧scope有活跃/unknown时保持阻塞，撤销不是停止或对账。批准后已覆盖范围内的每个子计划不再逐个弹授权。

## 单元1：Factory内子任务版本计划，端到端可见且无执行权限

**需求映射**：主要 AB-TSK-009（目标驱动）、AB-TSK-011（版本计划）；必须同时满足 AB-TSK-003/004/005/012、AB-SEC-002/003/005/010、AB-COR-002/007。依赖并复用已实现的AB-TSK-002/006/007/008骨架，不声称真实Codex/Qoder双向验收已完成。决定对应D03/题1、D12/题9、D11/题10、D15/题14、D10/题18/19、D20/题12。

**最小真实行为**：受管父/子Agent在既有批准连接和工作区内，为本Factory自身或授权后代child提交完整原始计划文本；Core验证并持久化不可变revision、digest及scope/task/lineage来源，UI能实际读取、比较/调整修订及查看历史，父任务交接只回传计划引用。计划不是调度/验收，不因存储成功产生Graph run、额外session/attempt、validator执行、TaskAccepted或workspace。已有普通fixed handoff授权不因新增计划被放大；child_goal_execution/create_workspace继续明确false。不是把任意Agent JSON当可信合同。

**工程接口建议（新接口，不声称现成API）**：增加一个固定scoped `submit_child_plan`，目标task_id、原始plan_json、expected_plan_revision、非空idempotency_key；调用者/Factory根/项目/Grant/权限不能由参数传入。目标仅自身或经过现有ancestry验证的同Factory后代，且不得处于cancel/unknown/已验收终态。读计划revision/ref可扩展现有get_task_status/get_task_result；UI使用固定只读get/list及原同一受限修订方法。不要把Agent接到通用`goal_*`/Owner/SQL/dispatch入口。原4工具保持所有旧输入/输出语义；新增固定工具需同步MCP schema及Core同一鉴权，不能只有descriptor没有handler。

**输入政策的缺口必须真正补上**：现有FactorySelection只有artifact/预算，没有子Goal验收规则/validator归属/版本计划政策；不能从被规划Agent提案中发明这些权限。child_planning=true时，新的完整Native Factory快照必须同时包含服务端解析、批准的子计划上限/输出合同/必要验收标准与可引用规则/固定输入版本/已有工作区与允许write set；这些必须是既有授权子集，必要policy模板由Core解析。false旧scope无需升级；不得默认全允许。DTO字段最终由唯一Core契约作者定名，写ADR映射现成Goal模型，而不是发明另一个workflow DSL。计划-only provenance须显式为Factory派生的窄authority，和Native Goal执行scope分开；可提取既有纯语义验证复用，但不能降低所有Goal constructor的root/Owner验证。计划原文上限不高于262144 bytes，节点/引用/修订不高于现成Goal256上限，同时受Factory较窄上限限制；整个IPC/事件/历史读写原有大小限制保留，不截字段求绿。

**权限与预算**：原ExecutionGrant ID/revision/工作区/连接/recipients/网络不变，新增的是一次明确批准的Factory规划政策，不是另造更宽Grant。规划若复用已有Agent turn，该turn仍记原Factory attempt；如确需新的planner attempt，只能走同一现有scheduler/reservation且消耗同project/root/祖先总量，不能开额外付费planner。单次metadata保存/只读preview不冒执行预算预留；计划节点也不是已创建Task，不能把每次修订当新预算。原文/修订/存储/CPU有界，取消/到期/撤销后拒绝新计划。合法exactkey历史读取不恢复过期scoped credential或降低UI floors；unknown先查询原回执，禁止换key重复副作用。

**源码所有权**：Core单一作者拥有factory.rs/store/runtime/reads、必要新child-plan存储模块及goal_plan纯验证复用、ipc固定入口与对应Core tests；同一作者串行拥有必要schema/迁移决定，Root单独安排（本报告不写schema）。Companion/CLI与该固定契约同步，不能第二作者同时改factory_companion.rs/ipc.rs。UI作者只拥有factory-types/form/guards/api、FactoryRuntime及新子计划历史/编辑组件/i18n/tests；Native作者拥有approval.rs/lib.rs必要固定桥与其测试。跨两单元相同Core/Native文件不得并写；Root冻结公共DTO后再并行互不重叠视图/测试。

**实际验收测试**：

1. 从真实私有Native Factory proposal/finalize批准child_planning=true，Cancel任意完整页/最终页均0 finalize；wrongkind/布尔替换/外来task/Grant/input/policy/receipt返回拒绝或unknown。旧false/旧快照原样拒新入口，不修改旧证据。
2. 真实Core+私有scoped companion/生成ACP提交rev1、rev2；SQLite中完整原文/revision/digest、samekey同回执和不同payload冲突；UI通过真实IPC显示原图/可修改同模型及旧history；掉真实响应后exactkey恢复、不降floor。至少包含合法原Grant children=0的独立Factory批准，不改Grant行来求绿。
3. expired/revoked/crosssession/forgedancestor/cancelled/unknown句柄、跨project/workspace/recipient、输入漂移、伪validator、改验收、更大预算、cycle、重名node/write-set冲突、oversize/duplicate键/unsafe数值全部有拒绝控；拒绝不留下半个plan/event。计划写入不产生Graph/session/validator/TaskAccepted；纯preview序列/预算不变。
4. 改计划不重置父子budget/history；规划模型turn真实记原预算，项目/根/祖先硬上限阻止新派发。并行1父等待仍可完成子任务；取消/崩溃/读失败留下原失败与可恢复检查点，不改unknown为cancelled。Linux/Mock/Native callback/macOS实际分别记录，随后精确提交CI。

**为什么先做**：基础delegate/身份/固定工作区/数据绑定/版本计划模型已存在；无需新workspace权限、真实模型账号或新的Graph worker。最关键的缺口是正确的派生规划来源及完整政策，而不是新的底层规划平台。该纵切完成真实持久计划闭环，然后继续执行，不以此宣布整个Factory/GOAL完成。

## 单元2：已存子计划在原Factory链内真实Goal执行与交接

**明确依赖单元1，不可同时先翻flag。** 主要 AB-TSK-002/003/005/006/007/008/009/010/011/012；AB-COR-002/003/006/007、AB-SEC-001/003/006/010，相关产物验证需求保持原编号。D03/题1、D11/题10、D12/题9、D15/题14、D18/题3、D19/题4/21及D20/题12。所有REQ仍需逐维证据，不以一次本地生成ACP当正式Provider验收。

**I/O与真实闭环**：输入为单元1的不可变plan revision/digest/ref和它的Factory scope、child、Task spec/input、完整验收/validator政策、当前ledger/CAS；新一次固定Native Factory能力批准明确child_goal_execution=true。后续scope内执行由同一scheduler自动选择ready节点，运行真实已批准Work/validator/Owner规则、生成artifact/receipt；输出为子任务状态、candidate/validation/acceptance refs及固定handoff digest，父任务在owned stop后以真实新attempt接续（当前不宣称native上下文恢复）。端到端实际两层计划→子Graph→按批准标准验收/失败→父收到引用；不让父Agent一句“完成”生成接受事件。

**权限与前置缺口**：仍使用同一个原rootExecutionGrant及其更窄连接/recipient/工作区，不能从child另批一个“新root”清空预算。原false执行scope不可原地升级；新的Native Factory批准需包含完整执行/验收/validator/节点/writeset合同，才可由Core派生实际执行origin。若现成验收规则需要人类Owner决定，仍必须真实按该规则批准；“不重复范围审批”不等于自动点击必需验收。Graph TaskAccepted只能绑定child的Spec/Plan/Scope/receipt，不能意外接受Factory父/根任务。

**先补唯一的跨scheduler准入，不准直连旧Goal根API**：真实Factory root_task_id/祖先和原root_grant_id必须随child Graph每个attempt/validator预算原子保留；Factory/Goal/legacy dispatch共享项目/rootGrant/祖先并发、次数、runtime、输出及unknown/fenced lease。当前Goal路径按单root scope解析，会修改Grant ceilings且历史GoalBinding root=该task，必须新增真实Factory-child origin分支并保留旧root严格检查，不能靠改label/SQL补owner/临时增Grant通过。准备I/O的watch/witness/async期限、事务后执行与Outbox对账继续复用；取消等待槽/worker owned join/revoke/deadline、daemon恢复都跨两链一致。root/project/ancestor任一unknown或耗尽即阻止新节点，plan修订/多child不得重置。必需validator权限/定义不是从Agent rawplan获得，已有Command one-shot已用则拒绝。

**路径所有权**：沿用单元1Core作者，并串行整合goal_runtime.rs/goal_graph.rs/goal_graph_validators.rs/goal_validator_io.rs、factory_budget.rs与execution/sessions必要共享准入；Native/UI作者只在冻结DTO后接线Graph child来源与handoff/history，不各自实现第二套budget规则；迁移、锁文件、公共IPC、共享STATUS仍Root单一所有者。

**正常/失败测试**：真实生成ACP多层parent/child运行与本地deterministic validator、完整TaskRequest与artifact字节；parent wait释放槽（parallel1），child成功/验证失败/Owner拒绝/取消/timeout/unknown分别回传，父不得伪成功；Root/项目/每一祖先budget含bootstrap/旧Goal/普通session，多child与rev2不重置，竞态时只一次预留；停止前不得释放lease；crash/outbox/丢响应先对账、exactkey不双dispatch；scope/input/candidate/validator drift、TaskAccepted跨层引用与同key旧receipt/新floor全有负控；UI真实IPC和双Mac分别验证。child_planning-only、false执行、falseworkspace旧合同全部继续拒绝。

## create_workspace 为什么不在这两个单元里先开启

D18/AB-PRJ-005是完整产品义务，不能删除或用advisory提示替代。现有`registry.rs:462`已有真实create_workspace，但它不是scoped Factory授权；Factory选一个既有Grant.workspace_ids，start_contract.new_workspace_authority=false，Grant.scope.narrower会拒新增workspace。直接把生成路径塞入原Grant或将false置true会扩大Native已经拒授的范围。

因此：单元1只规划，单元2仅允许**已经批准且满足实际隔离/互斥条件的工作区**；原地编码写、冲突并行write set或没有隔离路径必须阻塞，不能借这两个单元冒完成默认独立工作区需求。后续create_workspace需单独实现预先批准的源身份/目标受管根/创建类型与配额、计划/实际创建/失败残留/恢复、Grant派生范围与真实审批来源闭环，再接自动编码隔离；不需要负责人重新选择D18，但产品上当前未授权创建的旧scope不能自动获得该能力。这里仅保留它的明确依赖/禁区，不扩成第三个实施单元。

## 本次检查边界

只读检查固定Git对象/规格/现有stubs、核对27题覆盖与Core helperonly文件范围；没有Cargo/browser/daemon/测试/远程/真实Provider/账号/收费/源码/迁移/锁/STATUS写入，也没有子代理。未宣称新能力、测试或整个产品已经通过。只在本目录写本CONTRACT与manifest供Root继续授权范围内编码。
