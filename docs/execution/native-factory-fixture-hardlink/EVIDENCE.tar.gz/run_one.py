"""Run exactly the granted real Core test, retaining only allowlisted diagnostics."""
from pathlib import Path
import importlib.util,unittest,os,sys,json,hashlib,datetime
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog');out=Path(__file__).resolve().parent
label,daemon=sys.argv[1:];capture=out/label;capture.mkdir(mode=0o700)
os.environ['AGENTBATON_OWNER_FIXTURE_DAEMON']=daemon
file=root/'apps/desktop/src-tauri/tests/test_native_owner_dialog.py'
spec=importlib.util.spec_from_file_location('actual_factory_test',file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.runner.save
allowed={'daemon-cleanup.json','bootstrap-state.json','core-bootstrap-transcript.json','bootstrap-paths.json','fixture-tools.json'}
def retained(path,value):
 original(path,value)
 if path.name in allowed: original(capture/path.name,value)
m.runner.save=retained
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
suite=unittest.TestSuite([m.FactoryPlanningControls('test_real_core_factory_preparation_is_schema14_complete_and_never_finalizes_target')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
record={'selected_test':'FactoryPlanningControls.test_real_core_factory_preparation_is_schema14_complete_and_never_finalizes_target','daemon':daemon,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'exit':0 if result.wasSuccessful() else 1,'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'start_UTC':start,'end_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retention':'Only allowlisted diagnostics copied from runner.save after original write; real source/Guard/RPC unchanged; no token file copied','dimension':'Actual local schema14 Core/generated files/probe only; no GUI/Provider/model/Mac'}
(capture/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(record['exit'])
