"""Exercise exact nested test-copy helpers on inert files, never execute bytes."""
from pathlib import Path
import ast,importlib.util,tempfile,os,json,hashlib
out=Path(__file__).resolve().parent;root=Path('/workspace/.worktrees/factory-child-planning-native-dialog');source=root/'apps/desktop/src-tauri/tests/test_native_owner_dialog.py'
spec=importlib.util.spec_from_file_location('fixture_tests_for_copy',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
tree=ast.parse(source.read_text());method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='test_real_core_factory_preparation_is_schema14_complete_and_never_finalizes_target');nodes=[n for n in method.body if isinstance(n,ast.FunctionDef)]
assert [n.name for n in nodes]==['observe_tool','prepare_tools']
namespace={'os':os,'runner':m.runner};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
with tempfile.TemporaryDirectory(prefix='ab-inert-tool-copy-') as temp:
 root=Path(temp);raw=root/'raw';raw.mkdir();deps=raw/'deps';deps.mkdir()
 for name in ['batond','baton']:
  p=raw/name;p.write_bytes(('Inert generated '+name+'; NEVER execute\n').encode());p.chmod(0o700);os.link(p,deps/name)
 installed,record=namespace['prepare_tools'](raw/'batond',root/'private')
 assert all(v['nlink']==2 for v in record['source_before'].values())
 assert all(v['nlink']==1 and v['mode']==0o500 for v in record['copied'].values())
 assert record['source_before']==record['source_after_copy']
 for name in record['copied']:assert record['copied'][name]['sha256']==record['source_before'][name]['sha256']
 try:namespace['prepare_tools'](raw/'batond',installed)
 except FileExistsError:record['existing_private_directory_refused_without_overwrite']=True
 else:raise AssertionError('Existing private output must not be overwritten')
 record['dimension']='Inert actual filesystem/hardlink/copy controls from exact nested helper; no daemon/CLI/Provider/GUI execution'
 (out/'INERT_COPY.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS inert hardlink2 source -> copied nlink1/mode500/private700/exactsha; original metadata unchanged; existing directory refused')
