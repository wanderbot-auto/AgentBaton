from pathlib import Path
import os,stat,hashlib,json
out=Path(__file__).resolve().parent
shared=Path('/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target/debug')
frozen=Path('/workspace/.onboarding/factory-native-shared-limits-f0322/frozen')
manifest=json.loads((frozen/'manifest.json').read_text())
def record(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),p
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(65536),b''):h.update(c)
 return {'path':str(p),'canonical':str(p.resolve(strict=True)),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mode':stat.S_IMODE(s.st_mode),'bytes':s.st_size,'sha256':h.hexdigest(),'regular':stat.S_ISREG(s.st_mode),'executable':bool(s.st_mode&0o111),'no022':not bool(s.st_mode&0o022),'under128MiB':s.st_size<=128*1024*1024}
records={kind:{n:record(base/n) for n in ['batond','baton']} for kind,base in [('shared',shared),('frozen',frozen)]}
for kind,values in records.items():
 for n,r in values.items():assert r['sha256']==manifest['binaries'][n],(kind,n)
keys={(r['device'],r['inode']):(kind,n) for kind,values in records.items() for n,r in values.items()}
aliases={k+':'+n:[] for k,n in keys.values()}
for base in [shared,frozen]:
 for directory,dirs,files in os.walk(base,followlinks=False):
  dirs[:]=[d for d in dirs if not (Path(directory)/d).is_symlink()]
  for name in files:
   p=Path(directory)/name;s=p.lstat();key=(s.st_dev,s.st_ino)
   if key in keys:
    kind,n=keys[key];aliases[kind+':'+n].append(str(p))
result={'f032_manifest':manifest,'records':records,'aliases':aliases,'limitation':'Local current metadata only; CI job did not capture inode/nlink, so these are not asserted as CI stat evidence'}
(out/'LOCAL_TOOLS_BEFORE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'records':records,'aliases':aliases},indent=2))
