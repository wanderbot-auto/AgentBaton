from pathlib import Path
import subprocess,os,json,hashlib,datetime,time
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog');out=Path(__file__).resolve().parent
source=root/'apps/desktop/src-tauri/tests/test_native_owner_dialog.py';before=hashlib.sha256(source.read_bytes()).hexdigest()
env=os.environ.copy();env['AGENTBATON_OWNER_FIXTURE_DAEMON']='/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target/debug/batond'
cmd=['python','-B','apps/desktop/src-tauri/tests/test_native_owner_dialog.py']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (out/'full47.log').open('xb') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashlib.sha256(source.read_bytes()).hexdigest();assert before==after
record={'argv':cmd,'cwd':str(root),'daemon':env['AGENTBATON_OWNER_FIXTURE_DAEMON'],'exit':p.returncode,'wall_seconds':time.monotonic()-t,'start_UTC':start,'end_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'test_source_sha256':before,'source_before_after_equal':True,'log_sha256':hashlib.sha256((out/'full47.log').read_bytes()).hexdigest(),'dimension':'Actual local Python47 including5realCore cases; not Native GUI/Rust/Mac/Provider'}
(out/'FULL_RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(p.returncode)
