// generated helper; not a binary
