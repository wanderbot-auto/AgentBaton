from pathlib import Path
import ast,subprocess,json,hashlib,tomllib,re
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent;BASE='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4';rows=[]
def check(name,value):
 assert value,name
 rows.append(name)
def old(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
entry='apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs';expected=old(entry).replace(b'"native_owner_dialog/controller.rs"',b'"../native_owner_dialog_test/controller.rs"').replace(b'"native_owner_dialog/macos.rs"',b'"../native_owner_dialog_test/macos.rs"')
check('entry only two path replacements',(R/entry).read_bytes()==expected)
for name in ['controller.rs','macos.rs']:
 a='apps/desktop/src-tauri/src/bin/native_owner_dialog/'+name;b='apps/desktop/src-tauri/src/native_owner_dialog_test/'+name
 check('helper byte identical '+name,old(a)==(R/b).read_bytes());check('old helper path absent '+name,not (R/a).exists())
for m in re.finditer(r'#\[path = "([^"]+)"\]',(R/entry).read_text()):check('module relative path resolves '+m.group(1),(R/entry).parent.joinpath(m.group(1)).resolve().is_file())
check('release compile_error preserved',b'#[cfg(not(debug_assertions))]\ncompile_error!' in expected)
for path in ['apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','Cargo.lock','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs','.github/workflows/product.yml','scripts/release-audit.py']:
 if (R/path).is_file():check('protected unchanged '+path,old(path)==(R/path).read_bytes())
manifest=tomllib.loads((R/'apps/desktop/src-tauri/Cargo.toml').read_text());check('both explicit test binaries require native-smoke',len(manifest['bin'])==2 and all(b['required-features']==['native-smoke'] for b in manifest['bin']))
metadata=json.loads((O/'after-metadata.stdout').read_text());package=next(p for p in metadata['packages'] if p['name']=='agentbaton-desktop')
check('Cargo metadata byte-identical before after',(O/'before-metadata.stdout').read_bytes()==(O/'after-metadata.stdout').read_bytes())
check('Cargo exact three named binaries',sorted(t['name'] for t in package['targets'] if t['kind']==['bin'])==['agentbaton-desktop','agentbaton-native-owner-dialog-smoke','agentbaton-native-smoke'])
# Source-derived projection of pinned CLI get_binaries(), validated by actual CLI fixture logs.
def default_candidates(entries):
 disabled={Path(b['path']).name for b in manifest['bin']}
 return sorted([Path(p).stem for p in entries if Path(p).name not in disabled]+[manifest['package']['name']])
before=default_candidates(['native_owner_dialog','native_owner_dialog_smoke.rs','native_smoke.rs']);after=default_candidates([p.name for p in (R/'apps/desktop/src-tauri/src/bin').iterdir()])
check('pinned CLI source projection old extra helper',before==['agentbaton-desktop','native_owner_dialog'])
check('pinned CLI source projection new main only',after==['agentbaton-desktop'])
actual=json.loads((O/'exact-cli-commands.json').read_text());check('actual CLI old shape fails missing helper',actual[0]['exit']==1 and b'/native_owner_dialog' in (O/'exact-cli-before.stderr').read_bytes());check('actual CLI relocated shape succeeds',actual[1]['exit']==0)
check('actual generated fixture package excludes both test binaries',json.loads((O/'exact-cli-package-inspection.json').read_text())['default_installed_bin_names']==['agentbaton-desktop'])
# Python syntax only. Do not execute test suite: it contains real daemon cases.
for path in ['scripts/native-owner-dialog-smoke.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py']:
 compile(ast.parse((R/path).read_text()),path,'exec');check('Python test/runner unchanged '+path,old(path)==(R/path).read_bytes())
result={'passed':len(rows),'checks':rows,'default_binary_lists':{'pinned_source_derived_actual_project_before':before,'pinned_source_derived_actual_project_after':after,'installed_CLI_generated_fixture_after':['agentbaton-desktop']},'not_run':['Rust compile/tests/lint','actual Core/daemon','macOS bundle or GUI','CI'],'CLI_package_version':json.loads(Path('/workspace/AgentBaton/apps/desktop/node_modules/@tauri-apps/cli/package.json').read_text())['version'],'CLI_native_module_sha256':sha(Path('/workspace/AgentBaton/apps/desktop/node_modules/@tauri-apps/cli-linux-x64-gnu/cli.linux-x64-gnu.node').read_bytes())};(O/'finite-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
