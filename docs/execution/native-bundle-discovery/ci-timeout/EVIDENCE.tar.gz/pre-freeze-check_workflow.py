from pathlib import Path
import json,subprocess,hashlib,copy,yaml
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent;BASE='4d2ab1fbb9c4aa562a86de0dd127b61948fdaa2e';rows=[]
def check(n,v):
 assert v,n
 rows.append(n)
before=(O/'before-product.yml').read_bytes();after=(R/'.github/workflows/product.yml').read_bytes();old=yaml.safe_load(before);new=yaml.safe_load(after)
check('exactly one byte-level 45-to60 line substitution',before.count(b'    timeout-minutes: 45\n')==1 and after==before.replace(b'    timeout-minutes: 45\n',b'    timeout-minutes: 60\n'))
check('frozen base workflow matches captured before',before==subprocess.check_output(['git','show',BASE+':.github/workflows/product.yml'],cwd=R))
check('desktop old typed timeout45',type(old['jobs']['desktop']['timeout-minutes']) is int and old['jobs']['desktop']['timeout-minutes']==45)
check('desktop new typed timeout60',type(new['jobs']['desktop']['timeout-minutes']) is int and new['jobs']['desktop']['timeout-minutes']==60)
restored=copy.deepcopy(new);restored['jobs']['desktop']['timeout-minutes']=45;check('entire parsed workflow unchanged apart approved job limit',restored==old)
for key in ['runs-on','strategy','steps']:
 check('desktop unchanged '+key,new['jobs']['desktop'][key]==old['jobs']['desktop'][key])
for job in [name for name in old['jobs'] if name!='desktop']:
 check('all other job metadata and steps unchanged '+job,new['jobs'][job]==old['jobs'][job])
check('all job IDs unchanged',list(new['jobs'])==list(old['jobs']))
check('permissions unchanged',new.get('permissions')==old.get('permissions'))
check('original non-desktop25/20 job caps unchanged',[v['timeout-minutes'] for k,v in new['jobs'].items() if k!='desktop']==[25,20])
changed=subprocess.check_output(['git','diff','--name-only',BASE],cwd=R,text=True).splitlines();check('only workflow source differs from prior frozen leaf',changed==['.github/workflows/product.yml'])
annotation=json.loads((O/'intel-check-annotations.json').read_text());check('actual official annotation explicitly45m limit',any(x['message']=='The job has exceeded the maximum execution time of 45m0s' for x in annotation))
summary=(O/'SUMMARY.md').read_text();check('actual evidence distinguishes ARM bundle and Intel cancelled',all(x in summary for x in ['123175557753','123175557621','Intel stopped during release desktop/Core compilation without the ARM missing-binary error']))
result={'scope':'pure workflow YAML/bytes/provenance checks only, no CI execution','passed':len(rows),'checks':rows,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'not_run':['CI','Cargo/compilation','Core/daemon','browser/macOS/package']};(O/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
