from pathlib import Path
import ast,copy,importlib.util,sys,json,hashlib
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent;sys.path.insert(0,str(R/'scripts'));rows=[]
def check(n,v):
 assert v,n
 rows.append(n)
spec=importlib.util.spec_from_file_location('ci60_validator',R/'scripts/validate_infrastructure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
before=(O/'before-validator.py').read_bytes();after=(R/'scripts/validate_infrastructure.py').read_bytes();check('validator only maximum45-to60 substitution',after==before.replace(b'        maximum = 45\n',b'        maximum = 60\n'))
ast.parse(after);check('validator syntax parses',True)
job={'runs-on':'${{ matrix.os }}','strategy':{'matrix':{'os':['macos-15','macos-15-intel']},'max-parallel':2,'fail-fast':False},'timeout-minutes':60}
def allowed(j,workflow='product.yml',name='desktop'):
 try:m.validate_job_timeout(workflow,name,j);return True
 except AssertionError:return False
for value,want in [(60,True),('60',True),(61,False),('61',False),(0,False),(-1,False),(True,False),(False,False),(60.0,False),('invalid',False),('60.0',False),(None,False)]:
 q=copy.deepcopy(job);q['timeout-minutes']=value;check('desktop timeout '+repr(value)+' '+type(value).__name__,allowed(q) is want)
for val,want in [(30,True),(31,False)]:check('general job max30 '+str(val),allowed({'timeout-minutes':val},name='ordinary') is want)
check('special budget unavailable to other workflow',not allowed(job,workflow='other.yml'))
for label,host in [('different','macos-15'),('personal','self-hosted'),('missing',None)]:
 q=copy.deepcopy(job);q['runs-on']=host;check('refuse host '+label,not allowed(q))
for label,mat in [('one-host',{'os':['macos-15']}),('reordered',{'os':['macos-15-intel','macos-15']}),('extra-host',{'os':['macos-15','macos-15-intel','ubuntu-24.04']}),('extra-axis',{'os':['macos-15','macos-15-intel'],'extra':[1]})]:
 q=copy.deepcopy(job);q['strategy']['matrix']=mat;check('refuse matrix '+label,not allowed(q))
for value in [3,1,None,True,2.0]:
 q=copy.deepcopy(job);q['strategy']['max-parallel']=value;check('refuse concurrency '+repr(value),not allowed(q))
for value in [True,'true',None,1]:
 q=copy.deepcopy(job);q['strategy']['fail-fast']=value;check('refuse failfast '+repr(value),not allowed(q))
old=json.loads((O/'before-manifest.json').read_bytes());new=json.loads((R/'BOOTSTRAP_MANIFEST.json').read_bytes());check('same93 manifest paths',len(old['files'])==len(new['files'])==93 and set(old['files'])==set(new['files']));changed=[k for k in old['files'] if old['files'][k]!=new['files'][k]];check('only validator hash rebaselined',changed==['scripts/validate_infrastructure.py']);check('registered validator hash exact',new['files'][changed[0]]==hashlib.sha256(after).hexdigest())
for k in old['files']:
 if k!=changed[0]:assert old['files'][k]==new['files'][k] and hashlib.sha256((R/k).read_bytes()).hexdigest()==new['files'][k],k
check('other92 registered file hashes actually match',True)
(O/'finite-results.json').write_text(json.dumps({'passed':len(rows),'checks':rows,'scope':'pure static guard/generated job dictionaries; no CI/product execution'},indent=2)+'\n');print(json.dumps({'passed':len(rows),'scope':'static only'},indent=2))
