from pathlib import Path
import json,hashlib,subprocess,struct,datetime
O=Path(__file__).parent;P=Path('/workspace/.onboarding/factory-schema13-legacy-suite');R=Path('/workspace/.worktrees/factory-runtime-integration');SOURCE='8abb5cac8f7842a3286b27cc48583ee07b609f0b';sha=lambda b:hashlib.sha256(b).hexdigest();checks=[];external=[]
def check(n,b):assert b,n;checks.append(n)
def load(p):return json.loads(p.read_bytes())
def hashfile(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def copy(p,relative):
 q=O/relative;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
# Capture immutable original output bytes before inspection; no product process is started.
inventory=[]
for p in sorted(P.rglob('*')):
 if p.is_file():
  b=p.read_bytes();rel=p.relative_to(P);copy(p,Path('evidence')/rel);inventory.append({'path':str(rel),'bytes':len(b),'sha256':sha(b)})
wrapper=Path('/workspace/.onboarding/factory-browser-root/run-schema13-legacy-suite.py');copy(wrapper,'run-schema13-legacy-suite.py')
before=load(P/'BEFORE.json');result=load(P/'RESULT.json');progress=load(P/'PROGRESS.json');candidate=load(P/'candidate.json')
check('recorded actual execution source8abb/12case/clean before+after',before['commit']==result['commit']==SOURCE and before['tests']==result['tests']==12 and before['status']==result['status_after']=='')
check('twelve exit0 and unmodified input maps',result['all12_passed'] is True and result['source_and_inputs_unchanged'] is True and len(result['cases'])==12 and all(x['exit_code']==0 for x in result['cases']) and result['cases']==progress and before['source_and_input_hashes']==result['source_and_input_hashes'])
check('candidate exact integer schema13 and source-equivalence honestly distinct',type(candidate['schema']) is int and candidate['schema']==13 and candidate['source_head']==candidate['source_equivalent_commit']=='db949cb57d6fbcec5a47f1b2da8c271d29b1732e' and candidate['compiled_base_commit']=='c3e547308e549afc5bede12513686c9b2635998f' and 'not an exact clean CI build' in candidate['source_head_meaning'])
normalized=Path('/workspace/.onboarding/factory-candidate-db949/manifest.json');original=Path(candidate['original_manifest']['path']);check('normalized6347 and original6cdf raw manifests preserved',hashfile(normalized)==candidate['parent_normalized_manifest_sha256']=='6347f559145a0a21f39b3ca585825da6625e4591dd60a9f9e76fdb06c77f0be0' and hashfile(original)==candidate['original_manifest']['sha256']=='6cdfc423d2c15c5f91087350fa9742123bfdf58a1f88eca3434502f75cb5cd01')
copy(normalized,'provenance/normalized-manifest.json');copy(original,'provenance/original-compiled-WIP-manifest.json');n=load(normalized);orig=load(original);check('candidate only adds explicit source-head labels and parent hash',n=={k:v for k,v in candidate.items() if k not in ['source_head','source_head_meaning','parent_normalized_manifest_sha256']})
check('46 original compiled production sources unchanged in normalized candidate',len(candidate['production_sources'])==46 and orig['sources']==candidate['production_sources'] and orig['build_base_commit']==candidate['compiled_base_commit'] and orig['schema']==13)
check('candidate raw binary details identical original',candidate['tool_details']==orig['binaries'])
for path,digest in before['source_and_input_hashes'].items():
 p=Path(path);check('current exact recorded input '+path,hashfile(p)==digest);external.append({'path':path,'bytes':p.stat().st_size,'sha256':digest})
 if path.startswith(str(R)) and '/target/' not in path:copy(p,Path('inputs')/p.relative_to(R))
for f,digest in candidate['production_sources'].items():
 for rev in [SOURCE,candidate['source_equivalent_commit']]:check('production blob '+rev[:7]+' '+f,sha(subprocess.check_output(['git','show',rev+':'+f],cwd=R))==digest)
for name,tool in candidate['tool_details'].items():check('real raw '+name+' file length/SHA',Path(tool['path']).stat().st_size==tool['bytes'] and candidate['binaries'][name]==tool['sha256'])
rows=[];pngs={};assets={};fresh_run_ids=[];scope_ids=[];totalchecks=0;ledgerdetails={};knownnames={x['name']:x for x in result['cases']};found={}
for p in sorted(P.rglob('*.json')):
 d=load(p)
 if not isinstance(d,dict) or 'checks' not in d or 'screenshots' not in d:continue
 name=p.parent.name;found[name]=p;row=knownnames[name];command=row['command'];check(name+' wrapper output/binary/log hash/exit',command[command.index('--output')+1]==str(P/name) and command[command.index('--batond')+1]==candidate['tool_details']['batond']['path'] and row['exit_code']==0 and hashfile(P/(name+'.log'))==row['log_sha256'])
 script=command[1];check(name+' exact source8abb harness',sha(subprocess.check_output(['git','show',SOURCE+':'+script],cwd=R))==before['source_and_input_hashes'][str(R/script)])
 check(name+' actual report checks passed',len(d['checks'])>0 and all(x['status']=='passed' for x in d['checks']))
 if 'status'in d:check(name+' statuspassed',d['status']=='passed')
 check(name+' raw daemonSHA binding',d['daemon_sha256']==candidate['binaries']['batond'])
 if 'candidate'in d:check(name+' exactcandidate complete',d['candidate']==candidate)
 if 'manifest_sha256'in d:check(name+' manifest rawbytebinding',d['manifest_sha256']==hashfile(P/'candidate.json'))
 if 'harness_sha256'in d:check(name+' harnessreport sourcebinding',d['harness_sha256']==before['source_and_input_hashes'][str(R/script)])
 if 'frontend_assets_sha256'in d:assets[name]=d['frontend_assets_sha256']
 for x in d['screenshots']:
  path=x['path'] if isinstance(x,dict) else x;q=Path(path);check(name+' screenshot path exact new run',q.is_relative_to(P/name));raw=q.read_bytes();check(str(q.relative_to(P))+' PNGbytes',raw[:8]==b'\x89PNG\r\n\x1a\n');digest=sha(raw);w,h=struct.unpack('>II',raw[16:24]);declared=x.get('sha256') if isinstance(x,dict) else d.get('screenshot_sha256',{}).get(path,d.get('screenshot_sha256',{}).get(q.name))
  if declared is not None:check(str(q.relative_to(P))+' image declaredSHA',declared==digest)
  else:check('only old command has no imageSHA',name=='approved-commands')
  pngs[str(q.relative_to(P))]={'sha256':digest,'width':w,'height':h,'declared_sha256':declared,'viewed':False}
 obs=d.get('observations',{})
 if name.startswith('goal-graph-'):
  check(name+' no unexpected HTTPerrors',d['http_unexpected_errors']==[]);clean=d['cleanup'];check(name+' server/handlers joined daemon exit0 exact',clean[0]['thread_alive'] is False and clean[1]['active_handlers']==[] and clean[2]['wait_exitcode']==0 and clean[2]['forced_sigkill'] is False and clean[2]['process_not_alive'] is True);check(name+' exact generated identity cleanup',len(clean[3:])>=2 and all(x['original_process_not_alive'] is True and x['pid_exists'] is False and x['signal_sent'] is False for x in clean[3:]))
  g=obs['accepted']['graph'] if 'accepted'in obs else obs['blocked_graph'];fresh_run_ids.append(g['run']['id']);scope_ids.append(g['run']['scope_id']);check(name+' scoped run task binding',g['run']['task_id'] is not None and g['run']['scope_id'] is not None)
  check(name+' actual consumed budgets no active reservations',all(x['active']==0 and x['consumed']>0 for x in obs['observed_budgets'].values()))
  if 'real_validator'in obs:
   v=obs['real_validator'];receipt=v['receipt'];check(name+' complete original rawObservation digest',sha(v['observation_json'].encode())==receipt['result_digest'] and json.loads(v['observation_json'])==receipt['observation']);check(name+' actual worker joined noProvider',receipt['stop_confirmed'] is True and receipt['io_completion']=='worker_joined' and v['provider_session_created_for_validator'] is False)
  if 'accepted'in obs:
   task=obs['accepted']['task'];a=g['task_acceptance'];durable=obs['durable_acceptance'];seq,event=durable['event'];pay=event['payload'];check(name+' actual accepted projection exact receipt/task/event',g['task_accepted'] is True and g['run']['task_accepted'] is True and g['run']['state']=='accepted' and task['state']=='accepted' and a['id']==task['acceptance_ref']==pay['acceptance_ref'] and seq==task['acceptance_sequence']==pay['acceptance_sequence'] and event['kind']=='task.accepted' and event['source']=='baton_goal_acceptance' and event['aggregate_id']==task['id'] and pay['run_id']==g['run']['id']==a['run_id'] and pay['criteria_complete'] is True and pay['task_accepted'] is True and durable['receipt_sha256']==pay['receipt_digest'])
   check(name+' two exact actualOwner decisions',len(obs['private_owner_decisions'])==len(obs['durable_owner_decisions'])==len(g['owner_decisions'])==2)
   for private,stored in zip(obs['private_owner_decisions'],obs['durable_owner_decisions']):
    p=private['proposal'];snap=p['snapshot'];reply=private['decision'];dec=stored['decision'];run=snap['run_binding'];check(name+' Ownerproposal/receipt/fullref/validation binding '+dec['node_id'],reply==private['replay'] and reply['approval_id']==p['id']==dec['approval_id'] and reply['owner_decision_id']==dec['id'] and reply['node_id']==dec['node_id']==snap['node']['id'] and reply['run_id']==dec['run_id']==run['run_id']==g['run']['id'] and reply['plan_revision']==dec['plan_revision']==run['plan_revision'] and dec['plan_digest']==run['plan_digest'] and dec['criterion_digest']==snap['criterion']['criterion_digest'] and dec['source']=='local_owner_confirmation' and dec['candidate_refs']==snap['candidate_refs'] and dec['validation_ids']==[v['id'] for v in snap['validation_refs']] and dec['id'] in a['owner_decision_ids'])
   ledgers=durable['ledgers'];project='project:'+a['project_id'];root='root-grant:'+a['root_grant_id'];check(name+' actual project/root-grant cumulative ledger equality',project in ledgers and root in ledgers and ledgers[project]['observed_attempts']==ledgers[root]['observed_attempts'] and ledgers[project]['output_bytes']==ledgers[root]['output_bytes'] and ledgers[project]['observed_attempts']>0);ledgerdetails[name]={'project':ledgers[project],'root_grant':ledgers[root]}
  else:
   check(name+' actual negative blocked pending allOwner/notstarted',g['run']['state']=='blocked' and g['task_accepted'] is False and g['task_acceptance'] is None and g['owner_decisions']==[] and obs['real_validator']['receipt']['passed'] is False)
 rows.append({'name':name,'report':str(p.relative_to(P)) if isinstance(p,Path) else name+'/report.json','checks':len(d['checks']),'screenshots':len(d['screenshots']),'run_id':g['run']['id'] if name.startswith('goal-graph-') else None});totalchecks+=len(d['checks'])
check('12reports including two evidencejson/114checks/70actualPNG',set(found)==set(knownnames) and len(rows)==12 and totalchecks==114 and len(pngs)==len(list(P.rglob('*.png')))==70)
expectedassets={str(Path(k).relative_to('apps/desktop/dist')):v for k,v in candidate['frontend']['assets'].items()};check('all available reported assets match real candidate bytes',all(v==expectedassets for v in assets.values()))
check('six new distinct graph runs/scopes',len(fresh_run_ids)==len(set(fresh_run_ids))==len(scope_ids)==len(set(scope_ids))==6)
old=Path('/workspace/.onboarding/pr16-c6f6-linux-review/ui-artifact');old_ids=[];oldscopes=[]
for p in old.glob('goal-graph-*/report.json'):
 d=load(p);obs=d['observations'];g=obs.get('accepted',{}).get('graph',obs.get('blocked_graph'));old_ids.append(g['run']['id']);oldscopes.append(g['run']['scope_id'])
check('no oldPR16 Graphrun/scope reused as new success',not set(old_ids)&set(fresh_run_ids) and not set(oldscopes)&set(scope_ids))
# Every original output remains byte-equal during review. Do not inspect current process table and infer historical containment.
for x in inventory:check('originaloutput unchanged '+x['path'],hashfile(P/x['path'])==x['sha256'])
(O/'audit-results.json').write_text(json.dumps({'source':SOURCE,'current_integration_HEAD_observed':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_equivalent_compiled_checkpoint':candidate['source_head'],'clean_compiled_commit_claimed':False,'controls':checks,'passed_controls':len(checks),'external_input_hashes':external,'reports':rows,'check_total':totalchecks,'PNG_total':len(pngs),'PNGs':pngs,'cumulative_ledgers':ledgerdetails,'assets':expectedassets,'all_original_outputs_before_after_equal':True},indent=2)+'\n');(O/'output-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');print('PASS',len(checks),'read-only provenance/receipts/ledger/output checks;',len(rows),'reports;',totalchecks,'checks;',len(pngs),'PNG')
