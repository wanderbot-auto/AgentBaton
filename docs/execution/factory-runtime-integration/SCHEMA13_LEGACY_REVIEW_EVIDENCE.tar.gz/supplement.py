from pathlib import Path
import json,hashlib
O=Path(__file__).parent;P=Path('/workspace/.onboarding/factory-schema13-legacy-suite');rows=[]
def check(n,b):assert b,n;rows.append(n)
for n in ['goal-graph-command-timeout','goal-graph-data-range']:
 d=json.loads((P/n/'report.json').read_bytes());g=d['observations']['blocked_graph'];down=[x for x in g['nodes'] if x['node']['id'] not in ['produce-report','validate-report']];check(n+' Owner/Summary downstream truly notstarted/pending/noattempt',len(down)==3 and all(x['state']=='not_started' and x['acceptance_state']=='pending' and x['attempt_id'] is None for x in down));v=d['observations']['real_validator']['receipt'];check(n+' declared correctness does not establish task acceptance',v['task_acceptance']=='not_established' and v['state']=='failed' and v['passed'] is False)
r=json.loads((O/'audit-results.json').read_bytes());viewed=['goal-graph-command/03-task-accepted-five-node-command.png','goal-graph-data-range/01-five-node-data-range-blocked-before-owner.png','goal-graph-command-timeout/01-five-node-command-timeout-blocked-before-owner.png']
for name in viewed:r['PNGs'][name]['viewed']=True
r['actually_viewed']=3;r['hash_only_not_viewed']=67;(O/'audit-results.json').write_text(json.dumps(r,indent=2)+'\n')
(O/'supplement-results.json').write_text(json.dumps({'commands':'python3 -B supplement.py','controls':rows,'passed':len(rows),'images_actually_returned_by_view_image':viewed,'reviewer_exploratory_error':'One read-only exploratory print queried node_id on NodeView; KeyError corrected to node.id. No product/source/receipt change.'},indent=2)+'\n');print('PASS',len(rows),'additional downstream negative-state checks; 3 actual images/67hashonly')
