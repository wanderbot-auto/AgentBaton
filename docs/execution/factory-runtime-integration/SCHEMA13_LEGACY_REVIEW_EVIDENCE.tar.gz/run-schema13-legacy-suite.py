from pathlib import Path
import os,json,hashlib,subprocess,datetime,sys
assert not os.environ.get('LD_PRELOAD')
tree=Path('/workspace/.worktrees/factory-runtime-integration'); out=Path('/workspace/.onboarding/factory-schema13-legacy-suite');out.mkdir(exist_ok=False)
manifest=Path('/workspace/.onboarding/factory-candidate-db949/manifest.json');raw=manifest.read_bytes();assert hashlib.sha256(raw).hexdigest()=='6347f559145a0a21f39b3ca585825da6625e4591dd60a9f9e76fdb06c77f0be0';m=json.loads(raw);m['source_head']=m['source_equivalent_commit'];m['source_head_meaning']='Frozen source-equivalent production checkpoint, not an exact clean CI build; compiled_base/build_identity/46 hashes unchanged.';m['parent_normalized_manifest_sha256']=hashlib.sha256(raw).hexdigest();candidate=out/'candidate.json';candidate.write_text(json.dumps(m,indent=2)+'\n')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
paths={str(tree/n):v for n,v in m['production_sources'].items()}
for tool in m['tool_details'].values():paths[tool['path']]=tool['sha256']
paths[str(candidate)]=sha(candidate)
for n,v in m['frontend']['assets'].items():paths[str(tree/n)]=v
for p in (tree/'apps/desktop/tests').glob('*.py'):paths[str(p)]=sha(p)
for n,v in paths.items():assert sha(n)==v,n
py='/workspace/AgentBaton/artifacts/browser-venv/bin/python';batond=m['tool_details']['batond']['path'];scripts='apps/desktop/tests/';common=['--batond',batond,'--chromium','/usr/bin/chromium'];front=['--frontend',str(tree/'apps/desktop/dist')];bound=['--candidate-manifest',str(candidate)];cases=[('quiet-canvas','quiet-canvas-real-ipc.py',[]),('approved-commands','command-validation-real-ipc.py',[]),('goal-planning','goal-planning-real-ipc.py',[]),('goal-plan-editor','goal-planning-real-ipc.py',['--structured-editor']),('data-workspaces','data-workspace-real-ipc.py',front),('goal-execution','goal-execution-real-ipc.py',front+bound),('goal-graph-owner','goal-graph-real-ipc.py',front+bound+['--owner-only'])]
for c in ['integrity','data','command','data-range','command-timeout']:cases.append(('goal-graph-'+c,'goal-graph-real-ipc.py',front+bound+['--validation-case',c]))
before={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True),'source_and_input_hashes':paths,'dimension':'actual Linux built frontend/Unix IPC/generated account-free ACP and private Owner; not Mac/OSOwner/live product Provider/full acceptance','tests':len(cases)};(out/'BEFORE.json').write_text(json.dumps(before,indent=2)+'\n');results=[]
for name,script,extra in cases:
 command=[py,scripts+script,*common,*extra,'--output',str(out/name)];row={'name':name,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command}
 with (out/(name+'.log')).open('wb') as log:z=subprocess.run(command,cwd=tree,stdout=log,stderr=subprocess.STDOUT)
 row.update(exit_code=z.returncode,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(out/(name+'.log')));results.append(row);(out/'PROGRESS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if z.returncode:break
result={**before,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':results,'all12_passed':len(results)==12 and all(r['exit_code']==0 for r in results),'source_and_inputs_unchanged':all(sha(p)==v for p,v in paths.items()),'status_after':subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True)};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');sys.exit(0 if result['all12_passed'] and result['source_and_inputs_unchanged'] else 1)
