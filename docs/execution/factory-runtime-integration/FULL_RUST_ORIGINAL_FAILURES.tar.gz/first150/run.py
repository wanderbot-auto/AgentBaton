import os,subprocess,time,json,pathlib,shutil,signal,hashlib
root=pathlib.Path('/workspace/.worktrees/factory-runtime-integration')
out=pathlib.Path('/workspace/.onboarding/factory-root-rust-regression')
env=os.environ.copy()
env.update(CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup',CARGO_TARGET_DIR='/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env['PATH']=env['CARGO_HOME']+'/bin:'+env['PATH']
assert 'CARGO_PROFILE_DEV_DEBUG' not in env,'unexpected inherited dev debug override'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='8532b2adee5e2de872621674ebbe606822e25f3a'
os.umask(0o022)
commands=[('workspace-tests',['cargo','test','--workspace','--locked']),('workspace-clippy',['cargo','clippy','--workspace','--locked','--all-targets','--','-D','warnings']),('workspace-fmt',['cargo','fmt','--all','--','--check'])]
results=[]
for name,cmd in commands:
 log=out/(name+'.log');assert not log.exists(),str(log)
 started=time.time();samples=[];stop=None
 with log.open('wb') as stream:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  (out/(name+'-start.json')).write_text(json.dumps({'command':cmd,'pid':p.pid,'start_unix':started,'environment':{k:env[k] for k in ['CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','RUST_TEST_THREADS','CARGO_PROFILE_TEST_DEBUG','CARGO_NET_OFFLINE']},'dev_debug_override':'unset','umask':'022','free_bytes':shutil.disk_usage(root).free},indent=2)+'\n')
  while p.poll() is None:
   free=shutil.disk_usage(root).free
   samples.append({'elapsed_seconds':round(time.time()-started,2),'free_bytes':free})
   if free<200*1024*1024:
    stop='disk below200MiB guard; interrupted own Cargo process group, no cache deletion'
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(1)
  code=p.wait()
 result={'name':name,'command':cmd,'exit_code':code,'elapsed_seconds':round(time.time()-started,2),'interruption':stop,'disk_samples':samples,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 (out/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');results.append(result)
 print(json.dumps({k:result[k] for k in ['name','exit_code','elapsed_seconds','interruption']}),flush=True)
 if code or stop:break
(out/'COMMAND_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
