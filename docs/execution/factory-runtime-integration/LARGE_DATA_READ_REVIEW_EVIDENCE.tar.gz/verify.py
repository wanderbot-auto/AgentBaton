import pathlib,hashlib,json,subprocess
root=pathlib.Path('/workspace/.worktrees/factory-runtime-core');out=pathlib.Path('/workspace/AgentBaton/.onboarding/factory-large-data-read-review')
sha=lambda x:hashlib.sha256(x).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
p=root/'artifacts/factory-runtime-core/large-data-read-source-snapshot.json';assert sha(p.read_bytes())=='29716cca9cff6f7536259f3feebd11fdee87de20b86c03d436eb819e3477664d';m=json.loads(p.read_bytes());c=m['source_commit'];assert c=='259b2f7bc8b3e98e230e3c158992a93efab99c02'
sources={**m['test_sources'],**m['production_sources']};assert len(m['production_sources'])==46
for path,h in sources.items():
 b=git('show',f'{c}:{path}');assert sha(b)==h,path;assert (root/path).read_bytes()==b,path
 dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
assert not git('diff','--name-only',m['base_commit'],c,'--','crates/core/src','apps/cli/src','apps/daemon/src','crates/providers/src','crates/workspaces/src')
for path,item in m['artifacts'].items():
 # artifact map stores path->sha record
 fp=pathlib.Path(path);fp=fp if fp.is_absolute() else root/fp
 expected=item if isinstance(item,str) else item['sha256'];assert sha(fp.read_bytes())==expected,path
cp=m['compiler_identity_post_run_observation'];cc=pathlib.Path(cp['lookup_path']);assert str(cc.resolve())==cp['canonical_executable'];assert sha(cc.read_bytes())==cp['sha256'];assert cc.stat().st_size==cp['bytes']
prod=m['immutable_product_candidate'];mp=pathlib.Path(prod['manifest_path']);assert sha(mp.read_bytes())==prod['manifest_sha256'];pm=json.loads(mp.read_bytes());assert pm['sources']==m['production_sources']
for name,v in prod['binaries'].items():
 bp=pathlib.Path(v['path']);assert bp.stat().st_size==v['bytes'];assert sha(bp.read_bytes())==v['sha256']
case=[]
for r in m['final_actual_cases']:
 f=root/r['outcome_path'];o=json.loads(f.read_bytes());assert o==r['outcome'];b=json.loads(f.with_name('build.json').read_bytes());assert b==r['build']
 assert sha(f.with_name('generated-gate.c').read_bytes())==b['source_sha256'];assert sha(f.with_name('generated-gate.so').read_bytes())==b['library_sha256']
 assert b['raw_daemon_sha256']==prod['binaries']['batond']['sha256'];assert b['installed_stripped_daemon_sha256']=='054991be6d7dfb8e9d48680cba2c6590747dfa8bf9770dd7135be3e498a8fa45'
 assert json.loads(f.with_name('owned-daemon-exit.json').read_bytes())==r['daemon_exit'];assert r['daemon_exit']['status_code']==0
 assert r['actual_read_entered']['pid']==r['daemon_exit']['pid'];assert r['actual_read_entered']['pid']!=r['actual_read_entered']['tid'];assert r['actual_read_entered']['read_bytes']==65536
 assert o['active_before_release']==o['leases_before_release']==o['attempts']==o['consumed']==1;assert o['children']==0;assert o['dataset_bytes']==16777216
 assert o['read_response']['request_id']=='controlled-large-data-original-nonce';assert o['read_response']['error']['code']=='CANCEL_REQUESTED';assert 'result' not in o['read_response'];assert o['read_worker_thread_gone_after_pending_reply'] and o['original_leader_reaped']
 assert o['explicit_owner_cancel_issued']==(o['mode']=='read_gate_cancel');assert o['approved_scope_ttl_ms']==(4000 if o['mode']=='read_gate_expiry' else 30000)
 assert o['owner_status_elapsed_ms']<3000
 case.append({k:o[k] for k in ['mode','owner_status_elapsed_ms','owner_stop_elapsed_ms','owner_revoke_elapsed_ms','approved_scope_ttl_ms','active_before_release','leases_before_release','explicit_owner_cancel_issued']})
# No global process-environment mutation; LD limited to private own-daemon Command.
rs=git('show',f'{c}:crates/core/tests/fixtures/factory_large_data_gate.rs').decode();ct=git('show',f'{c}:crates/core/tests/fixtures/factory_data_read_gate.c').decode();main=git('show',f'{c}:crates/core/tests/factory_runtime_ipc.rs').decode()
assert 'std::env::set_var' not in rs.replace('// Process-local Command environment only, never std::env::set_var.','')
assert rs.count('command.env("LD_PRELOAD", &self.library)')==1;assert "'LD_PRELOAD'" in main
assert ct.index('ssize_t n=next_read(fd,buffer,count);')<ct.index('!selected(fd)')<ct.index('marker(CONTROL_DIR "/entered"')
assert rs.index('assert_eq!(\n        held_active, 1')<rs.index('    gate.release();\n    let deadline')
assert rs.index('let denied = pending.join().unwrap();')<rs.index('!thread_path.exists()')
summary={'state':'PASS independent static/hash review only, no compiler/runtime invocation','source_commit':c,'source_snapshot_sha256':sha(p.read_bytes()),'test_source_count':len(m['test_sources']),'unchanged_production_count':len(m['production_sources']),'artifact_count':len(m['artifacts']),'cases':case,'compiler_identity':'post-run read/hash only; compile-time version/argv recorded, not pre-execution image pin','stripped_temporary_daemon':'hash recorded in all final builds; temporary image no longer retained, not independently rehashed','raw_immutable_tools':'both independently hashed','limits':m['remaining_not_run']}
(out/'VERIFICATION.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'AUTHOR_SNAPSHOT.json').write_bytes(p.read_bytes());print(json.dumps(summary,ensure_ascii=False))
