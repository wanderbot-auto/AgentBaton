from pathlib import Path
import json,hashlib,subprocess
O=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();out=[];C=json.loads((O/'candidate-manifest.json').read_text())
for n,h in C['production_sources'].items():assert H(subprocess.check_output(['git','show',C['source_equivalent_commit']+':'+n],cwd='/workspace/.worktrees/factory-runtime-integration'))==h
for c in ['normal','cancel','unknown']:
 D=O/c/'evidence';p=json.loads((D/'report.json').read_text());raws=[]
 for e in p['http']:
  raw=(json.dumps(e['response'],ensure_ascii=False,separators=(',',':'))+'\n').encode();assert H(raw)==e['original_core_reply_sha256'];raws.append({'method':e['method'],'raw_reply_sha256':H(raw),'bytes':len(raw)})
 records=[]
 for f in sorted(D.glob('verified-*.json')):
  v=json.loads(f.read_text());raw=json.dumps(v['record']).encode();assert H(raw)==v['original_file_pin']['sha256'] and len(raw)==v['original_file_pin']['bytes'];records.append({'file':f.name,'exact_original_encoding_sha256':H(raw),'bytes':len(raw)})
 out.append({'case':c,'all_complete_Core_reply_bytes_reconstructed_and_match_pinned_SHA':raws,'all_original_nonce_record_defaultJSON_bytes_reconstructed_and_match_FDpin':records})
(O/'raw-binding-check.json').write_text(json.dumps({'source_equivalent_commit_46_sources_match':True,'cases':out,'note':'Reconstruction matches retained original-byte SHA exactly, not a general JSON parse/stringify equivalence claim. Full Factory proposal encoding is NOT reconstructed because original full proposal is not retained.'},indent=2)+'\n');print('PASS 46 db949 source hashes; 89 exact reply re-encoding hashes; 5 exact original record hashes')
