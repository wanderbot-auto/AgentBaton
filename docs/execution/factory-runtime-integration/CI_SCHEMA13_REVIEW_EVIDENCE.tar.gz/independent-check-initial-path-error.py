from pathlib import Path
import ast, hashlib, json, subprocess, sqlite3, itertools, types, copy, yaml
R=Path('/workspace/.worktrees/factory-ci-schema13');O=Path(__file__).parent;BASE='8c6ea33c493d1936dfe7521d1bb96f0e410319ad';LOOKUP='435ac7b6dfc8810646109c414c244cb403a12954';SRC='98bc23ee10529ed290eaaaa68412e4e3ff971aef';checks=[]
def check(n,b):
 assert b,n
 checks.append(n)
def source(p,rev=SRC):return subprocess.check_output(['git','show',rev+':'+p],cwd=R).decode()
def dump(x):return ast.dump(x,include_attributes=False)
wf='.github/workflows/product.yml';old=yaml.safe_load(source(wf,LOOKUP));new=yaml.safe_load(source(wf));before=copy.deepcopy(old);after=copy.deepcopy(new)
def step(w,n):return next(s for s in w['jobs']['frontend']['steps'] if s.get('name')==n)
buildname='Real daemon and browser test dependencies';runname='Actual frontend with real Unix IPC and responsive screenshots'
for n in [buildname,runname]:del step(before,n)['run'];del step(after,n)['run']
check('workflow all metadata/other job content unchanged from exact lookup',before==after)
check('build block differs only adding sibling baton',step(old,buildname)['run'].replace('cargo build --locked --bin batond\n','cargo build --locked --bin batond --bin baton\n')==step(new,buildname)['run'])
for p in ['.github/workflows/environment.yml','infra/execution-gate.json']:
 check(p+' unchanged',source(p)==source(p,BASE))
run=step(new,runname)['run'];oldrun=step(old,runname)['run'];marker="artifacts/browser-venv/bin/python - <<'PY'\n"
check('five original shell flows prefix byte-identical',run.split(marker)[0]==oldrun.split(marker)[0])
body=run.split(marker)[1].rsplit('\nPY',1)[0];tree=ast.parse(body);oldtree=ast.parse(oldrun.split(marker)[1].rsplit('\nPY',1)[0]);compile(tree,'workflow-inline','exec')
def calls(t):return [n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess' and n.func.attr=='run']
check('old 3 subprocess callsites exact AST',list(map(dump,calls(oldtree)))==list(map(dump,calls(tree)[:3])))
check('old 12 flows: five shell plus Goal1 and Graph1+5',len([x for x in run.split(marker)[0].splitlines() if 'bin/python apps/desktop/tests/' in x])==5 and len(calls(oldtree))==3 and "['integrity', 'data', 'command', 'data-range', 'command-timeout']" in body)
assign=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='candidate' for t in n.targets))
class File:
 def __init__(self,*a):self.a=a
 def read_bytes(self):return {'batond':b'raw daemon\x00','baton':b'raw cli\xff'}[self.a[-1]]
env={'hashlib':hashlib,'pathlib':types.SimpleNamespace(Path=File),'git':lambda *a: {('rev-parse','HEAD'):'a'*40,('rev-parse','HEAD^{tree}'):'b'*40}[a]}
exec(compile(ast.Module([assign],[]),'candidate-only-ast','exec'),env);candidate=env['candidate']
check('candidate actual checkout/tree/clean exact fields',candidate['git_head']=='a'*40 and candidate['git_tree']=='b'*40 and candidate['dirty'] is False and type(candidate['schema']) is int and candidate['schema']==13)
check('candidate hashes original raw bytes of both tools',candidate['binaries']=={k:hashlib.sha256(v).hexdigest() for k,v in [('batond',b'raw daemon\x00'),('baton',b'raw cli\xff')]})
loop=next(n for n in tree.body if isinstance(n,ast.For) and dump(n.iter)==dump(ast.parse("['normal','cancel','unknown']",mode='eval').body));aggregate=ast.Module([next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='factory_failures' for x in n.targets)),loop,next(n for n in tree.body if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='factory_failures')],[])
for bits in itertools.product([False,True],repeat=3):
 seen=[];fail={c for c,b in zip(['normal','cancel','unknown'],bits) if b}
 class Stub:
  CalledProcessError=subprocess.CalledProcessError
  @staticmethod
  def run(argv,check):
   assert check is True
   c=argv[argv.index('--case')+1];seen.append(argv)
   if c in fail:raise subprocess.CalledProcessError(137,argv)
 env={'subprocess':Stub,'sys':types.SimpleNamespace(executable='fixed-python'),'chromium':'fixed-chromium','json':json}
 try:exec(compile(aggregate,'aggregate-only-ast','exec'),env);outcome=False
 except SystemExit as e:outcome=True;assert e.code and isinstance(e.code,str)
 check('all three exact argv/unique output/nonzero aggregate mask '+str(bits),[a[a.index('--case')+1] for a in seen]==['normal','cancel','unknown'] and len({a[a.index('--output')+1] for a in seen})==3 and all(a[a.index('--output')+1]=='artifacts/ui-browser/factory-'+a[a.index('--case')+1] and a[a.index('--candidate-manifest')+1]=='artifacts/ui-browser/goal-execution-candidate.json' and a[1]=='apps/desktop/tests/factory-real-ipc.py' for a in seen) and outcome==bool(fail))
for f in ['goal-execution-real-ipc.py','goal-graph-real-ipc.py','data-workspace-real-ipc.py','factory-real-ipc.py']:
 p='apps/desktop/tests/'+f;txt=source(p);t=ast.parse(txt);compile(t,p,'exec');check('AST compile '+f,True)
 guards=[n for n in ast.walk(t) if isinstance(n,ast.Assert) and 'manifest' in ast.unparse(n.test) and 'schema' in ast.unparse(n.test)]
 # Factory and Graph first schema Assert; Goal/Data first combined manifest/hash Assert.
 assert guards
 for schema in [12,14,13.0,13.0001,True,False,'13',None,13]:
  en={'manifest':{'schema':schema},'type':type,'binary':types.SimpleNamespace(read_bytes=lambda:b'guard'),'sha':lambda b:hashlib.sha256(b).hexdigest(),'expected_binary':hashlib.sha256(b'guard').hexdigest(),'report':{'daemon_sha256':hashlib.sha256(b'guard').hexdigest()}}
  check(f+' strict schema '+repr(schema),bool(eval(compile(ast.Expression(guards[0].test),'schema-assert','eval'),en))==(type(schema) is int and schema==13))
 for g in [n for n in ast.walk(t) if isinstance(n,ast.Assert) and 'PRAGMA user_version' in ast.unparse(n.test)]:
  for ver in [12,13,14]:
   with sqlite3.connect(':memory:') as db:
    db.execute('PRAGMA user_version='+str(ver));db.execute('PRAGMA query_only=ON')
    check(f+' SQLite assertion '+str(g.lineno)+' version '+str(ver),bool(eval(compile(ast.Expression(g.test),'sqlite-assert','eval'),{'db':db,'store':db}))==(ver==13))
# Prove old harness full source conservation under the enumerated schema changes.
for f in ['goal-execution-real-ipc.py','data-workspace-real-ipc.py']:
 p='apps/desktop/tests/'+f;a=source(p,BASE);b=source(p)
 a=a.replace('schema12','schema13').replace("assert manifest['schema'] == 12", "assert type(manifest.get('schema')) is int and manifest['schema'] == 13").replace("fetchone()[0] == 12","fetchone()[0] == 13")
 check(f+' full old source retained except exact schema delta',a==b)
# Existing Native non-schema assertions retain exactly their expressions and ordering.
shell=source('scripts/native-macos-smoke.sh');oldsh=source('scripts/native-macos-smoke.sh',BASE)
def inline(s):return s.split("python3 - \"$output/native-smoke.json\" <<'PY'\n",1)[1].rsplit('\nPY',1)[0]
a=ast.parse(inline(oldsh));b=ast.parse(inline(shell));compile(b,'native-inline','exec')
def non_schema_asserts(t):return [dump(n) for n in ast.walk(t) if isinstance(n,ast.Assert) and 'schema_version' not in ast.unparse(n.test) and 'factory_error' not in ast.unparse(n.test)]
check('all original Native non-schema asserts exact and ordered',non_schema_asserts(a)==non_schema_asserts(b))
check('Native shell prefix retains every original command',oldsh.split("python3 - \"$output/native-smoke.json\" <<'PY'\n")[0]==shell.split("python3 - \"$output/native-smoke.json\" <<'PY'\n")[0])
for g in [n for n in ast.walk(b) if isinstance(n,ast.Assert) and 'schema_version' in ast.unparse(n.test)]:
 for ver in [12,14,13.0,True,None,13]:
  record={k:{'before':{'schema_version':ver}} for k in ['goal_execution_readonly_database','goal_graph_readonly_database']}
  check('Native shell strict schema '+str(g.lineno)+' '+repr(ver),bool(eval(compile(ast.Expression(g.test),'native-schema','eval'),{'record':record}))==(type(ver) is int and ver==13))
# Original float acceptance reproduced from old Factory schema assert, not historical runtime reason.
base=ast.parse(source('apps/desktop/tests/factory-real-ipc.py',BASE));g=next(n for n in ast.walk(base) if isinstance(n,ast.Assert) and "manifest['schema']" in ast.unparse(n.test));check('old Factory assert actually accepts float13.0',eval(compile(ast.Expression(g.test),'old-schema','eval'),{'manifest':{'schema':13.0}}) is True)
check('no author tracked mutation',subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R)==b'')
(O/'independent-results.json').write_text(json.dumps({'source':SRC,'controls':checks,'passed_controls':len(checks),'dimension':'static AST and synthetic raw bytes/in-memory SQLite; no product subprocess/browser/native/Core'},indent=2)+'\n');print('PASS',len(checks),'independently authored finite controls')
