from pathlib import Path
import subprocess,json,hashlib,datetime,sys
O=Path(__file__).parent;R=Path('/workspace/.worktrees/factory-ci-schema13'); rows=[]
for tag,argv in [('infrastructure',[sys.executable,'-B','scripts/validate_infrastructure.py']),('native-shell-syntax',['bash','-n','scripts/native-macos-smoke.sh']),('cumulative-diff',['git','diff','--check','8c6ea33c493d1936dfe7521d1bb96f0e410319ad','98bc23ee10529ed290eaaaa68412e4e3ff971aef']),('tracked-clean',['git','status','--porcelain','--untracked-files=no'])]:
 p=subprocess.run(argv,cwd=R,capture_output=True);(O/(tag+'.stdout')).write_bytes(p.stdout);(O/(tag+'.stderr')).write_bytes(p.stderr);rows.append({'tag':tag,'argv':argv,'cwd':str(R),'exit':p.returncode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert p.returncode==0
 if tag=='tracked-clean':assert p.stdout==b''
b=json.loads((O/'bindings.json').read_text())
for row in b['source_bindings']:
 assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==b['docs_head']
(O/'final-checks.json').write_text(json.dumps({'commands':rows,'all_source_before_after_sha_equal':True,'head_before_after_equal':True,'tracked_clean':True},indent=2)+'\n');print('PASS infrastructure, shell syntax, diff, clean, exact source/hash before-after')
