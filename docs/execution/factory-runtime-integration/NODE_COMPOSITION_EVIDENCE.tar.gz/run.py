import subprocess,json,hashlib,datetime
from pathlib import Path
root=Path('/workspace/.worktrees/factory-runtime-integration');out=Path('/workspace/.onboarding/factory-native-composition/node');modules=root/'apps/desktop/node_modules';target=Path('/workspace/AgentBaton/apps/desktop/node_modules')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');files=[x for x in files if x];before={p:sha(root/p) for p in files}
assert not modules.exists() and not modules.is_symlink();modules.symlink_to(target)
results=[]
try:
 versions=subprocess.check_output(['node','--version']).decode().strip()
 for name,cmd in [('tests',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build'])]:
  log=out/(name+'.log');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with log.open('wb') as f:r=subprocess.run(cmd,cwd=root/'apps/desktop',stdout=f,stderr=subprocess.STDOUT)
  results.append({'command':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':log.name,'log_sha256':sha(log)})
  if r.returncode:break
finally:
 assert modules.is_symlink() and modules.readlink()==target;modules.unlink()
 after={p:sha(root/p) for p in files};assets={str(p.relative_to(root)):sha(p) for p in (root/'apps/desktop/dist').rglob('*') if p.is_file()}
 (out/'RESULT.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'node':versions,'commands':results,'source_before_after_equal':before==after,'source_hashes_before':before,'changed':[p for p in files if before[p]!=after[p]],'temporary_modules_link_removed':not modules.is_symlink(),'assets':assets,'dimension':'composed Node/mock UI/type/build only; actual Factory IPC/browser NOT_RUN'},indent=2)+'\n')
 print(json.dumps({'commands':results,'assets':assets,'source_unchanged':before==after},indent=2),flush=True)
