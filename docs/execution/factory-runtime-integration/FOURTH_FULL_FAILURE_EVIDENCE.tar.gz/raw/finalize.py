from pathlib import Path
import json,hashlib,os,subprocess,re,shutil
root=Path('/workspace/.worktrees/factory-runtime-integration');out=Path('/workspace/.onboarding/factory-root-rust-regression-setup-fixed');before=json.loads((out/'BEFORE.json').read_text());redirect=json.loads((out/'GENERATED_REDIRECT.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
commands=json.loads((out/'COMMAND_RESULTS.json').read_text())
removed=[]
for x in redirect['links']:
 p=Path(x['path']);s=p.lstat();assert p.is_symlink() and os.readlink(p)==x['target'] and s.st_ino==x['inode'] and s.st_dev==x['device'];p.unlink();removed.append(x['path'])
p=Path(redirect['root_parent']['path']);s=p.stat();assert s.st_ino==redirect['root_parent']['inode'] and s.st_dev==redirect['root_parent']['device'];assert not list(p.iterdir());p.rmdir();(out/'GENERATED_REDIRECT_REMOVED.json').write_text(json.dumps({'removed_only_own_symlinks':removed,'removed_empty_own_parent':str(p),'generated_evidence_retained':str(out/'test-artifacts')},indent=2)+'\n')
changed=[p for p,h in before['tracked_files'].items() if sha(root/p)!=h];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True)
assert not changed and not status and head==before['head'],(changed,status,head)
tools={}
for n,x in before['shared_debug_tools'].items():
 p=Path(x['path']);s=p.stat();tools[n]={'path':str(p),'sha256':sha(p),'bytes':s.st_size,'inode':s.st_ino,'nlink':s.st_nlink,'changed_during_this_build':sha(p)!=x['sha256']}
cas=json.loads(Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/manifest.json').read_text())
for item in cas['binaries'].values():assert sha(item['path'])==item['sha256']
text=(out/'workspace-tests.log').read_text();sections=[];current=None
for line in text.splitlines():
 if line.startswith('     Running') or re.match(r'\s+Doc-tests ',line):
  current={'entry':line.strip(),'kind':'doctest' if 'Doc-tests' in line else 'outer','summaries':[]};sections.append(current)
 if line.startswith('test result:') and current is not None:current['summaries'].append(line)
outer=[];nested=[];docs=[]
for s in sections:
 for i,line in enumerate(s['summaries']):
  x=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',line);v={'entry':s['entry'],'passed':int(x[1]),'failed':int(x[2]),'ignored':int(x[3]),'summary':line}
  (nested if i<len(s['summaries'])-1 else docs if s['kind']=='doctest' else outer).append(v)
after={'head':head,'status':status,'tracked_files_equal':len(before['tracked_files']),'changed_tracked_files':changed,'shared_debug_tools':tools,'immutable_CAS_tools_equal':True,'source_generated_redirect_removed':True,'free_bytes':shutil.disk_usage(root).free,'outer_suites':outer,'nested_summaries':nested,'doctest_suites':docs,'unique_outer_passed':sum(x['passed'] for x in outer),'unique_outer_failed':sum(x['failed'] for x in outer),'outer_ignored':sum(x['ignored'] for x in outer),'nested_passed_not_added_to_outer':sum(x['passed'] for x in nested),'doctests_passed':sum(x['passed'] for x in docs),'doctests_failed':sum(x['failed'] for x in docs),'doctests_ignored':sum(x['ignored'] for x in docs),'commands':commands,'profile':'TEST_DEBUG0 only; DEV_DEBUG unset, assertions/optimization/timeouts not overridden; not CI default-debug2/Mac/Native'}
(out/'AFTER.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({k:after[k] for k in ['head','status','tracked_files_equal','unique_outer_passed','unique_outer_failed','nested_passed_not_added_to_outer','doctests_passed','doctests_failed','free_bytes']},indent=2))
