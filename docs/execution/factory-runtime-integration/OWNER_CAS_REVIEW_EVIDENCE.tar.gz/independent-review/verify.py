import hashlib,json,pathlib,subprocess
root=pathlib.Path('/workspace/.worktrees/factory-runtime-core')
out=pathlib.Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-review')
commit='db949cb57d6fbcec5a47f1b2da8c271d29b1732e'
mp=pathlib.Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/manifest.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
assert sha(mp.read_bytes())=='6cdfc423d2c15c5f91087350fa9742123bfdf58a1f88eca3434502f75cb5cd01'
m=json.loads(mp.read_bytes()); sources={**m['sources'],**m['tests']}; checked={}
for path,expected in sources.items():
 b=git('show',f'{commit}:{path}'); assert sha(b)==expected,path
 assert (root/path).read_bytes()==b,path
 dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 checked[path]=expected
logs={}
for name,item in m['logs'].items():
 p=pathlib.Path(item['path']); assert sha(p.read_bytes())==item['sha256'],name
 logs[name]=item
bins={}
for name,item in m['binaries'].items():
 p=pathlib.Path(item['path']); assert p.stat().st_size==item['bytes']; assert sha(p.read_bytes())==item['sha256']
 bins[name]=item
changed=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
assert changed==['crates/core/src/factory_reads.rs','crates/core/tests/factory_runtime_ipc.rs']
s=(root/'crates/core/src/factory_reads.rs').read_text()
start=s.index('"factory_runs.start" => {');end=s.index('"approvals.finalize" => {',start); branch=s[start:end]
assert branch.index('.factory_start_replay(')<branch.index('let scope = scope(')<branch.index('if scope.revision != revision')<branch.index('pinned_companion = Some(')
assert s.index('let proofs = projection(',end)>end
ipc=(root/'crates/core/src/ipc.rs').read_text();st=ipc.index('let factory = match self.factory_context_for_request(&job.raw)')
assert st<ipc.index('let graph = match self.graph_context_for_request(&job.raw)',st)<ipc.index('match self.data_contexts_for_request(&job.raw)',st)<ipc.index('self.data_workers.defer(contexts, graph, factory, job)',st)
# Removal of only the added CAS block and new unit exactly restores existing reads module.
old=git('show',f'{commit}^:crates/core/src/factory_reads.rs').decode();new=s
cas_start=new.index('                // Exact-key history above stays read-only')
cas_end=new.index('                // Start uses the exact native-approved',cas_start)
new=new[:cas_start]+new[cas_end:]
test_start=new.index('    #[test]\n    fn wrong_owner_start_revision_')
test_end=new.index('    #[test]\n    fn readonly_query_only_connection_',test_start)
new=new[:test_start]+new[test_end:];assert new==old
oldlog=pathlib.Path(m['logs']['wrong-start-cas-old-owner-ipc.log']['path']).read_text(); assert 'CANCEL_REQUESTED' in oldlog and '0 passed; 1 failed' in oldlog
unit=pathlib.Path(m['logs']['wrong-start-cas-thirteen-unit.log']['path']).read_text(); assert '13 passed; 0 failed; 0 ignored' in unit
actual=pathlib.Path(m['logs']['wrong-start-cas-final-owner-ipc.log']['path']).read_text();assert 'STALE_REVISION' in actual and '1 passed; 0 failed; 0 ignored' in actual
r={'commit':commit,'candidate_manifest':str(mp),'candidate_manifest_sha256':sha(mp.read_bytes()),'production_sources_checked':len(m['sources']),'test_sources_checked':len(m['tests']),'checked_source_sha256':checked,'logs_checked':logs,'binaries_checked':bins,'independent_execution':'static/source/hash probes only; no Cargo, test ELF, daemon or browser executed','static_checks':{'replay_before_cas':True,'cas_before_projection_fd_worker':True,'ipc_factory_context_before_data_context_and_defer':True,'old_12_read_units_byte_unchanged':True,'only_two_source_files_changed_in_commit':True},'author_execution_evidence':{'old_actual_ipc':'0 PASS / 1 FAIL, exit101; CANCEL_REQUESTED/not_started, expected STALE_REVISION','final_units':'13 PASS / 0 FAIL / 0 ignored, 6.06s','final_actual_ipc':'1 PASS / 0 FAIL / 0 ignored, 2.18s; wrong CAS then normal completion then history replay after companion deletion','build':'PASS, 15.64s','clippy':'PASS, 8.38s','fmt':'PASS empty log'}}
(out/'VERIFICATION.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':'PASS','sources':len(sources),'logs':len(logs),'binaries':len(bins),'static_checks':r['static_checks']}))
