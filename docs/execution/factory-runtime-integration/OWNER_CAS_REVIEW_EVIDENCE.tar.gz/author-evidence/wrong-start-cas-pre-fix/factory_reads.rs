//! Request-owned, read-only Factory approval/start observations. These types are
//! not Deserialize and cannot be submitted by a Renderer, Provider or MCP token.
use super::{store::*, FactoryScopeBindings, FactoryScopeSelection};
use crate::{
    data_workspaces::{DataArtifactPins, DataInputWitness},
    storage::{db_error, decode, encode, Store},
    CoreError, Result,
};
use agentbaton_workspaces::{
    validation::{ArtifactRequirement, BoundArtifact},
    WorkspaceKind,
};
use rusqlite::{Connection, OpenFlags, OptionalExtension};
use std::{
    fs::{self, File, OpenOptions},
    os::unix::fs::{MetadataExt, OpenOptionsExt},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    time::{Duration, Instant},
};

pub(crate) struct FactoryReadControl {
    cancel: Arc<AtomicBool>,
    deadline: Instant,
}
impl FactoryReadControl {
    pub(crate) fn check(&self) -> Result<()> {
        if Instant::now() >= self.deadline {
            return Err(CoreError::new(
                "DEADLINE_EXCEEDED",
                "Factory read observation arrived after its original deadline",
            ));
        }
        if self.cancel.load(Ordering::Relaxed) {
            return Err(CoreError::new(
                "CANCEL_REQUESTED",
                "The owned Factory read was cancelled before admission",
            ));
        }
        Ok(())
    }
}
struct QueryProof {
    sql: &'static str,
    args: Vec<String>,
    rows: Vec<String>,
}
impl QueryProof {
    fn capture(db: &Connection, sql: &'static str, args: Vec<String>) -> Result<Self> {
        Self::capture_bounded(db, sql, args, &mut (1_048_576, 100_000))
    }
    fn capture_bounded(
        db: &Connection,
        sql: &'static str,
        args: Vec<String>,
        remaining: &mut (usize, usize),
    ) -> Result<Self> {
        // Every query is defined in this module, not deserialized/user SQL. Bound
        // raw count/bytes before fetching any complete value into Rust.
        let budget=format!("SELECT count(*),COALESCE(sum(octet_length(value)),0),COALESCE(max(octet_length(value)),0) FROM ({sql})");
        let (count, bytes, largest): (i64, i64, i64) = db
            .query_row(&budget, rusqlite::params_from_iter(&args), |r| {
                Ok((r.get(0)?, r.get(1)?, r.get(2)?))
            })
            .map_err(db_error)?;
        if count > 100_000 || bytes > 1_048_576 || largest > 1_048_576 || count < 0 || bytes < 0 {
            return Err(limited());
        }
        let bytes = usize::try_from(bytes).map_err(|_| limited())?;
        let count = usize::try_from(count).map_err(|_| limited())?;
        if bytes > remaining.0 || count > remaining.1 {
            return Err(limited());
        }
        // Consume shared budget BEFORE materializing the next query's rows.
        remaining.0 -= bytes;
        remaining.1 -= count;
        let mut query = db.prepare(sql).map_err(db_error)?;
        let rows = query
            .query_map(rusqlite::params_from_iter(&args), |r| r.get::<_, String>(0))
            .map_err(db_error)?
            .collect::<std::result::Result<Vec<_>, _>>()
            .map_err(db_error)?;
        Ok(Self { sql, args, rows })
    }
    fn recheck(&self, db: &Connection) -> Result<()> {
        if Self::capture(db, self.sql, self.args.clone())?.rows != self.rows {
            return Err(changed());
        }
        Ok(())
    }
}
// This seals the complete observed work tree, not just selected inputs. A
// directory stamp detects entry creation/removal, while each nofollow leaf stat
// detects edits outside the selected set. Captured BEFORE the worker's full Git
// clean/base check; rechecked after it and at the Actor boundary. This is an
// observation, never continuous OS immutability. Ignored entries are included
// conservatively. Large/deep trees fail explicitly rather than being truncated.
const MAX_TREE_ENTRIES: usize = 8192;
const MAX_TREE_DIRECTORIES: usize = 256;
const MAX_TREE_NAME_BYTES: usize = 1_048_576;
#[derive(PartialEq, Eq)]
struct TreeStamp([i128; 11]);
fn tree_stamp(s: &rustix::fs::Stat) -> TreeStamp {
    TreeStamp([
        s.st_dev as i128,
        s.st_ino as i128,
        s.st_mode as i128,
        s.st_uid as i128,
        s.st_gid as i128,
        s.st_nlink as i128,
        s.st_size as i128,
        s.st_mtime as i128,
        s.st_mtime_nsec as i128,
        s.st_ctime as i128,
        s.st_ctime_nsec as i128,
    ])
}
struct TreeDirectory {
    fd: File,
    stamp: TreeStamp,
    depth: usize,
}
struct TreeEntry {
    directory: usize,
    name: std::ffi::OsString,
    stamp: TreeStamp,
}
struct GitRefObservation {
    parent: PathBuf,
    fd: File,
    stamp: TreeStamp,
    refs: Option<GitTreeObservation>,
}
impl GitRefObservation {
    fn capture(
        parent: &Path,
        control: &FactoryReadControl,
        budget: &mut TreeBudget,
    ) -> Result<Self> {
        if budget.directories >= MAX_TREE_DIRECTORIES {
            return Err(limited());
        }
        budget.directories += 1;
        let fd = tree_root(parent)?;
        let stamp = tree_stamp(&rustix::fs::fstat(&fd).map_err(|_| changed())?);
        let refs = match rustix::fs::statat(&fd, "refs", rustix::fs::AtFlags::SYMLINK_NOFOLLOW) {
            Ok(st)
                if rustix::fs::FileType::from_raw_mode(st.st_mode)
                    == rustix::fs::FileType::Directory =>
            {
                Some(GitTreeObservation::capture(
                    &parent.join("refs"),
                    control,
                    budget,
                )?)
            }
            Err(rustix::io::Errno::NOENT) => None,
            _ => return Err(changed()),
        };
        let observed = Self {
            parent: parent.into(),
            fd,
            stamp,
            refs,
        };
        observed.recheck()?;
        Ok(observed)
    }
    fn recheck(&self) -> Result<()> {
        if tree_stamp(&rustix::fs::fstat(tree_root(&self.parent)?).map_err(|_| changed())?)
            != self.stamp
            || tree_stamp(&rustix::fs::fstat(&self.fd).map_err(|_| changed())?) != self.stamp
        {
            return Err(changed());
        }
        match &self.refs {
            Some(tree) => tree.recheck()?,
            None => {
                if !matches!(
                    rustix::fs::statat(&self.fd, "refs", rustix::fs::AtFlags::SYMLINK_NOFOLLOW),
                    Err(rustix::io::Errno::NOENT)
                ) {
                    return Err(changed());
                }
            }
        }
        Ok(())
    }
}
struct GitTreeObservation {
    root: PathBuf,
    directories: Vec<TreeDirectory>,
    entries: Vec<TreeEntry>,
}
#[derive(Default)]
struct TreeBudget {
    entries: usize,
    directories: usize,
    names: usize,
}
fn tree_root(path: &Path) -> Result<File> {
    use rustix::fs::{open, openat, Mode, OFlags};
    let flags =
        OFlags::RDONLY | OFlags::DIRECTORY | OFlags::NOFOLLOW | OFlags::NONBLOCK | OFlags::CLOEXEC;
    let mut fd: File = open("/", flags, Mode::empty())
        .map_err(|_| changed())?
        .into();
    if !path.is_absolute() || path.as_os_str().len() > 4096 {
        return Err(changed());
    }
    for part in path.components() {
        match part {
            std::path::Component::RootDir => {}
            std::path::Component::Normal(name) => {
                fd = openat(&fd, name, flags, Mode::empty())
                    .map_err(|_| changed())?
                    .into();
            }
            _ => return Err(changed()),
        }
    }
    Ok(fd)
}
impl GitTreeObservation {
    fn capture(root: &Path, control: &FactoryReadControl, budget: &mut TreeBudget) -> Result<Self> {
        use rustix::fs::{fstat, openat, statat, AtFlags, Dir, FileType, Mode, OFlags};
        use std::os::unix::ffi::OsStrExt;
        control.check()?;
        if budget.directories >= MAX_TREE_DIRECTORIES {
            return Err(limited());
        }
        let fd = tree_root(root)?;
        let root_stat = fstat(&fd).map_err(|_| changed())?;
        budget.directories += 1;
        let mut observation = Self {
            root: root.into(),
            directories: vec![TreeDirectory {
                fd,
                stamp: tree_stamp(&root_stat),
                depth: 0,
            }],
            entries: vec![],
        };
        let mut i = 0;
        while i < observation.directories.len() {
            control.check()?;
            let mut stream =
                Dir::read_from(&observation.directories[i].fd).map_err(|_| changed())?;
            while let Some(entry) = stream.read() {
                control.check()?;
                let entry = entry.map_err(|_| changed())?;
                let name = entry.file_name();
                if name.to_bytes() == b"." || name.to_bytes() == b".." {
                    continue;
                }
                // .git is separately pinned by capture_pins, including its
                // worktree pointer, HEAD/index/config and common metadata.
                if i == 0 && name.to_bytes() == b".git" {
                    continue;
                }
                if budget.entries >= MAX_TREE_ENTRIES
                    || budget
                        .names
                        .checked_add(name.to_bytes().len())
                        .is_none_or(|n| n > MAX_TREE_NAME_BYTES)
                {
                    return Err(limited());
                }
                budget.entries += 1;
                budget.names += name.to_bytes().len();
                let name = std::ffi::OsStr::from_bytes(name.to_bytes()).to_os_string();
                let st = statat(
                    &observation.directories[i].fd,
                    &name,
                    AtFlags::SYMLINK_NOFOLLOW,
                )
                .map_err(|_| changed())?;
                let kind = FileType::from_raw_mode(st.st_mode);
                if !matches!(
                    kind,
                    FileType::RegularFile | FileType::Directory | FileType::Symlink
                ) || (kind != FileType::Directory && st.st_nlink != 1)
                {
                    return Err(changed());
                }
                if kind == FileType::Directory {
                    if budget.directories >= MAX_TREE_DIRECTORIES
                        || observation.directories[i].depth >= 64
                    {
                        return Err(limited());
                    }
                    let fd: File = openat(
                        &observation.directories[i].fd,
                        &name,
                        OFlags::RDONLY
                            | OFlags::DIRECTORY
                            | OFlags::NOFOLLOW
                            | OFlags::NONBLOCK
                            | OFlags::CLOEXEC,
                        Mode::empty(),
                    )
                    .map_err(|_| changed())?
                    .into();
                    if tree_stamp(&fstat(&fd).map_err(|_| changed())?) != tree_stamp(&st) {
                        return Err(changed());
                    }
                    budget.directories += 1;
                    let depth = observation.directories[i].depth + 1;
                    observation.directories.push(TreeDirectory {
                        fd,
                        stamp: tree_stamp(&st),
                        depth,
                    });
                }
                observation.entries.push(TreeEntry {
                    directory: i,
                    name,
                    stamp: tree_stamp(&st),
                });
            }
            i += 1;
        }
        observation.recheck()?;
        Ok(observation)
    }
    fn recheck(&self) -> Result<()> {
        use rustix::fs::{fstat, statat, AtFlags};
        let current = tree_root(&self.root)?;
        if tree_stamp(&fstat(current).map_err(|_| changed())?) != self.directories[0].stamp {
            return Err(changed());
        }
        for directory in &self.directories {
            if tree_stamp(&fstat(&directory.fd).map_err(|_| changed())?) != directory.stamp {
                return Err(changed());
            }
        }
        for entry in &self.entries {
            let st = statat(
                &self.directories[entry.directory].fd,
                &entry.name,
                AtFlags::SYMLINK_NOFOLLOW,
            )
            .map_err(|_| changed())?;
            if tree_stamp(&st) != entry.stamp {
                return Err(changed());
            }
        }
        // Recheck parent directories after leaf observations to catch changes
        // during this bounded traversal. Kernel stalls remain non-interruptible.
        for directory in &self.directories {
            if tree_stamp(&fstat(&directory.fd).map_err(|_| changed())?) != directory.stamp {
                return Err(changed());
            }
        }
        Ok(())
    }
}
fn git_directory(root: &Path) -> Result<PathBuf> {
    use std::io::Read;
    let path = root.join(".git");
    let m = fs::symlink_metadata(&path).map_err(|_| changed())?;
    if m.is_dir() {
        return path.canonicalize().map_err(|_| changed());
    }
    if !m.is_file() || m.nlink() != 1 {
        return Err(changed());
    }
    let mut text = String::new();
    OpenOptions::new()
        .read(true)
        .custom_flags((rustix::fs::OFlags::NOFOLLOW | rustix::fs::OFlags::NONBLOCK).bits() as i32)
        .open(&path)
        .map_err(|_| changed())?
        .take(4097)
        .read_to_string(&mut text)
        .map_err(|_| changed())?;
    let target = text
        .strip_prefix("gitdir: ")
        .ok_or_else(changed)?
        .trim_end_matches(['\n', '\r']);
    if text.len() > 4096 || target.is_empty() || target.contains(['\0', '\n', '\r']) {
        return Err(changed());
    }
    root.join(target).canonicalize().map_err(|_| changed())
}
fn check_head_reference(root: &Path) -> Result<()> {
    use std::io::Read;
    let mut text = String::new();
    OpenOptions::new()
        .read(true)
        .custom_flags((rustix::fs::OFlags::NOFOLLOW | rustix::fs::OFlags::NONBLOCK).bits() as i32)
        .open(root.join("HEAD"))
        .map_err(|_| changed())?
        .take(4097)
        .read_to_string(&mut text)
        .map_err(|_| changed())?;
    let text = text.trim_end_matches(['\n', '\r']);
    if text.len() > 4096 {
        return Err(changed());
    }
    if let Some(reference) = text.strip_prefix("ref: refs/") {
        if reference.is_empty()
            || reference.contains(['\0', '\n', '\r'])
            || Path::new(reference)
                .components()
                .any(|p| !matches!(p, std::path::Component::Normal(_)))
        {
            return Err(changed());
        }
    } else if !matches!(text.len(), 40 | 64) || !text.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err(changed());
    }
    Ok(())
}
fn capture_git_trees(
    db: &Connection,
    selection: &FactoryScopeSelection,
    control: &FactoryReadControl,
) -> Result<(Vec<GitTreeObservation>, Vec<GitRefObservation>)> {
    let grant = crate::policy::checked_lineage(db, &selection.grant_id)?;
    let mut budget = TreeBudget::default();
    let mut trees = vec![];
    let mut refs = vec![];
    let mut seen = std::collections::BTreeSet::new();
    for id in &grant.scope.workspace_ids {
        let workspace = read_workspace(db, id)?;
        if let Some(WorkspaceKind::Git { common_dir, .. }) =
            workspace.identity.as_ref().map(|i| &i.kind)
        {
            trees.push(GitTreeObservation::capture(
                &workspace.root,
                control,
                &mut budget,
            )?);
            let gitdir = git_directory(&workspace.root)?;
            check_head_reference(&gitdir)?;
            for parent in [&gitdir, common_dir] {
                if seen.insert(parent.clone()) {
                    refs.push(GitRefObservation::capture(parent, control, &mut budget)?);
                }
            }
        }
    }
    Ok((trees, refs))
}

struct DatabasePin {
    path: PathBuf,
    file: File,
    parent: File,
    device: u64,
    inode: u64,
    parent_device: u64,
    parent_inode: u64,
}
impl DatabasePin {
    fn capture(db: &Connection) -> Result<Self> {
        let path = PathBuf::from(db.path().ok_or_else(changed)?);
        if !path.is_absolute()
            || path.as_os_str().len() > 4096
            || path.canonicalize().ok().as_deref() != Some(path.as_path())
        {
            return Err(changed());
        }
        let flags = (rustix::fs::OFlags::NOFOLLOW
            | rustix::fs::OFlags::NONBLOCK
            | rustix::fs::OFlags::CLOEXEC)
            .bits() as i32;
        let parent = OpenOptions::new()
            .read(true)
            .custom_flags(flags | rustix::fs::OFlags::DIRECTORY.bits() as i32)
            .open(path.parent().ok_or_else(changed)?)
            .map_err(|_| changed())?;
        let file = OpenOptions::new()
            .read(true)
            .custom_flags(flags)
            .open(&path)
            .map_err(|_| changed())?;
        let p = parent.metadata().map_err(|_| changed())?;
        let m = file.metadata().map_err(|_| changed())?;
        if !p.is_dir()
            || p.mode() & 0o7777 != 0o700
            || !m.is_file()
            || m.nlink() != 1
            || m.mode() & 0o7777 != 0o600
            || m.uid() != rustix::process::geteuid().as_raw()
            || p.uid() != m.uid()
        {
            return Err(denied());
        }
        Ok(Self {
            path,
            file,
            parent,
            device: m.dev(),
            inode: m.ino(),
            parent_device: p.dev(),
            parent_inode: p.ino(),
        })
    }
    fn open_readonly(&self, deadline: Instant) -> Result<Connection> {
        self.recheck()?;
        let connection = Connection::open_with_flags(
            &self.path,
            OpenFlags::SQLITE_OPEN_READ_ONLY
                | OpenFlags::SQLITE_OPEN_NO_MUTEX
                | OpenFlags::SQLITE_OPEN_NOFOLLOW,
        )
        .map_err(db_error)?;
        connection
            .busy_timeout(
                Duration::from_secs(3).min(deadline.saturating_duration_since(Instant::now())),
            )
            .map_err(db_error)?;
        connection
            .execute_batch("PRAGMA query_only=ON; BEGIN;")
            .map_err(db_error)?;
        Ok(connection)
    }
    fn recheck(&self) -> Result<()> {
        let held = self.file.metadata().map_err(|_| changed())?;
        let p = self.parent.metadata().map_err(|_| changed())?;
        let current = fs::symlink_metadata(&self.path).map_err(|_| changed())?;
        let current_parent =
            fs::symlink_metadata(self.path.parent().ok_or_else(changed)?).map_err(|_| changed())?;
        if !current.is_file()
            || current.nlink() != 1
            || held.nlink() != 1
            || current.mode() & 0o7777 != 0o600
            || !current_parent.is_dir()
            || current_parent.mode() & 0o7777 != 0o700
            || self.path.canonicalize().ok().as_deref() != Some(self.path.as_path())
            || [
                (&held, self.device, self.inode),
                (&current, self.device, self.inode),
                (&p, self.parent_device, self.parent_inode),
                (&current_parent, self.parent_device, self.parent_inode),
            ]
            .iter()
            .any(|(m, d, i)| {
                m.dev() != *d || m.ino() != *i || m.uid() != rustix::process::geteuid().as_raw()
            })
        {
            return Err(changed());
        }
        Ok(())
    }
}
/// Stop metadata, never an approval/dispatch capability. Cloning it cannot
/// grant reads or allow any method; the request-owned proof is separate.
#[derive(Clone)]
pub(crate) struct FactoryReadWatch {
    task_id: String,
    task_revision: u64,
    project_id: String,
    project_revision: u64,
    grant_id: String,
    grant_revision: u64,
    approval: Option<(String, u64, bool)>,
}
impl FactoryReadWatch {
    pub(crate) fn current(&self, store: &Store) -> bool {
        let current = (|| -> Result<bool> {
            let task = store.get(&self.task_id)?;
            let project = store.get_project(&self.project_id)?;
            let grant = crate::policy::checked_lineage(&store.conn, &self.grant_id)?;
            if task.revision != self.task_revision
                || task.state != crate::storage::TaskState::Draft
                || project.revision != self.project_revision
                || project.archived
                || grant.revision != self.grant_revision
            {
                return Ok(false);
            }
            if let Some((id, revision, is_scope)) = &self.approval {
                if *is_scope {
                    let scope = scope(&store.conn, id)?;
                    return Ok(!scope.revoked
                        && scope.revision == *revision
                        && scope.expires_at_ms > ms()?);
                }
                let raw:Option<(Option<String>,bool)>=store.conn.query_row("SELECT CASE WHEN octet_length(document)<=1048576 THEN document END,result IS NOT NULL FROM approval_proposals WHERE id=?1",[id],|r|Ok((r.get(0)?,r.get(1)?))).optional().map_err(db_error)?;
                let Some((Some(raw), false)) = raw else {
                    return Ok(false);
                };
                let proposal: crate::sessions::ApprovalProposal = decode(&raw)?;
                return Ok(proposal.kind == "factory"
                    && !proposal.consumed
                    && proposal.revision == *revision
                    && proposal.expires_at_ms > ms()?);
            }
            Ok(true)
        })();
        current.unwrap_or(false)
    }
    pub(crate) fn scope_id(&self) -> Option<&str> {
        self.approval
            .as_ref()
            .filter(|(_, _, is_scope)| *is_scope)
            .map(|(id, _, _)| id.as_str())
    }
}
pub(crate) struct FactoryReadPlan {
    watch: FactoryReadWatch,
    selection: FactoryScopeSelection,
    companion: PathBuf,
    database: DatabasePin,
    proofs: Vec<QueryProof>,
    request_hash: String,
}
pub(crate) struct FactoryReadWitness {
    selection: FactoryScopeSelection,
    companion: PathBuf,
    database: DatabasePin,
    proofs: Vec<QueryProof>,
    bindings: FactoryScopeBindings,
    pins: Vec<DataArtifactPins>,
    git_trees: Vec<GitTreeObservation>,
    request_hash: String,
    deadline: Instant,
    git_refs: Vec<GitRefObservation>,
}
fn projection(
    db: &Connection,
    selection: &FactoryScopeSelection,
    approval: Option<&str>,
) -> Result<Vec<QueryProof>> {
    let grant = crate::policy::checked_lineage(db, &selection.grant_id)?;
    limits(selection, &grant)?;
    let task = Store::factory_read_task(db, &selection.root_task_id)?;
    let mut proofs = Vec::new();
    let mut remaining = (4_194_304, 100_000);
    let mut add = |sql, args| -> Result<()> {
        proofs.push(QueryProof::capture_bounded(db, sql, args, &mut remaining)?);
        Ok(())
    };
    add(
        "SELECT document AS value FROM tasks WHERE id=?1",
        vec![task.id.clone()],
    )?;
    add(
        "SELECT document AS value FROM projects WHERE id=?1",
        vec![task.project_id.clone()],
    )?;
    add(
        "SELECT document AS value FROM execution_grants WHERE id=?1",
        vec![grant.id.clone()],
    )?;
    for id in &grant.scope.connection_ids {
        add(
            "SELECT document AS value FROM connections WHERE id=?1",
            vec![id.clone()],
        )?;
    }
    for id in &grant.scope.workspace_ids {
        add(
            "SELECT document AS value FROM managed_workspaces WHERE id=?1",
            vec![id.clone()],
        )?;
    }
    if let Some(id) = approval {
        add(
            "SELECT document AS value FROM approval_proposals WHERE id=?1",
            vec![id.into()],
        )?;
        add(
            "SELECT COALESCE(result,'null') AS value FROM approval_proposals WHERE id=?1",
            vec![id.into()],
        )?;
        add(
            "SELECT document AS value FROM factory_scopes WHERE id=?1",
            vec![id.into()],
        )?;
        add("SELECT json_array(revision,revoked,owner_sequence) AS value FROM factory_scopes WHERE id=?1",vec![id.into()])?;
    }
    for scope in [
        format!("project:{}", task.project_id),
        format!("root:{}", task.id),
    ] {
        add("SELECT json_array(total_limit,parallel_limit,consumed,active) AS value FROM budgets WHERE scope=?1",vec![scope])?;
    }
    for scope in [
        format!("project:{}", task.project_id),
        format!("root-grant:{}", grant.root_grant_id),
    ] {
        add(
            "SELECT document AS value FROM goal_ledgers WHERE scope=?1",
            vec![scope],
        )?;
    }
    add(
        "SELECT document AS value FROM factory_scopes WHERE root_task_id=?1 ORDER BY id",
        vec![task.id.clone()],
    )?;
    add("SELECT json_array(id,revision,revoked,owner_sequence) AS value FROM factory_scopes WHERE root_task_id=?1 ORDER BY id",vec![task.id.clone()])?;
    add(
        "SELECT document AS value FROM factory_runs WHERE root_task_id=?1 ORDER BY id",
        vec![task.id.clone()],
    )?;
    add(
        "SELECT document AS value FROM factory_task_lineage WHERE task_id=?1",
        vec![task.id.clone()],
    )?;
    add("SELECT json_array(d.id,d.state,d.document,a.binding) AS value FROM dispatch_intents d JOIN attempts a ON a.id=d.attempt_id WHERE a.task_id=?1 ORDER BY d.id",vec![task.id])?;
    add("SELECT document AS value FROM factory_budget_reservations WHERE project_id=?1 OR json_extract(document,'$.root_grant_id')=?2 ORDER BY attempt_id",vec![task.project_id.clone(),grant.root_grant_id.clone()])?;
    add("SELECT x.document AS value FROM goal_run_reservations x JOIN goal_runs r ON r.id=x.run_id WHERE r.project_id=?1 OR json_extract(r.document,'$.root_grant_id')=?2 ORDER BY x.attempt_id",vec![task.project_id,grant.root_grant_id])?;
    Ok(proofs)
}
impl Store {
    pub(crate) fn factory_proposal_replay(
        &self,
        selection: &FactoryScopeSelection,
        key_id: &str,
    ) -> Result<bool> {
        Ok(
            replay::<serde_json::Value>(
                &self.conn,
                "factory:propose",
                key_id,
                &encode(selection)?,
            )?
            .is_some(),
        )
    }
    fn factory_read_task(db: &Connection, id: &str) -> Result<crate::storage::Task> {
        let row:Option<Option<String>>=db.query_row("SELECT CASE WHEN octet_length(document)<=1048576 THEN document END FROM tasks WHERE id=?1",[id],|r|r.get(0)).optional().map_err(db_error)?;
        decode(&row.flatten().ok_or_else(changed)?)
    }
    pub(crate) fn prepare_factory_owner_read(
        &self,
        method: &str,
        params: &serde_json::Value,
        revision: Option<u64>,
        key_id: Option<&str>,
        raw: &str,
        companion: Option<PathBuf>,
    ) -> Result<Option<FactoryReadPlan>> {
        let mut pinned_companion = None;
        let (selection, approval) = match method {
            "factory_scopes.propose" => {
                let selection: FactoryScopeSelection =
                    serde_json::from_value(params.clone()).map_err(|_| invalid())?;
                let key_id = key_id.ok_or_else(invalid)?;
                if replay::<serde_json::Value>(
                    &self.conn,
                    "factory:propose",
                    key_id,
                    &encode(&selection)?,
                )?
                .is_some()
                {
                    return Ok(None);
                }
                (selection, None)
            }
            "factory_runs.start" => {
                let id = params
                    .get("scope_id")
                    .and_then(|v| v.as_str())
                    .ok_or_else(invalid)?;
                if self
                    .factory_start_replay(
                        id,
                        revision.ok_or_else(invalid)?,
                        key_id.ok_or_else(invalid)?,
                    )?
                    .is_some()
                {
                    return Ok(None);
                }
                let scope = scope(&self.conn, id)?;
                // Start uses the exact native-approved immutable installation,
                // never silently substitutes this daemon's adjacent executable.
                pinned_companion = Some(scope.bindings.companion.executable.clone());
                (scope.selection, Some(scope.id))
            }
            "approvals.finalize" => {
                let id = params
                    .get("proposal_id")
                    .and_then(|v| v.as_str())
                    .ok_or_else(invalid)?;
                let row:Option<(Option<String>,bool)>=self.conn.query_row("SELECT CASE WHEN octet_length(document)<=1048576 THEN document END,result IS NOT NULL FROM approval_proposals WHERE id=?1",[id],|r|Ok((r.get(0)?,r.get(1)?))).optional().map_err(db_error)?;
                let Some((document, done)) = row else {
                    return Ok(None);
                };
                if done {
                    return Ok(None);
                }
                let proposal: crate::sessions::ApprovalProposal =
                    decode(&document.ok_or_else(limited)?)?;
                if proposal.kind != "factory" {
                    return Ok(None);
                }
                if proposal.revision != revision.ok_or_else(invalid)?
                    || proposal.consumed
                    || proposal.expires_at_ms <= ms()?
                {
                    return Err(denied());
                }
                (
                    serde_json::from_value(proposal.snapshot["selection"].clone())
                        .map_err(|_| invalid())?,
                    Some(proposal.id),
                )
            }
            _ => return Ok(None),
        };
        let proofs = projection(&self.conn, &selection, approval.as_deref())?;
        let companion = match pinned_companion.or(companion) {
            Some(path) => path,
            None => crate::factory::companion_path()?,
        };
        let database = DatabasePin::capture(&self.conn)?;
        let task = self.get(&selection.root_task_id)?;
        let project = self.get_project(&task.project_id)?;
        let watch = FactoryReadWatch {
            task_id: task.id,
            task_revision: task.revision,
            project_id: project.id,
            project_revision: project.revision,
            grant_id: selection.grant_id.clone(),
            grant_revision: selection.expected_grant_revision,
            approval: approval
                .map(|id| (id, revision.unwrap_or(0), method == "factory_runs.start")),
        };
        Ok(Some(FactoryReadPlan {
            watch,
            selection,
            companion,
            database,
            proofs,
            request_hash: agentbaton_workspaces::validation::sha256(raw.as_bytes()),
        }))
    }
}
impl FactoryReadPlan {
    pub(crate) fn watch(&self) -> FactoryReadWatch {
        self.watch.clone()
    }
    pub(crate) fn execute(
        self,
        witness: DataInputWitness,
        cancel: Arc<AtomicBool>,
        deadline: Instant,
    ) -> Result<DataInputWitness> {
        let control = FactoryReadControl { cancel, deadline };
        control.check()?;
        self.database.recheck()?;
        let connection = self.database.open_readonly(deadline)?;
        let version: u32 = connection
            .pragma_query_value(None, "user_version", |r| r.get(0))
            .map_err(db_error)?;
        if version != 13 {
            return Err(changed());
        }
        // Match the live Actor's exact approved business rows BEFORE filesystem
        // reads, preventing an independently replaced readonly DB granting reads.
        for proof in &self.proofs {
            control.check()?;
            proof.recheck(&connection)?;
        }
        let mut reader = Store {
            conn: connection,
            data_input: Some(witness),
            graph_input: None,
            graph_capture_clocks: Default::default(),
            factory_read_control: Some(control),
        };
        let workspace = read_workspace(&reader.conn, &self.selection.workspace_ids[0])?;
        let (pins, required) =
            capture_pins(&reader.conn, &self.selection, &workspace, &self.companion)?;
        let (git_trees, git_refs) = capture_git_trees(
            &reader.conn,
            &self.selection,
            reader.factory_read_control.as_ref().unwrap(),
        )?;
        let bindings = reader.resolve_factory_bindings(&self.selection, &self.companion)?;
        for pin in &pins {
            pin.verify(false)?;
        }
        required.verify(true)?;
        for tree in &git_trees {
            tree.recheck()?;
        }
        for refs in &git_refs {
            refs.recheck()?;
        }
        let mut pins = pins;
        pins.push(required);
        reader.factory_read_control.as_ref().unwrap().check()?;
        self.database.recheck()?;
        reader.conn.execute_batch("ROLLBACK;").map_err(db_error)?;
        let mut witness = reader.data_input.take().ok_or_else(changed)?;
        witness.factory = Some(Box::new(FactoryReadWitness {
            selection: self.selection,
            companion: self.companion,
            database: self.database,
            proofs: self.proofs,
            bindings,
            pins,
            git_trees,
            git_refs,
            request_hash: self.request_hash,
            deadline,
        }));
        Ok(witness)
    }
}
impl FactoryReadWitness {
    pub(super) fn recheck(
        &self,
        store: &Store,
        selection: &FactoryScopeSelection,
        companion: &Path,
    ) -> Result<FactoryScopeBindings> {
        if Instant::now() >= self.deadline
            || self.selection != *selection
            || self.companion != companion
            || !store
                .data_input
                .as_ref()
                .is_some_and(|w| w.for_hash(&self.request_hash))
        {
            return Err(changed());
        }
        self.database.recheck()?;
        for proof in &self.proofs {
            proof.recheck(&store.conn)?;
        }
        for pins in &self.pins {
            pins.verify(false)?;
        }
        for tree in &self.git_trees {
            tree.recheck()?;
        }
        for refs in &self.git_refs {
            refs.recheck()?;
        }
        check_admission_db(&store.conn, &self.bindings)?;
        crate::policy::observe_grant_bindings(&store.conn, &self.bindings.approved_grant)?;
        for id in &self.bindings.approved_grant.scope.workspace_ids {
            let w = read_workspace(&store.conn, id)?;
            if matches!(
                w.identity.as_ref().map(|i| &i.kind),
                Some(WorkspaceKind::Directory)
            ) {
                store.require_data_input(&w)?;
            }
        }
        if Instant::now() >= self.deadline {
            return Err(CoreError::new(
                "DEADLINE_EXCEEDED",
                "Original Factory observation expired during bounded metadata admission",
            ));
        }
        Ok(self.bindings.clone())
    }
}
fn read_workspace(db: &Connection, id: &str) -> Result<crate::registry::ManagedWorkspace> {
    let raw:Option<Option<String>>=db.query_row("SELECT CASE WHEN octet_length(document)<=1048576 THEN document END FROM managed_workspaces WHERE id=?1",[id],|r|r.get(0)).optional().map_err(db_error)?;
    decode(&raw.flatten().ok_or_else(changed)?)
}
fn capture_pins(
    db: &Connection,
    selection: &FactoryScopeSelection,
    workspace: &crate::registry::ManagedWorkspace,
    path: &Path,
) -> Result<(Vec<DataArtifactPins>, DataArtifactPins)> {
    use std::io::Read;
    let mut required = selection
        .inputs
        .iter()
        .map(|input| {
            BoundArtifact::from_approved_root(&workspace.root, input.clone())
                .map(|b| b.contract_view())
                .map_err(|_| changed())
        })
        .collect::<Result<Vec<_>>>()?;
    // This is a metadata-only pin for the separately bounded 128MiB executable,
    // not an artifact read or a widening of BoundArtifact's 64MiB file limit.
    let image_root = path.parent().ok_or_else(changed)?;
    if image_root.canonicalize().ok().as_deref() != Some(image_root) {
        return Err(changed());
    }
    let root_metadata = fs::metadata(image_root).map_err(|_| changed())?;
    required.push(agentbaton_workspaces::validation::ArtifactContractView {
        canonical_root: image_root.into(),
        root_device: root_metadata.dev(),
        root_inode: root_metadata.ino(),
        requirement: ArtifactRequirement {
            artifact_id: "factory-main-image".into(),
            relative_path: path.file_name().ok_or_else(changed)?.into(),
            max_bytes: 128 * 1024 * 1024,
            expected_sha256: None,
        },
    });
    let required = DataArtifactPins::capture(&required)?;
    let grant = crate::policy::checked_lineage(db, &selection.grant_id)?;
    let mut state = Vec::new();
    let mut add = |root: &Path, relative: &Path| -> Result<()> {
        match fs::symlink_metadata(root.join(relative)) {
            Ok(m) if !m.is_file() || m.nlink() != 1 => return Err(changed()),
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(_) => return Err(changed()),
        }
        let requirement = ArtifactRequirement {
            artifact_id: format!("factory-git-state-{}", state.len()),
            relative_path: relative.into(),
            max_bytes: 16 * 1024 * 1024,
            expected_sha256: None,
        };
        state.push(
            BoundArtifact::from_approved_root(root, requirement)
                .map_err(|_| changed())?
                .contract_view(),
        );
        Ok(())
    };
    for id in &grant.scope.workspace_ids {
        let workspace = read_workspace(db, id)?;
        let Some(identity) = workspace.identity else {
            return Err(changed());
        };
        let WorkspaceKind::Git { common_dir, .. } = identity.kind else {
            continue;
        };
        let dotgit = workspace.root.join(".git");
        let metadata = fs::symlink_metadata(&dotgit).map_err(|_| changed())?;
        let gitdir = if metadata.is_dir() {
            dotgit.canonicalize().map_err(|_| changed())?
        } else {
            if !metadata.is_file() || metadata.nlink() != 1 {
                return Err(changed());
            }
            add(&workspace.root, Path::new(".git"))?;
            let file = OpenOptions::new()
                .read(true)
                .custom_flags(
                    (rustix::fs::OFlags::NOFOLLOW | rustix::fs::OFlags::NONBLOCK).bits() as i32,
                )
                .open(&dotgit)
                .map_err(|_| changed())?;
            let mut text = String::new();
            file.take(4097)
                .read_to_string(&mut text)
                .map_err(|_| changed())?;
            if text.len() > 4096 {
                return Err(changed());
            }
            let target = text
                .strip_prefix("gitdir: ")
                .ok_or_else(changed)?
                .trim_end_matches(['\n', '\r']);
            if target.is_empty() || target.contains(['\0', '\n', '\r']) {
                return Err(changed());
            }
            workspace
                .root
                .join(target)
                .canonicalize()
                .map_err(|_| changed())?
        };
        for root in [&gitdir, &common_dir] {
            for relative in [
                "HEAD",
                "index",
                "config",
                "config.worktree",
                "commondir",
                "gitdir",
                "packed-refs",
                "info/sparse-checkout",
                "info/attributes",
                "objects/info/alternates",
            ] {
                add(root, Path::new(relative))?;
            }
        }
    }
    if state.len() > 512 {
        return Err(limited());
    }
    let pins = state
        .chunks(64)
        .map(DataArtifactPins::capture)
        .collect::<Result<Vec<_>>>()?;
    Ok((pins, required))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{factory::FactoryCapabilities, goal_plan::BudgetLimits};
    use agentbaton_config::runtime::{RuntimePlan, RuntimeProvider};
    use std::{os::unix::fs::PermissionsExt, process::Command};
    struct Fixture {
        _temp: tempfile::TempDir,
        store: Store,
        selection: FactoryScopeSelection,
        companion: PathBuf,
        raw: String,
        input: PathBuf,
    }
    fn git(root: &Path, args: &[&str]) -> String {
        let output = Command::new("git")
            .env_clear()
            .env("PATH", "/usr/bin:/bin")
            .env("GIT_CONFIG_GLOBAL", "/dev/null")
            .env("GIT_CONFIG_NOSYSTEM", "1")
            .args([
                "-c",
                "user.name=Generated fixture",
                "-c",
                "user.email=fixture@invalid",
                "-c",
                "core.hooksPath=/dev/null",
                "-C",
            ])
            .arg(root)
            .args(args)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        String::from_utf8(output.stdout).unwrap().trim().into()
    }
    impl Fixture {
        fn new() -> Self {
            let temp = tempfile::Builder::new()
                .permissions(fs::Permissions::from_mode(0o700))
                .tempdir()
                .unwrap();
            let base = temp.path().canonicalize().unwrap();
            let database = base.join("baton.sqlite3");
            drop(
                OpenOptions::new()
                    .create_new(true)
                    .write(true)
                    .mode(0o600)
                    .open(&database)
                    .unwrap(),
            );
            let mut store = Store::open(&database).unwrap();
            let source = base.join("source");
            fs::create_dir(&source).unwrap();
            git(&source, &["init", "--initial-branch=main"]);
            fs::write(source.join("input"), b"generated fixed data").unwrap();
            fs::write(source.join("unselected"), b"approved other bytes").unwrap();
            git(&source, &["add", "input", "unselected"]);
            git(&source, &["commit", "-m", "generated"]);
            let head = git(&source, &["rev-parse", "HEAD"]);
            let project = store
                .import_project(&source, "Generated readonly Factory fixture", "project")
                .unwrap();
            let managed = base.join("managed");
            fs::create_dir(&managed).unwrap();
            fs::set_permissions(&managed, fs::Permissions::from_mode(0o700)).unwrap();
            let workspace = store
                .create_workspace(&project.id, project.revision, &head, &managed, "workspace")
                .unwrap();
            let companion = base.join("generated-not-executed-companion");
            fs::write(
                &companion,
                b"Only hashed; no child process in this unit fixture\n",
            )
            .unwrap();
            fs::set_permissions(&companion, fs::Permissions::from_mode(0o700)).unwrap();
            // Explicit synthetic ready metadata. This is not a Provider probe or
            // native OS dialog; real generated ACP/MCP tests are separate.
            let connection = serde_json::json!({"id":"fixture-connection","name":"Synthetic not executed","provider":"custom_acp","protocol_route":"custom_acp","executable":companion,"arguments":[],"executable_sha256":agentbaton_workspaces::validation::sha256(&fs::read(&companion).unwrap()),"environment_id":"fixture-environment","identity_ref":"unknown","host_id":"local","config_revision":"fixture-config","runtime_plan":RuntimePlan::empty(RuntimeProvider::CustomAcp),"probe_state":"ready","revision":1,"approval_id":"synthetic-no-provider","capability_snapshot_id":"fixture-capability","identity_status":"unknown","config_status":"baton_managed","created_at":"2026-10-28T00:00:00Z","version_evidence":null});
            store
                .conn
                .execute(
                    "INSERT INTO connections(id,document) VALUES('fixture-connection',?1)",
                    [connection.to_string()],
                )
                .unwrap();
            let task = store
                .create_registered(
                    &project.id,
                    "Read only the fixed generated artifact",
                    "task",
                )
                .unwrap();
            let grant = store
                .create_grant(
                    &project.id,
                    &workspace.id,
                    "fixture-connection",
                    4,
                    1,
                    30_000,
                    true,
                    "trusted-host-fixture-grant",
                )
                .unwrap();
            let budget = BudgetLimits {
                attempts: 4,
                parallel: 1,
                runtime_ms: 30_000,
                output_bytes: 4096,
                children: 1,
                reworks: 0,
                tokens: None,
                cost_microunits: None,
            };
            let selection = FactoryScopeSelection {
                root_task_id: task.id,
                expected_task_revision: task.revision,
                grant_id: grant.id,
                expected_grant_revision: grant.revision,
                connection_ids: vec!["fixture-connection".into()],
                workspace_ids: vec![workspace.id],
                inputs: vec![ArtifactRequirement {
                    artifact_id: "input".into(),
                    relative_path: "input".into(),
                    max_bytes: 1024,
                    expected_sha256: Some(agentbaton_workspaces::validation::sha256(
                        b"generated fixed data",
                    )),
                }],
                outputs: vec![ArtifactRequirement {
                    artifact_id: "output".into(),
                    relative_path: "output".into(),
                    max_bytes: 1024,
                    expected_sha256: None,
                }],
                recipients: vec![],
                max_depth: 1,
                max_children: 1,
                max_total_nodes: 2,
                root_budget: budget.clone(),
                project_budget: budget,
                ttl_ms: 30_000,
                capabilities: FactoryCapabilities {
                    delegate_task: true,
                    resume_parent_as_new_attempt: true,
                    child_planning: false,
                    child_goal_execution: false,
                    create_workspace: false,
                },
            };
            Self {
                _temp: temp,
                store,
                selection,
                companion,
                raw: "generated exact Owner request nonce A".into(),
                input: workspace.root.join("input"),
            }
        }
        fn plan(&self) -> FactoryReadPlan {
            self.store
                .prepare_factory_owner_read(
                    "factory_scopes.propose",
                    &serde_json::to_value(&self.selection).unwrap(),
                    None,
                    Some("fixture-read"),
                    &self.raw,
                    Some(self.companion.clone()),
                )
                .unwrap()
                .unwrap()
        }
        fn observe(&self, plan: FactoryReadPlan) -> DataInputWitness {
            let deadline = Instant::now() + Duration::from_secs(30);
            let witness = DataInputWitness::restore(
                vec![],
                agentbaton_workspaces::validation::sha256(self.raw.as_bytes()),
                deadline,
            )
            .unwrap();
            plan.execute(witness, Arc::new(AtomicBool::new(false)), deadline)
                .unwrap()
        }
    }
    #[test]
    fn readonly_worker_preserves_rows_until_actor_commits_the_exact_proposal() {
        let mut f = Fixture::new();
        let seq = f.store.sequence().unwrap();
        let witness = f.observe(f.plan());
        assert!(witness.for_request(&f.raw));
        assert!(!witness.for_request("different raw nonce"));
        assert_eq!(f.store.sequence().unwrap(), seq);
        f.store.data_input = Some(witness);
        let p = f
            .store
            .propose_factory_scope(&f.selection, "fixture-read", &f.companion)
            .unwrap();
        f.store.data_input = None;
        assert_eq!(p.kind, "factory");
        assert_eq!(
            f.store
                .factory_record_counts(&f.selection.root_task_id)
                .unwrap()
                .scopes,
            0
        );
        fs::remove_file(&f.companion).unwrap();
        assert!(
            f.store
                .prepare_factory_owner_read(
                    "factory_scopes.propose",
                    &serde_json::to_value(&f.selection).unwrap(),
                    None,
                    Some("fixture-read"),
                    "new nonce historical same key",
                    Some(f.companion.clone())
                )
                .unwrap()
                .is_none(),
            "historical reply must require neither image nor new hash"
        );
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "fixture-read", &f.companion)
                .unwrap()
                .id,
            p.id
        );
    }
    #[test]
    fn wrong_owner_start_revision_never_prepares_an_observation_or_reads_the_program() {
        let mut f = Fixture::new();
        let p = f
            .store
            .propose_factory_scope(&f.selection, "cas-scope", &f.companion)
            .unwrap();
        let scope: super::super::FactoryScope =
            serde_json::from_value(f.store.finalize_proposal(&p.id, p.revision).unwrap()).unwrap();
        fs::remove_file(&f.companion).unwrap();
        let seq = f.store.sequence().unwrap();
        let error = f
            .store
            .prepare_factory_owner_read(
                "factory_runs.start",
                &serde_json::json!({"scope_id":scope.id}),
                Some(scope.revision + 1),
                Some("must-not-prepare-reader"),
                "wrong-cas-original-raw",
                None,
            )
            .err()
            .expect("wrong CAS must return an error, not a read plan");
        assert_eq!(error.code, "STALE_REVISION");
        assert_eq!(error.side_effect_state, "not_started");
        assert_eq!(f.store.sequence().unwrap(), seq);
        assert_eq!(
            f.store
                .factory_record_counts(&scope.root_task_id)
                .unwrap()
                .runs,
            0
        );
    }
    #[test]
    fn readonly_query_only_connection_refuses_real_writes_without_mutating_schema_or_journal() {
        let f = Fixture::new();
        let plan = f.plan();
        let sequence = f.store.sequence().unwrap();
        let readonly = plan
            .database
            .open_readonly(Instant::now() + Duration::from_secs(30))
            .unwrap();
        assert!(readonly.is_readonly(rusqlite::MAIN_DB).unwrap());
        assert_eq!(
            readonly
                .pragma_query_value(None, "query_only", |r| r.get::<_, i64>(0))
                .unwrap(),
            1
        );
        assert!(readonly
            .execute("INSERT INTO events(document) VALUES('{}')", [])
            .is_err());
        assert!(readonly.execute_batch("PRAGMA user_version=14;").is_err());
        assert!(readonly
            .execute_batch("CREATE TABLE cannot_create(value TEXT);")
            .is_err());
        assert_eq!(f.store.sequence().unwrap(), sequence);
        assert_eq!(
            f.store
                .conn
                .pragma_query_value(None, "user_version", |r| r.get::<_, u32>(0))
                .unwrap(),
            13
        );
    }
    #[test]
    fn actor_business_rows_are_matched_before_any_file_read_on_the_readonly_connection() {
        let f = Fixture::new();
        let plan = f.plan();
        f.store.conn.execute("UPDATE tasks SET document=json_set(document,'$.goal','changed before worker') WHERE id=?1",[&f.selection.root_task_id]).unwrap();
        fs::remove_file(&f.companion).unwrap();
        let deadline = Instant::now() + Duration::from_secs(30);
        let witness = DataInputWitness::restore(
            vec![],
            agentbaton_workspaces::validation::sha256(f.raw.as_bytes()),
            deadline,
        )
        .unwrap();
        assert_eq!(
            plan.execute(witness, Arc::new(AtomicBool::new(false)), deadline)
                .err()
                .unwrap()
                .code,
            "INPUT_CHANGED",
            "changed rows must refuse before missing companion lookup"
        );
    }
    #[test]
    fn actor_rechecks_connection_config_after_worker_observation_without_hashing_again() {
        let mut f = Fixture::new();
        let witness = f.observe(f.plan());
        f.store.conn.execute("UPDATE connections SET document=json_set(document,'$.config_revision','unapproved') WHERE id='fixture-connection'",[]).unwrap();
        f.store.data_input = Some(witness);
        let seq = f.store.sequence().unwrap();
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "deny-current-config", &f.companion)
                .unwrap_err()
                .code,
            "INPUT_CHANGED"
        );
        assert_eq!(f.store.sequence().unwrap(), seq);
    }
    #[test]
    fn actor_rejects_unselected_tracked_change_after_clean_worker_observation() {
        let mut f = Fixture::new();
        let witness = f.observe(f.plan());
        fs::write(
            f.input.parent().unwrap().join("unselected"),
            b"different other bytes",
        )
        .unwrap();
        let seq = f.store.sequence().unwrap();
        f.store.data_input = Some(witness);
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "deny-unselected", &f.companion)
                .unwrap_err()
                .code,
            "INPUT_CHANGED"
        );
        assert_eq!(f.store.sequence().unwrap(), seq);
    }
    #[test]
    fn actor_rejects_new_untracked_after_clean_worker_observation() {
        let mut f = Fixture::new();
        let witness = f.observe(f.plan());
        fs::write(
            f.input.parent().unwrap().join("unapproved"),
            b"generated untracked bytes",
        )
        .unwrap();
        let seq = f.store.sequence().unwrap();
        f.store.data_input = Some(witness);
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "deny-untracked", &f.companion)
                .unwrap_err()
                .code,
            "INPUT_CHANGED"
        );
        assert_eq!(f.store.sequence().unwrap(), seq);
    }
    #[test]
    fn actor_rejects_same_bytes_replaced_input_after_worker_observation() {
        let mut f = Fixture::new();
        let witness = f.observe(f.plan());
        let bytes = fs::read(&f.input).unwrap();
        fs::remove_file(&f.input).unwrap();
        fs::write(&f.input, bytes).unwrap();
        f.store.data_input = Some(witness);
        let seq = f.store.sequence().unwrap();
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "deny-replaced-input", &f.companion)
                .unwrap_err()
                .code,
            "INPUT_CHANGED"
        );
        assert_eq!(f.store.sequence().unwrap(), seq);
    }
    #[test]
    fn actor_rejects_loose_head_reference_drift_after_clean_worker_observation() {
        let mut f = Fixture::new();
        let root = f.input.parent().unwrap();
        let head = git(root, &["rev-parse", "HEAD"]);
        git(
            root,
            &["symbolic-ref", "HEAD", "refs/heads/generated-factory-ref"],
        );
        git(
            root,
            &["update-ref", "refs/heads/generated-factory-ref", &head],
        );
        let witness = f.observe(f.plan());
        // A second raw commit with identical tree does not touch working-tree
        // files or index. Only the loose HEAD target changes after observation.
        let tree = git(root, &["rev-parse", "HEAD^{tree}"]);
        let replacement = git(
            root,
            &[
                "commit-tree",
                &tree,
                "-p",
                &head,
                "-m",
                "generated alternate",
            ],
        );
        git(
            root,
            &[
                "update-ref",
                "refs/heads/generated-factory-ref",
                &replacement,
            ],
        );
        let seq = f.store.sequence().unwrap();
        f.store.data_input = Some(witness);
        assert_eq!(
            f.store
                .propose_factory_scope(&f.selection, "deny-ref-drift", &f.companion)
                .unwrap_err()
                .code,
            "INPUT_CHANGED"
        );
        assert_eq!(f.store.sequence().unwrap(), seq);
    }
    #[test]
    fn clean_observation_covers_nested_entries_symlink_replacement_and_ignored_files() {
        for mode in ["nested", "symlink", "ignored"] {
            let mut f = Fixture::new();
            let root = f.input.parent().unwrap();
            fs::create_dir(root.join("nested")).unwrap();
            fs::write(root.join("nested/tracked"), b"approved nested").unwrap();
            fs::write(root.join(".gitignore"), b"ignored-fixture\n").unwrap();
            git(root, &["add", "nested/tracked", ".gitignore"]);
            git(root, &["commit", "-m", "generated nested fixture"]);
            // Refresh the synthetic fixture's explicitly approved base so the
            // actual production full Git admission still runs before mutation.
            let head = git(root, &["rev-parse", "HEAD"]);
            f.store.conn.execute("UPDATE managed_workspaces SET document=json_set(document,'$.base_revision',?1,'$.identity.kind.head',?1) WHERE id=?2",rusqlite::params![head,&f.selection.workspace_ids[0]]).unwrap();
            f.store
                .conn
                .execute(
                    "UPDATE execution_grants SET document=json_set(document,?1,?2) WHERE id=?3",
                    rusqlite::params![
                        format!(
                            "$.workspace_bindings.{}.kind.head",
                            f.selection.workspace_ids[0]
                        ),
                        head,
                        &f.selection.grant_id
                    ],
                )
                .unwrap();
            let witness = f.observe(f.plan());
            match mode {
                "nested" => {
                    fs::write(root.join("nested/new"), b"new nested untracked").unwrap();
                }
                "symlink" => {
                    fs::remove_file(root.join("unselected")).unwrap();
                    std::os::unix::fs::symlink("input", root.join("unselected")).unwrap();
                }
                _ => {
                    fs::write(
                        root.join("ignored-fixture"),
                        b"conservatively observed even if ignored",
                    )
                    .unwrap();
                }
            }
            let seq = f.store.sequence().unwrap();
            f.store.data_input = Some(witness);
            assert_eq!(
                f.store
                    .propose_factory_scope(&f.selection, "deny-tree-drift", &f.companion)
                    .unwrap_err()
                    .code,
                "INPUT_CHANGED",
                "{mode}"
            );
            assert_eq!(f.store.sequence().unwrap(), seq);
        }
    }
    #[test]
    fn tree_and_aggregate_query_budgets_fail_explicitly_before_extending_observations() {
        let f = Fixture::new();
        let control = FactoryReadControl {
            cancel: Arc::new(AtomicBool::new(false)),
            deadline: Instant::now() + Duration::from_secs(30),
        };
        let mut budget = TreeBudget {
            entries: MAX_TREE_ENTRIES,
            directories: 0,
            names: 0,
        };
        assert_eq!(
            GitTreeObservation::capture(f.input.parent().unwrap(), &control, &mut budget)
                .err()
                .unwrap()
                .code,
            "RESOURCE_LIMIT"
        );
        let mut remaining = (4_194_304, 100_000);
        let sql = "SELECT hex(zeroblob(262144)) AS value";
        for _ in 0..8 {
            QueryProof::capture_bounded(&f.store.conn, sql, vec![], &mut remaining).unwrap();
        }
        assert_eq!(remaining.0, 0);
        assert_eq!(
            QueryProof::capture_bounded(&f.store.conn, sql, vec![], &mut remaining)
                .err()
                .unwrap()
                .code,
            "RESOURCE_LIMIT"
        );
        assert_eq!(remaining.0, 0);
    }
    #[test]
    fn cancellation_and_original_deadline_refuse_before_readonly_database_or_image_open() {
        for cancel in [false, true] {
            let f = Fixture::new();
            let plan = f.plan();
            fs::remove_file(&f.companion).unwrap();
            let deadline = Instant::now() + Duration::from_secs(30);
            let witness = DataInputWitness::restore(
                vec![],
                agentbaton_workspaces::validation::sha256(f.raw.as_bytes()),
                deadline,
            )
            .unwrap();
            let execution_deadline = if cancel {
                deadline
            } else {
                Instant::now() - Duration::from_millis(1)
            };
            assert_eq!(
                plan.execute(
                    witness,
                    Arc::new(AtomicBool::new(cancel)),
                    execution_deadline
                )
                .err()
                .unwrap()
                .code,
                if cancel {
                    "CANCEL_REQUESTED"
                } else {
                    "DEADLINE_EXCEEDED"
                }
            );
        }
    }
    #[test]
    fn private_database_replacement_is_rejected_before_readonly_connection() {
        let f = Fixture::new();
        let plan = f.plan();
        let old = PathBuf::from(f.store.conn.path().unwrap());
        fs::rename(&old, old.with_extension("retained-original")).unwrap();
        drop(
            OpenOptions::new()
                .create_new(true)
                .write(true)
                .mode(0o600)
                .open(&old)
                .unwrap(),
        );
        let deadline = Instant::now() + Duration::from_secs(30);
        let witness = DataInputWitness::restore(
            vec![],
            agentbaton_workspaces::validation::sha256(f.raw.as_bytes()),
            deadline,
        )
        .unwrap();
        assert_eq!(
            plan.execute(witness, Arc::new(AtomicBool::new(false)), deadline)
                .err()
                .unwrap()
                .code,
            "INPUT_CHANGED"
        );
    }
}
