from pathlib import Path
import json,hashlib,subprocess
root=Path('/workspace/.worktrees/factory-runtime-integration');original=Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/manifest.json')
raw=original.read_bytes();assert hashlib.sha256(raw).hexdigest()=='6cdfc423d2c15c5f91087350fa9742123bfdf58a1f88eca3434502f75cb5cd01';source=json.loads(raw)
old=json.loads(Path('/workspace/.onboarding/factory-candidate-12e/manifest.json').read_text())
for name,digest in source['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,tool in source['binaries'].items():
 p=Path(tool['path']);assert p.stat().st_size==tool['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==tool['sha256'],name
for name,digest in old['frontend']['assets'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
m={'schema':13,'source_equivalent_commit':'db949cb57d6fbcec5a47f1b2da8c271d29b1732e','compiled_base_commit':source['build_base_commit'],'build_identity':source['source_identity'],'integration_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binaries':{n:t['sha256'] for n,t in source['binaries'].items()},'tool_details':source['binaries'],'original_manifest':{'path':str(original),'sha256':hashlib.sha256(raw).hexdigest()},'production_sources':source['sources'],'all46_source_hashes_match_integration':True,'frontend':old['frontend'],'limits':'Source-equivalent working-source build, not exact clean CI build. Independent CAS review and Root three flows separate; no native/live Provider/full acceptance claim.'}
out=Path('/workspace/.onboarding/factory-candidate-db949');out.mkdir(exist_ok=False);p=out/'manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
oldwrapper=Path('/workspace/.onboarding/factory-browser-root/run-reviewed-12e-22cc.py').read_text()
new=oldwrapper.replace('reviewed-12e-22cc-','reviewed-db949-744-').replace('factory-candidate-12e','factory-candidate-db949').replace('390561cd633086bfd77b4f64790cbdbabfb0aa542659c0e25b75dd5ef56b1a05',h).replace('b7d9c16c4582ba3d486ad1e4fec693563280d35953b1a73c1290f8fde0ae3ea4','4aa84fb34529e6712923e5783e7824d3965adbce7742ca8386b22a9d45264162').replace('Core explicitly yielded CPU; unique Cargo lease retained by Core but idle for this runtime','Root exclusive CPU/Cargo window; Core explicitly idle, no Cargo in runtime')
p=Path('/workspace/.onboarding/factory-browser-root/run-reviewed-db949-744.py');assert not p.exists();p.write_text(new)
print(json.dumps({'normalized_manifest_sha256':h,'integration':m['integration_commit'],'production_sources':len(m['production_sources']),'actual_runtime':'not_run pending independent CAS review','wrapper_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
