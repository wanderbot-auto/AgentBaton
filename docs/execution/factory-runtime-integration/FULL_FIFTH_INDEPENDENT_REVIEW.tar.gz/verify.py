import pathlib,json,hashlib,re,subprocess,os
p=pathlib.Path('/workspace/.onboarding/factory-root-rust-regression-shared-budget');out=pathlib.Path('/workspace/.onboarding/factory-full-fifth-review');root=pathlib.Path('/workspace/.worktrees/factory-runtime-integration');sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((p/'MANIFEST.json').read_bytes())=='486b0265ca52412a60000734a3d0b564cb185f49b021b6c6b5ea73e418a7114e';assert sha((p/'RESULT.json').read_bytes())=='9c47e31610d2c666d66c9af59fd4a6361104fcb00465f1aa68b8f4e7bd1b8ca7';m=json.loads((p/'MANIFEST.json').read_bytes());before=json.loads((p/'BEFORE.json').read_bytes());after=json.loads((p/'AFTER.json').read_bytes());result=json.loads((p/'RESULT.json').read_bytes());head='6d666ed3a52ad14889440b84a903c58e050fa24c';assert m['source']==before['head']==after['head']==result['source']==head
assert len(m['files'])==157
for item in m['files']:
 f=p/item['path'];assert f.is_file() and f.stat().st_size==item['bytes'] and sha(f.read_bytes())==item['sha256'],str(f)
actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()};declared={v['path'] for v in m['files']};assert actual-declared=={'MANIFEST.json','composition.index'} and not(declared-actual)
assert before['status']==after['status']=='' and after['changed_tracked_files']==[];assert len(before['tracked_files'])==after['tracked_files_equal']==1308
for f,h in before['tracked_files'].items():assert sha((root/f).read_bytes())==h,f
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==head;assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain=v1'])
assert before['tracked_files']['crates/core/tests/sessions_ipc.rs']=='8c1c84db1593130e2b6fa6c7df1e448d02b723b895d466162e0f2f10b93afc69'
for n,b in before['shared_debug_tools'].items():
 a=after['shared_debug_tools'][n];assert all(a[k]==b[k] for k in ['path','sha256','bytes','inode','nlink']);f=pathlib.Path(a['path']);s=f.stat();assert sha(f.read_bytes())==a['sha256'] and s.st_size==a['bytes'] and s.st_ino==a['inode'] and s.st_nlink==a['nlink']
redirect=json.loads((p/'GENERATED_REDIRECT.json').read_bytes());removed=json.loads((p/'GENERATED_REDIRECT_REMOVED.json').read_bytes());assert len(redirect['links'])==4;assert removed['removed_only_own_symlinks']==[x['path'] for x in redirect['links']]
for x in redirect['links']:assert not os.path.lexists(x['path']);assert pathlib.Path(x['target']).is_dir()
assert not pathlib.Path(redirect['root_parent']['path']).exists()
commands=json.loads((p/'COMMAND_RESULTS.json').read_bytes());assert len(commands)==3 and commands==after['commands']==result['commands'];starts=[]
for c in commands:
 n=c['name'];assert c==json.loads((p/(n+'-result.json')).read_bytes());s=json.loads((p/(n+'-start.json')).read_bytes());assert s['command']==c['command'];assert c['exit_code']==0 and c['interruption'] is None;assert sha((p/(n+'.log')).read_bytes())==c['log_sha256'];assert s['environment']['CARGO_PROFILE_TEST_DEBUG']=='0' and s['dev_debug_override']=='unset';assert s['environment']['RUST_TEST_THREADS']=='1' and s['environment']['CARGO_BUILD_JOBS']=='2';starts.append(s['start_unix']);assert min(v['free_bytes'] for v in c['disk_samples'])>=200*1024*1024
assert starts[0]+commands[0]['elapsed_seconds']<starts[1] and starts[1]+commands[1]['elapsed_seconds']<=starts[2]+0.1
text=(p/'workspace-tests.log').read_text();matches=list(re.finditer(r'(?m)^(     Running .+|   Doc-tests .+)\n',text));outer=[];nested=[];docs=[]
for i,match in enumerate(matches):
 body=text[match.end():matches[i+1].start() if i+1<len(matches) else len(text)];summaries=list(re.finditer(r'(?m)^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$',body));assert summaries
 entry=match[1].strip();s=summaries[-1];v={'entry':entry,'passed':int(s[2]),'failed':int(s[3]),'ignored':int(s[4]),'summary':s[0]};names=set(re.findall(r'(?m)^test ([\w:]+) \.\.\.',body))
 if 'Doc-tests' in entry:docs.append(v)
 else:assert len(names)==v['passed'],(entry,len(names),v['passed']);v['unique_names']=sorted(names);outer.append(v)
 for ns in summaries[:-1]:
  prefix=body[:ns.start()];which=re.findall(r'(?m)^test ([\w:]+) \.\.\.',prefix)[-1];assert which in names;nested.append({'entry':entry,'name':which,'passed':int(ns[2]),'failed':int(ns[3]),'summary':ns[0]})
assert sum(x['passed'] for x in outer)==645 and sum(x['failed'] for x in outer)==0 and sum(x['ignored'] for x in outer)==0
assert len(nested)==sum(x['passed'] for x in nested)==5 and sum(x['failed'] for x in nested)==0
assert sum(x['passed'] for x in docs)==7 and sum(x['failed'] for x in docs)==0
assert len(re.findall(r'(?m)^test .+ - compile fail \.\.\. ok$',text))==7
sessions=[v for v in outer if v['entry'].startswith('Running tests/sessions_ipc.rs')][0];factory=[v for v in outer if v['entry'].startswith('Running tests/factory_runtime_ipc.rs')][0];assert sessions['passed']==57 and factory['passed']==18
assert all(n in sessions['unique_names'] for n in ['actual_goal_shared_budget_clean_exhaustion_refuses_ordinary_and_lowlevel_attempts','actual_goal_shared_budget_dirty_inputs_refuse_ordinary_and_lowlevel_attempts','actual_goal_shared_budget_remaining_allows_bounded_ordinary_without_refunding_consumption'])
old=[]
for suffix,passed in [('',150),('-schema13',170),('-pre13',224),('-setup-fixed',421)]:
 d=pathlib.Path('/workspace/.onboarding/factory-root-rust-regression'+suffix);f=d/'RESULT.json';o=json.loads(f.read_bytes());old.append({'directory':str(d),'result_sha256':sha(f.read_bytes()),'expected_outer_passes':passed,'status':o.get('state')});assert ('FAIL' in o.get('state','')) or any(c.get('exit_code')==101 for c in o.get('commands',[]))
pref=json.loads((p/'PREFLIGHT_AUTHOR_VS_MERGED_SOURCE.json').read_bytes());assert pref['exit_code']==1 and pref['cargo_started'] is False;assert pref['expected_author_source'].startswith('19ce') and pref['actual_merged_source']==before['tracked_files']['crates/core/tests/sessions_ipc.rs'];assert json.loads((p/'COMPOSITION_ROOT_CHECK.json').read_bytes())['pass'] is True
v={'state':'PASS independent evidence audit only, no new product execution','source':head,'verified_manifest_files':len(m['files']),'verified_tracked_source_files':1308,'commands':[{'name':c['name'],'command':c['command'],'exit_code':0,'wall_seconds':c['elapsed_seconds'],'log_sha256':c['log_sha256']} for c in commands],'outer_cases':645,'outer_failures':0,'outer_ignored':0,'outer_suites':outer,'nested_repetitions_not_added':nested,'compilefail_doctests':7,'doctest_suites':docs,'old_full_failures_unchanged':old,'preflight_guard_failure_preserved':pref,'profile':'Linux TEST_DEBUG0, jobs2 serialtests; not CI debug2/Mac/Native/realaccount/provider/fullFactory','tools':after['shared_debug_tools'],'four_owned_redirects_removed':True}
(out/'VERIFICATION.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ['state','source','verified_manifest_files','verified_tracked_source_files','outer_cases','outer_failures','outer_ignored','nested_repetitions_not_added','compilefail_doctests']},ensure_ascii=False))
