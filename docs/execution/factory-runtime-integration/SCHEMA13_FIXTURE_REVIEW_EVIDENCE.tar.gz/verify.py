import pathlib,subprocess,hashlib,json,difflib,re
root=pathlib.Path('/workspace/.worktrees/factory-runtime-core');out=pathlib.Path('/workspace/AgentBaton/.onboarding/factory-schema13-fixture-review')
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a]);sha=lambda b:hashlib.sha256(b).hexdigest()
base='dac6d80ebebcc9285c1a3eadafc81668c5b9567c';head='116506ace23a073f1f60b1968110258aa4a8a0df'
files=git('diff','--name-only',base,head).decode().splitlines();tests=[f for f in files if f.startswith('crates/core/tests/')];assert len(tests)==13
assert all(f in tests or f.startswith('docs/execution/factory-runtime-core/') for f in files)
counts={'current':0,'future_input':0,'future_name':0,'diagnostic':0};checks={}
for f in tests:
 before=git('show',f'{base}:{f}');after=git('show',f'{head}:{f}');a=before.decode().splitlines(keepends=True);b=after.decode().splitlines(keepends=True);normalized=[];changed=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag=='equal':normalized.extend(b[k:l]);continue
  assert tag=='replace' and j-i==l-k,(f,tag)
  for x,y,ai,bi in zip(a[i:j],b[k:l],range(i,j),range(k,l)):
   if x.strip() in ('12','12,') and y.strip()==x.strip().replace('12','13'):
    assert 'pragma_query_value' in ''.join(a[max(0,ai-6):ai]),f
    kind='current'
   elif 'PRAGMA user_version=13' in x and y==x.replace('PRAGMA user_version=13','PRAGMA user_version=14'):
    kind='future_input'
    # Existing fixture still asserts exact rejection and raw bytes following this input.
    tail=''.join(a[ai:ai+35]);assert 'VERSION_UNSUPPORTED' in tail,f
   elif x.lstrip().startswith('fn ') and y==x.replace('schema13','schema14').replace('v13','v14'):
    kind='future_name'
   elif 'CI fixture must link exact schema12 source' in x and y==x.replace('schema12','schema13'):
    kind='diagnostic'
   else:raise AssertionError((f,x,y))
   normalized.append(x);counts[kind]+=1;changed.append({'old_line':ai+1,'new_line':bi+1,'kind':kind,'old':x.rstrip('\n'),'new':y.rstrip('\n')})
 assert ''.join(normalized).encode()==before,f
 assert (root/f).read_bytes()==after,f
 for sub,data in [('before',before),('after',after)]:
  p=out/sub/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 checks[f]={'before_sha256':sha(before),'after_sha256':sha(after),'normalized_after_equals_before':True,'changes':changed}
assert counts=={'current':12,'future_input':7,'future_name':6,'diagnostic':1},counts
mp=pathlib.Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/manifest.json');m=json.loads(mp.read_bytes());assert len(m['sources'])==46
for f,h in m['sources'].items():
 assert sha(git('show',f'{base}:{f}'))==h;assert sha(git('show',f'{head}:{f}'))==h;assert sha((root/f).read_bytes())==h
cargo=[f for f in git('ls-tree','-r','--name-only',head).decode().splitlines() if pathlib.Path(f).name in ['Cargo.lock','Cargo.toml']]
for f in cargo:assert git('show',f'{base}:{f}')==git('show',f'{head}:{f}'),f
snap=root/'artifacts/factory-runtime-core/schema13-fixture-source-snapshot.json';sm=json.loads(snap.read_bytes());assert sm['source_head']==head
for f,v in sm['test_files'].items():assert checks[f]['before_sha256']==v['before_sha256'] and checks[f]['after_sha256']==v['after_sha256']
for p,h in sm['original_full_failure']['references'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
log=pathlib.Path('/workspace/.onboarding/factory-root-rust-regression/workspace-tests.log').read_text();assert 'left: 13\n right: 12' in log
res={'state':'PASS independent static byte normalization, not runtime tests','base_commit':base,'source_head':head,'changes':counts,'files':checks,'unchanged_production_bindings':m['sources'],'unchanged_cargo_manifests_and_locks':cargo,'author_snapshot_sha256':sha(snap.read_bytes()),'old_full_failure':sm['original_full_failure'],'new_runtime_execution':'NOT_RUN by this reviewer; Root will rerun full suite on integrated exact source'}
(out/'AUTHOR_SNAPSHOT.json').write_bytes(snap.read_bytes());(out/'VERIFICATION.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'state':'PASS','tests':len(tests),'counts':counts,'prod':len(m['sources']),'cargo_manifests_and_locks':len(cargo),'author_snapshot_sha256':sha(snap.read_bytes())}))
