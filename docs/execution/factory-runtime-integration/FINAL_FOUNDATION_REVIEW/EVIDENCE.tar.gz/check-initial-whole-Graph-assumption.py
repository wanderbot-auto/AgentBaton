import ast,hashlib,io,json,subprocess,tarfile,shutil
from pathlib import Path,PurePosixPath
O=Path(__file__).parent;R=Path('/workspace/.worktrees/factory-runtime-integration');B='6d666ed3a52ad14889440b84a903c58e050fa24c';I='bb8c093e613e7dbfcf6d165d3258d5bb75830c71';HEAD='1f325d80561ea48301f5f72b2ecf4c7c9745efb9';MERGE='44d87fdb54f3f9716aaa0d2e87673362a8be45e1';G=lambda *a:subprocess.check_output(['git',*a],cwd=R);H=lambda b:hashlib.sha256(b).hexdigest();read=lambda c,p:G('show',c+':'+p)
assert G('rev-parse','HEAD').decode().strip()==HEAD and G('status','--porcelain')==b'';assert G('diff',B,HEAD,'--','crates','apps/cli','apps/daemon','Cargo.toml','Cargo.lock','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock')==b'';assert G('diff','--check',B,HEAD)==b''
for p in ['apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs','scripts/validate_infrastructure.py','tests/infrastructure/test_runtime_policy.py']:
 assert read(HEAD,p)==read(I,p),p
assert read(HEAD,'apps/desktop/tests/goal-graph-real-ipc.py')==read(I,'apps/desktop/tests/goal-graph-real-ipc.py');assert H(read(HEAD,'apps/desktop/tests/goal-graph-real-ipc.py'))=='a054989b5a20972f332312c3bb7ddf9e87e0ca17181448c4a405459451105ed1'
wf=read(HEAD,'.github/workflows/product.yml');old=read(B,'.github/workflows/product.yml');assert old.count(b'    timeout-minutes: 45')==1 and wf==old.replace(b'    timeout-minutes: 45',b'    timeout-minutes: 60',1)
# Conflict1: preserve the 130 IDs/status/WP and both parents' verified slices.
p='docs/execution/requirements-progress.json';olds=[json.loads(read(c,p))for c in [B,I]];now=json.loads(read(HEAD,p));rows={r['id']:r for r in now['requirements']};assert len(rows)==len(now['requirements'])==130
for prev in olds:
 assert prev['design_version']==now['design_version']and prev['approval_id']==now['approval_id']
 assert set(r['id']for r in prev['requirements'])==set(rows)
 for r in prev['requirements']:
  n=rows[r['id']];assert r['status']==n['status']and r['work_package']==n['work_package'];assert all(v in n.get('verified_slices',[])for v in r.get('verified_slices',[]));assert n.get('coverage')!='complete'
# Conflict2: retain both non-common STATUS prefixes and the shared historical suffix.
p='docs/execution/STATUS.md';a=read(B,p).decode().splitlines(True);b=read(I,p).decode().splitlines(True);common=0
while common<min(len(a),len(b))and a[-1-common]==b[-1-common]:common+=1
text=read(HEAD,p).decode();assert common>0 and ''.join(a[:-common])in text and ''.join(b[:-common])in text and ''.join(a[-common:])in text
# Conflict3: incoming reviewed registry with only final STATUS hash refresh.
a=json.loads(read(I,'BOOTSTRAP_MANIFEST.json'));b=json.loads(read(HEAD,'BOOTSTRAP_MANIFEST.json'));assert set(a)==set(b)and a['algorithm']==b['algorithm']and a['note']==b['note']and set(a['files'])==set(b['files'])and len(b['files'])==93;assert[n for n in a['files']if a['files'][n]!=b['files'][n]]==['docs/execution/STATUS.md']
for n,h in b['files'].items():assert H(read(HEAD,n))==h
# Conflict4: strict incoming Owner guards preserved, only the exact schema predicate advances to13 and table set extends.
p='scripts/native-owner-dialog-smoke.py';old=read(I,p).decode();new=read(HEAD,p).decode();A=ast.parse(old);C=ast.parse(new);fa={n.name:ast.get_source_segment(old,n)for n in A.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};fb={n.name:ast.get_source_segment(new,n)for n in C.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};assert set(fa)==set(fb)
for name in fa:
 expect=fa[name].replace("json_exact(value.get('schema_version'), 12)","json_exact(value.get('schema_version'), 13)")if name in ['pending_error','approved_error']else fa[name];assert fb[name]==expect,name
assert new.count("json_exact(value.get('schema_version'), 13)")==2 and "json_exact(value.get('schema_version'), 12)"not in new
# No execution: literal table/AST verification only.
ns={}
for n in C.body:
 if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in ['GOAL_TABLES','FACTORY_TABLES','ZERO_TABLES']for t in n.targets):exec(compile(ast.Module(body=[n],type_ignores=[]),'literal-table-set','exec'),ns)
assert len(ns['FACTORY_TABLES'])==9 and len(ns['ZERO_TABLES'])==28
root=Path('/workspace/.onboarding/factory-goal-base-integration');results=json.loads((root/'COMMAND_RESULTS.json').read_text());assert len(results['commands'])==3 and all(c['exit_code']==0 for c in results['commands']);assert results['actual_bootstrap_daemon']=='/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/batond'
for c in results['commands']:
 for suffix in ['stdout','stderr']:
  raw=(root/(c['name']+'.'+suffix)).read_bytes();assert H(raw)==c[suffix+'_sha256'];(O/(c['name']+'.'+suffix)).write_bytes(raw)
assert b'Ran 30 tests'in(root/'native-owner-python.stderr').read_bytes()and b'OK'in(root/'native-owner-python.stderr').read_bytes();assert b'Ran 34 tests'in(root/'python-infrastructure.stderr').read_bytes()
with Path(results['actual_bootstrap_daemon']).open('rb')as s:daemonsha=hashlib.file_digest(s,'sha256').hexdigest()
assert daemonsha=='2f5eb74f52b0653397683def7f66c579418c95f133cfc692bae68511be30c6b3'
# Four bounded Git archives, including sparse-omitted blobs: stream safe regular members, never extract paths.
prefix='docs/execution/factory-runtime-integration/';im=json.loads(read(HEAD,prefix+'FULL_FIFTH_REVIEW_IMPORTS.json'));ar=[]
for item in im['archives']:
 raw=read(HEAD,prefix+item['label']+'.tar.gz');assert len(raw)==item['bytes']and H(raw)==item['sha256']and len(raw)<1024*1024;(O/(item['label']+'.tar.gz')).write_bytes(raw);members=[];size=0
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:
  names=set()
  for m in t.getmembers():
   assert m.isfile()and not PurePosixPath(m.name).is_absolute()and'..'not in PurePosixPath(m.name).parts and m.name not in names;names.add(m.name);size+=m.size;assert size<32*1024*1024;data=t.extractfile(m).read()
   if'source'in item:assert data==(Path(item['source'])/m.name).read_bytes()
   members.append({'path':m.name,'bytes':len(data),'sha256':H(data)})
 assert len(members)==item['regular_members'];ar.append({'label':item['label'],'sha256':H(raw),'members':members,'original_roundtrip_checked':'source'in item,'subset_omission':item.get('omits')})
 if item['label']=='FOURTH_FULL_FAILURE_EVIDENCE':
  (O/'fourth-member-list.json').write_text(json.dumps(members,indent=2)+'\n')
review=Path('/workspace/.onboarding/factory-full-fifth-review');assert H((review/'REVIEW.md').read_bytes()).startswith('bf880188')and H((review/'MANIFEST.json').read_bytes()).startswith('470be657');v=json.loads((review/'VERIFICATION.json').read_text());assert v['source']==B and v['verified_manifest_files']==157
for c in v['commands']:assert c['exit_code']==0
for p in [root/'COMMAND_RESULTS.json',root/'REQUIREMENTS_MERGE.json',root/'STATUS_MERGE.json',review/'VERIFICATION.json',review/'REVIEW.md']:(O/('parent-'+p.name)).write_bytes(p.read_bytes())
(O/'proof.json').write_text(json.dumps({'subject':HEAD,'tested_parent':B,'incoming_parent':I,'merge':MERGE,'Core_Coretests_appsCLI_daemon_allCargo_exactly_unchanged_since_tested_parent':True,'incoming_Nativehelper_nativeParent_and_strictCIguard_bytes_exact':True,'workflow_diff_since_Factory_parent_only45_to60':True,'requirements130_IDstatusWP_preserved_both_verified_slices_subsets':True,'both_STATUS_history_prefixes_and_common_suffix_retained':common,'bootstrap_incoming93_onlySTATUS_changed_all_actualGit_hashes_match':True,'strictOwner_all_incoming_functions_byteidentical_except_exact_schema12_to13_predicate':True,'nativeOwner_currentSchema13_nineFactoryPlus19zeroTables':True,'integration_existing_Python34_Node4_NativeOwner30_logs_pin_verified':True,'actualSchema13_bootstrap_daemon_sha':daemonsha,'fifth_parent_645unique7docs_no_new_full_rerun':True,'bounded_four_archives':ar,'limitations':'No newCargo/Nativeworkspace/Mac/GUI/schema14/full130/runtime/CI execution. Parent645 review/raw unchanged; sparse omitted tracked blobs read via git show, not classified lost.'},indent=2)+'\n');print('PASS fixed integration four conflicts, strict13, incoming60, existing logs and four bounded archives')
