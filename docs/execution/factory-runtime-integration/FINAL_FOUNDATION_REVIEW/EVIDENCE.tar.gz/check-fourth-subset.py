from pathlib import Path
import tarfile,json,hashlib
O=Path(__file__).parent;H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
with tarfile.open(O/'FOURTH_FULL_FAILURE_EVIDENCE.tar.gz','r:gz')as t:
 m=json.loads(t.extractfile('SUBSET_MANIFEST.json').read());root=Path(m['original']);assert len(m['files'])==147
 for e in m['files']:
  b=t.extractfile('raw/'+e['path']).read();assert len(b)==e['bytes']and H(b)==e['sha256'];assert b==(root/e['path']).read_bytes()
 for e in m['omitted_bytes']:
  p=Path(e['path']);assert p.is_file()and p.stat().st_size==e['bytes'];assert e['path']not in [x.name for x in t.getmembers()]
  with p.open('rb')as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  assert actual==e['sha256'];rows.append({'path':e['path'],'bytes':e['bytes'],'sha256':actual,'not_embedded':True,'actual_original_retained_and_rehashed':True})
(O/'fourth-subset-proof.json').write_text(json.dumps({'original':m['original'],'subject':m['subject'],'actual_failed_scope':m['result'],'all147_retained_payloads_match_manifest_and_originals':True,'omitted_originals':rows,'no_ELF_execution_or_copy':True},indent=2)+'\n');print('PASS fourth147payloads exact original/hash and omitted original36MB ELF still retained/rehashed, not executed')
