# Fifth local workspace regression — independent evidence audit

Verdict: verified actual local workspace test/Clippy/format success at `6d666ed3a52ad14889440b84a903c58e050fa24c`, within the recorded Linux profile. No unresolved evidence must-fix found. This audit is not a new runtime execution, formal PR approval, CI/Mac/Native acceptance, or complete Factory/product acceptance.

Evidence directory `/workspace/.onboarding/factory-root-rust-regression-shared-budget` is sealed. Root RESULT SHA-256 `9c47e31610d2c666d66c9af59fd4a6361104fcb00465f1aa68b8f4e7bd1b8ca7`, MANIFEST SHA-256 `486b0265ca52412a60000734a3d0b564cb185f49b021b6c6b5ea73e418a7114e`. Independently verified all157 declared files, their sizes/hashes and exact manifest coverage. This includes generated test-artifact JSON, C sources/shared libraries, full response/timing packets and original command/start/result logs. Only the manifest itself and the explicitly excluded reproducible private Git composition.index are outside that inventory; exact composition proof is retained separately. No declared file was missing or mismatched.

## Independent count from raw output

Raw Running sections contain48 outer harness suites. For each suite the final summary agrees with the number of unique printed test names, deduplicating subprocess re-executions within that target. Total: **645 unique outer passes, zero failed, zero ignored**. Four documentation harnesses contain **7 compile-fail documentation passes**, zero failures/ignored; all seven expected compile-fail lines are present and their expected compiler-error output is not counted as a failed product test.

The five additional successful nested summaries are repetitions of existing outer test cases and are not added to645:

- Core `policy::live_workspace_tests::live_writer_fifo_pointer_cannot_block_actor`: one child pass.
- Workspaces `linux::delayed_exit_cleanup_and_cancel_observations_cannot_be_accepted`: three child passes for separate deadline/cleanup/cancel modes of the one outer case.
- Workspaces `fifo_read_is_bounded_in_killable_child`: one child pass.

The full sessions_ipc target has57 passes, including all three reviewed dirty-input/exhausted-cap1/remaining-cap2 budget cases; it is no longer merely the prior3-case filtered run. The Factory runtime target has18 passes, including each real synthetic Linux in-flight cancel/revoke/scope-expiry case. Factory scope11 and migration3, and the rest of the workspace suites, are present in the independent suite inventory. This does not assert that those tests exhaust all Factory requirements.

## Commands, source and tool provenance

All three actual command start/result records match COMMAND_RESULTS/AFTER/RESULT, their log hashes and recorded ordering; all exit0, no interruption or disk-guard termination:

| Command | Wall seconds |
|---|---:|
| `cargo test --workspace --locked -- --show-output` | 586.21 |
| `cargo clippy --workspace --locked --all-targets -- -D warnings` | 13.01 |
| `cargo fmt --all -- --check` | 1.00 |

The recorded profile explicitly sets TEST_DEBUG0, incremental0, jobs2, serial Rust tests, offline dependency access, umask022 and no DEV_DEBUG override. Clippy's own log finishes its dev check in12.54s;13.01 is wrapper wall time, not a conflicting harness duration. Runtime assertions/optimization and original product deadlines were not overridden. This remains a Linux TEST_DEBUG0 run, not the normal CI debug2 profile or a performance bound under arbitrary contention.

BEFORE/AFTER bind the same clean commit. Independently read and hashed all1308 tracked files against BEFORE while Root kept its source frozen; all matched and the current HEAD/tree were clean. Merged sessions source is exactly `8c1c84db1593130e2b6fa6c7df1e448d02b723b895d466162e0f2f10b93afc69`, reflecting the independently checked disjoint composition rather than misidentifying it as author-only19ce.

The four generated artifact redirect links were recorded with their identities; finalizer source verifies exact link/inode/device before unlinking. Actual links and their exclusively owned empty parent are gone, the four target evidence directories remain, and removal records list precisely those four paths. No original source/evidence directory was recursively removed.

Shared raw daemon188f1df3… (31,466,688B) and CLI57798c44… (81,315,144B) retain their BEFORE/AFTER SHA, inode, link count and size; reviewer independently rehashed the current images read-only. Their legitimate Root8532 build provenance remains separate from the older immutable CAS daemon2f5. The latter candidate's two tools were also independently rehashed unchanged. Temporary stripped runtime images in per-case build packets remain historical recorded images, not falsely described as retained independently rehashed executables.

## Failed history remains failed

Independent re-counts of all four preserved prior raw full-run logs confirm150/170/224/421 outer passes respectively, each with one outer failure and one nested pass kept separate. Their original result/log hashes are recorded in VERIFICATION.json. They are not rewritten, added together or relabeled as fifth-run passes.

The separate19ce-versus-8c preflight failure also remains an exit1 before Cargo, redirects or product execution. It arose because author and correctly composed Root files differ by previously reviewed fixture changes. Exact disjoint patch composition was proved, then this new run froze the specific merged8c source; no accepting-either-hash guard was introduced and the initial failure is not a passed test.

## Bounds of the result

The Cargo workspace explicitly contains config/core/providers/workspaces/daemon/CLI and excludes apps/desktop/src-tauri. Therefore this full workspace green does not execute the Native desktop suite, UI/browser tests, real macOS dialogs, dual-architecture installers, signing or actual Provider/account/model calls. Generated local protocol/contract fixtures and Linux synthetic post-read stalls are correctly scoped; neither a blocked-kernel syscall interruption nor complete escaped-descendant containment is proved. Remaining Factory graph/fault/unknown/recovery/accounting requirements cannot be declared complete merely from the count645.

Reviewer performed only read-only git/files, independent raw-log parsing, exact SHA/source comparisons and count/provenance checks. No Cargo, relink, compiler, test ELF, daemon, browser or remote operation was run; no source, STATUS, lockfile or target was changed. No Cargo/CPU lease was acquired or retained. Root may coordinate the next writer lease independently.
