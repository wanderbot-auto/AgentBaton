import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/.worktrees/factory-runtime-integration'); out=Path('/workspace/.onboarding/factory-native-composition/second')
source=Path('/workspace/.worktrees/goal-graph-integration')
links=[(root/'apps/desktop/dist',source/'apps/desktop/dist')]+[(root/'apps/desktop/src-tauri/binaries'/name,source/'apps/desktop/src-tauri/binaries'/name) for name in ['baton-x86_64-unknown-linux-gnu','batond-x86_64-unknown-linux-gnu']]
out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0'); files=[x for x in files if x]
before={p:sha(root/p) for p in files}
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':before,'borrowed_compile_only_assets':[{'path':str(a),'target':str(b),'kind':'old5541 sidecar/previous Graph dist; compile macro only, NOT Factory13 executable/UI evidence','sha256':sha(b) if b.is_file() else None} for a,b in links]}
(out/'BEFORE.json').write_text(json.dumps(manifest,indent=2)+'\n')
created=[]; results=[]
env=os.environ.copy(); env.update(CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1',CARGO_TARGET_DIR='/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target')
env['PATH']=env['CARGO_HOME']+'/bin:'+env['PATH']; sysroot='/workspace/.toolchains/linux-ui/sysroot'; env.update(PKG_CONFIG_SYSROOT_DIR=sysroot,PKG_CONFIG_LIBDIR=sysroot+'/usr/lib/x86_64-linux-gnu/pkgconfig:'+sysroot+'/usr/share/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig',LD_LIBRARY_PATH=sysroot+'/usr/lib/x86_64-linux-gnu',LIBRARY_PATH=sysroot+'/usr/lib/x86_64-linux-gnu')
commands=[['cargo','test','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--features','native-smoke,custom-protocol','--lib','--bins'],['cargo','fmt','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--check'],['cargo','clippy','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--all-targets','--features','native-smoke,custom-protocol','--','-D','warnings']]
try:
 for a,b in links:
  assert not a.exists() and not a.is_symlink(),a
  a.parent.mkdir(parents=True,exist_ok=True); a.symlink_to(b); created.append((a,b))
 for index,cmd in enumerate(commands):
  path=out/('native-'+str(index)+'.log'); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with path.open('wb') as log: result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  results.append({'command':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'log':path.name,'log_sha256':sha(path)})
  if result.returncode: break
finally:
 for a,b in reversed(created):
  assert a.is_symlink() and a.readlink()==b;a.unlink()
 after={p:sha(root/p) for p in files}
 (out/'RESULT.json').write_text(json.dumps({'head':manifest['head'],'commands':results,'source_before_after_equal':before==after,'changed':[p for p in files if before[p]!=after[p]],'temporary_links_removed':all(not a.is_symlink() for a,b in created),'dimension':'Linux Native pure tests only; no AppKit/Mac/sidecar or actualFactory13UI runtime'},indent=2)+'\n')
 print(json.dumps({'commands':results,'source_equal':before==after,'changed':[p for p in files if before[p]!=after[p]]},indent=2),flush=True)
