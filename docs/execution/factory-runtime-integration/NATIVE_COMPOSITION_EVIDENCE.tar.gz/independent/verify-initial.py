from pathlib import Path
import subprocess,json,hashlib,re,sqlite3
r=Path('/workspace/.worktrees/factory-runtime-integration');o=Path('/workspace/.onboarding/factory-native-composition-independent-review');base='489f302bdc9c235fbc09e9fac14513ab8e66eb36';head='3346968d548fd9c942b6a5de31e88592250bd85f'
commands=[]
def git(*args):
    p=subprocess.run(['git',*args],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE); commands.append({'command':['git',*args],'exit':p.returncode});assert p.returncode==0,p.stderr;return p.stdout
p='apps/desktop/src-tauri/src/bin/native_smoke.rs';before=git('show',base+':'+p);after=git('show',head+':'+p)
old=b'''            ("budget_reservations","INSERT INTO factory_budget_reservations VALUES('attempt','scope','root','project','{}')"),'''
new=b'''            ("budget_reservations",r#"INSERT INTO factory_budget_reservations VALUES('attempt','scope','root','project','{"authority_kind":"factory_task"}')"#),'''
assert before.count(old)==1 and after.count(new)==1
assert after.replace(new,old,1)==before
assert git('diff','--name-only',base,head).decode().splitlines()==[p]
assert (r/p).read_bytes()==after
(o/'native-before.rs').write_bytes(before);(o/'native-after.rs').write_bytes(after);(o/'one-line.patch').write_bytes(git('diff','--binary',base,head,'--',p))
# Exact SQL comes from the integrated Core migration, independently bound to053.
core=git('rev-parse','053b432').decode().strip();cp='crates/core/src/factory_store.rs';coreblob=git('show',core+':'+cp);now=git('show',head+':'+cp);assert coreblob==now
(o/'core-factory-store.rs').write_bytes(now)
line=next(x for x in now.decode().splitlines() if x.startswith('CREATE TABLE factory_budget_reservations('));sql=line.split(';',1)[0]+';'
# Constraint-only disposable SQLite control: NOT an actual Core schema migration,
# scope, grant, approved binding or SQL-based product acceptance.
db=sqlite3.connect(':memory:');db.execute(sql);assert db.execute('PRAGMA foreign_keys').fetchone()[0]==0
old_err=None
try: db.execute("INSERT INTO factory_budget_reservations VALUES('attempt','scope','root','project','{}')")
except sqlite3.IntegrityError as e: old_err=str(e)
assert old_err and 'CHECK constraint failed' in old_err
assert db.execute('SELECT count(*) FROM factory_budget_reservations').fetchone()[0]==0
new_sql=new.decode().split('r#"',1)[1].rsplit('"#',1)[0];db.execute(new_sql)
assert db.execute('SELECT count(*) FROM factory_budget_reservations').fetchone()[0]==1;db.close()
source=after.decode();start=source.index('    fn factory_real_sql_observes_each_table_drift_wrong_schema_and_missing_table_instead_of_zero()');case=source[start:]
fields=['scopes','runs','task_lineage','task_bindings','delegations','attempts','scoped_handles','handoffs','budget_reservations']
for field in fields: assert '("'+field+'",' in case
for exact in ['assert!(status.success());','assert!(factory_database_snapshot(&runtime).is_err());','assert_eq!(observed[field], 1);','assert_eq!(observed["sequence"], 0);','"PRAGMA user_version=12"','"PRAGMA user_version=14"','"DROP TABLE factory_scopes"','"DROP TABLE factory_budget_reservations"']:
    assert exact in case
# Narrow patch implies every other tracked source, including Owner/bootstrap,
# defaults/locks and13-table bindings/guards, equals the reviewed composition base.
protected=['scripts/native-owner-dialog-smoke.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs','apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','.github/workflows/product.yml']
hashes={}
for path in protected:
    a=git('show',base+':'+path);b=git('show',head+':'+path);assert a==b;hashes[path]=hashlib.sha256(b).hexdigest()
log=Path('/workspace/.onboarding/factory-native-composition/native-0.log').read_bytes();(o/'native-0.log').write_bytes(log)
text=log.decode();counts=[tuple(map(int,m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text)]
assert counts==[(70,0),(6,0),(29,1)],counts
assert 'sqlite3.IntegrityError: CHECK constraint failed:' in text and 'src/bin/native_smoke.rs:2731:13' in text
proof={'base':base,'head':head,'core_source':core,'exact_one_line_inverse_restores_entire_native_file':True,'only_changed_file':p,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'core_migration_sha256':hashlib.sha256(now).hexdigest(),'budget_DDL':sql,'constraint_only_probe':{'old_document_failed':old_err,'old_after_count':0,'new_after_count':1,'not_actual_Core_migration_or_authority':True},'nine_drift_controls_and_all_other_bytes_preserved':fields,'protected_unchanged_hashes':hashes,'original_run':{'path':'native-0.log','sha256':hashlib.sha256(log).hexdigest(),'bytes':len(log),'results':counts,'overall':'failed in negative fixture preparation'},'commands':commands,'no_Cargo_target_or_remote_actions':True,'untracked_dist_observed_not_modified':True}
(o/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':'PASS narrow fixture maintenance review','head':head,'native_after_sha256':proof['after_sha256'],'old_run_results':counts}))
