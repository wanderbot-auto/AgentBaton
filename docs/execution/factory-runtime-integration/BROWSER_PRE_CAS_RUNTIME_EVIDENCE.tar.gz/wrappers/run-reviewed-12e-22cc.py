import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

tree = Path('/workspace/.worktrees/factory-runtime-integration')
case = sys.argv[1]
assert case in ['normal', 'cancel', 'unknown']
output = Path('/workspace/.onboarding/factory-browser-root') / ('reviewed-12e-22cc-' + case)
assert not output.exists()
output.mkdir()
manifest = Path('/workspace/.onboarding/factory-candidate-12e/manifest.json')
candidate = json.loads(manifest.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


paths = {str(tree / name): digest for name, digest in candidate['production_sources'].items()}
for tool in candidate['tool_details'].values():
    paths[tool['path']] = tool['sha256']
paths[str(manifest)] = '390561cd633086bfd77b4f64790cbdbabfb0aa542659c0e25b75dd5ef56b1a05'
paths[str(tree / 'apps/desktop/tests/factory-real-ipc.py')] = 'b7d9c16c4582ba3d486ad1e4fec693563280d35953b1a73c1290f8fde0ae3ea4'
for name, digest in {
    'index.html': '409c30ec49aa45a9566e00b0f3ad66fe2324ec8db9b77c8cbbbdd18660968997',
    'assets/index-BMwbYbXt.js': 'f31b650fa1a794b9572098e51f64b8983a4494f7524c1a428040b7bf88fde1b7',
    'assets/index-DczAmFjL.css': 'bdb1e006f25f8d0d3b0c9651badc4faf61f04358c6bbb74e2d5a09e797f32944',
}.items():
    paths[str(tree / 'apps/desktop/dist' / name)] = digest
for path in (tree / 'apps/desktop/tests').glob('*.py'):
    paths.setdefault(str(path), sha(path))
for name, digest in paths.items():
    assert sha(Path(name)) == digest, name
command = [
    '/workspace/AgentBaton/artifacts/browser-venv/bin/python',
    'apps/desktop/tests/factory-real-ipc.py', '--case', case,
    '--batond', candidate['tool_details']['batond']['path'],
    '--candidate-manifest', str(manifest),
    '--frontend', str(tree / 'apps/desktop/dist'), '--output', str(output / 'evidence'),
]
before = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=tree, text=True).strip(),
          'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip(),
          'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True),
          'command': command, 'source_and_input_hashes': paths,
          'dimension': 'actual Linux browser + Unix IPC + generated ACP/fixed stdio MCP; NOT macOS, live Provider/model, human Owner or full Design acceptance',
          'cpu_lease': 'Core explicitly yielded CPU; unique Cargo lease retained by Core but idle for this runtime'}
(output / 'BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
with (output / 'runner.log').open('wb') as log:
    result = subprocess.run(command, cwd=tree, stdout=log, stderr=subprocess.STDOUT)
after = {**before, 'ended_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'exit_code': result.returncode, 'source_and_inputs_unchanged': all(sha(Path(p)) == d for p, d in paths.items()),
         'status_after': subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True),
         'runner_log_sha256': sha(output / 'runner.log')}
(output / 'RESULT.json').write_text(json.dumps(after, indent=2) + '\n')
print(json.dumps({k: after[k] for k in ['commit', 'exit_code', 'source_and_inputs_unchanged', 'ended_at']}))
sys.exit(result.returncode if after['source_and_inputs_unchanged'] else 1)
