import pathlib,json,hashlib,subprocess,re
repo=pathlib.Path('/workspace/.worktrees/factory-runtime-core');ev=pathlib.Path('/workspace/.onboarding/factory-goal-ordinary-budget-20261029');out=pathlib.Path('/workspace/.onboarding/factory-goal-ordinary-budget-review');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git','-C',str(repo),*a]);head='5c9d49384bad83b20999286efc82829db669ad9a';base='d2e5bbbe7d09005df6d1c33682777a3c3cbab0d1';f='crates/core/tests/sessions_ipc.rs'
assert git('diff','--name-only',base,head).decode().splitlines()==[f];old=git('show',f'{base}:{f}').decode();new=git('show',f'{head}:{f}').decode();assert sha(new.encode())=='19ceacd2ed56e63c3e39fec8a1a4a123b6cec6bcc54943978da5651fcc18b7b2';assert (repo/f).read_text()==new
s=new
start=s.index('    fn with_provider(duration: u64, provider: &str) -> Self {');end=s.index('        let dir = tempfile::tempdir().unwrap();',start);s=s[:start]+'    fn with_provider(duration: u64, provider: &str) -> Self {\n'+s[end:]
start=s.index('        if clean_outputs {');end=s.index('        git(&source, &["add", "file"]);',start);s=s[:start]+s[end:];assert s.count('"max_attempts":attempts')==1;s=s.replace('"max_attempts":attempts','"max_attempts":2',1)
start=s.index('#[test]\nfn actual_goal_shared_budget_clean_exhaustion_');end=s.index('struct OwnedGoalDaemonProcess {',start);s=s[:start]+s[end:]
s=s.replace('actual_goal_shared_budget_dirty_inputs_refuse_ordinary_and_lowlevel_attempts','actual_goal_shared_budget_cannot_be_bypassed_by_normal_session_or_trusted_lowlevel_attempt',1)
start=s.index('fn actual_goal_shared_budget_cannot_be_bypassed_by_normal_session_or_trusted_lowlevel_attempt');end=s.index('struct OwnedGoalDaemonProcess {',start);block=s[start:end];assert block.count('"INPUT_CHANGED"')==1;block=block.replace('"INPUT_CHANGED"','"AUTH_REQUIRED"',1);assert block.count('    assert_eq!(refused["error"]["side_effect_state"], "not_started");\n')==1;block=block.replace('    assert_eq!(refused["error"]["side_effect_state"], "not_started");\n','',1);s=s[:start]+block+s[end:];assert s==old
assert old.count('#[test]')==55 and new.count('#[test]')==57
m=json.loads((ev/'SOURCE_SNAPSHOT.json').read_bytes());assert m['source_commit']==head
for p,v in m['artifacts'].items():q=pathlib.Path(p);assert sha(q.read_bytes())==v['sha256'] and q.stat().st_size==v['bytes'],p
for name,result in m['commands'].items():assert sha((ev/result['name'].replace('targeted-tests','targeted-tests')).with_suffix('.log').read_bytes())==result['log_sha256']
prod=json.loads(pathlib.Path('/workspace/AgentBaton/.onboarding/factory-owner-cas-candidate-20261028/manifest.json').read_bytes())['sources']
for path,h in prod.items():assert sha(git('show',f'{head}:{path}'))==h
cargo=[p for p in git('ls-tree','-r','--name-only',head).decode().splitlines() if pathlib.Path(p).name in ['Cargo.toml','Cargo.lock']]
for path in cargo:assert git('show',f'{base}:{path}')==git('show',f'{head}:{path}')
packets={}
for p in m['artifacts']:
 if 'generated-goal-ordinary-budget-1-cc25' in p or 'generated-goal-ordinary-budget-2-8d23' in p:
  v=json.loads(pathlib.Path(p).read_bytes());cap=v['attempt_cap'];assert v['grant_unchanged'] is True and v['precommitted_gitignore']=='/reports/\n/fixture-started\n'
  for prefix in ['project','root']:
   a=v['Goal_only_'+prefix+'_meter'];b=v['final_'+prefix+'_meter'];assert a['limits']==b['limits'] and a['limits']['attempts']==cap;assert a['observed_attempts']==1 and b['observed_attempts']==cap;assert a['output_bytes']==b['output_bytes']==12
   if cap==1:assert a==b and b['runtime_ms']==111
   else:assert a['runtime_ms']==96 and b['runtime_ms']==141 and b['runtime_ms']-a['runtime_ms']==45
  packets[cap]={'path':p,'sha256':sha(pathlib.Path(p).read_bytes()),'initial':v['Goal_only_project_meter'],'final':v['final_project_meter']}
assert set(packets)=={1,2}
log=(ev/'fixed-targeted-tests.log').read_text();assert '3 passed; 0 failed; 0 ignored' in log and 'finished in 3.85s' in log and 'Compiling agentbaton-core' in log
oldlog=(ev/'targeted-tests.log').read_text();assert '2 passed; 1 failed' in oldlog
fail=(ev/'exhaustion-diagnostic.log').read_text();assert '0 passed; 1 failed' in fail and 'PERMISSION_DENIED' in fail
prior=m['prior_full_failure'];dd=pathlib.Path(prior['directory']);assert sha((dd/'RESULT.json').read_bytes())==prior['result_sha256'] and sha((dd/'MANIFEST.json').read_bytes())==prior['manifest_sha256']
for name,text in [('baseline-sessions_ipc.rs',old),('fixed-sessions_ipc.rs',new)]: (out/name).write_text(text)
(out/'AUTHOR_SNAPSHOT.json').write_bytes((ev/'SOURCE_SNAPSHOT.json').read_bytes())
r={'state':'PASS independent static byte/hash/receipt arithmetic only, no runtime','source':head,'base':base,'source_sha256':sha(new.encode()),'inverse_normalized_sha256':sha(s.encode()),'old_tests':55,'new_tests':57,'old_defaults_preserved':'false clean_outputs and attempts2; exact inverse source equality except expressly normalized dirty diagnostic','unchanged_production':len(prod),'unchanged_Cargo_files':len(cargo),'artifact_count':len(m['artifacts']),'final_packets':packets,'author_results':{'targeted_three':'3PASS0FAIL0ignored3.85s, real recompile','preliminary_first':'2PASS1FAIL setup','diagnostic_second':'0PASS1FAIL setup permission cap mismatch','Clippy_fmt':'recorded after final3: Clippy exit0/2.0s, fmt exit0/1.0s. Per-command instantaneous source hashes not captured; later frozen source binding only'},'prior_full':prior,'test_ELF':'Running path/recompile logged; no separately frozen SHA-pinned final test ELF retained/claimed. Existing old full binary must not be relabeled final.'}
(out/'VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['final_packets','prior_full']},ensure_ascii=False))
