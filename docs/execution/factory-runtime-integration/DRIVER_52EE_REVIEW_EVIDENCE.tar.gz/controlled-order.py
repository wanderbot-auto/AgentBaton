#!/usr/bin/env python3
"""Controlled async trace/clock helpers only, no HTTP/Core/browser or real clock."""
import ast,copy,importlib.util,json,sys
from pathlib import Path
BASE=Path(__file__).parent
SUBJECT=BASE/'source-after.py'
spec=importlib.util.spec_from_file_location('start_subject',SUBJECT);s=importlib.util.module_from_spec(spec);sys.modules[spec.name]=s;spec.loader.exec_module(s)
source=SUBJECT.read_text();module=ast.parse(source)
runtime=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='runtime_driver')
wait_node=next(n for n in ast.walk(runtime) if isinstance(n,ast.FunctionDef) and n.name=='wait')
checks=[]
def check(name,value=True):
 assert value,name;checks.append({'name':name,'status':'passed'})
scope={'id':'scope','revision':1}
entry={'method':'factory_runs.start','params':{'scope_id':'scope'},'key':'actual-unit-key','revision':1,
 'request_body_sha256':'a'*64,'original_core_reply_sha256':'b'*64,'response_complete':True,
 'response':{'request_id':'request','revision':14,'warnings':[],'result':{
  'active_session_id':None,'active_task_id':None,'cancel_requested':False,
  'context_continuation':'new_attempt_explicit_handoff_only','created_at':'unit-timestamp','id':'run',
  'last_error':None,'project_id':'project','revision':1,'root_task_id':'task','scope_id':'scope','state':'queued','updated_at':'unit-timestamp'}}}
def confirm(rows):return s.confirmed_start_response(rows,scope,'project','task')
class Clock:
 def __init__(self):self.now=0
 def monotonic(self):return self.now
 def sleep(self,seconds):self.now+=seconds
def setup():
 clock=Clock();calls={'observe':0,'get':0}
 def observe():calls['observe']+=1
 env={'time':clock,'pump':lambda:None,'observe_records':observe,'clean':str}
 exec(compile(ast.Module(body=[wait_node],type_ignores=[]),'exact-runtime-wait','exec'),env)
 return clock,calls,env['wait']
check('no response is pending, not a run query',confirm([])is None)
pending=copy.deepcopy(entry);pending['response_complete']=False
check('Core reply not yet written cannot confirm browser start',confirm([pending])is None)
inflight=copy.deepcopy(pending);del inflight['response'];del inflight['original_core_reply_sha256']
check('inflight actual request without Core reply remains pending',confirm([inflight])is None)
check('whole queued receipt accepted unchanged',confirm([entry])is entry)
clock,calls,wait=setup();stages=iter([[],[inflight],[pending],[entry]])
ack=wait(lambda:confirm(next(stages)),lambda v:v is not None,observe=False,deadline=15)
check('controlled asynchronous request pending then complete before observe/get',ack is entry and calls=={'observe':0,'get':0})
def terminal():calls['get']+=1;return 'completed'
check('terminal query occurs after confirmed reply within same deadline',wait(terminal,lambda v:v=='completed',deadline=15)=='completed' and calls=={'observe':1,'get':1})
for name,ack_elapsed,next_elapsed,cancel in [('ack-late',15,0,False),('terminal-exhausts-original-budget',14.9,.2,False),('cancel-fixture-exhausts-shared-budget',14.9,.2,True)]:
 clock,calls,wait=setup()
 def read_ack():clock.now+=ack_elapsed;return confirm([entry])
 failed=False
 try:
  wait(read_ack,lambda v:v is not None,observe=False,deadline=15)
  def read_next():
   clock.now+=next_elapsed
   if not cancel:calls['get']+=1
   return ['fixture'] if cancel else 'completed'
  wait(read_next,bool,deadline=15)
 except AssertionError as error:
  failed='deadline exhausted' in str(error)
 check(name,failed and (name!='ack-late' or calls=={'observe':0,'get':0}))
clock,calls,wait=setup()
try:wait(lambda:confirm([pending]),lambda v:v is not None,observe=False,deadline=.05)
except AssertionError:check('never-written response exhausts shared stage without any get',calls=={'observe':0,'get':0})
else:raise AssertionError('unwritten response passed')
for name in ['duplicate','scope','revision','bool-revision','key-empty','bad-hash','error-reply','project','root','run-state','run-revision','missing-run-field','active-session','cancel-requested','context','response-complete-type']:
 changed=copy.deepcopy(entry)
 if name=='duplicate':rows=[changed,copy.deepcopy(changed)]
 else:
  rows=[changed];run=changed['response']['result']
  if name=='scope':changed['params']['scope_id']='foreign'
  if name=='revision':changed['revision']=2
  if name=='bool-revision':changed['revision']=True
  if name=='key-empty':changed['key']=''
  if name=='bad-hash':changed['original_core_reply_sha256']='bad'
  if name=='error-reply':changed['response']={'error':{'code':'NOT_FOUND'}}
  if name=='project':run['project_id']='foreign'
  if name=='root':run['root_task_id']='foreign'
  if name=='run-state':run['state']='running'
  if name=='run-revision':run['revision']=2
  if name=='missing-run-field':del run['context_continuation']
  if name=='active-session':run['active_session_id']='session'
  if name=='cancel-requested':run['cancel_requested']=True
  if name=='context':run['context_continuation']='implicit'
  if name=='response-complete-type':changed['response_complete']=1
 clock,calls,wait=setup()
 try:wait(lambda:confirm(rows),lambda v:v is not None,observe=False,deadline=15)
 except AssertionError:check(name+' cannot enable terminal query',calls=={'observe':0,'get':0})
 else:raise AssertionError(name)
(BASE/'results.json').write_text(json.dumps({'source_sha256':s.sha(SUBJECT.read_bytes()),'status':'passed','count':len(checks),'checks':checks,
 'dimension':'exact extracted wait+pure confirmation helper, deterministic unit-only clock and HTTP trace DTO, NO actualHTTP/Core/browser/clock evidence'},indent=2)+'\n')
print('passed',len(checks),'controlled start-order/budget checks; no Core/browser')
