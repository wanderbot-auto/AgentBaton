import subprocess,json,hashlib,os
from pathlib import Path
O=Path(__file__).parent;env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');results=[]
commands=[('controlled-order',['python3',str(O/'controlled-order.py')])]+[(name,['python3',str(O/'source-after.py'),flag,'--output',str(O/name)]) for name,flag in [('boundary','--self-check'),('fixture','--fixture-self-check'),('cleanup','--cleanup-self-check'),('diagnostic','--diagnostic-self-check')]]
for name,cmd in commands:
 p=subprocess.run(cmd,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);results.append({'name':name,'argv':cmd,'exitcode':p.returncode});assert p.returncode==0,(name,p.stderr)
(O/'commands.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS independent 26 +63/13/28/25 pure checks; no runtime')
