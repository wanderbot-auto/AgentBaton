import ast,hashlib,json,subprocess,shutil
from pathlib import Path
O=Path(__file__).parent; R=Path('/workspace/.worktrees/factory-browser-diagnostics'); path='apps/desktop/tests/factory-real-ipc.py'; base='744bf29d255b618c54a905dff72a784942903f83'; head='52ee7ab93b4238ea2c642dbb19f58a9930e21e38'
a=subprocess.check_output(['git','show',base+':'+path],cwd=R);b=subprocess.check_output(['git','show',head+':'+path],cwd=R)
assert hashlib.sha256(b).hexdigest()=='ad0f5b6ac01214e13852ee330412dd878c56a72cb987f795b697e5079b276b63'
(O/'source-before.py').write_bytes(a);(O/'source-after.py').write_bytes(b);(O/'source.patch').write_bytes(subprocess.check_output(['git','diff',base,head,'--',path],cwd=R))
compile(b,'fixed52ee','exec'); assert subprocess.run(['git','diff','--check',base,head,'--',path],cwd=R).returncode==0
A=ast.parse(a); B=ast.parse(b)
def defs(t,raw):return {n.name:ast.get_source_segment(raw.decode(),n) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
x=defs(A,a);y=defs(B,b);changed=[k for k in x if x[k]!=y[k]];assert changed==['runtime_driver'];assert set(y)-set(x)=={'confirmed_start_response'}
ra=next(n for n in A.body if getattr(n,'name',None)=='runtime_driver'); rb=next(n for n in B.body if getattr(n,'name',None)=='runtime_driver')
old_nested={n.name:ast.get_source_segment(a.decode(),n) for n in ast.walk(ra) if isinstance(n,(ast.FunctionDef,ast.ClassDef))};new_nested={n.name:ast.get_source_segment(b.decode(),n) for n in ast.walk(rb) if isinstance(n,(ast.FunctionDef,ast.ClassDef))}; assert all(old_nested[k]==new_nested[k] for k in old_nested if k not in {'runtime_driver','wait','Handler','do_POST'})
# All pre-existing assertions remain byte-identical and in order, including the wrong-CAS/terminal/cleanup tests.
orig=[ast.dump(n,include_attributes=False) for n in ast.walk(A) if isinstance(n,ast.Assert)]; now=[ast.dump(n,include_attributes=False) for n in ast.walk(B) if isinstance(n,ast.Assert)]; it=iter(now);assert all(any(v==w for w in it) for v in orig)
oldmanifest=O.parent/'revision-744bf29d/MANIFEST.json';assert hashlib.sha256(oldmanifest.read_bytes()).hexdigest()=='c80e59686b058bd5e2ca8d70239cc7125682875b8e06c0c1ff4575d05157ada9'
for name,v in json.loads(oldmanifest.read_text())['files'].items():
 data=(oldmanifest.parent/name).read_bytes();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
src=Path('/workspace/.onboarding/factory-browser-diagnostics/start-ack-freeze/controls.py'); data=src.read_text();(O/'author-controls-original.py').write_text(data);data=data.replace("SUBJECT=Path('/workspace/.worktrees/factory-browser-diagnostics/apps/desktop/tests/factory-real-ipc.py')","SUBJECT=BASE/'source-after.py'");(O/'controlled-order.py').write_text(data)
raw=Path('/workspace/.onboarding/factory-browser-root/reviewed-db949-744-normal/evidence/report.json').read_bytes();(O/'prior-runtime-failure-report.json').write_bytes(raw); p=json.loads(raw);assert p['status']!='passed' and len(p['checks'])==2 and len(p['screenshots'])==2
assert p['observations']['actual_wrong_start_CAS_refusal']['error']['code']=='STALE_REVISION';get=[t for t in p['http'] if t['method']=='factory_runs.get' and t['response'].get('error',{}).get('code')=='NOT_FOUND'];start=[t for t in p['http'] if t['method']=='factory_runs.start'];assert get and start and get[0]['response']['revision']==13 and start[0]['response']['revision']==14 and start[0]['response']['result']['state']=='queued'; assert p['observations']['failure_factory_response']['revision']==19
(O/'static-proof.json').write_text(json.dumps({'base':base,'subject':head,'source_sha256':hashlib.sha256(b).hexdigest(),'only_changed_existing_top_level_definition':changed,'only_new_definition':'confirmed_start_response','all_other_top_level_definitions_and_existing_nested_helpers_identical':True,'all_original_assert_AST_retained_in_order':True,'old744_10files_and_manifest_unchanged':True,'prior_failure_sha256':hashlib.sha256(raw).hexdigest(),'prior_distinct_observations':{'early_not_found_revision':13,'later_start_queued_revision':14,'later_failure_get_revision':19,'checks':2,'PNGs':2,'status':p['status']},'runtime_this_review':'NOT_RUN'},indent=2)+'\n')
print('PASS fixed-source preservation, old744 hashes, and prior distinct-time failure evidence')
