import ast,copy,hashlib,http.server,importlib.util,io,json,sys,threading
from pathlib import Path
O=Path(__file__).parent;sys.dont_write_bytecode=True;S=O/'source-after.py';sp=importlib.util.spec_from_file_location('fixed_subject_handler',S);s=importlib.util.module_from_spec(sp);sys.modules[sp.name]=s;sp.loader.exec_module(s)
t=ast.parse(S.read_text());r=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='runtime_driver');node=next(n for n in ast.walk(r) if isinstance(n,ast.ClassDef) and n.name=='Handler');fixture=json.loads((O/'results.json').read_text()); assert fixture['count']==26
scope={'id':'scope','revision':1};reply={'request_id':'unit-call','result':{'active_session_id':None,'active_task_id':None,'cancel_requested':False,'context_continuation':'new_attempt_explicit_handoff_only','created_at':'time','id':'run','last_error':None,'project_id':'project','revision':1,'root_task_id':'task','scope_id':'scope','state':'queued','updated_at':'time'},'revision':14,'warnings':[]};rawreply=json.dumps(reply,separators=(',',':')).encode()+b'\n';req=json.dumps({'command':'factory_runs_start','args':{'scopeId':'scope','expectedRevision':1,'idempotencyKey':'unit-start'}}).encode(); checks=[]
class Headers(dict):
 def get_all(self,k):return [self[k]] if k in self else []
for mode in ['success','broken-write','reset-write','core-exception','header-exception']:
 report={'http':[],'http_unexpected_errors':[],'readonly_aborts':[]};active={};observed=[]
 class Host:
  def wire(self,call):
   assert call.method=='factory_runs.start' and call.params=={'scope_id':'scope'} and call.key=='unit-start' and call.revision==1
   assert len(report['http'])==1 and report['http'][0]['response_complete'] is False and 'response' not in report['http'][0]
   if mode=='core-exception':raise RuntimeError('unit-core-failure')
   return copy.deepcopy(reply),rawreply
 ns=dict(vars(s));ns.update(lock=threading.Lock(),report=report,active=active,phase={'value':'serving'},url='http://127.0.0.1:12345',bounds=s.Bounds('project','task','scope'),host=Host(),clean=str)
 exec(compile(ast.Module(body=[node],type_ignores=[]),'exact-fixed-Handler','exec'),ns);C=ns['Handler'];h=object.__new__(C);h.path='/__test_factory_ipc';h.headers=Headers({'Content-Length':str(len(req)),'Origin':ns['url'],'Host':'127.0.0.1:12345','Content-Type':'application/json'});h.rfile=io.BytesIO(req);h.send_header=lambda *a:None;h.end_headers=lambda:None;h.send_error=lambda *a:None
 def headers(*args):
  if mode=='header-exception':raise OSError('unit-header-failure')
 h.send_response=headers
 class Writer:
  def write(self,data):
   assert data==rawreply;trace=report['http'][0];assert trace['response_complete'] is False and trace['response']==reply;assert trace['request_body_sha256']==s.sha(req) and trace['original_core_reply_sha256']==s.sha(rawreply);observed.append('before-complete-write')
   if mode=='broken-write':raise BrokenPipeError('unit-write-failed')
   if mode=='reset-write':raise ConnectionResetError('unit-write-reset')
   return len(data)
 h.wfile=Writer();h.do_POST();assert active=={};trace=report['http'][0]
 if mode=='success':
  assert trace['response_complete'] is True and not report['http_unexpected_errors'] and observed==['before-complete-write'];assert s.confirmed_start_response(report['http'],scope,'project','task') is trace
 else:
  assert trace['response_complete'] is False and report['http_unexpected_errors'] and not report['readonly_aborts'];assert s.confirmed_start_response(report['http'],scope,'project','task') is None
 checks.append({'name':mode,'status':'passed','dimension':'exact Handler AST with synthetic request/response and controlled writer; no HTTP socket/browser/Core'})
# Every malformed or duplicate receipt must fail closed before a run query can be enabled.
entry={'method':'factory_runs.start','params':{'scope_id':'scope'},'key':'unit-start','revision':1,'request_body_sha256':'a'*64,'original_core_reply_sha256':'b'*64,'response_complete':True,'response':copy.deepcopy(reply)}
for name in ['reply-revision-bool','run-revision-bool','unknown-result-field','unknown-reply-field','warnings-not-list','request-id-empty']:
 e=copy.deepcopy(entry)
 if name=='reply-revision-bool':e['response']['revision']=True
 if name=='run-revision-bool':e['response']['result']['revision']=True
 if name=='unknown-result-field':e['response']['result']['foreign']=1
 if name=='unknown-reply-field':e['response']['foreign']=1
 if name=='warnings-not-list':e['response']['warnings']={}
 if name=='request-id-empty':e['response']['request_id']=''
 try:s.confirmed_start_response([e],scope,'project','task')
 except (AssertionError,TypeError,KeyError):pass
 else:raise AssertionError(name)
 checks.append({'name':name,'status':'passed','dimension':'pure receipt guard'})
(O/'handler-results.json').write_text(json.dumps({'source_sha256':s.sha(S.read_bytes()),'count':len(checks),'checks':checks,'no_browser_Core_daemon_listener':True},indent=2)+'\n');print('PASS',len(checks),'independent Handler/typed receipt checks')
