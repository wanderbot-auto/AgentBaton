import subprocess,json,os
from pathlib import Path
O=Path(__file__).parent;R='/workspace/.worktrees/factory-browser-diagnostics';H='52ee7ab93b4238ea2c642dbb19f58a9930e21e38';env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
for n in ['run-checks.log','fixture.stderr','fixture.stdout']:
 (O/n).rename(O/('initial-flat-fixture-'+n))
D=O/'subject/tests';D.mkdir(parents=True);(D/'factory-real-ipc.py').write_bytes((O/'source-after.py').read_bytes());(D/'goal-graph-real-ipc.py').write_bytes((O/'goal-graph-real-ipc.py').read_bytes());p='apps/desktop/src-tauri/tests/fixtures/factory-wire-bundle-0c6fbd065df4a49997acca4fc898a3f952721bfbc60b57229ca36571db0c0c64.json';F=O/'subject/src-tauri/tests/fixtures';F.mkdir(parents=True);(F/Path(p).name).write_bytes(subprocess.check_output(['git','show',H+':'+p],cwd=R))
results=[]
for name,flag in [('fixture','--fixture-self-check'),('cleanup','--cleanup-self-check'),('diagnostic','--diagnostic-self-check')]:
 cmd=['python3',str(D/'factory-real-ipc.py'),flag,'--output',str(O/(name+'-complete'))];p=subprocess.run(cmd,env=env,cwd=O,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);results.append({'name':name,'argv':cmd,'exitcode':p.returncode});assert p.returncode==0,(name,p.stderr)
(O/'resume-commands.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS remaining fixture13/cleanup28/diagnostic25; earlier order26/boundary63 already exit0')
