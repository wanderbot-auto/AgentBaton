from pathlib import Path
r=Path('/workspace/.worktrees/factory-child-goal-native');p=r/'apps/desktop/src-tauri/src/approval.rs';s=p.read_text()
s=s.replace('&& graph_revision(&reference["revision"])\n        && graph_revision(&reference["receipt_sequence"])','&& factory_safe(&reference["revision"], 1, 256)\n        && graph_revision(&reference["receipt_sequence"])',1)
# Tests inside existing module retain access to its original exact Node fixture.
pos=s.index('\n}\n\n#[cfg(test)]\nmod graph_review_tests {')
new=r'''
    fn factory_node_fixture() -> (Value,Value) {
        let (mut p,selection)=graph_node_proposal_fixture();
        let budget=json!({"attempts":1,"parallel":1,"runtime_ms":1000,"output_bytes":1024,"children":1,"reworks":0,"tokens":null,"cost_microunits":null});
        let policy=json!({"max_nodes":2,"max_runs_per_task":1,"max_total_runs":2,"root_budget":budget,"project_budget":budget,"require_owner_acceptance":true});
        let origin=json!({"factory_scope_id":"factory-scope","factory_scope_digest":"f".repeat(64),"factory_run_id":"factory-run","factory_root_task_id":"factory-root","parent_task_id":"factory-root","ancestors":["task-1","factory-root"],"original_native_approval_id":"factory-scope","root_grant_id":"grant-1","root_grant_revision":2,
          "initial_plan":{"id":"saved-plan","scope_id":"factory-scope","run_id":"factory-run","task_id":"task-1","revision":3,"plan_digest":"b".repeat(64),"raw_sha256":"a".repeat(64),"receipt_sequence":5},
          "execution_binding":{"schema_version":1,"authority_kind":"factory_child_goal_execution_v1","policy":policy,"planning_policy_digest":"c".repeat(64),"root_grant_id":"grant-1","root_grant_revision":2,"original_max_children":1,"original_max_depth":1,"graph_contract_version":1,"definition_digest":"e".repeat(64),"new_workspace_authorized":false}});
        p["result"]["snapshot"]["run_binding"]["factory_origin"]=origin;
        p["result"]["snapshot"]["criterion"]["rule_id"]=json!("factory-child-owner-review");
        p["result"]["snapshot"]["node"]["executor"]["rule_id"]=json!("factory-child-owner-review");
        (p,selection)
    }
    #[test]
    fn factory_owner_complete_origin_candidate_criterion_and_initial_ref_are_all_paged() {
        let (mut p,selection)=factory_node_fixture();
        p["result"]["snapshot"]["criterion"]["criterion_text"]=json!("完整条件😀".repeat(800));
        let expected=serde_json::to_string(&p["result"]["snapshot"]).unwrap();
        let mut pages=Vec::new();let calls=Cell::new(0);
        let result=confirm_goal_node_and_finalize(p,&selection,9,|message|{
            if !message.contains("FINAL native decision") {pages.push(message.rsplit("\n\n").next().unwrap().to_owned());}
            true
        },|frame|{calls.set(calls.get()+1);assert_eq!(frame["params"]["proposal_id"],"owner-proposal");Ok(json!({"result":{"graph_contract_version":1,"approval_id":"owner-proposal","run_id":"run-1","node_id":"owner-1","plan_revision":3,"decision":"accepted","owner_decision_id":"decision","run_revision":10,"task_accepted":false}}))}).unwrap();
        assert!(pages.len()>1);assert_eq!(pages.concat(),expected);assert_eq!(calls.get(),1);
        assert_eq!(result["result"]["task_accepted"],false);
    }
    #[test]
    fn factory_owner_missing_null_cross_scope_or_malformed_origin_never_prompts() {
        let (p,selection)=factory_node_fixture();
        for pointer in ["/factory_scope_id","/original_native_approval_id","/root_grant_id","/root_grant_revision","/initial_plan/scope_id","/initial_plan/run_id","/initial_plan/task_id","/initial_plan/plan_digest","/initial_plan/raw_sha256","/initial_plan/receipt_sequence","/execution_binding/root_grant_revision","/execution_binding/authority_kind","/execution_binding/planning_policy_digest","/execution_binding/policy/max_runs_per_task","/execution_binding/policy/require_owner_acceptance","/execution_binding/new_workspace_authorized","/ancestors/0","/parent_task_id"] {
            let mut bad=p.clone();*bad["result"]["snapshot"]["run_binding"]["factory_origin"].pointer_mut(pointer).unwrap()=json!("bad");
            let reply=confirm_goal_node_and_finalize(bad,&selection,9,|_|panic!("invalid origin prompted"),|_|panic!("invalid origin finalized")).unwrap();
            assert_eq!(reply["error"]["code"],"INVALID_APPROVAL_PROPOSAL","{pointer}");
        }
        for absent in [true,false] {
            let mut bad=p.clone();let b=&mut bad["result"]["snapshot"]["run_binding"];
            if absent {b.as_object_mut().unwrap().remove("factory_origin");}else{b["factory_origin"]=Value::Null;}
            assert!(!graph_node_snapshot_matches(&bad["result"]["snapshot"],&selection,9));
        }
        let mut legacy=p;legacy["result"]["snapshot"]["criterion"]["rule_id"]=json!("goal-owner-review");legacy["result"]["snapshot"]["node"]["executor"]["rule_id"]=json!("goal-owner-review");
        assert!(!graph_node_snapshot_matches(&legacy["result"]["snapshot"],&selection,9));
    }
    #[test]
    fn factory_owner_root_lineage_and_saved_initial_ref_stay_distinct_from_current_plan() {
        let (p,_)=factory_node_fixture();let b=&p["result"]["snapshot"]["run_binding"];let mut origin=b["factory_origin"].clone();
        assert!(factory_origin_matches(&origin,&b["task_id"],&b["root_grant_id"],&json!(4),&json!("9".repeat(64))));
        origin["ancestors"]=json!(["task-1"]);origin["factory_root_task_id"]=json!("task-1");origin["parent_task_id"]=Value::Null;
        assert!(factory_origin_matches(&origin,&b["task_id"],&b["root_grant_id"],&b["plan_revision"],&b["plan_digest"]));
        origin["ancestors"]=json!(["task-1","task-1"]);assert!(!factory_origin_matches(&origin,&b["task_id"],&b["root_grant_id"],&b["plan_revision"],&b["plan_digest"]));
    }
    #[test]
    fn factory_owner_cancel_every_page_and_final_is_zero_decision_for_approve_and_reject() {
        let (mut p,selection)=factory_node_fixture();p["result"]["snapshot"]["criterion"]["criterion_text"]=json!("中".repeat(4000));
        let count=graph_review_pages(&p["result"]["snapshot"]).unwrap().len();
        for decline in 0..=count {for reject in [true,false] {
            let seen=Cell::new(0);let confirm=|_:&str|{let n=seen.get();seen.set(n+1);n!=decline};
            let reply=if reject {confirm_goal_node_rejection_and_decline(p.clone(),&selection,9,confirm,|_|panic!("cancel declined"))}else{confirm_goal_node_and_finalize(p.clone(),&selection,9,confirm,|_|panic!("cancel finalized"))}.unwrap();
            assert_eq!(reply["error"]["code"],"PERMISSION_DENIED");
        }}
    }
    #[test]
    fn legacy_owner_origin_omission_preserves_bytes_but_explicit_null_does_not_upgrade() {
        let (p,selection)=graph_node_proposal_fixture();let original=serde_json::to_vec(&p).unwrap();
        assert!(graph_node_snapshot_matches(&p["result"]["snapshot"],&selection,9));assert_eq!(serde_json::to_vec(&p).unwrap(),original);
        let mut bad=p;bad["result"]["snapshot"]["run_binding"]["factory_origin"]=Value::Null;
        assert!(!graph_node_snapshot_matches(&bad["result"]["snapshot"],&selection,9));
    }
'''
s=s[:pos]+new+s[pos:]
pos=s.index('\n}\n\n#[cfg(test)]\nmod factory_contract_regression_tests {')
new=r'''
    fn execution_fixture() -> (Value,Value) {
        let (mut selection,mut p)=planning_fixture();
        selection["capabilities"]["child_goal_execution"]=json!(true);
        let budget=json!({"attempts":2,"parallel":1,"runtime_ms":1000,"output_bytes":1024,"children":1,"reworks":0,"tokens":null,"cost_microunits":null});
        let policy=json!({"max_nodes":2,"max_runs_per_task":1,"max_total_runs":2,"root_budget":budget,"project_budget":budget,"require_owner_acceptance":true});
        selection["child_goal_execution_policy"]=policy.clone();p["result"]["snapshot"]["selection"]=selection.clone();
        let b=&mut p["result"]["snapshot"]["bindings"];b["approved_grant"]["scope"]["max_children"]=json!(1);b["approved_grant"]["scope"]["max_depth"]=json!(1);
        b["child_goal_execution"]=json!({"schema_version":1,"authority_kind":"factory_child_goal_execution_v1","policy":policy,"planning_policy_digest":b["child_planning"]["definition_digest"],"root_grant_id":"grant","root_grant_revision":2,"original_max_children":1,"original_max_depth":1,"graph_contract_version":1,"definition_digest":"f".repeat(64),"new_workspace_authorized":false});
        (selection,p)
    }
    #[test]
    fn explicit_execution_policy_full_snapshot_keeps_original_grant_and_does_not_start() {
        let (selection,p)=execution_fixture();assert!(factory_snapshot_matches(&p["result"]["snapshot"],&selection));
        let expected=serde_json::to_string(&p["result"]["snapshot"]).unwrap();let mut parts=Vec::new();let before=p["result"]["snapshot"]["bindings"]["approved_grant"].clone();
        let result=confirm_factory_and_finalize(p.clone(),&selection,|message|{assert!(message.contains("CHILD GOAL EXECUTION"));if !message.contains("FINAL independent") {parts.push(message.rsplit("\n\n").next().unwrap().to_owned());}true},|frame|{assert_eq!(frame["method"],"approvals.finalize");Ok(scope_result(&p))}).unwrap();
        assert_eq!(parts.concat(),expected);assert_eq!(result["result"]["bindings"]["approved_grant"],before);
        assert_eq!(result["result"]["bindings"]["child_planning"]["goal_execution_authorized"],false);
    }
    #[test]
    fn execution_missing_policy_old_none_or_expanded_grant_budget_never_prompts() {
        let (selection,p)=execution_fixture();
        for pointer in ["/schema_version","/authority_kind","/policy/max_nodes","/policy/max_runs_per_task","/policy/require_owner_acceptance","/planning_policy_digest","/root_grant_revision","/original_max_children","/original_max_depth","/new_workspace_authorized"] {
            let mut bad=p.clone();*bad["result"]["snapshot"]["bindings"]["child_goal_execution"].pointer_mut(pointer).unwrap()=json!("bad");
            let value=confirm_factory_and_finalize(bad,&selection,|_|panic!("bad execution prompted"),|_|panic!("bad execution finalized")).unwrap();assert_eq!(value["error"]["code"],"INVALID_APPROVAL_PROPOSAL");
        }
        for field in ["child_goal_execution_policy","child_planning_policy"] {let mut bad=selection.clone();bad.as_object_mut().unwrap().remove(field);assert!(!factory_selection_matches(&bad));bad[field]=Value::Null;assert!(!factory_selection_matches(&bad));}
        for key in ["attempts","parallel","runtime_ms","output_bytes","children"] {
            let mut bad=selection.clone();bad["child_goal_execution_policy"]["root_budget"][key]=json!(999999);assert!(!factory_selection_matches(&bad));
        }
        let mut bad=p;bad["result"]["snapshot"]["bindings"]["approved_grant"]["scope"]["max_children"]=json!(0);assert!(!factory_snapshot_matches(&bad["result"]["snapshot"],&selection));
    }
    #[test]
    fn false_execution_legacy_selection_and_binding_remain_omitted_not_null() {
        for planning in [false,true] {
            let (selection,p)=if planning {planning_fixture()}else{fixture()};let raw=serde_json::to_vec(&p).unwrap();
            assert!(factory_snapshot_matches(&p["result"]["snapshot"],&selection));assert_eq!(raw,serde_json::to_vec(&p).unwrap());
            let mut bad=selection.clone();bad["child_goal_execution_policy"]=Value::Null;assert!(!factory_selection_matches(&bad));
            let mut bad=p;bad["result"]["snapshot"]["bindings"]["child_goal_execution"]=Value::Null;assert!(!factory_snapshot_matches(&bad["result"]["snapshot"],&selection));
        }
    }
'''
s=s[:pos]+new+s[pos:];p.write_text(s)
p=r/'apps/desktop/src-tauri/src/lib.rs';s=p.read_text();pos=s.rindex('\n}')
new=r'''
    fn child_goal_request_fixture() -> agentbaton_core::factory::FactoryChildGoalSubmission {
        serde_json::from_value(json!({"task_id":"child","plan":{"id":"saved","scope_id":"factory","run_id":"factory-run","task_id":"child","revision":2,"plan_digest":"a".repeat(64),"raw_sha256":"b".repeat(64),"receipt_sequence":12},"expected_factory_run_revision":9})).unwrap()
    }
    #[test]
    fn child_goal_fixed_frames_preserve_three_separate_cas_values_original_key_and_inner_snake_case() {
        let request=child_goal_request_fixture();
        assert_eq!(factory_child_goal_start_frame("factory",&request,7,"same-key"),json!({"method":"factory_child_goals.start","params":{"scope_id":"factory","request":request},"expected_revision":7,"idempotency_key":"same-key"}));
        assert_eq!(factory_child_goal_advance_frame("factory","goal-run",&request,4,7,"same-key"),json!({"method":"factory_child_goals.advance_plan","params":{"scope_id":"factory","goal_run_id":"goal-run","request":request,"expected_goal_run_revision":4},"expected_revision":7,"idempotency_key":"same-key"}));
        assert_eq!(factory_child_goal_cancel_frame("factory","child","goal-run",4,7,"same-key"),json!({"method":"factory_child_goals.cancel","params":{"scope_id":"factory","task_id":"child","goal_run_id":"goal-run","expected_goal_run_revision":4},"expected_revision":7,"idempotency_key":"same-key"}));
    }
    #[test]
    fn child_goal_read_routes_have_explicit_nullable_run_and_no_cas_or_mutation_key() {
        assert_eq!(factory_child_goal_get_frame("factory","child",None),json!({"method":"factory_child_goals.get","params":{"scope_id":"factory","task_id":"child","goal_run_id":null}}));
        assert_eq!(factory_child_goal_get_frame("factory","child",Some("run")),json!({"method":"factory_child_goals.get","params":{"scope_id":"factory","task_id":"child","goal_run_id":"run"}}));
        assert_eq!(factory_child_goal_list_frame("factory","child"),json!({"method":"factory_child_goals.list","params":{"scope_id":"factory","task_id":"child","goal_run_id":null}}));
    }
    #[test]
    fn child_goal_typed_request_does_not_accept_authority_caller_tokens_or_float_revisions() {
        for key in ["approved","token","caller","root_grant_id","scope_id","execution_binding"] {
            let mut value=json!(child_goal_request_fixture());value[key]=json!(true);
            assert!(serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalSubmission>(value).is_err());
        }
        for value in [json!(true),json!(1.0),json!(null)] {
            let mut request=json!(child_goal_request_fixture());request["expected_factory_run_revision"]=value;
            assert!(serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalSubmission>(request).is_err());
        }
    }
'''
s=s[:pos]+new+s[pos:];p.write_text(s)
