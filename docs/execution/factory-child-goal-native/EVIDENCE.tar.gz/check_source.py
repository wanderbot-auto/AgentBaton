"""Finite source/contract checks only. Does NOT execute new Rust behavior."""
from pathlib import Path
import subprocess,re,json,hashlib
root=Path('/workspace/.worktrees/factory-child-goal-native');out=Path(__file__).resolve().parent;base='2a3d6ae88f93fa074ada32973ed7a400cf500e89'
sha=lambda b:hashlib.sha256(b).hexdigest()
def old(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root).decode()
def end_brace(source,start):
 i=start;depth=0
 while i<len(source):
  if source.startswith('//',i):i=source.find('\n',i);continue
  if source.startswith('/*',i):
   level=1;i+=2
   while level:
    if source.startswith('/*',i):level+=1;i+=2
    elif source.startswith('*/',i):level-=1;i+=2
    else:i+=1
   continue
  raw=re.match(r'r(#+)?"',source[i:])
  if raw:
   end='"'+(raw[1] or '');i=source.index(end,i+len(raw[0]))+len(end);continue
  if source[i]=='"':
   i+=1
   while source[i]!='"':i+=2 if source[i]=='\\' else 1
   i+=1;continue
  if source[i]=="'":
   char=re.match(r"'(?:\\(?:u\{[0-9a-fA-F]+\}|.)|[^'\\\n])'",source[i:])
   if char:i+=len(char[0]);continue
  if source[i]=='{':depth+=1
  elif source[i]=='}':
   depth-=1
   if depth==0:return i+1
  i+=1
 raise ValueError('Unterminated Rust block')
def tests(source):
 result={}
 for m in re.finditer(r'#\[test\]\s*fn\s+(\w+)\s*\(',source):
  brace=source.index('{',m.end());result[m[1]]=source[m.start():end_brace(source,brace)]
 return result
checks=[]
def check(name,value,detail=None):checks.append({'name':name,'passed':bool(value),'detail':detail});assert value,name
approval=(root/'apps/desktop/src-tauri/src/approval.rs').read_text();lib=(root/'apps/desktop/src-tauri/src/lib.rs').read_text()
for path,source in [('apps/desktop/src-tauri/src/approval.rs',approval),('apps/desktop/src-tauri/src/lib.rs',lib)]:
 a,b=tests(old(path)),tests(source);check('all_prior_Rust_tests_byte_equal:'+path,all(b.get(k)==v for k,v in a.items()),{'old':len(a),'new':len(b),'added':sorted(set(b)-set(a))})
for path in ['apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs','crates/core/src/factory.rs','crates/core/src/goal_graph.rs']:
 check('unchanged:'+path,(root/path).read_text()==old(path))
contract=old('docs/execution/factory-child-goal-core/WIRE_CONTRACT.md')
methods=['start','get','list','cancel','advance_plan']
for method in methods:
 name='factory_child_goals_'+method
 check('fixed_tauri_registered:'+method,re.search(r'#\[tauri::command\]\s*async fn '+name+r'\(',lib) is not None and lib.count('\n        '+name+',')==1)
 check('fixed_core_method:'+method,'"factory_child_goals.'+method+'"' in lib)
 check('frozen_wire_names:'+method,name in contract and 'factory_child_goals.'+method in contract)
check('typed_inner_request_only',lib.count('request: agentbaton_core::factory::FactoryChildGoalSubmission')==2)
check('no_HTTP_or_token_method_bridge','async fn factory_child_goals_call' not in lib and 'async fn factory_child_goals_finalize' not in lib)
for field in ['scope_id','request','expected_goal_run_revision','expected_revision','idempotency_key','goal_run_id']:
 check('wire_snake_field:'+field,'"'+field+'"' in lib[lib.index('fn factory_child_goal_start_frame'):lib.index('async fn goal_graph_run_approve')])
check('get_list_explicit_nullable_run', '"goal_run_id":goal_run_id' in lib and '"goal_run_id":null' in lib)
check('Core_typed_origin_not_assembled', 'serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalOriginView>' in approval)
check('get_requires_typed_view','serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalView>' in approval)
check('old_private_Node_routes_preserved', '"approvals.finalize"' in approval and '"approvals.decline"' in approval and '"goal_node_acceptance"' in approval)
check('no_new_approval_kind','"factory_child_goal_acceptance"' not in approval and '"factory_child_goal_execution" => ' not in approval)
check('legacy_None_no_insertion','match binding.get("factory_origin")' in approval and 'None => criterion["rule_id"] != "factory-child-owner-review"' in approval)
check('initial_ref_full_scope_run_task_binding',all(x in approval for x in ['initial["scope_id"] == origin["factory_scope_id"]','initial["run_id"] == origin["factory_run_id"]','initial["task_id"] == *task']))
check('digest_domains_not_conflated','binding["scope_digest"] == origin["execution_binding"]["planning_policy_digest"]' in approval and 'binding["scope_digest"] == origin["factory_scope_digest"]' not in approval)
check('full_criterion_bound', '16_384' in approval[approval.index('criterion["criterion_text"]'):approval.index('criterion["criterion_digest"]')])
# Keep the original planning/legacy caption extraction byte-identical for14 harness.
original=old('apps/desktop/src-tauri/src/approval.rs');pattern=r'let action = if selection\["capabilities"\]\["child_planning"\] == true \{.*?\n    \};'
check('old_false_planning_caption_complete_bytes',re.search(pattern,approval,re.S).group()==re.search(pattern,original,re.S).group())
for marker in ['GRAPH_REVIEW_SNAPSHOT_BYTES: usize = 1_048_576','GRAPH_REVIEW_PAGE_BYTES: usize = 12_288','message.len() > 16_384']:
 check('original_review_bound:'+marker,marker in approval and marker in original)
check('no_Native15_Cargo_claim',True,'Static checks and parse only; no Rust compilation/unit execution, Core/IPC, Node, AppKit/Mac, CI or packages')
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=root,text=True).splitlines();check('two_allowed_production_paths_only',changed==['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs'])
record={'base':base,'checks':checks,'count':len(checks),'source':{p:sha((root/p).read_bytes()) for p in changed},'Rust_markers':{'approval':len(tests(approval)),'bridge_lib':len(tests(lib))},'status':'STATIC_ONLY_RUNTIME_NOT_RUN'}
(out/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all_pass':True,'Rust_markers':record['Rust_markers']}))
