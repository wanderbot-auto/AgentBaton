from pathlib import Path
r=Path('/workspace/.worktrees/factory-child-goal-native');p=r/'apps/desktop/src-tauri/src/approval.rs';s=p.read_text()
a=s.index('fn factory_planning_fields(');b=s.index('\nfn factory_planning_reference',a)
s=s[:a]+'''fn factory_policy_fields(value: &Value, fields: &[&str], optional: &[(&str, bool)]) -> bool {
    value.as_object().is_some_and(|object| {
        object.len() == fields.len() + optional.iter().filter(|(_, enabled)| *enabled).count()
            && fields.iter().all(|name| object.contains_key(*name))
            && optional.iter().all(|(name, enabled)| object.contains_key(*name) == *enabled)
    })
}
'''+s[b:]
s=s.replace('    let planning = value["capabilities"]["child_planning"] == true;\n    factory_planning_fields(', '    let planning = value["capabilities"]["child_planning"] == true;\n    let execution = value["capabilities"]["child_goal_execution"] == true;\n    factory_policy_fields(',1)
s=s.replace('''        "child_planning_policy",
        planning,
    ) && graph_id''','''        &[("child_planning_policy", planning), ("child_goal_execution_policy", execution)],
    ) && graph_id''',1)
s=s.replace('''        && value["capabilities"]["child_goal_execution"] == false
        && value["capabilities"]["create_workspace"] == false''','''        && (if execution {
            planning && factory_execution_policy(&value["child_goal_execution_policy"])
                && factory_budget_narrower(&value["child_goal_execution_policy"]["root_budget"], &value["root_budget"])
                && factory_budget_narrower(&value["child_goal_execution_policy"]["project_budget"], &value["project_budget"])
                && value["child_goal_execution_policy"]["max_nodes"].as_u64() <= value["child_planning_policy"]["max_nodes"].as_u64()
                && value["child_goal_execution_policy"]["max_total_runs"].as_u64() <= value["max_total_nodes"].as_u64()
        } else { value["capabilities"]["child_goal_execution"] == false })
        && value["capabilities"]["create_workspace"] == false''',1)
s=s.replace('''|| !factory_planning_fields(
            b,''','''|| !factory_policy_fields(
            b,''',1)
s=s.replace('''            "child_planning",
            selection["capabilities"]["child_planning"] == true,
        )''','''            &[("child_planning", selection["capabilities"]["child_planning"] == true),
              ("child_goal_execution", selection["capabilities"]["child_goal_execution"] == true)],
        )''',1)
s=s.replace('''        || !exact_fields(
            project,''','''        || (selection["capabilities"]["child_goal_execution"] == true
            && !factory_execution_binding(&b["child_goal_execution"], selection, b))
        || !exact_fields(
            project,''',1)
pos=s.index('\nfn factory_selection_matches(')
new=r'''

fn factory_budget_narrower(value: &Value, ceiling: &Value) -> bool {
    factory_budget(value) && factory_budget(ceiling)
        && ["attempts","parallel","runtime_ms","output_bytes","children","reworks"].iter()
           .all(|key|value[*key].as_u64()<=ceiling[*key].as_u64())
        && ["tokens","cost_microunits"].iter().all(|key|value[*key].is_null() && ceiling[*key].is_null())
}
fn factory_execution_policy(policy: &Value) -> bool {
    exact_fields(policy,&["max_nodes","max_runs_per_task","max_total_runs","root_budget","project_budget","require_owner_acceptance"])
        && factory_safe(&policy["max_nodes"],1,256)
        && factory_safe(&policy["max_runs_per_task"],1,1)
        && factory_safe(&policy["max_total_runs"],1,1000)
        && policy["require_owner_acceptance"]==true
        && factory_budget_narrower(&policy["root_budget"],&policy["project_budget"])
        && policy["root_budget"]["reworks"]==0 && policy["project_budget"]["reworks"]==0
}
fn factory_execution_binding_shape(binding: &Value) -> bool {
    exact_fields(binding,&["schema_version","authority_kind","policy","planning_policy_digest","root_grant_id","root_grant_revision","original_max_children","original_max_depth","graph_contract_version","definition_digest","new_workspace_authorized"])
        && factory_safe(&binding["schema_version"],1,1)
        && binding["authority_kind"]=="factory_child_goal_execution_v1"
        && factory_execution_policy(&binding["policy"])
        && graph_hash(&binding["planning_policy_digest"]) && graph_hash(&binding["definition_digest"])
        && graph_id(&binding["root_grant_id"]) && graph_revision(&binding["root_grant_revision"])
        && factory_safe(&binding["original_max_children"],0,u32::MAX as u64)
        && factory_safe(&binding["original_max_depth"],0,u32::MAX as u64)
        && factory_safe(&binding["graph_contract_version"],1,1)
        && binding["new_workspace_authorized"]==false
        && binding["policy"]["max_nodes"].as_u64().is_some_and(|nodes|nodes<=binding["original_max_children"].as_u64().unwrap_or(0).saturating_add(1))
        && binding["policy"]["root_budget"]["children"].as_u64()<=binding["original_max_children"].as_u64()
}
fn factory_execution_binding(binding: &Value, selection: &Value, bindings: &Value) -> bool {
    let grant=&bindings["approved_grant"];
    factory_execution_binding_shape(binding)
        && binding["policy"]==selection["child_goal_execution_policy"]
        && binding["planning_policy_digest"]==bindings["child_planning"]["definition_digest"]
        && binding["root_grant_id"]==grant["id"] && binding["root_grant_revision"]==grant["revision"]
        && binding["original_max_children"]==grant["scope"]["max_children"]
        && binding["original_max_depth"]==grant["scope"]["max_depth"]
        && [ ("attempts","max_attempts"),("parallel","max_concurrency"),("runtime_ms","max_duration_ms") ].iter()
            .all(|(p,g)| binding["policy"]["root_budget"][*p].as_u64().is_some_and(|n|grant["scope"][*g].as_u64().is_some_and(|limit|n<=limit)))
}
fn factory_saved_ref(reference: &Value) -> bool {
    exact_fields(reference,&["id","scope_id","run_id","task_id","revision","plan_digest","raw_sha256","receipt_sequence"])
        && ["id","scope_id","run_id","task_id"].iter().all(|k|graph_id(&reference[*k]))
        && graph_revision(&reference["revision"]) && graph_revision(&reference["receipt_sequence"])
        && graph_hash(&reference["plan_digest"]) && graph_hash(&reference["raw_sha256"])
}
/// This is a server-derived provenance display, never a minted capability.
/// Core's private typed issuer authenticates origin before returning/proposing.
fn factory_origin_matches(origin: &Value, task: &Value, root_grant: &Value, revision: &Value, plan_digest: &Value) -> bool {
    if serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalOriginView>(origin.clone()).is_err()
        || !exact_fields(origin,&["factory_scope_id","factory_scope_digest","factory_run_id","factory_root_task_id","parent_task_id","ancestors","original_native_approval_id","root_grant_id","root_grant_revision","initial_plan","execution_binding"]) {
        return false;
    }
    let initial=&origin["initial_plan"];let execution=&origin["execution_binding"];
    ["factory_scope_id","factory_run_id","factory_root_task_id","root_grant_id","original_native_approval_id"].iter().all(|k|graph_id(&origin[*k]))
        && graph_hash(&origin["factory_scope_digest"])
        && origin["original_native_approval_id"]==origin["factory_scope_id"]
        && origin["root_grant_id"]==*root_grant && graph_revision(&origin["root_grant_revision"])
        && execution["root_grant_id"]==*root_grant && execution["root_grant_revision"]==origin["root_grant_revision"]
        && factory_execution_binding_shape(execution) && factory_saved_ref(initial)
        && initial["scope_id"]==origin["factory_scope_id"] && initial["run_id"]==origin["factory_run_id"]
        && initial["task_id"]==*task && graph_revision(revision)
        && revision.as_u64()>=initial["revision"].as_u64()
        && (*revision!=initial["revision"] || *plan_digest==initial["plan_digest"])
        && factory_ids(&origin["ancestors"],true)
        && origin["ancestors"].as_array().is_some_and(|a| {
            a.len()<=33 && a.first()==Some(task) && a.last()==Some(&origin["factory_root_task_id"])
                && match a.get(1) {Some(parent)=>*parent==origin["parent_task_id"],None=>origin["parent_task_id"].is_null()}
        })
}
fn graph_factory_origin_matches(binding: &Value, criterion: &Value) -> bool {
    match binding.get("factory_origin") {
        None => criterion["rule_id"]!="factory-child-owner-review",
        Some(origin) => criterion["rule_id"]=="factory-child-owner-review"
            && factory_origin_matches(origin,&binding["task_id"],&binding["root_grant_id"],&binding["plan_revision"],&binding["plan_digest"])
            && binding["scope_digest"]==origin["execution_binding"]["planning_policy_digest"],
    }
}
'''
s=s[:pos]+new+s[pos:]
s=s.replace('''        && snapshot["capability_digest"] == binding["capability_digest"]
        && graph_candidate_receipts_match''','''        && snapshot["capability_digest"] == binding["capability_digest"]
        && graph_factory_origin_matches(binding, criterion)
        && graph_candidate_receipts_match''',1)
# New explicit execution caption only; preserve exact old false/planning captions.
s=s.replace('''    let action = if selection["capabilities"]["child_planning"] == true {''','''    let action = if selection["capabilities"]["child_goal_execution"] == true {
        "Review INDEPENDENT explicit Factory CHILD GOAL EXECUTION within the ORIGINAL immutable Grant. Review the complete separate planning and execution policies, original Grant children/depth/attempt/duration limits, shared budgets, pinned outputs/validator definitions, lineage and input/identity/workspace bindings. Approval does NOT start a run, accept a candidate, enlarge the original Grant, create a workspace, or grant integration/release. Every Owner node still needs its own exact candidate/criterion decision. / 独立审查原Grant限额内的子Goal执行：完整核对规划与执行两策略、原子数/深度/尝试/期限、共享预算、输出与检查定义及输入身份工作区绑定；批准不启动、不验收产物、不扩大原Grant、不新建工作区，不授合入或发布；每个负责人节点仍须独立审查固定产物与验收条件。"
    } else if selection["capabilities"]["child_planning"] == true {''',1)
p.write_text(s)
