from pathlib import Path
r=Path('/workspace/.worktrees/factory-child-goal-native');p=r/'apps/desktop/src-tauri/src/approval.rs';s=p.read_text().replace('!text.trim().is_empty() && text.len() <= 2048','!text.trim().is_empty() && text.len() <= if binding.get("factory_origin").is_some() { 16_384 } else { 2048 }',1)
pos=s.index('\nfn factory_selection_matches(')
s=s[:pos]+r'''

pub(crate) fn check_factory_child_goal_view(response: Value, scope_id: &str, task_id: &str, goal_run_id: Option<&str>) -> Result<Value,String> {
    if let Some(error)=graph_server_error(&response) {return error;}
    let view=&response["result"];let summary=&view["summary"];let run=&view["details"]["run"];let origin=&view["origin"];
    let valid=serde_json::from_value::<agentbaton_core::factory::FactoryChildGoalView>(view.clone()).is_ok()
        && summary["authority_kind"]=="factory_child_goal_execution_v1"
        && summary["factory_scope_id"]==scope_id && summary["task_id"]==task_id
        && summary["factory_scope_id"]==origin["factory_scope_id"]
        && summary["factory_run_id"]==origin["factory_run_id"]
        && summary["factory_root_task_id"]==origin["factory_root_task_id"]
        && summary["parent_task_id"]==origin["parent_task_id"]
        && summary["execution_policy_digest"]==origin["execution_binding"]["definition_digest"]
        && summary["goal"]["run"]==*run && run["task_id"]==task_id
        && goal_run_id.is_none_or(|id|run["id"]==id)
        && view["details"]["graph_contract_version"]==1 && summary["goal"]["graph_contract_version"]==1
        && summary["goal"]["ledger_revision"]==view["details"]["ledger_revision"]
        && summary["goal"]["task_accepted"]==view["details"]["task_accepted"]
        && factory_saved_ref(&summary["plan"])
        && summary["plan"]["scope_id"]==origin["factory_scope_id"]
        && summary["plan"]["run_id"]==origin["factory_run_id"] && summary["plan"]["task_id"]==*task_id
        && summary["plan"]["revision"]==run["plan_revision"] && summary["plan"]["plan_digest"]==run["plan_digest"]
        && factory_origin_matches(origin,&run["task_id"],&run["root_grant_id"],&run["plan_revision"],&run["plan_digest"]);
    if !valid {return Ok(json!({"request_id":null,"error":{"code":"INVALID_CORE_RESPONSE","message":"Factory child Goal history requires its complete exact server origin, selected task/scope/run and saved reference; reconcile the original request","retryable":false,"side_effect_state":"not_started","details_ref":null},"revision":0,"warnings":[]}));}
    Ok(response)
}
'''+s[pos:]
s=s.replace('summary["plan"]["task_id"]==*task_id','summary["plan"]["task_id"]==task_id')
p.write_text(s)
p=r/'apps/desktop/src-tauri/src/lib.rs';s=p.read_text();pos=s.index('\n#[tauri::command]\nasync fn goal_graph_run_approve(')
bridges=r'''

// Fixed Owner child-Goal routes. The inner request uses Core's frozen typed
// snake_case DTO; it is not an authorization/caller/token or method selector.
fn factory_child_goal_start_frame(scope_id: &str, request: &agentbaton_core::factory::FactoryChildGoalSubmission, expected_revision: u64, key: &str) -> Value {
    json!({"method":"factory_child_goals.start","params":{"scope_id":scope_id,"request":request},"expected_revision":expected_revision,"idempotency_key":key})
}
fn factory_child_goal_get_frame(scope_id: &str, task_id: &str, goal_run_id: Option<&str>) -> Value {
    json!({"method":"factory_child_goals.get","params":{"scope_id":scope_id,"task_id":task_id,"goal_run_id":goal_run_id}})
}
fn factory_child_goal_list_frame(scope_id: &str, task_id: &str) -> Value {
    json!({"method":"factory_child_goals.list","params":{"scope_id":scope_id,"task_id":task_id,"goal_run_id":null}})
}
fn factory_child_goal_cancel_frame(scope_id: &str, task_id: &str, goal_run_id: &str, expected_goal_run_revision: u64, expected_revision: u64, key: &str) -> Value {
    json!({"method":"factory_child_goals.cancel","params":{"scope_id":scope_id,"task_id":task_id,"goal_run_id":goal_run_id,"expected_goal_run_revision":expected_goal_run_revision},"expected_revision":expected_revision,"idempotency_key":key})
}
fn factory_child_goal_advance_frame(scope_id: &str, goal_run_id: &str, request: &agentbaton_core::factory::FactoryChildGoalSubmission, expected_goal_run_revision: u64, expected_revision: u64, key: &str) -> Value {
    json!({"method":"factory_child_goals.advance_plan","params":{"scope_id":scope_id,"goal_run_id":goal_run_id,"request":request,"expected_goal_run_revision":expected_goal_run_revision},"expected_revision":expected_revision,"idempotency_key":key})
}
#[tauri::command]
async fn factory_child_goals_start(runtime: tauri::State<'_,Runtime>, scope_id: String, request: agentbaton_core::factory::FactoryChildGoalSubmission, expected_revision: u64, idempotency_key: String) -> Result<Value,String> {
    call(&runtime,factory_child_goal_start_frame(&scope_id,&request,expected_revision,&idempotency_key),false).await
}
#[tauri::command]
async fn factory_child_goals_get(runtime: tauri::State<'_,Runtime>, scope_id: String, task_id: String, goal_run_id: Option<String>) -> Result<Value,String> {
    let response=call(&runtime,factory_child_goal_get_frame(&scope_id,&task_id,goal_run_id.as_deref()),false).await?;
    approval::check_factory_child_goal_view(response,&scope_id,&task_id,goal_run_id.as_deref())
}
#[tauri::command]
async fn factory_child_goals_list(runtime: tauri::State<'_,Runtime>, scope_id: String, task_id: String) -> Result<Value,String> {
    call(&runtime,factory_child_goal_list_frame(&scope_id,&task_id),false).await
}
#[tauri::command]
async fn factory_child_goals_cancel(runtime: tauri::State<'_,Runtime>, scope_id: String, task_id: String, goal_run_id: String, expected_goal_run_revision: u64, expected_revision: u64, idempotency_key: String) -> Result<Value,String> {
    call(&runtime,factory_child_goal_cancel_frame(&scope_id,&task_id,&goal_run_id,expected_goal_run_revision,expected_revision,&idempotency_key),false).await
}
#[tauri::command]
async fn factory_child_goals_advance_plan(runtime: tauri::State<'_,Runtime>, scope_id: String, goal_run_id: String, request: agentbaton_core::factory::FactoryChildGoalSubmission, expected_goal_run_revision: u64, expected_revision: u64, idempotency_key: String) -> Result<Value,String> {
    call(&runtime,factory_child_goal_advance_frame(&scope_id,&goal_run_id,&request,expected_goal_run_revision,expected_revision,&idempotency_key),false).await
}
'''
s=s[:pos]+bridges+s[pos:]
s=s.replace('        factory_child_plans_submit,','        factory_child_plans_submit,\n        factory_child_goals_start,\n        factory_child_goals_get,\n        factory_child_goals_list,\n        factory_child_goals_cancel,\n        factory_child_goals_advance_plan,',1);p.write_text(s)
