from pathlib import Path
import subprocess,hashlib,json,datetime,sys
root=Path('/workspace/.worktrees/factory-child-goal-native');out=Path(__file__).resolve().parent;source='d250d3bd20d8295f238974c4c2f64564ffbdd735'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
paths=['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs'];before={p:sha(root/p) for p in paths}
commands=[('source48',['python','-B',str(out/'check_source.py')]),('rustfmt',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check',*paths]),('diffcheck',['git','diff','--check',source+'^',source])];results=[]
for name,command in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(command,cwd=root,capture_output=True)
 for suffix,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (out/(name+'.'+suffix)).write_bytes(raw)
 results.append({'name':name,'argv':command,'cwd':str(root),'start_UTC':start,'exit':p.returncode,'stdout':name+'.stdout','stdout_sha256':sha(out/(name+'.stdout')),'stderr':name+'.stderr','stderr_sha256':sha(out/(name+'.stderr'))});assert p.returncode==0,name
assert before=={p:sha(root/p) for p in paths}
inputs={}
for p in ['crates/core/src/factory.rs','crates/core/src/goal_graph.rs','crates/core/src/factory_child_goal.rs','crates/core/src/goal_factory.rs','docs/execution/factory-child-goal-core/WIRE_CONTRACT.md']:
 raw=subprocess.check_output(['git','show','2a3d6ae88f93fa074ada32973ed7a400cf500e89:'+p],cwd=root);target=out/('INPUT-'+Path(p).name);target.write_bytes(raw);inputs[p]={'sha256':sha(target),'copy':target.name,'bytes':len(raw)}
record={'source_commit':source,'base':'2a3d6ae88f93fa074ada32973ed7a400cf500e89','tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'source_files':{p:{'sha256':before[p],'bytes':(root/p).stat().st_size} for p in paths},'source_before_after_equal':True,'commands':results,'frozen_contract_inputs':inputs,'python_version':sys.version,'all_new_Rust_tests':{'added':13,'execution':'NOT_RUN','approval_markers':67,'bridge_markers':14,'library_total_including_unchanged_parent15':96,'counts_are_source_expectations_only':True},'not_run':['Cargo','Rust unit/type/Clippy','Core/schema15 runtime/migration/IPC/ledger/dispatch','Node/browser','Native AppKit/Mac','CI','Provider/accounts/credentials','packages'],'integration_constraint':'Retain Root later c0a readonly constant fix and later CI/test fixes; cherry-pick these two source deltas, never replace whole files with this2a3 baseline'}
(out/'SOURCE_SNAPSHOT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'source':source,'commands':[v['exit'] for v in results],'source_equal':True,'snapshot_sha256':sha(out/'SOURCE_SNAPSHOT.json')}))
