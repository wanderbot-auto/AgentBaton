"""Finite SOURCE/model checks only: never compiles or executes Native/Core."""
from pathlib import Path
import copy, hashlib, json, re, subprocess

ROOT = Path('/workspace/.worktrees/factory-child-goal-native')
OUT = Path(__file__).resolve().parent
PREVIOUS = 'd250d3bd20d8295f238974c4c2f64564ffbdd735'
CONTRACT = '4ffb21000030a3f82580f5a9c14ed40056bb13a0'
PATH = 'apps/desktop/src-tauri/src/approval.rs'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)

# Reuse only the prior lexical Rust-block scanner (not its executable checks,
# output writer, fixtures, policy or approval implementation).
old_checker = (OUT.parent / 'check_source.py').read_text()
scanner = old_checker[old_checker.index('def end_brace('):old_checker.index('checks=[]')]
exec(scanner, globals())
old = git('show', PREVIOUS + ':' + PATH).decode()
new = (ROOT / PATH).read_text()
checks = []
def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})
    assert condition, name
def function_map(source):
    result = {}
    for match in re.finditer(r'\bfn\s+(\w+)\s*(?:<[^\n]*>)?\s*\(', source):
        brace = source.index('{', match.end())
        result[match[1]] = source[match.start():end_brace(source, brace)]
    return result

a, b = function_map(old), function_map(new)
allowed = {'factory_budget', 'factory_execution_policy', 'factory_selection_matches'}
changed = {name for name in a if a[name] != b.get(name)}
check('only_three_existing_functions_changed', changed == allowed, sorted(changed))
old_tests, new_tests = tests(old), tests(new)
check('all_67_prior_approval_tests_byte_identical', len(old_tests) == 67 and
      all(new_tests.get(k) == v for k, v in old_tests.items()))
added = sorted(set(new_tests) - set(old_tests))
check('exactly_five_new_Rust_tests_SOURCE_ONLY', len(added) == 5, added)
libpath = 'apps/desktop/src-tauri/src/lib.rs'
check('lib_all_14_existing_tests_and_five_bridges_byte_identical',
      (ROOT / libpath).read_bytes() == git('show', PREVIOUS + ':' + libpath))
for name in ['graph_review_pages', 'factory_snapshot_matches',
             'factory_execution_binding', 'factory_execution_binding_shape',
             'factory_origin_matches', 'confirm_factory_and_finalize']:
    check('unchanged_full_review_or_binding:' + name, a[name] == b[name])
check('only_approval_source_modified_since_previous_checkpoint',
      git('diff', '--name-only', '4775b3f2ca7281d621879f46ec93ecf20063304e').decode().splitlines() == [PATH])
check('children_thousand_cap_unchanged', 'factory_safe(&value["children"], 0, 1000)' in b['factory_budget'])
check('reworks_strict_uint_less_than_attempts',
      'value["attempts"].as_u64().unwrap_or(0).saturating_sub(1)' in b['factory_budget'])
check('no_extra_project_thousand_reworks_cap',
      '["children", "reworks"]' not in b['factory_budget'])
check('legacy_false_planning_still_zero',
      '(execution || value[*k]["reworks"] == 0)' in b['factory_selection_matches'])
check('both_budget_layers_exact_reworks_equality',
      '&& ["root_budget", "project_budget"].iter().all(|k|' in b['factory_selection_matches'] and
      '== value[*k]["reworks"]' in b['factory_selection_matches'])
check('planning_revision_root_bound',
      '.is_some_and(|revisions| n < revisions)' in b['factory_selection_matches'])
check('policy_narrower_and_Owner_maxruns_remain', all(s in b['factory_execution_policy'] for s in [
    'factory_budget_narrower(&policy["root_budget"], &policy["project_budget"])',
    'policy["require_owner_acceptance"] == true',
    'factory_safe(&policy["max_runs_per_task"], 1, 1)']))
check('complete_policy_narrower_scope_still_required',
      b['factory_selection_matches'].count('factory_budget_narrower(') == 2)
check('no_workspaces_or_incomplete_execution_scope', all(s in b['factory_selection_matches'] for s in [
    'value["capabilities"]["create_workspace"] == false',
    'planning\n', 'factory_execution_policy(&value["child_goal_execution_policy"])']))
contract_inputs = {}
for path in ['crates/core/src/factory.rs', 'crates/core/src/factory_child_goal.rs',
             'docs/execution/factory-child-goal-core/WIRE_CONTRACT.md']:
    raw = git('show', CONTRACT + ':' + path)
    target = OUT / ('INPUT-4ff-' + Path(path).name)
    target.write_bytes(raw)
    contract_inputs[path] = {'sha256': sha(raw), 'bytes': len(raw), 'copy': target.name}
policy_source = (OUT / 'INPUT-4ff-factory_child_goal.rs').read_text()
for statement in [
    'policy.root_budget.reworks != selection.root_budget.reworks',
    'policy.project_budget.reworks != selection.project_budget.reworks',
    'policy.root_budget.reworks > policy.root_budget.attempts.saturating_sub(1)',
    'policy.project_budget.reworks > policy.project_budget.attempts.saturating_sub(1)',
    'policy.root_budget.reworks > planning.max_revisions.saturating_sub(1)',
]:
    check('frozen_4ff_condition:' + statement, statement in policy_source)

# This independent small arithmetic specification does NOT execute Rust and
# does not model authority, full snapshots, Grant freshness, CAS or dispatch.
def accepts(v):
    for label in ['selection_root', 'selection_project', 'policy_root', 'policy_project']:
        x = v[label]
        if type(x['attempts']) is not int or not 1 <= x['attempts'] <= 100000:
            return False
        if type(x['reworks']) is not int or not 0 <= x['reworks'] < x['attempts']:
            return False
    if v['selection_root']['reworks'] > v['selection_project']['reworks']:
        return False
    if not v['execution']:
        return v['selection_root']['reworks'] == v['selection_project']['reworks'] == 0
    return (v['planning'] and v['binding_present'] and
            v['policy_root']['reworks'] == v['selection_root']['reworks'] and
            v['policy_project']['reworks'] == v['selection_project']['reworks'] and
            v['policy_root']['reworks'] <= v['policy_project']['reworks'] and
            type(v['max_revisions']) is int and
            1 <= v['max_revisions'] <= 256 and
            v['policy_root']['reworks'] < v['max_revisions'])
base = {'selection_root': {'attempts': 3, 'reworks': 1},
        'selection_project': {'attempts': 3, 'reworks': 1},
        'policy_root': {'attempts': 2, 'reworks': 1},
        'policy_project': {'attempts': 2, 'reworks': 1},
        'execution': True, 'planning': True, 'binding_present': True, 'max_revisions': 4}
vectors = []
def vector(name, mutate, expected):
    value = copy.deepcopy(base)
    mutate(value)
    actual = accepts(value)
    vectors.append({'name': name, 'input': value, 'expected': expected, 'actual': actual})
    assert actual == expected, name
vector('explicit_complete_nonzero', lambda v: None, True)
for label in ['selection_root', 'selection_project', 'policy_root', 'policy_project']:
    vector(label + '_mismatch_zero', lambda v, k=label: v[k].update(reworks=0), False)
    vector(label + '_attempts_equal_reworks', lambda v, k=label: v[k].update(attempts=1), False)
    for invalid in [True, 1.0, '1', None, -1]:
        vector(label + '_reject_type_or_sign_' + repr(invalid),
               lambda v, k=label, n=invalid: v[k].update(reworks=n), False)
for flag in ['planning', 'binding_present']:
    vector(flag + '_missing', lambda v, k=flag: v.update({k: False}), False)
vector('planning_boundary_equal_root_reworks_rejected', lambda v: v.update(max_revisions=1), False)
vector('planning_boundary_root_plus_one_accepted', lambda v: v.update(max_revisions=2), True)
def large(v):
    for k in ['selection_project', 'policy_project']:
        v[k].update(attempts=100000, reworks=99999)
vector('project99999_no_unapproved_thousand_cap', large, True)
for planning in [True, False]:
    vector('legacy_or_planning_nonzero_' + str(planning),
           lambda v, p=planning: v.update(execution=False, planning=p), False)
    def zero(v, p=planning):
        v.update(execution=False, planning=p)
        for k in ['selection_root', 'selection_project', 'policy_root', 'policy_project']:
            v[k]['reworks'] = 0
    vector('legacy_or_planning_zero_' + str(planning), zero, True)
check('focused_arithmetic_vectors_NOT_Rust_or_authority_execution',
      all(v['actual'] == v['expected'] for v in vectors), len(vectors))
(OUT / 'ARITHMETIC_VECTORS.json').write_text(json.dumps(vectors, indent=2) + '\n')
record = {'scope': 'Static source preservation + focused arithmetic specification only',
          'previous_source': PREVIOUS, 'Core_contract': CONTRACT, 'checks': checks,
          'static_checks': len(checks), 'arithmetic_vectors': len(vectors),
          'new_Rust_tests': added, 'Rust_tests_execution': 'NOT_RUN',
          'approval_source_sha256': sha((ROOT / PATH).read_bytes()),
          'contract_inputs': contract_inputs,
          'integration': 'Keep later Root c0a feature constant view; do not replace whole lib.rs.',
          'not_run': ['Cargo/Rust tests/type/Clippy', 'Core15 runtime/owned-stop/reworks',
                      'Node/browser', 'Native macOS/AppKit', 'CI', 'Provider', 'packages']}
(OUT / 'CHECKS.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'static_checks': len(checks), 'arithmetic_vectors': len(vectors),
                  'all_pass': True, 'new_Rust_test_sources': len(added), 'Rust_execution': 'NOT_RUN'}))
