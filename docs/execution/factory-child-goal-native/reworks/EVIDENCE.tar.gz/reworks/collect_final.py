from pathlib import Path
import datetime, hashlib, json, subprocess, sys

ROOT = Path('/workspace/.worktrees/factory-child-goal-native')
OUT = Path(__file__).resolve().parent
SOURCE = '9c81ea53422ebd55337076e9d8c450a2c726c1c0'
PREVIOUS = '4775b3f2ca7281d621879f46ec93ecf20063304e'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('status', '--porcelain') == b''
paths = ['apps/desktop/src-tauri/src/approval.rs', 'apps/desktop/src-tauri/src/lib.rs',
         'apps/desktop/src-tauri/src/native_parent.rs', 'apps/desktop/src-tauri/Cargo.toml',
         'apps/desktop/src-tauri/Cargo.lock', 'crates/core/src/factory.rs']
before = {p: {'sha256': sha((ROOT / p).read_bytes()), 'bytes': (ROOT / p).stat().st_size}
          for p in paths}
for p in paths:
    assert sha(git('show', SOURCE + ':' + p)) == before[p]['sha256'], p
for p in paths[:2]:
    (OUT / ('SOURCE-' + Path(p).name)).write_bytes((ROOT / p).read_bytes())
commands = [
    ('source-26-vectors38', ['python', '-B', str(OUT / 'check_source.py')]),
    ('rustfmt', ['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt',
                 '--edition', '2021', '--check', *paths[:2]]),
    ('diffcheck', ['git', 'diff', '--check', PREVIOUS, SOURCE]),
    ('cumulative-diffcheck', ['git', 'diff', '--check', '2a3d6ae88f93fa074ada32973ed7a400cf500e89', SOURCE]),
]
results = []
for name, argv in commands:
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.run(argv, cwd=ROOT, capture_output=True)
    record = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'start_UTC': timestamp,
              'exit': child.returncode}
    for suffix, raw in [('stdout', child.stdout), ('stderr', child.stderr)]:
        target = OUT / (name + '.' + suffix)
        target.write_bytes(raw)
        record[suffix] = {'path': target.name, 'bytes': len(raw), 'sha256': sha(raw)}
    results.append(record)
    assert child.returncode == 0, name
after = {p: {'sha256': sha((ROOT / p).read_bytes()), 'bytes': (ROOT / p).stat().st_size}
         for p in paths}
assert before == after
assert git('status', '--porcelain') == b''
for p in ['docs/execution/factory-child-goal-native/EVIDENCE.json',
          'docs/execution/factory-child-goal-native/EVIDENCE.tar.gz']:
    # Hash from exact prior Git objects, not from an agent's test claim.
    assert git('show', PREVIOUS + ':' + p) == git('show', SOURCE + ':' + p), p
snapshot = {'source_commit': SOURCE, 'previous_checkpoint': PREVIOUS,
            'previous_source': 'd250d3bd20d8295f238974c4c2f64564ffbdd735',
            'Core_contract': '4ffb21000030a3f82580f5a9c14ed40056bb13a0',
            'source_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'tracked_before': before, 'tracked_after': after, 'before_after_equal': before == after,
            'commands': results, 'python_version': sys.version,
            'original_records_unchanged': {
                p: sha(git('show', SOURCE + ':' + p)) for p in [
                    'docs/execution/factory-child-goal-native/EVIDENCE.json',
                    'docs/execution/factory-child-goal-native/EVIDENCE.tar.gz']},
            'new_Rust_tests_source_only': 5, 'previous_new_Rust_tests_source_only': 13,
            'expected_library_markers_only': 101,
            'execution_status': 'NO_CARGO_NO_RUST_RUNTIME_NO_NATIVE_OS',
            'not_run': ['Rust unit/type/Clippy', 'Core15/schema15/IPC/shared ledger/actual reworks',
                        'Node/browser', 'Native macOS/AppKit', 'CI', 'Provider', 'packages']}
(OUT / 'SOURCE_SNAPSHOT.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'source': SOURCE, 'command_exits': [c['exit'] for c in results],
                  'before_after_equal': True, 'snapshot_sha256': sha((OUT / 'SOURCE_SNAPSHOT.json').read_bytes())}))
