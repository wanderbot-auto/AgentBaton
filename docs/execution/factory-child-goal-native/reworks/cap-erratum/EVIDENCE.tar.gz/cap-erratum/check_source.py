"""Static preservation + arithmetic specification, not Native/Core execution."""
from pathlib import Path
import copy,hashlib,json,re,subprocess

ROOT=Path('/workspace/.worktrees/factory-child-goal-native')
OUT=Path(__file__).resolve().parent
OLD='9c81ea53422ebd55337076e9d8c450a2c726c1c0'
CORE='4ffb21000030a3f82580f5a9c14ed40056bb13a0'
PATH='apps/desktop/src-tauri/src/approval.rs'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
sha=lambda x:hashlib.sha256(x).hexdigest()
original=(OUT.parent.parent/'check_source.py').read_text()
exec(original[original.index('def end_brace('):original.index('checks=[]')],globals())
def functions(s):
 result={}
 for m in re.finditer(r'\bfn\s+(\w+)\s*(?:<[^\n]*>)?\s*\(',s):
  b=s.index('{',m.end());result[m[1]]=s[m.start():end_brace(s,b)]
 return result
old=git('show',OLD+':'+PATH).decode();new=(ROOT/PATH).read_text()
a,b=functions(old),functions(new);checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'passed':bool(value),'detail':detail});assert value,name
renamed='reworks_project_bound_has_no_extra_native_thousand_cap_and_types_are_exact'
changed={k for k in a if a[k]!=b.get(k)}
check('exactly_budget_plus_corrected_test_changed',changed=={'factory_budget',renamed},sorted(changed))
prior=git('show','d250d3bd20d8295f238974c4c2f64564ffbdd735:'+PATH).decode()
pt,ot,nt=tests(prior),tests(old),tests(new)
check('all_original_67_tests_byte_equal',len(pt)==67 and all(nt.get(k)==v for k,v in pt.items()))
check('four_other_reworks_tests_byte_equal',sum(k not in pt and k!=renamed for k in ot)==4 and all(nt.get(k)==v for k,v in ot.items() if k!=renamed))
check('test_count72_unchanged_SOURCE_ONLY',len(nt)==len(ot)==72)
check('corrected_boundary_test_declared','reworks_project_keeps_general_thousand_cap_and_types_are_exact' in nt)
check('source_retains_general_cap','factory_safe(&value["reworks"], 0, 1000)' in b['factory_budget'])
check('source_retains_children_cap','factory_safe(&value["children"], 0, 1000)' in b['factory_budget'])
check('source_retains_attempt_bound','value["attempts"].as_u64().unwrap_or(0).saturating_sub(1)' in b['factory_budget'])
for k in ['factory_execution_policy','factory_selection_matches','factory_snapshot_matches','factory_execution_binding','factory_execution_binding_shape','factory_origin_matches','graph_review_pages','confirm_factory_and_finalize']:
 check('conditional_and_authority_checks_unchanged:'+k,a[k]==b[k])
lib='apps/desktop/src-tauri/src/lib.rs'
check('lib_and_14_bridge_tests_unchanged',(ROOT/lib).read_bytes()==git('show',OLD+':'+lib))
check('only_approval_source_changed',git('diff','--name-only','6c5f5c24ccc1591ee86585ab09dc0cd3c50582b7').decode().splitlines()==[PATH])
inputs={}
for path in ['crates/core/src/goal_plan.rs','crates/core/src/factory_child_goal.rs','crates/core/src/factory_store.rs','docs/execution/factory-child-goal-core/WIRE_CONTRACT.md']:
 raw=git('show',CORE+':'+path);p=OUT/('INPUT-4ff-'+Path(path).name);p.write_bytes(raw)
 inputs[path]={'path':p.name,'sha256':sha(raw),'bytes':len(raw)}
gp=(OUT/'INPUT-4ff-goal_plan.rs').read_text()
valid=gp[gp.index('impl BudgetLimits {'):gp.index('fn bounded(')]
check('complete_core_general_cap_source','&& self.reworks <= 1000' in valid)
check('complete_core_narrower_validates_both_sides','self.valid()\n            && other.valid()' in valid)
child=(OUT/'INPUT-4ff-factory_child_goal.rs').read_text()
check('complete_child_policy_calls_narrower',all(s in child for s in ['!policy.root_budget.narrower(&selection.root_budget)','!policy.project_budget.narrower(&selection.project_budget)','!policy.root_budget.narrower(&policy.project_budget)']))
check('attempts_and_planning_conditions_still_in_core',all(s in child for s in ['policy.root_budget.reworks > policy.root_budget.attempts.saturating_sub(1)','policy.project_budget.reworks > policy.project_budget.attempts.saturating_sub(1)','policy.root_budget.reworks > planning.max_revisions.saturating_sub(1)']))
cases=[]
def budget(attempts,reworks):
 return type(attempts)is int and 1<=attempts<=100000 and type(reworks)is int and 0<=reworks<=1000 and reworks<attempts
for attempts,reworks,expected in [(1001,1000,True),(100000,1000,True),(1000,1000,False),(100000,1001,False),(100000,99999,False),(100000,100000,False),(2,1,True),(1,0,True),(1,1,False),(0,0,False),(100001,0,False)]:
 actual=budget(attempts,reworks);cases.append({'attempts':attempts,'reworks':reworks,'expected':expected,'actual':actual});assert actual==expected
for bad in [True,False,1.0,'1',None,-1]:
 assert not budget(100000,bad);cases.append({'attempts':100000,'reworks':bad,'expected':False,'actual':False})
check('corrected_arithmetic_boundary_vectors_NOT_Rust',all(c['actual']==c['expected'] for c in cases),len(cases))
# Preserve and explicitly invalidate the historical specification, not its raw
# existence or old recorded exit0. No Core binary is invoked for this counterexample.
history=OUT.parent/'ARITHMETIC_VECTORS.json';rows=json.loads(history.read_text())
incorrect=next(v for v in rows if v['name']=='project99999_no_unapproved_thousand_cap')
check('historical_wrong_positive_preserved',incorrect['expected'] is True and incorrect['actual'] is True)
counter={'scope':'Arithmetic contract counterexample, NOT Core/Rust execution','historical_file_sha256':sha(history.read_bytes()),'historical_vector':incorrect,'corrected_accepts_project':budget(100000,99999),'explanation':'9c81/26+38 used an incomplete local contract. BudgetLimits::narrower calls valid on both budgets; valid imposes reworks<=1000.'}
check('historical99999_expected_true_now_false',counter['corrected_accepts_project'] is False)
(OUT/'HISTORICAL_SPEC_COUNTEREXAMPLE.json').write_text(json.dumps(counter,indent=2)+'\n')
(OUT/'BOUNDARY_VECTORS.json').write_text(json.dumps(cases,indent=2)+'\n')
for filename,expected in [('EVIDENCE.tar.gz','f97ac724f3cb69faabf76242a774fcc4d138379ef452f5f6e55d753ef9692f38'),('MANIFEST.json','5d3e3f462b2cccea94afc716058f3fe02c958b8dec3ef5855b0a407c15066cbf')]:
 check('immutable9c81_raw:'+filename,sha((OUT.parent/filename).read_bytes())==expected)
result={'scope':'Source preservation + finite arithmetic contract only','old_source':OLD,'contract':CORE,'checks':checks,'static_checks':len(checks),'arithmetic_vectors':len(cases),'inputs':inputs,'source_sha256':sha((ROOT/PATH).read_bytes()),'Rust_execution':'NOT_RUN','historical9c81_status':'SUPERSEDED_WRONG_SPECIFICATION_NOT_RUNTIME_PROOF'}
(OUT/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'static_checks':len(checks),'arithmetic_vectors':len(cases),'all_pass':True,'Rust_or_Core_execution':'NOT_RUN','old99999_positive':'preserved and invalidated'}))
