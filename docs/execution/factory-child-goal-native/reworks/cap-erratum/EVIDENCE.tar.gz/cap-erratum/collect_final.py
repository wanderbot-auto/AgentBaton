from pathlib import Path
import datetime,hashlib,json,subprocess,sys
ROOT=Path('/workspace/.worktrees/factory-child-goal-native');OUT=Path(__file__).resolve().parent
SOURCE='b97501c2719b0eaf0a459e79d09fd771a7231b03';PREVIOUS='6c5f5c24ccc1591ee86585ab09dc0cd3c50582b7'
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
sha=lambda x:hashlib.sha256(x).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
paths=['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','crates/core/src/factory.rs']
before={p:sha((ROOT/p).read_bytes()) for p in paths}
for p in paths[:2]:(OUT/('SOURCE-'+Path(p).name)).write_bytes(git('show',SOURCE+':'+p))
commands=[('corrected-static-boundaries',['python','-B',str(OUT/'check_source.py')]),('rustfmt',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check',*paths[:2]]),('diffcheck',['git','diff','--check',PREVIOUS,SOURCE]),('cumulative-diffcheck',['git','diff','--check','2a3d6ae88f93fa074ada32973ed7a400cf500e89',SOURCE])]
results=[]
for name,argv in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=ROOT,capture_output=True)
 row={'name':name,'argv':argv,'cwd':str(ROOT),'start_UTC':start,'exit':p.returncode}
 for suffix,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  target=OUT/(name+'.'+suffix);target.write_bytes(raw);row[suffix]={'path':target.name,'sha256':sha(raw),'bytes':len(raw)}
 results.append(row);assert p.returncode==0,name
after={p:sha((ROOT/p).read_bytes()) for p in paths};assert before==after and not git('status','--porcelain')
record={'source_commit':SOURCE,'previous_checkpoint':PREVIOUS,'contract':'4ffb21000030a3f82580f5a9c14ed40056bb13a0','before':before,'after':after,'source_before_after_equal':True,'commands':results,'python_version':sys.version,'Rust_test_execution':'NOT_RUN','new_Rust_tests_added_this_correction':0,'reworks_tests_retained_with_one_corrected':5,'prior_new_Rust_tests_also_NOT_RUN':13,'expected_total_library_markers_SOURCE_ONLY':101,'not_run':['Cargo/Rust type/tests/Clippy','Core15/IPC/ledger/actual reworks','Node/browser','macOS/AppKit','CI','Provider','packages'],'integration_constraint':'Keep later Root c0a constant bridge; integrate deltas, not whole old lib.rs.'}
(OUT/'SOURCE_SNAPSHOT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'source':SOURCE,'command_exits':[x['exit'] for x in results],'snapshot_sha256':sha((OUT/'SOURCE_SNAPSHOT.json').read_bytes()),'before_after_equal':True}))
