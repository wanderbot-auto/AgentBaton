import ast, hashlib, json, re, subprocess
from pathlib import Path
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog')
out=Path(__file__).resolve().parent
base='f9a7e0cd81c2e106e723c083e8c9b0a16fa33e2b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def original(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root)
allowed=['apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','scripts/native-owner-dialog-smoke.py']
preserved=['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/build.rs','apps/desktop/src-tauri/tauri.conf.json','scripts/native-run.py']
checks=[]
def check(name,passed,detail=None):
 checks.append({'name':name,'passed':bool(passed),'detail':detail});assert passed,name
for p in preserved:check('base_byte_equal:'+p,(root/p).read_bytes()==original(p),sha(original(p)))
new_tests=ast.parse((root/allowed[3]).read_text());old_tests=ast.parse(original(allowed[3]))
def methods(tree):return {n.name+'.'+f.name:ast.dump(f) for n in tree.body if isinstance(n,ast.ClassDef) for f in n.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
old=methods(old_tests);new=methods(new_tests);discovered_test_count=len(new)
check('all_old_30_python_test_AST_unchanged',len(old)==30 and all(new.get(k)==v for k,v in old.items()),{'old':len(old),'new':len(new),'added':len(new)-len(old)})
runner_old=ast.parse(original(allowed[4]));runner_new=ast.parse((root/allowed[4]).read_text())
def defs(tree):return {n.name:ast.dump(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(runner_old),defs(runner_new)
for name in ['NativeCoreClient','run','pending_error','approved_error','expected_message','presentation_prompts','presentation_error','stop_owned','group_helpers','enable_owned_subreaper']:
 check('original_Grant_AST_unchanged:'+name,a[name]==b[name])
mac=(root/allowed[2]).read_text();mac_old=original(allowed[2]).decode()
for literal in ['Duration::from_secs(75)','Duration::from_secs(4)','Duration::from_millis(500)','native_grant_os_dialog_fixture','expected["invoke"]["maxAttempts"] != 1','expected["invoke"]["maxDurationMs"] != 1000','fs::metadata(&fixture)?.len() > 65536']:
 check('original_native_gate_present:'+literal,literal in mac and literal in mac_old)
runner=(root/allowed[4]).read_text();check('85second_Grant_and_Factory_each',runner.count('time.monotonic() + 85')==2)
check('only_fixed_kind_choices',"choices=['grant', 'factory_planning'], default='grant'" in runner)
check('Native_real_production_dispatch', 'agentbaton_desktop::dispatch_production(invoke)' in mac)
check('Native_real_click_not_synthetic_result','unsafe { button.performClick(None) }' in mac)
entry=(root/allowed[0]).read_text();check('release_compile_error_preserved','#[cfg(not(debug_assertions))]\ncompile_error!("native owner dialog smoke must never ship in release");' in entry)
controller=(root/allowed[1]).read_text();check('old_10_plus_new_6_Rust_test_markers',controller.count('#[test]')==16)
old_block=original(allowed[1]).decode().split('#[cfg(test)]\nmod tests {',1)[1].strip()
new_block=controller.split('#[cfg(test)]\nmod tests {',1)[1].split('#[cfg(test)]\nmod factory_tests {',1)[0].strip()
check('original_Rust_10_test_block_byte_equal',old_block==new_block)
# Current input was captured by Core author, not executed by this reviewer/task.
capture=Path('/workspace/.onboarding/factory-child-planning-core/actual-core-owner-fixture-r2.json')
raw=capture.read_bytes();check('captured_Core_fixture_hash',sha(raw)=='317406b18ff81f4825b3182443ce07240f8a2f41106f7b41d7e64c5a3047085d')
(out/'captured-core-r2-INPUT.json').write_bytes(raw)
import importlib.util
spec=importlib.util.spec_from_file_location('runner_check',root/allowed[4]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
s=json.loads(raw)['scope'];proposal={'id':s['id'],'kind':'factory','revision':1,'consumed':False,'snapshot':{'schema_version':1,'selection':s['selection'],'bindings':s['bindings'],'contract_digest':s['contract_digest']}}
messages,pages,contexts=module.factory_presentation(proposal,(root/preserved[0]).read_text())
segments=[m.split('\n\n',2)[2] for m in messages[:-1]]
check('captured_full_snapshot_reverse_bytes',''.join(segments).encode()==module.compact(proposal['snapshot']))
shape={'dimension':'Captured earlier Core DTO as immutable data ONLY, NOT new Core/IPC/OS execution','producer_fixture_sha256':sha(raw),'snapshot_bytes':len(module.compact(proposal['snapshot'])),'outer_callbacks':len(messages),'inner_OS_pages':len(pages),'minimum_500ms_stability_seconds_per_phase':len(pages)*.5}
(out/'captured-shape-replay.json').write_text(json.dumps(shape,indent=2)+'\n')
# Proposed patches are NOT applied. No workflow/audit writer collision.
for path,old,new,label in [
('.github/workflows/product.yml',"      - uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02\n        if: always()\n        with:\n          name: native-webview-", "      - name: Actual Native Factory planning approval and unchanged Grant evidence\n        run: |\n          set -euo pipefail\n          python3 scripts/native-owner-dialog-smoke.py --kind factory_planning --binary apps/desktop/src-tauri/target/debug/agentbaton-native-owner-dialog-smoke --daemon target/debug/batond --companion target/debug/baton --output artifacts/native-smoke/factory-planning-owner-dialog\n      - uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02\n        if: always()\n        with:\n          name: native-webview-",'PROPOSED_CI_PATCH.diff'),
('scripts/native-audit-release.sh',"native_smoke_report|native-smoke-create|AGENTBATON_SMOKE_COMMIT", "native_smoke_report|native-smoke-create|AGENTBATON_SMOKE_COMMIT|owner_dialog_report|native_factory_planning_os_dialog_fixture",'PROPOSED_AUDIT_PATCH.diff')]:
 import difflib
 text=original(path).decode();check('proposal_unique_anchor:'+path,text.count(old)==1)
 changed=text.replace(old,new)
 (out/label).write_text(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
record={'base':base,'source_hashes':{p:sha((root/p).read_bytes()) for p in allowed},'checks':checks,'count':len(checks),'actual_native_Rust_AppKit_Mac_Core':'NOT_RUN'}
(out/'PRESERVATION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_pass':True,'python_discovered':discovered_test_count,'python_old_unchanged':30,'rust_controller_markers':16,'captured_shape':shape}))
