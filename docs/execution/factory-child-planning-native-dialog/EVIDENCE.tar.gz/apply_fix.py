from pathlib import Path
r=Path('/workspace/.worktrees/factory-child-planning-native-dialog');p=r/'scripts/native-owner-dialog-smoke.py';s=p.read_text()
s=s.replace("'other_proposals': dict(conn.execute('SELECT id,document FROM approval_proposals WHERE id!=?', (proposal_id,))),", "'other_proposals': other_proposal_rows(conn, proposal_id),")
pos=s.index('\ndef factory_database(')
helpers=r'''

def sqlite_raw(value, kind):
    """Lossless typed SQLite cell, never parse/normalize another receipt JSON."""
    if kind == 'null' and value is None:
        return {'sqlite_type': 'null', 'value': None}
    if kind == 'text' and type(value) is str:
        value.encode('utf-8')  # invalid text is failure, not a replacement string
        return {'sqlite_type': 'text', 'value': value}
    if kind == 'blob' and type(value) is bytes:
        return {'sqlite_type': 'blob', 'hex': value.hex()}
    if kind == 'integer' and type(value) is int:
        return {'sqlite_type': 'integer', 'value': value}
    if kind == 'real' and type(value) is float and math.isfinite(value):
        return {'sqlite_type': 'real', 'value': value}
    raise ValueError('Unsupported or mismatched SQLite storage class')


def other_proposal_rows(conn, excluded):
    # Actual approval_proposals has exactly id/document/result. Consumed,
    # expiry and every other immutable proposal field live inside document.
    rows = {}
    for key, document, result, doc_type, result_type in conn.execute(
            'SELECT id,document,result,typeof(document),typeof(result) FROM approval_proposals WHERE id!=?', (excluded,)):
        if type(key) is not str or key in rows:
            raise ValueError('Invalid/ambiguous non-target approval primary key')
        rows[key] = {'document': sqlite_raw(document, doc_type), 'result': sqlite_raw(result, result_type)}
    return rows


NATIVE_OWNER_BINARY = 'agentbaton-native-owner-dialog-smoke'


def native_binary_record(path):
    """Record the explicit compiled test executable without reading FIFO/links.

    This is byte/identity evidence, not compiler provenance or an OS sandbox.
    The actual build log + checkout + this raw hash supply that separate proof.
    """
    requested = Path(path).absolute()
    if requested.name != NATIVE_OWNER_BINARY:
        raise ValueError('Only the fixed Native Owner test executable is supported; not the default application')
    initial = requested.lstat()
    if (not stat.S_ISREG(initial.st_mode) or initial.st_uid != os.geteuid()
            or initial.st_mode & 0o022 or not initial.st_mode & 0o111):
        raise ValueError('Native test executable must be an owned regular non-writable-by-group/world executable, not a link/FIFO/directory')
    canonical = requested.resolve(strict=True)
    fields = ('st_dev', 'st_ino', 'st_nlink', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    fd = os.open(canonical, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    try:
        before = os.fstat(fd)
        if any(getattr(before, name) != getattr(initial, name) for name in fields):
            raise ValueError('Native test executable changed before capture')
        digest_value, size = hashlib.sha256(), 0
        while chunk := os.read(fd, 65536):
            digest_value.update(chunk)
            size += len(chunk)
        after = os.fstat(fd)
        live = canonical.lstat()
        if (size != before.st_size or any(getattr(after, name) != getattr(before, name) for name in fields)
                or any(getattr(live, name) != getattr(before, name) for name in fields)):
            raise ValueError('Native test executable changed during capture')
        return {'path': str(canonical), 'sha256': digest_value.hexdigest(), 'bytes': size,
                'device': before.st_dev, 'inode': before.st_ino, 'nlink': before.st_nlink,
                'mode': stat.S_IMODE(before.st_mode), 'mtime_ns': before.st_mtime_ns, 'ctime_ns': before.st_ctime_ns}
    finally:
        os.close(fd)


def native_binary_check(original):
    try:
        observed = native_binary_record(Path(original['path']))
        return {'stable': json_exact(observed, original), 'observed': observed}
    except Exception as error:
        return {'stable': False, 'error': {'type': type(error).__name__, 'message': str(error)}}


@contextmanager
def native_binary_witness(binary, output):
    original = native_binary_record(binary)
    save(output / 'native-binary-before.json', {'source': original, 'executed': original,
         'resource_contract': 'Execute the original canonical build path; no Native copy/resource-directory relocation',
         'compiler_provenance': 'Not certified by path/hash; bind real same-checkout build log separately'})
    primary = None
    try:
        yield original
    except BaseException as error:
        primary = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        after = native_binary_check(original)
        after['original_failure'] = primary
        try:
            save(output / 'native-binary-after.json', after)
        except Exception as secondary:
            if primary is None:
                raise
            print('SECONDARY Native binary evidence write failure: ' + repr(secondary), file=sys.stderr)
        if not after['stable'] and primary is None:
            raise RuntimeError('Native test executable changed; no successful Factory evidence')
'''
s=s[:pos]+helpers+s[pos:]
old="""    installed = output / 'private-tools'
    installed.mkdir(mode=0o700)
"""
new="""    with native_binary_witness(binary, output) as native:
        return run_factory_pinned(Path(native['path']), daemon_path, companion_path, output, cancel_at, native)


def run_factory_pinned(binary, daemon_path, companion_path, output, cancel_at, native):
    # Keep the existing Native executable/resource location. Only the normal
    # generated daemon/companion are copied beside one another as before.
    installed = output / 'private-tools'
    installed.mkdir(mode=0o700)
"""
assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace("            phase_failure = None\n            try:\n                app = subprocess.Popen", "            phase_failure = None\n            try:\n                native_before = native_binary_check(native)\n                save(phase_out / 'native-binary-before.json', native_before)\n                if not native_before['stable']:\n                    raise ValueError('Native test executable changed before actual Popen')\n                app = subprocess.Popen",1)
s=s.replace("                save(phase_out / 'app-cleanup.json', cleanup)\n                if not cleanup['ok'] and phase_failure is None:\n                    raise RuntimeError('Factory OS app did not exit cleanly')", "                save(phase_out / 'app-cleanup.json', cleanup)\n                native_after = native_binary_check(native)\n                save(phase_out / 'native-binary-after.json', native_after)\n                if phase_failure is None:\n                    if not cleanup['ok']:\n                        raise RuntimeError('Factory OS app did not exit cleanly')\n                    if not native_after['stable']:\n                        raise RuntimeError('Native test executable changed after actual Popen')",1)
s=s.replace("         'human_owner_approval': 'not_claimed', 'os': sys.platform, 'architecture': platform.machine()})", "         'human_owner_approval': 'not_claimed', 'os': sys.platform, 'architecture': platform.machine(),\n         'harness_binary_sha256': native['sha256'], 'harness_binary_path': native['path'],\n         'harness_binary_bytes': native['bytes'], 'harness_binary': native})",1)
p.write_text(s)
