import ast, datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog')
out=Path(__file__).resolve().parent
source='6002b10f7d0522791efef05a3461d7e6d68bb99b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==source
entries=subprocess.check_output(['git','ls-files','-v','-z'],cwd=root).decode().split('\0')
def snapshot():
 d={}
 for entry in entries:
  if not entry:continue
  flag,path=entry[0],entry[2:];p=root/path
  if p.is_file():d[path]=sha(p)
  elif flag=='S':d[path]=None
  else:raise ValueError('Unexpected missing tracked path '+path)
 return d
before=snapshot();results=[]
commands=[('pure-final',['python','-B',str(out.parent/'run_pure.py')]),('preservation-final-structured',['python','-B',str(out/'check_preservation.py')]),('rustfmt-final',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs']),('source-diff-check',['git','diff','--check',source+'^',source])]
for name,cmd in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(cmd,cwd=root,capture_output=True)
 stdout=out/(name+'.stdout');stderr=out/(name+'.stderr');stdout.write_bytes(p.stdout);stderr.write_bytes(p.stderr)
 results.append({'name':name,'argv':cmd,'cwd':str(root),'start_UTC':start,'end_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'stdout':stdout.name,'stdout_sha256':sha(stdout),'stderr':stderr.name,'stderr_sha256':sha(stderr)})
 assert p.returncode==0,name
for value in ['scripts/native-owner-dialog-smoke.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py']:
 compile((root/value).read_bytes(),value,'exec');ast.parse((root/value).read_text())
after=snapshot();assert before==after
paths=git('diff','--name-only','f9a7e0cd81c2e106e723c083e8c9b0a16fa33e2b',source).splitlines()
record={'base':git('rev-parse',source+'^'),'source_commit':source,'source_tree':git('rev-parse',source+'^{tree}'),'tracked_paths':len(before),'sparse_absent':sum(v is None for v in before.values()),'tracked_before_after_equal':before==after,'source_files':{p:{'sha256':before[p],'bytes':(root/p).stat().st_size} for p in paths},'python_version':sys.version,'standalone_rustfmt_version':subprocess.check_output([commands[2][1][0],'--version'],text=True).strip(),'commands':results,'python_syntax_compile_AST':'PASS (compile object only, no pycache writes)','actual_Core_Native_Rust_AppKit_Mac_browser_Provider':'NOT_RUN','remaining_actual_Core_tests':5,'future_Rust_controller_tests':16,'pure_Python_executed':42,'entire_Python_discovered':47,'record_boundary':'test-only source and generated/synthetic controls; no actual Factory approval was executed'}
(out/'SOURCE_SNAPSHOT.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'COMMAND_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'source':source,'tracked_before_after_equal':True,'commands':[{'name':v['name'],'exit':v['exit']} for v in results],'snapshot_sha256':sha(out/'SOURCE_SNAPSHOT.json')}))
