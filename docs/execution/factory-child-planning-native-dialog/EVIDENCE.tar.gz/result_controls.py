"""Exact SQL read-set controls, one generated table, NOT Core migration/runtime."""
import ast, importlib.util, sqlite3, sys, unittest
from pathlib import Path
module_path=Path(sys.argv.pop(1))
spec=importlib.util.spec_from_file_location('receipt_subject',module_path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
if hasattr(m,'other_proposal_rows'):
 def read(conn):return m.other_proposal_rows(conn,'target')
else:
 tree=ast.parse(module_path.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='database')
 query=next(n.value for n in ast.walk(fn) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('SELECT id,document FROM approval_proposals WHERE'))
 def read(conn):return dict(conn.execute(query,('target',)))
class ReceiptControls(unittest.TestCase):
 def test_result_only_storage_mutations_are_observed(self):
  for original,changed in [('original receipt','changed receipt'),(None,'null'),('null',None),('null',b'null'),('',None),('中文😀','中文😀'.encode())]:
   with self.subTest(original=repr(original),changed=repr(changed)):
    with sqlite3.connect(':memory:') as conn:
     conn.execute('CREATE TABLE approval_proposals(id TEXT PRIMARY KEY,document TEXT NOT NULL,result TEXT)')
     conn.execute('INSERT INTO approval_proposals VALUES(?,?,?)',('other','{"consumed":true,"expires_at_ms":999}',original))
     before=read(conn);conn.execute('UPDATE approval_proposals SET result=? WHERE id=?',(changed,'other'));after=read(conn)
     self.assertNotEqual(before,after,'result-only mutation must not become unchanged evidence')
 def test_document_consumed_and_expiry_changes_were_already_observed(self):
  for changed in ['{"consumed":false,"expires_at_ms":999}','{"consumed":true,"expires_at_ms":1000}']:
   with self.subTest(changed=changed),sqlite3.connect(':memory:') as conn:
    conn.execute('CREATE TABLE approval_proposals(id TEXT PRIMARY KEY,document TEXT NOT NULL,result TEXT)')
    conn.execute('INSERT INTO approval_proposals VALUES(?,?,?)',('other','{"consumed":true,"expires_at_ms":999}','receipt'))
    before=read(conn);conn.execute('UPDATE approval_proposals SET document=?',(changed,));self.assertNotEqual(before,read(conn))
if __name__=='__main__':unittest.main(verbosity=2)
