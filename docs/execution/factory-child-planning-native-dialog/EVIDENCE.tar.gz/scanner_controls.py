"""Shell scanner on generated TEXT ONLY. No application/bundle is executed."""
from pathlib import Path
import subprocess,tempfile,os,json,hashlib
out=Path(__file__).resolve().parent
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog')
old=subprocess.check_output(['git','show','f9a7e0cd81c2e106e723c083e8c9b0a16fa33e2b:scripts/native-audit-release.sh'],cwd=root)
original='native_smoke_report|native-smoke-create|AGENTBATON_SMOKE_COMMIT'
markers=['native_smoke_report','native-smoke-create','AGENTBATON_SMOKE_COMMIT','owner_dialog_report','native_factory_planning_os_dialog_fixture']
new=old.replace(original.encode(),('|'.join(markers)).encode());assert new!=old
(out/'original-audit.sh').write_bytes(old);(out/'proposed-audit.sh').write_bytes(new)
records=[]
with tempfile.TemporaryDirectory(prefix='ab-audit-controls-') as temp:
 base=Path(temp);fixture=base/'generated-text-fixture'
 normal='AgentBaton Native owner approval / Independent Factory approval / factory_scope_approve / factory_child_plans_context / factory_child_planning_only / 普通术语\n'
 cases=[('normal_production_words',normal,0,None)]+[(m,'controlled test-only '+m+'\n',1,None) for m in markers]+[('strings_failure','normal text\n',23,'strings'),('grep_failure','normal text\n',2,'grep')]
 for version,script in [('old',out/'original-audit.sh'),('proposed',out/'proposed-audit.sh')]:
  for name,text,expected,fail in cases:
   fixture.write_text(text);env=os.environ.copy()
   if fail:
    folder=base/(version+'-'+name);folder.mkdir();tool=folder/fail;tool.write_text('#!/bin/sh\nexit '+str(expected)+'\n');tool.chmod(0o700);env['PATH']=str(folder)+os.pathsep+env['PATH']
   p=subprocess.run(['/bin/bash',str(script),str(fixture)],capture_output=True,env=env)
   stdout=out/(version+'-audit-'+name+'.stdout');stderr=out/(version+'-audit-'+name+'.stderr');stdout.write_bytes(p.stdout);stderr.write_bytes(p.stderr)
   intended=0 if version=='old' and name in markers[-2:] else expected
   assert p.returncode==intended,(version,name,p.returncode,intended)
   if intended:assert b'PASS' not in p.stdout
   records.append({'version':version,'case':name,'argv':['/bin/bash',str(script),str(fixture)],'exit':p.returncode,'desired_policy_exit':expected,'stdout':stdout.name,'stderr':stderr.name,'scope':'synthetic text only, not an actual release audit'})
(out/'SCANNER_CONTROLS.json').write_text(json.dumps({'records':records,'actual_release_bundle':'NOT_RUN','old_new_marker_acceptances':2,'proposed_cases':8,'markers':markers,'production_words_should_pass':normal},indent=2)+'\n')
print('PASS old scanner original controls; reproduced2 new-marker acceptances; proposed scanner8cases strict (normal words,5markers,strings23,grep2). No product executable scanned.')
