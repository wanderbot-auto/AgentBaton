"""Execute pure controls ONLY. Actual Core cases remain present and explicitly NOT_RUN."""
import importlib.util, unittest, json, sys
from pathlib import Path
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog')
p=root/'apps/desktop/src-tauri/tests/test_native_owner_dialog.py'
spec=importlib.util.spec_from_file_location('native_dialog_tests',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
not_run={
 'test_real_readonly_sqlite_observation_rejects_authority_change',
 'test_real_core_grant_contract_binds_independent_approval_and_owner_proposal',
 'test_alias_parent_real_core_refuses_raw_alias_but_canonical_bootstrap_is_ready',
 'test_long_private_temp_parent_uses_short_canonical_real_core_runtime',
 'test_real_core_factory_preparation_is_schema14_complete_and_never_finalizes_target',
}
all_tests=[]
def visit(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):visit(t)
  else:all_tests.append(t)
visit(unittest.defaultTestLoader.loadTestsFromModule(m))
assert {t._testMethodName for t in all_tests if t._testMethodName in not_run}==not_run
selected=[t for t in all_tests if t._testMethodName not in not_run]
print(json.dumps({'pure_selected':[t.id() for t in selected],'actual_core_NOT_RUN':sorted(not_run),'policy':'No source tests deleted/skipped; this finite local selector does not claim full-suite PASS'}),flush=True)
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
sys.exit(not result.wasSuccessful())
