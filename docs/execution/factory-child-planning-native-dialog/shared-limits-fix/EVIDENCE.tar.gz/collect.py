from pathlib import Path
import hashlib,json,subprocess,datetime,shutil,tarfile
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog');out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source='c0a31a0da116694a95dd00036bc46c8ddc528463'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
paths=['apps/desktop/src-tauri/src/native_parent.rs','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs']
before={p:sha(root/p) for p in paths};results=[]
commands=[('mechanical16',['python','-B',str(out/'check_shared_limits.py')]),('rustfmt',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check',*paths]),('diffcheck',['git','diff','--check',source+'^',source])]
for name,cmd in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=root,capture_output=True)
 for suffix,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (out/(name+'.'+suffix)).write_bytes(raw)
 results.append({'argv':cmd,'cwd':str(root),'start_UTC':start,'exit':p.returncode,'stdout':name+'.stdout','stdout_sha256':sha(out/(name+'.stdout')),'stderr':name+'.stderr','stderr_sha256':sha(out/(name+'.stderr'))});assert p.returncode==0
assert before=={p:sha(root/p) for p in paths}
original=Path('/workspace/.onboarding/factory-child-planning-native-62518-actual')
for source_path,name in [(original/'actual-run/native-0.log','Root625-native-compile-failed.log'),(original/'actual-run/RESULT.json','Root625-native-result.json'),(original/'PYTHON_RESULT.json','Root625-PYTHON_RESULT.json'),(original/'python47.log','Root625-python47.log')]:
 shutil.copyfile(source_path,out/name)
assert sha(out/'Root625-native-compile-failed.log')=='1f512a9335aeba5c1d59e027aed457ac4fb2e688726bafe53f571fea4c78a843'
assert sha(out/'Root625-python47.log')=='4e2d26d8b279f3c0598a1bb28348d5abf32b5529ab37b2227910ab2dc295a7e8'
record={'source':source,'source_files':before,'source_before_after_equal':True,'commands':results,'own_execution':'static/Python source inspection + standalone Rustfmt only; no Cargo/Node/Core/browser','Root_prior_Rust':{'head':'62518def138d7c831d9f9cc4fbe59ea6478f59c9','exit':101,'tests_executed':0,'missing_constant_diagnostics':5,'original_inode_mode_nlink_sha_restored':True},'Root_prior_Python':{'head':'62518def138d7c831d9f9cc4fbe59ea6478f59c9','entire_tests':47,'actual_Core_cases_included':5,'unittest_seconds':8.247,'exit':0,'log_sha256':sha(out/'Root625-python47.log'),'dimension':'Root actual run, not independently executed by this author; two Python source files byte-equal current; does not prove Rust/AppKit/current const view'}}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'source':source,'commands':[v['exit'] for v in results],'source_equal':True,'root_compile_fail_preserved':True,'root_python47_separate':True}))
