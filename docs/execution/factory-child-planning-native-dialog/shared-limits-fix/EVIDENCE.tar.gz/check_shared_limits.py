from pathlib import Path
import subprocess,hashlib,json,re
root=Path('/workspace/.worktrees/factory-child-planning-native-dialog');out=Path(__file__).resolve().parent;base='6002b10f7d0522791efef05a3461d7e6d68bb99b'
checks=[]
def old(p):return subprocess.check_output(['git','show',base+':'+p],cwd=root).decode()
def check(name,condition):checks.append({'name':name,'passed':bool(condition)});assert condition,name
p='apps/desktop/src-tauri/src/native_parent.rs';parent=(root/p).read_text();before=old(p)
names=['REVIEW_MESSAGE_BYTES','REVIEW_ROW_ENCODED_BYTES','REVIEW_ROWS_PER_PAGE']
restored=parent
for name in names:
 check('single_production_definition:'+name,parent.count('pub(super) const '+name+': usize = ')==1)
 restored=restored.replace('pub(super) const '+name+': usize = ','const '+name+': usize = ',1)
check('parent_only_visibility_changes_full_bytes',restored==before)
p='apps/desktop/src-tauri/src/lib.rs';lib=(root/p).read_text();start=lib.index('// Read-only limits shared with the feature-gated Native test binary.');end=lib.index('\nstruct Runtime {',start);view=lib[start:end]
check('lib_only_view_addition_full_bytes',lib[:start]+lib[end+1:]==old(p))
check('view_cfg_native_smoke_only','#[cfg(feature = "native-smoke")]\npub mod native_review_test_limits {' in view)
for name in names:
 check('alias_references_same_definition:'+name,'pub const '+name+': usize = super::native_parent::'+name+';' in view)
check('no_public_use_E0364','pub use' not in view)
check('no_methods_or_ipc_or_numeric_copy',not re.search(r'\bfn\b|\bcommand\b|=\s*\d',view))
check('native_smoke_release_refusal_unchanged',lib[:lib.index('use agentbaton_core::ipc;')]==old(p)[:old(p).index('use agentbaton_core::ipc;')])
p='apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs';controller=(root/p).read_text();prefix='use agentbaton_desktop::native_review_test_limits::{\n    REVIEW_MESSAGE_BYTES, REVIEW_ROWS_PER_PAGE, REVIEW_ROW_ENCODED_BYTES,\n};\n'
check('controller_only_import_full_bytes',controller.replace(prefix,'',1)==old(p))
check('original10_new6_Rust_tests_untouched',controller.count('#[test]')==16)
# Root actually executed Python47 against625; these two files are byte-identical,
# but this does NOT turn the failed Rust build or new const bridge into a pass.
for p in ['scripts/native-owner-dialog-smoke.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py']:
 check('Python_exact625:'+p,(root/p).read_bytes()==subprocess.check_output(['git','show','62518def138d7c831d9f9cc4fbe59ea6478f59c9:'+p],cwd=root))
record={'base':base,'checks':checks,'count':len(checks),'new_Rust_compilation_tests':'NOT_RUN','own_Cargo_Core_Node_browser':'NOT_RUN'}
(out/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all_pass':True}))
