from pathlib import Path
import subprocess,hashlib,json,ast,re
r=Path('/workspace/.worktrees/playwright-driver-lifecycle');out=Path('/workspace/.onboarding/playwright-driver-lifecycle-independent-review');subject='65f7fd26bec8a88307178a69381389de6188efaa';p='.github/workflows/product.yml'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
base=git('rev-parse',subject+'^').decode().strip();a=git('show',base+':'+p).decode();b=git('show',subject+':'+p).decode();assert git('diff','--name-only',base,subject).decode().splitlines()==[p]
(out/'product-before.yml').write_text(a);(out/'product-after.yml').write_text(b);(out/'source.patch').write_bytes(git('diff','--binary',base,subject,'--',p))
oldimport='          import hashlib, json, pathlib, subprocess, sys\n          from playwright.sync_api import sync_playwright\n';newimport='          import asyncio, hashlib, json, pathlib, subprocess, sys\n          from playwright.async_api import async_playwright\n';oldlookup='          with sync_playwright() as playwright:\n              chromium = playwright.chromium.executable_path\n';newlookup='          async def chromium_executable_path():\n              async with async_playwright() as playwright:\n                  return playwright.chromium.executable_path\n          chromium = asyncio.run(chromium_executable_path())\n';assert b.count(newimport)==b.count(newlookup)==1;assert b.replace(newimport,oldimport,1).replace(newlookup,oldlookup,1)==a
start="          artifacts/browser-venv/bin/python - <<'PY'\n"
def block(s):return ''.join(line[10:]+'\n' for line in s.split(start,1)[1].split('          PY\n',1)[0].splitlines())
oldpy,newpy=block(a),block(b);compile(oldpy,'old-inline-CI-Python','exec');compile(newpy,'new-inline-CI-Python','exec');(out/'old-inline.py').write_text(oldpy);(out/'new-inline.py').write_text(newpy)
# Compare subprocess arguments/candidate/source guards structurally without executing them.
calls=lambda text:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id in {'subprocess','pathlib'}]
assert calls(oldpy)==calls(newpy)
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'launch','launch_persistent_context','connect','connect_over_cdp'} for n in ast.walk(ast.parse(newlookup.replace('          ', '', 1) if False else 'async def f():\n async with async_playwright() as playwright:\n  return playwright.chromium.executable_path\n')))
try:
 import yaml
 yaml.safe_load(b);yaml_parse='PyYAML safe_load PASS; no mutation/evaluation of GitHub expressions'
except ImportError:yaml_parse='PyYAML not installed; exact inverse and inline Python syntax used; no installation'
proof={'subject':subject,'base':base,'workflow_sha256':hashlib.sha256(b.encode()).hexdigest(),'old_workflow_sha256':hashlib.sha256(a.encode()).hexdigest(),'only_one_workflow_file_changed':True,'two_exact_inverse_regions_restore_complete_parent_bytes':True,'all_job_names_runners_triggers_permissions_concurrency_limits_artifacts_and_other_steps_unchanged':True,'subprocess_calls_candidate_manifest_and_source_guards_AST_unchanged':True,'inline_Python_syntax':'PASS old/new','YAML':yaml_parse,'public_async_context_accessor_only_no_browser_launch_sleep_retry_filter_privateAPI':True,'requirements_hash_unchanged':hashlib.sha256(git('show',subject+':requirements-browser.txt')).hexdigest()};assert git('show',subject+':requirements-browser.txt')==git('show',base+':requirements-browser.txt')
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
