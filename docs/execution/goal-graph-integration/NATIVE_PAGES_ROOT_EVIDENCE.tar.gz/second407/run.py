import os,stat,hashlib,json,subprocess,datetime
from pathlib import Path
root=Path('/workspace/.worktrees/native-review-presentation');out=Path('/workspace/.onboarding/native-presentation-root/second');target=Path('/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target');frozen=Path('/workspace/.worktrees/goal-validation-graph/artifacts/goal-validation-graph/candidate-70a48d416631');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=[x for x in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if x];before={p:sha(root/p) for p in tracked};tools=[];links=[];results=[];restored=[]
for name in ['batond','baton']:
 p=target/'debug'/name;s=p.lstat();assert stat.S_ISREG(s.st_mode);backup=out/'backup'/name;assert not backup.exists();os.link(p,backup);tools.append({'name':name,'path':str(p),'backup':str(backup),'original_sha256':sha(p),'original_bytes':s.st_size,'original_inode':s.st_ino,'original_mode':stat.S_IMODE(s.st_mode),'staged_sha256':sha(frozen/name),'staged_source':str(frozen/name),'preservation':'hardlink keeps original inode; locked tauri-build removes destination before copying'})
manifest={'source':'407ab9e7b014a1af81e39bf90ffac5034708285f','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tracked_source_sha256':before,'tools':tools,'dimension':'Linux Native library/controller tests only; no AppKit or runtime frozen tool execution'};(out/'BEFORE.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1',CARGO_TARGET_DIR=str(target));env['PATH']=env['CARGO_HOME']+'/bin:'+env['PATH'];sysroot='/workspace/.toolchains/linux-ui/sysroot';env.update(PKG_CONFIG_SYSROOT_DIR=sysroot,PKG_CONFIG_LIBDIR=sysroot+'/usr/lib/x86_64-linux-gnu/pkgconfig:'+sysroot+'/usr/share/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig',LD_LIBRARY_PATH=sysroot+'/usr/lib/x86_64-linux-gnu',LIBRARY_PATH=sysroot+'/usr/lib/x86_64-linux-gnu')
commands=[['cargo','test','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--features','native-smoke,custom-protocol','--lib','--bin','agentbaton-native-owner-dialog-smoke'],['cargo','fmt','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--check'],['cargo','clippy','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--all-targets','--features','native-smoke,custom-protocol','--','-D','warnings']]
try:
 candidates=[(root/'apps/desktop/dist',Path('/workspace/.worktrees/goal-graph-integration/apps/desktop/dist'))]+[(root/'apps/desktop/src-tauri/binaries'/(n+'-x86_64-unknown-linux-gnu'),frozen/n) for n in ['batond','baton']]
 for path,source in candidates:
  assert not path.exists() and not path.is_symlink();path.parent.mkdir(parents=True,exist_ok=True);path.symlink_to(source);links.append((path,source))
 for i,cmd in enumerate(commands):
  log=out/('native-'+str(i)+'.log');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with log.open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  results.append({'command':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':log.name,'sha256':sha(log)})
  if r.returncode:break
finally:
 for row in tools:
  p=Path(row['path']);b=Path(row['backup']);assert sha(b)==row['original_sha256'] and b.stat().st_ino==row['original_inode'];current=sha(p);assert current in [row['original_sha256'],row['staged_sha256']],('unexpected target mutation; backup retained',str(p))
  if current==row['original_sha256'] and p.stat().st_ino==row['original_inode']:b.unlink()
  else:os.replace(b,p)
  assert sha(p)==row['original_sha256'] and p.stat().st_ino==row['original_inode'];restored.append({'path':str(p),'before':row['original_sha256'],'observed_after_build_before_restore':current,'after_restore':sha(p),'same_inode_restored':True})
 for path,source in reversed(links):assert path.is_symlink() and path.readlink()==source;path.unlink()
 after={p:sha(root/p) for p in tracked};record={'source':manifest['source'],'head':manifest['head'],'commands':results,'tracked_source_before_after_equal':before==after,'changed':[p for p in tracked if before[p]!=after[p]],'tool_restoration':restored,'owned_temporary_links_removed':all(not p.is_symlink() for p,s in links),'dimension':manifest['dimension']};(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
