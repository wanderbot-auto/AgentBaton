import pathlib,sys,types,subprocess,os,io,json,hashlib
from unittest.mock import patch
D=pathlib.Path(__file__).resolve().parent;P=D/'source.py';m=types.ModuleType('review_observer_guards');sys.modules[m.__name__]=m;m.__file__=str(P);exec(compile(P.read_bytes(),str(P),'exec'),m.__dict__);rows=[]
def record(name,test,**values):
 assert test,(name,values)
 rows.append({'name':name,'status':'passed',**values})
class Entries:
 def __init__(self,entries):self.entries=entries
 def __enter__(self):return iter(self.entries)
 def __exit__(self,*_):pass
real_scan=os.scandir;real_open=pathlib.Path.open
samples=[]
def capped_scan(path):
 if str(path)=='/proc':return Entries([types.SimpleNamespace(name=str(x)) for x in range(1,8194)])
 return real_scan(path)
with patch.object(os,'scandir',capped_scan):
 try:m.owned_command_child(os.getpid(),samples)
 except AssertionError as e:refused='capacity' in str(e)
 else:refused=False
record('8193 numeric PID metadata exceeds fixed capacity and fails closed',refused and samples[-1]['observer_error']['type']=='AssertionError',samples=samples)
with patch.object(pathlib.Path,'open',return_value=io.BytesIO(b'x'*4097)):
 try:m.proc_identity(os.getpid())
 except AssertionError:refused=True
 else:refused=False
record('4097 byte stat metadata rejected',refused)
p=subprocess.Popen(['/usr/bin/sleep','3'],start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
samples=[]
try:
 def feature_open(self,*args,**kwargs):
  if self.name=='children' and self.parent.parent==pathlib.Path(f'/proc/{os.getpid()}/task'):
   return io.BytesIO(str(p.pid).encode())
  return real_open(self,*args,**kwargs)
 def no_global_scan(path):
  assert str(path)!='/proc','task children backend must not enumerate global PID metadata'
  return real_scan(path)
 with patch.object(pathlib.Path,'open',feature_open),patch.object(os,'scandir',no_global_scan):
  result=m.owned_command_child(os.getpid(),samples)
 record('synthetic task-children discovery preferred with actual private child identity',result['pid']==p.pid and samples[-1]['discovery']=='task_children' and samples[-1]['pid_stat_examined']==0,samples=samples)
finally:
 if p.poll() is None:p.terminate()
 rc=p.wait(timeout=2)
 record('preferred-backend actual private child reaped',not pathlib.Path(f'/proc/{p.pid}').exists(),exitcode=rc)
report={'status':'passed','dimension':'explicit synthetic discovery/stat-boundary guards + actual author-owned child identity; no Core/Chrome/Cargo','source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'checks':rows};(D/'guard-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(rows)}))
