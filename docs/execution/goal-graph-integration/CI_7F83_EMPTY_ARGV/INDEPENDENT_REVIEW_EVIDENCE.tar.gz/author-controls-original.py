from pathlib import Path
import ast,contextlib,hashlib,importlib.util,io,json,os,signal,subprocess,sys,types
from unittest.mock import patch
R=Path(__file__).parent;P=Path('/workspace/.worktrees/goal-graph-empty-argv/apps/desktop/tests/goal-graph-real-ipc.py');oldsrc=subprocess.check_output(['git','show','7f83c66652a40a9d01e995b45ce270abd44fbdde:apps/desktop/tests/goal-graph-real-ipc.py'],cwd='/workspace/AgentBaton')
def load(name,src):
 m=types.ModuleType(name);m.__file__=str(P);sys.modules[name]=m;exec(compile(src,str(P),'exec'),m.__dict__);return m
m=load('empty_new',P.read_bytes());old=load('empty_old',oldsrc);rows=[];samples={}
def ck(name,ok,**details):assert ok,(name,details);rows.append({'name':name,'status':'passed',**details})
class Entries:
 def __init__(self,x):self.x=x
 def __enter__(self):return iter(self.x)
 def __exit__(self,*x):pass
ready_r,ready_w=os.pipe2(os.O_CLOEXEC);release_r,release_w=os.pipe2(os.O_CLOEXEC);pid=os.fork()
if pid==0:
 try:
  os.close(ready_r);os.close(release_w);os.setpgid(0,0);os.write(ready_w,b'R');assert os.read(release_r,1)==b'X';os.execv('/usr/bin/sleep',['/usr/bin/sleep','3'])
 finally:os._exit(3)
os.close(ready_w);os.close(release_r);realopen=Path.open;realid=m.proc_identity;opened=[]
def op(raw):
 def inner(p,*a,**k):
  if p.name=='children' and p.parent.parent==Path(f'/proc/{os.getpid()}/task'):return io.BytesIO(str(pid).encode())
  if str(p)==f'/proc/{pid}/cmdline':
   opened.append(str(p))
   if isinstance(raw,BaseException):raise raw
   if raw is not None:return io.BytesIO(raw)
  return realopen(p,*a,**k)
 return inner
try:
 assert os.read(ready_r,1)==b'R';before=realid(pid)
 ck('real fork held beforeexec belongs only own parent/privatePGID',before['parent_pid']==os.getpid() and os.getpgid(pid)==pid)
 for mod,name in [(old,'old'),(m,'new')]:
  notes=[]
  with patch.object(Path,'open',op(b'')):
   try:result=mod.owned_command_child(os.getpid(),notes)
   except AssertionError as e:
    ck('old empty read hardfailure retained',name=='old' and str(e)=='Complete bounded private argv required');result='old-hardfail'
   else:ck('new empty live observation stays pending, nevercommand',name=='new' and result is None and notes[-1]['last_private_child_observation']['classification']=='pending_empty_argv' and notes[-1]['last_private_child_observation']['accepted']is False)
  samples[name+'-empty']=notes
 for raw,label in [(b'x','nonempty missingNUL'),(b'x'*1025,'oversize'),(b'x'*1024+b'\0','1025includingNUL')]:
  notes=[]
  with patch.object(Path,'open',op(raw)):
   try:m.owned_command_child(os.getpid(),notes)
   except AssertionError as e:ck(label+' still originalhardfail',str(e)=='Complete bounded private argv required')
   else:raise AssertionError(label+' accepted')
  samples[label]=notes
 with patch.object(Path,'open',op(b'x'*1023+b'\0')):ck('complete1024B unrelatedargv nevercommand',m.owned_command_child(os.getpid())is None)
 with patch.object(Path,'open',op(PermissionError('own injected denial'))):
  try:m.owned_command_child(os.getpid())
  except PermissionError:ck('permission error not swallowed',True)
  else:raise AssertionError('permission swallowed')
 count=[0]
 def drift(p):
  v=realid(p)
  if p==pid:
   count[0]+=1
   if count[0]>1:v={**v,'start_ticks':'changed'}
  return v
 with patch.object(Path,'open',op(b'')),patch.object(m,'proc_identity',drift):ck('empty identitydrift neveraccepted',m.owned_command_child(os.getpid())is None)
 def foreign(p):
  v=realid(p);return {**v,'parent_pid':-123}if p==pid else v
 opened.clear()
 with patch.object(Path,'open',op(b'')),patch.object(m,'proc_identity',foreign):ck('foreign PPID no argvread',m.owned_command_child(os.getpid())is None and not opened)
 count=[0]
 def parentdrift(p):
  v=realid(p)
  if p==os.getpid():
   count[0]+=1
   if count[0]>1:v={**v,'start_ticks':'changed'}
  return v
 with patch.object(Path,'open',op(b'')),patch.object(m,'proc_identity',parentdrift):
  try:m.owned_command_child(os.getpid())
  except AssertionError as e:ck('pendingempty parentstartdrift hardfails',str(e)=='Private parent identity changed')
  else:raise AssertionError('parent drift accepted')
 with patch.object(Path,'open',op(b'')),patch.object(m.os,'getpgid',side_effect=AssertionError('unclassified PGID must not be used')):ck('pendingempty adds no PGID acceptance gate',m.owned_command_child(os.getpid())is None)
 # Exact original nested wait AST, fake monotonic advances only by original20ms sleep.
 node=next(x for x in ast.walk(ast.parse(P.read_text()))if isinstance(x,ast.FunctionDef)and x.name=='wait');clock=types.SimpleNamespace(now=0.0);clock.monotonic=lambda:clock.now
 def advance(x):clock.now+=x
 clock.sleep=advance;ns={'time':clock,'pump':lambda:None,'clean':lambda x:x};exec(compile(ast.Module(body=[node],type_ignores=[]),'<original wait>','exec'),ns)
 notes=[]
 with patch.object(Path,'open',op(b'')),patch.object(m,'time',clock):
  try:ns['wait'](lambda:m.owned_command_child(os.getpid(),notes,observation_deadline=5),lambda x:x is not None,seconds=5)
  except AssertionError as e:ck('permanentempty original5s deadline fails withoutcommand',str(e).startswith("('Observation timed out'")and 5<=clock.now<5.021 and all(x.get('last_private_child_observation',{}).get('accepted')is False for x in notes))
  else:raise AssertionError('permanentempty succeeded')
 samples['permanentempty']=notes
 os.write(release_w,b'X');os.close(release_w);release_w=None;assert os.read(ready_r,1)==b''
 with patch.object(Path,'open',op(None)):
  found=m.owned_command_child(os.getpid())
 ck('same actualownPID accepted only after realexec exactsleep3',found is not None and found['pid']==pid and found['start_ticks']==before['start_ticks']and found['pgid']==pid and found['argv']==['/usr/bin/sleep','3'])
 clock.now=5.001
 with patch.object(Path,'open',op(None)),patch.object(m,'time',clock):
  try:m.owned_command_child(os.getpid(),observation_deadline=5)
  except AssertionError as e:ck('late exactcommand rejected by same absolute5s',str(e)=='Actual command observation exceeded its original deadline')
  else:raise AssertionError('late commandaccepted')
 clock.now=4.999
 with patch.object(Path,'open',op(None)),patch.object(m,'time',clock):ck('beforedeadline exactcommand stillaccepted',m.owned_command_child(os.getpid(),observation_deadline=5)['pid']==pid)
finally:
 v=realid(pid);assert v['start_ticks']==before['start_ticks']and v['parent_pid']==os.getpid();os.kill(pid,signal.SIGTERM);waited,status=os.waitpid(pid,0);assert waited==pid
 if release_w is not None:os.close(release_w)
 os.close(ready_r);ck('only owncreatedchild signaled/waited and originalgone',not Path(f'/proc/{pid}').exists(),pid=pid,wait_status=status)
(R/'controls.json').write_text(json.dumps({'status':'passed','count':len(rows),'source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'checks':rows,'samples':samples,'limits':'Own realfork/exec; empty proc reads explicitly injected, not natural kernel-race reproduction. NoCore/browser/Cargo/oldorphans/remote.'},indent=2)+'\n');print('PASS',len(rows))
