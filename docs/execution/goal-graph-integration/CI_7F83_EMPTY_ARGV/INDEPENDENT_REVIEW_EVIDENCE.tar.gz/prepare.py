from pathlib import Path
import ast,hashlib,json,subprocess,shutil,copy,base64
O=Path(__file__).parent;R=Path('/workspace/.worktrees/goal-graph-empty-argv');B='7f83c66652a40a9d01e995b45ce270abd44fbdde';S='79bbf4e8ab69d0e24800f1c49c356673c2a8e4bc';DOC='8bc0070949790369c83e468fcc5e64af93c09612';P='apps/desktop/tests/goal-graph-real-ipc.py';H=lambda b:hashlib.sha256(b).hexdigest();G=lambda *a:subprocess.check_output(['git',*a],cwd=R)
a=G('show',B+':'+P);b=G('show',S+':'+P);assert H(b)=='2066f54bc6f0a0d3cf6add7885caa53fb322c28478c714846ebf5f9c04a76955' and H(a)=='a054989b5a20972f332312c3bb7ddf9e87e0ca17181448c4a405459451105ed1';(O/'source-before.py').write_bytes(a);(O/'source.py').write_bytes(b);(O/'source.patch').write_bytes(G('diff',B,S,'--',P));compile(b,'fixed-empty-source','exec');assert G('diff','--check',B,DOC)==b'';assert G('show',DOC+':'+P)==b
A=ast.parse(a);N=ast.parse(b);oldfn=next(n for n in A.body if getattr(n,'name',None)=='owned_command_child');oldassign=next(n for n in ast.walk(A)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='command_identity'for t in n.targets)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='wait')
class Restore(ast.NodeTransformer):
 def visit_FunctionDef(self,n):
  if n.name=='owned_command_child':return copy.deepcopy(oldfn)
  return self.generic_visit(n)
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name)and t.id=='command_observation_deadline'for t in n.targets):return None
  if any(isinstance(t,ast.Name)and t.id=='command_identity'for t in n.targets)and'observation_deadline' in ast.unparse(n):return copy.deepcopy(oldassign)
  return n
assert ast.dump(Restore().visit(copy.deepcopy(N)),include_attributes=False)==ast.dump(A,include_attributes=False)
# All nonempty acceptance gates, initial before/after identity fences and default cleanup observer stay exact original source.
oldhelper=ast.get_source_segment(a.decode(),oldfn);newhelper=ast.get_source_segment(b.decode(),next(n for n in N.body if getattr(n,'name',None)=='owned_command_child'));assert "assert len(raw) <= 1024 and raw.endswith(b'\\0'), 'Complete bounded private argv required'"in newhelper;assert "if raw == b'':"in newhelper and "accepted=False"in newhelper
oldobs=[ast.dump(n,include_attributes=False)for n in ast.walk(A)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='owned_command_child'];newobs=[ast.dump(n,include_attributes=False)for n in ast.walk(N)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='owned_command_child'];assert len(oldobs)==len(newobs)==2 # case plus cleanup
Aroot=Path('/workspace/.onboarding/goal-graph-empty-argv');manifest=Aroot/'MANIFEST.json';assert H(manifest.read_bytes())=='adb65857bfdc1369e42da2231f54e9e99cc812cb73f2ea89435febfe6f8589e6';M=json.loads(manifest.read_text());assert len(M['files'])==18
for e in M['files']:
 raw=(Aroot/e['path']).read_bytes();assert H(raw)==e['sha256']and len(raw)==e['bytes']
# Fixed-source author controls copied/adapted solely to review subject/old Git bytes paths.
s=(Aroot/'controls.py').read_text();(O/'author-controls-original.py').write_text(s);s=s.replace("P=Path('/workspace/.worktrees/goal-graph-empty-argv/apps/desktop/tests/goal-graph-real-ipc.py')","P=R/'source.py'");start="oldsrc=subprocess.check_output(['git','show','7f83c66652a40a9d01e995b45ce270abd44fbdde:apps/desktop/tests/goal-graph-real-ipc.py'],cwd='/workspace/AgentBaton')";assert start in s;s=s.replace(start,"oldsrc=(R/'source-before.py').read_bytes()");(O/'controls.py').write_text(s)
(O/'compatibility').mkdir();shutil.copyfile(O/'source.py',O/'compatibility/source.py')
for name in ['controls.py','guard_controls.py']:shutil.copyfile(Aroot/'compatibility'/name,O/'compatibility'/name)
(O/'author-docs').mkdir()
for p in G('diff-tree','--no-commit-id','--name-only','-r',DOC).decode().splitlines():assert p.startswith('docs/execution/goal-graph-real-ipc/');(O/'author-docs'/Path(p).name).write_bytes(G('show',DOC+':'+p))
# Verify official retained response/base64 and exact SHA; no refetch or claim it is hosted CI's kernel.
off=json.loads((Aroot/'official-source.json').read_text());(O/'official').mkdir()
for e in off:
 p=e['api'].split('contents/',1)[1].split('?')[0];raw=(Aroot/'official-linux-v6.8'/p).read_bytes();assert H(raw)==e['sha256']and len(raw)==e['bytes'];v=json.loads((Aroot/('github-api-'+p.replace('/','_')+'.json')).read_text());assert base64.b64decode(v['content'])==raw and v['sha']==e['blob_git_sha'];(O/'official'/p.replace('/','_')).write_bytes(raw)
shutil.copyfile(Aroot/'official-source.json',O/'official-source.json');old=Path('/workspace/.onboarding/pr16-7f83-linux-review/MANIFEST.json');assert H(old.read_bytes()).startswith('99a842c1')
for e in json.loads(old.read_text())['files']:
 raw=(old.parent/e['path']).read_bytes();assert H(raw)==e['sha256']and len(raw)==e['bytes']
f=old.parent/'failure/goal-graph-command-timeout/report.json';shutil.copyfile(f,O/'original-7f83-failure-report.json');p=json.loads(f.read_text());sample=p['observations']['command_child_observer'][-1]['failing_private_child_observation'];assert sample['pid']==10200 and sample['raw_len']==0 and sample['trailing_nul']is False and sample['raw_sha256']==H(b'')
for key in ['before','after_read','after_failure']:assert sample[key]['pid']==10200 and sample[key]['parent_pid']==9949 and sample[key]['start_ticks']=='20524'and sample[key]['state']=='R'
(O/'static-proof.json').write_text(json.dumps({'base':B,'source':S,'source_sha256':H(b),'docs':DOC,'whole_module_AST_same_after_restoring_only_helper_and_two_case_assignments':True,'only_case_and_cleanup_observer_call_sites':len(newobs),'original_1024_NUL_gate_retained':True,'author18files_manifest_unchanged':True,'old7f83_evidence_full_manifest_rehash_unchanged':H(old.read_bytes()),'actual_CI_empty_identity':sample,'official_v6_8_bytes_verified_not_specific_CI_kernel_proof':off,'compile_diffcheck_exit':0},indent=2)+'\n');print('PASS fixed source scope/original gates/case-onlydeadline/old evidence + official source bytes')
