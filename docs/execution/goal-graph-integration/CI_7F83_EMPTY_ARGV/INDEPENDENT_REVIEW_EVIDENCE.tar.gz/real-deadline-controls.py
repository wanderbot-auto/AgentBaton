from pathlib import Path
import ast,types,sys,subprocess,os,io,json,hashlib,time
from unittest.mock import patch
O=Path(__file__).parent;P=O/'source.py';m=types.ModuleType('independent_wall_observer');m.__file__=str(P);sys.modules[m.__name__]=m;exec(compile(P.read_bytes(),str(P),'exec'),m.__dict__);node=next(x for x in ast.walk(ast.parse(P.read_text()))if isinstance(x,ast.FunctionDef)and x.name=='wait');ns={'time':time,'pump':lambda:None,'clean':lambda v:v};exec(compile(ast.Module(body=[node],type_ignores=[]),'unchanged-original-wait','exec'),ns);rows=[];original=Path.open
p=subprocess.Popen(['/usr/bin/sleep','20'],start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);pid=p.pid;identity=m.proc_identity(pid);notes=[]
def private_open(path,*a,**k):
 if path.name=='children'and path.parent.parent==Path(f'/proc/{os.getpid()}/task'):return io.BytesIO(str(pid).encode())
 if str(path)==f'/proc/{pid}/cmdline':return io.BytesIO(b'')
 return original(path,*a,**k)
try:
 t0=time.monotonic();absolute=t0+5
 with patch.object(Path,'open',private_open):
  try:ns['wait'](lambda:m.owned_command_child(os.getpid(),notes,observation_deadline=absolute),lambda v:v is not None,seconds=max(0,absolute-time.monotonic()))
  except AssertionError as e:assert str(e).startswith("('Observation timed out'");message=str(e)
  else:raise AssertionError('permanent empty passed')
 elapsed=time.monotonic()-t0;assert 5<=elapsed<7 # scheduler tolerance on test wallclock, NOT a product timeout change
 assert notes and all(x.get('last_private_child_observation',{}).get('accepted')is False for x in notes);assert len(notes)<=64
 rows.append({'name':'actual monotonic original5s wait fails for permanently injected empty own argv','status':'passed','seconds_observed':elapsed,'configured_deadline_seconds':5,'retained_samples':len(notes),'no_identity_accepted':True,'failure':message,'dimension':'real own process and real wait clock; empty cmdline explicitly injected, not natural kernel race'})
finally:
 current=m.proc_identity(pid);assert current['start_ticks']==identity['start_ticks']and current['parent_pid']==os.getpid()
 if p.poll()is None:p.terminate()
 rc=p.wait(timeout=2);assert not Path(f'/proc/{pid}').exists();rows.append({'name':'own long-sleep control truly waited and gone','status':'passed','pid':pid,'wait_exitcode':rc})
# Exact deadline boundary on a real sleep3 private identity, fixed test clock only for return decision.
p=subprocess.Popen(['/usr/bin/sleep','3'],start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);pid=p.pid
try:
 def child_feature(path,*a,**k):
  if path.name=='children'and path.parent.parent==Path(f'/proc/{os.getpid()}/task'):return io.BytesIO(str(pid).encode())
  return original(path,*a,**k)
 for now in [10.0,10.001,9.999]:
  with patch.object(Path,'open',child_feature),patch.object(m,'time',types.SimpleNamespace(monotonic=lambda:now)):
   try:found=m.owned_command_child(os.getpid(),observation_deadline=10)
   except AssertionError as e:assert now>=10 and str(e)=='Actual command observation exceeded its original deadline';found=None
   else:assert now<10 and found['pid']==pid
  rows.append({'name':'exact return deadline boundary','status':'passed','controlled_clock':now,'absolute_deadline':10,'accepted':now<10,'dimension':'real owned identity/argv, injected test clock'})
 with patch.object(Path,'open',child_feature):assert m.owned_command_child(os.getpid())['pid']==pid
 rows.append({'name':'cleanup no-deadline default preserves strict exact observer behavior','status':'passed'})
finally:
 if p.poll()is None:p.terminate()
 rc=p.wait(timeout=2);assert not Path(f'/proc/{pid}').exists();rows.append({'name':'second own child truly waited and gone','status':'passed','pid':pid,'wait_exitcode':rc})
(O/'real-deadline-controls.json').write_text(json.dumps({'source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'count':len(rows),'checks':rows,'no_Core_browser_Cargo':True},indent=2)+'\n');print('PASS',len(rows),'independent realclock/permanentempty/exactboundary controls')
