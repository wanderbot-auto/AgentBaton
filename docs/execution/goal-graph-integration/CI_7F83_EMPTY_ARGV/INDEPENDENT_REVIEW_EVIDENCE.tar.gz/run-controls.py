from pathlib import Path
import subprocess,os,json
O=Path(__file__).parent;env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[]
for name,cmd in [('empty17',['python3',str(O/'controls.py')]),('compat13',['python3',str(O/'compatibility/controls.py')]),('guard4',['python3',str(O/'compatibility/guard_controls.py')])]:
 p=subprocess.run(cmd,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':cmd,'exitcode':p.returncode});assert p.returncode==0,(name,p.stderr)
(O/'control-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS independent exact17 + compatibility13 +4 finite controls; no Core/browser/Cargo')
