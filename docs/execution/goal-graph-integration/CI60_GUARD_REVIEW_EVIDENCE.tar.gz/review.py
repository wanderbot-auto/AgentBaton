#!/usr/bin/env python3
"""Exact guard delta, finite own function cases and actual static checks only."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent
HEAD='53785196ec166637ca89fd732639888a1048360c';BASE='2cbdebba8127ae26749391b113834946ddf8b5b7'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sha(raw):return hashlib.sha256(raw).hexdigest()
checks=[];commands=[]
def check(name,value):
 assert value,name;checks.append({'name':name,'status':'passed'})
path='scripts/validate_infrastructure.py';before=git('show',BASE+':'+path);after=git('show',HEAD+':'+path)
(O/'before-validator.py').write_bytes(before);(O/'after-validator.py').write_bytes(after)
check('exact fixedsource parent',git('rev-parse',HEAD+'^').decode().strip()==BASE)
check('only validator and manifest changed',git('diff','--name-only',BASE,HEAD).decode().splitlines()==['BOOTSTRAP_MANIFEST.json',path])
check('sole validator expression45to60',before.count(b'        maximum = 45\n')==1 and after==before.replace(b'        maximum = 45\n',b'        maximum = 60\n'))
check('working validator and manifest equal fixedsource',after==(R/path).read_bytes()and git('show',HEAD+':BOOTSTRAP_MANIFEST.json')==(R/'BOOTSTRAP_MANIFEST.json').read_bytes())
a=json.loads(git('show',BASE+':BOOTSTRAP_MANIFEST.json'));b=json.loads(git('show',HEAD+':BOOTSTRAP_MANIFEST.json'))
check('manifest has exact93 registeredfiles',len(a['files'])==len(b['files'])==93)
check('one registered validator hash update only',[k for k in a['files']if a['files'][k]!=b['files'][k]]==[path]and set(a)==set(b))
restored=copy.deepcopy(b);restored['files'][path]=a['files'][path]
check('full parsed manifest unchanged aside validatorhash',restored==a)
check('validator new registered hash matches actualbytes',b['files'][path]==sha(after))
check('other92 registeredfiles actualhashes match',all(sha((R/p).read_bytes())==h for p,h in b['files'].items()if p!=path))
sys.path.insert(0,str(R/'scripts'))
spec=importlib.util.spec_from_file_location('fixed_guard',R/path);s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
job={'runs-on':'${{ matrix.os }}','timeout-minutes':60,'strategy':{'matrix':{'os':['macos-15','macos-15-intel']},'max-parallel':2,'fail-fast':False},'steps':[]}
def case(name,workflow,jname,value,accepted):
 passed=True
 try:s.validate_job_timeout(workflow,jname,value)
 except AssertionError:passed=False
 check(name,passed==accepted)
for value in [60,'60',1,'1']:
 x=copy.deepcopy(job);x['timeout-minutes']=value;case('exact desktop accepts '+repr(value),'product.yml','desktop',x,True)
for value in [61,'61',0,-1,True,60.0,None,'60.0']:
 x=copy.deepcopy(job);x['timeout-minutes']=value;case('desktop rejects '+repr(value),'product.yml','desktop',x,False)
for value,accepted in [(30,True),('30',True),(31,False),(60,False)]:
 x={'runs-on':'ubuntu-24.04','timeout-minutes':value};case('generic30bound '+repr(value),'other.yml','job',x,accepted)
for workflow,jname in [('other.yml','desktop'),('product.yml','other'),('environment-preflight.yml','desktop')]:
 case('wrong exception selector '+workflow+'/'+jname,workflow,jname,copy.deepcopy(job),False)
for name in ['host','missing-intel','extra-host','reverse-matrix','parallel3','parallel1','failfasttrue','failfast-stringtrue']:
 x=copy.deepcopy(job)
 if name=='host':x['runs-on']='self-hosted'
 if name=='missing-intel':x['strategy']['matrix']['os']=['macos-15']
 if name=='extra-host':x['strategy']['matrix']['os'].append('ubuntu-24.04')
 if name=='reverse-matrix':x['strategy']['matrix']['os'].reverse()
 if name=='parallel3':x['strategy']['max-parallel']=3
 if name=='parallel1':x['strategy']['max-parallel']=1
 if name=='failfasttrue':x['strategy']['fail-fast']=True
 if name=='failfast-stringtrue':x['strategy']['fail-fast']='true'
 case('strict exception boundary '+name,'product.yml','desktop',x,False)
for name,argv in [('infrastructure',[sys.executable,'scripts/validate_infrastructure.py']),('bootstrap',[sys.executable,'scripts/verify_bootstrap_manifest.py'])]:
 result=subprocess.run(argv,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,timeout=30)
 (O/(name+'.stdout')).write_bytes(result.stdout);(O/(name+'.stderr')).write_bytes(result.stderr)
 commands.append({'name':name,'argv':argv,'exitcode':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)})
 check('actual static '+name+' exit0',result.returncode==0)
out={'subject':HEAD,'base':BASE,'count':len(checks),'status':'passed','checks':checks,'commands':commands,'validator_sha256':sha(after),'manifest_sha256':sha(git('show',HEAD+':BOOTSTRAP_MANIFEST.json')),'scope':'finite helper boundaries + actual static infra/bootstrap, no remoteCI/product','not_run':['real CI or60minute runtime','Cargo/daemon/GUI/Nodebuild','Mac newbundle/audit/install']}
(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',len(checks),'independent finite controls and static infrastructure/bootstrap; no CI')
