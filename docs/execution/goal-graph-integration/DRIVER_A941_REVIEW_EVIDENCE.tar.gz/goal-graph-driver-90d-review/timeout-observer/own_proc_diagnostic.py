import pathlib,subprocess,os,time,json,hashlib
D=pathlib.Path(__file__).resolve().parent;p=subprocess.Popen(['/usr/bin/sleep','3'],start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 time.sleep(.02);parent=os.getpid();base=pathlib.Path(f'/proc/{parent}/task');globpaths=list(base.glob('*/children'));direct={str(x):x.read_text() for x in globpaths};cmd=pathlib.Path(f'/proc/{p.pid}/cmdline').read_bytes();stat=pathlib.Path(f'/proc/{p.pid}/stat').read_text();report={'parent':parent,'pid':p.pid,'ppid_expected':parent,'own_group':os.getpgid(p.pid),'task_children':direct,'cmdline_bytes_list':list(cmd),'cmdline_decoded':cmd.split(b'\0')[:8],'stat_tail':stat.rsplit(')',1)[1].split()[:22]};report['cmdline_decoded']=[b.decode(errors='replace') for b in report['cmdline_decoded']];(D/'own-proc-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
finally:
 if p.poll()is None:p.terminate()
 p.wait(timeout=2)
