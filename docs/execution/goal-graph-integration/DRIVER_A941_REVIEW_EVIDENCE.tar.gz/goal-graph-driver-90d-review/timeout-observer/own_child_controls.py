import pathlib,sys,types,subprocess,os,time,json,hashlib
D=pathlib.Path(__file__).resolve().parent;P=D.parent/'final-160e/source.py';m=types.ModuleType('review_current_driver');sys.modules[m.__name__]=m;exec(compile(P.read_bytes(),str(P),'exec'),m.__dict__);rows=[]
def run_case(name,args,*,newsession=True,executable=None,expected='match'):
 p=subprocess.Popen(args,executable=executable,start_new_session=newsession,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  deadline=time.monotonic()+1
  while True:
   try:found=m.owned_command_child(os.getpid());status='match' if found is not None else 'none'
   except AssertionError:found=None;status='unsafe-refused'
   if status!='none'or time.monotonic()>=deadline or expected!='match':break
   time.sleep(.01)
  assert status==expected,(name,status,expected);row={'name':name,'actual':status,'expected':expected,'owned_child':p.pid,'observation':found,'status':'passed'}
  if expected=='match':assert found['pid']==p.pid and found['parent_pid']==os.getpid() and found['pgid']==p.pid and m.owned_command_child(p.pid) is None
 finally:
  if p.poll()is None:p.terminate()
  rc=p.wait(timeout=2)
 row['cleanup_exitcode']=rc;row['reaped']=True;rows.append(row)
run_case('actual own direct sleep3 child+new session seen',['/usr/bin/sleep','3'])
run_case('wrong argument excluded',['/usr/bin/sleep','2'],expected='none')
run_case('different argv0 excluded; actual Core rule remains /usr/bin/sleep',['unit-only-foreign-argv0','3'],executable='/usr/bin/sleep',expected='none')
run_case('matching argv without private group fails identity assertion',['/usr/bin/sleep','3'],newsession=False,expected='unsafe-refused')
report={'status':'passed','source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'dimension':'Light actual subprocess/procfs controls, only reviewer-owned short-lived sleep processes; no Core/daemon/Chromium/Cargo/model','checks':rows,'conclusion':'Helper can observe a live matching direct private child. Actual timeout None cannot prove no execution; actual observation timing still unknown until bounded diagnostics.'};(D/'own-child-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','count':len(rows)}))
