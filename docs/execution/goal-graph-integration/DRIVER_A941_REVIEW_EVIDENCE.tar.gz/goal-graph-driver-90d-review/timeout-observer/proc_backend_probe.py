import os,pathlib,json,subprocess,time
D=pathlib.Path(__file__).resolve().parent;pid=os.getpid();p=subprocess.Popen(['/usr/bin/sleep','3'],start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 taskdir=pathlib.Path(f'/proc/{pid}/task');direct=taskdir/str(pid)/'children';report={'own_parent_pid':pid,'controlled_child_pid':p.pid,'taskdir_exists':taskdir.exists(),'taskdir_is_dir':taskdir.is_dir(),'task_entries':[], 'direct_children_path':str(direct),'direct_children_exists':direct.exists()}
 try:report['task_entries']=[x.name for x in taskdir.iterdir()]
 except OSError as e:report['task_listing_error']={'type':type(e).__name__,'errno':e.errno}
 try:report['direct_children_content']=direct.read_text()
 except OSError as e:report['direct_children_error']={'type':type(e).__name__,'errno':e.errno,'message':str(e)}
 report['own_task_dir_entries']=[x.name for x in (taskdir/str(pid)).iterdir()];report['controlled_child_stat']=pathlib.Path(f'/proc/{p.pid}/stat').read_text();report['controlled_child_cmdline']=pathlib.Path(f'/proc/{p.pid}/cmdline').read_bytes().decode().split('\0')
 (D/'proc-backend-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
finally:
 if p.poll()is None:p.terminate()
 p.wait(timeout=2)
