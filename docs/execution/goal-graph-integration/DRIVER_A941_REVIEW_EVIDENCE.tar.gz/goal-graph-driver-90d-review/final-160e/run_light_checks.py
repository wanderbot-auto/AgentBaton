import pathlib,subprocess,json,hashlib,time,ast
D=pathlib.Path(__file__).resolve().parent;script=D/'source.py';assert hashlib.sha256(script.read_bytes()).hexdigest()=='9b1bc1c5127b795c9a86fce85998b30f9a4cd36562c43439d9f7dca323ebc452'
commands=[]
for mode in ['self','driver-self','transport-self','validation-self','packet-self']:
 cmd=['python3',str(script),'--'+mode+'-check','--output',str(D/mode)]
 if mode=='packet-self':
  for kind,h in [('data','97c07926adf05f4bc04bcbeed97adc6d6aea59cbbcaa10d6aaeebad19a456d99'),('command','526a42e1775785b82eaf420af9dd6fd9a3f3c299f885f1535ab23835a812ed19')]:cmd+=['--packet',f'/workspace/.worktrees/goal-validation-graph/artifacts/goal-validation-graph/actual-{kind}-graph-{h}.json']
 t=time.monotonic()
 with (D/(mode+'.log')).open('wb')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0,(mode,r.returncode);report=next((D/mode).glob('*.json'));packet=json.loads(report.read_text());commands.append({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-t,'count':packet['count'],'dimension':packet['dimension'],'log_sha256':hashlib.sha256((D/(mode+'.log')).read_bytes()).hexdigest(),'report':str(report.relative_to(D))})
# Previous generated-program five unit processes tested exact function/program bytes.
old=(D.parent/'repair-7d80/source.py').read_text();new=script.read_text();treeold=ast.parse(old);treenew=ast.parse(new)
for name in ['provider_fixture_self_check']:
 a=ast.get_source_segment(old,next(n for n in treeold.body if isinstance(n,ast.FunctionDef)and n.name==name));b=ast.get_source_segment(new,next(n for n in treenew.body if isinstance(n,ast.FunctionDef)and n.name==name));assert a==b
prog=lambda t:ast.literal_eval(next(n for n in t.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='VALIDATION_ACP'for x in n.targets)).value)
assert prog(treeold)==prog(treenew)
(D/'light-checks.json').write_text(json.dumps({'status':'passed','source_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'commands':commands,'generated_provider_5_previous_actual_source':'7d80c2cc258669dd82bf235ad8753c5373705e70','generated_program_and_test_function_exact_current_bytes':True,'not_run':'No Core/Chromium/Cargo/actual validator by reviewer; prior provider5 is synthetic unit, not real Goal dispatch'},indent=2)+'\n');print([(c['count'],c['exit_code'])for c in commands])
