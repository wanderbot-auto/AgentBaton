import ast,pathlib,subprocess,json,hashlib
W=pathlib.Path('/workspace/.worktrees/goal-graph-driver-90d-review');D=pathlib.Path('/workspace/.onboarding/goal-graph-driver-90d-review');p='apps/desktop/tests/goal-graph-real-ipc.py';base='5b7e401780ab393a13fccd1c54b64362cdbef452';new=(W/p).read_text();old=subprocess.check_output(['git','-C',str(W),'show',base+':'+p],text=True);assert hashlib.sha256(new.encode()).hexdigest()=='5e326cb17af7a3502262202703d3005312db66c7fd3f89661f1589ba0c16ce2f'
a={n.name:ast.get_source_segment(old,n)for n in ast.parse(old).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};b={n.name:ast.get_source_segment(new,n)for n in ast.parse(new).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};preserved={}
for n in ['BoundaryRefusal','require','safe_integer','unique_object','FixtureBounds','FixedCall','decode_envelope','decode_http','PrivateUnixFixture','check_full_review','boundary_self_check','sha','readonly_reply_abort','transport_self_check','owner_only_plans','verify_candidate','pinned_artifact']:
 assert a[n]==b[n],n;preserved[n]=hashlib.sha256(b[n].encode()).hexdigest()
assert a['driver_self_check'].replace('compile(GRAPH_ACP,','compile(VALIDATION_ACP,')==b['driver_self_check']
nt=ast.parse(new);main=next(x for x in nt.body if isinstance(x,ast.FunctionDef)and x.name=='owner_only_driver');sql=[]
for n in ast.walk(main):
 if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='execute':
  s=ast.unparse(n.args[0]);assert 'INSERT' not in s and 'UPDATE'not in s and 'DELETE'not in s;sql.append(s)
for n in ['verify_validation_receipt']:
 for x in ast.walk(next(x for x in nt.body if isinstance(x,ast.FunctionDef)and x.name==n)):
  if isinstance(x,ast.Call)and isinstance(x.func,ast.Attribute)and x.func.attr=='execute':
   s=ast.unparse(x.args[0]);assert not any(word in s for word in ['INSERT','UPDATE','DELETE']);sql.append(s)
(D/'source.py').write_text(new);(D/'diff-from-5b.patch').write_bytes(subprocess.check_output(['git','-C',str(W),'diff',base,'90d12ff1d60534f53ff45733a3ccf44322f5cc83','--',p]));compile(new,'frozen90d','exec')
proof={'status':'passed','source':'90d12ff1d60534f53ff45733a3ccf44322f5cc83','sha256':hashlib.sha256(new.encode()).hexdigest(),'base':base,'unchanged_top_level_functions_classes':preserved,'driver_self_check_only_generated_program_name_changed':True,'SQL_read_only_assertions':sql,'legacy_keys':15,'graph_keys':17,'cases':['integrity','data','command','data-range','command-timeout'],'not_executed':['Core','Chromium','Cargo','provider subprocess self-check','actual500ms command fixture']};(D/'source-preservation.json').write_text(json.dumps(proof,indent=2)+'\n');print('PASS syntax/preserved17functions/readonlySQL; actual four blockers remain')
