import ast, pathlib, sys, types, subprocess, os, time, json, hashlib
from unittest.mock import patch
D=pathlib.Path(__file__).resolve().parent;P=D/'source.py';m=types.ModuleType('review_observer');sys.modules[m.__name__]=m;exec(compile(P.read_bytes(),str(P),'exec'),m.__dict__)
rows=[]
def check(name,condition,**values):
 assert condition,(name,values)
 rows.append({'name':name,'status':'passed',**values})
def run_case(name,args,*,newsession=True,executable=None,expected='match'):
 p=subprocess.Popen(args,executable=executable,start_new_session=newsession,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 samples=[];start=time.monotonic()
 try:
  try:
   found=m.owned_command_child(os.getpid(),samples);status='match' if found is not None else 'none'
  except AssertionError:found=None;status='unsafe-refused'
  check(name,status==expected,actual=status,expected=expected,pid=p.pid,observation=found,samples=samples,seconds=time.monotonic()-start)
  if expected=='match':
   check('exact private parent/group/live identity',found['pid']==p.pid and found['parent_pid']==os.getpid() and found['pgid']==p.pid and found['state']not in('Z','X') and found['start_ticks']==m.proc_identity(p.pid)['start_ticks'])
   check('wrong parent cannot claim child',m.owned_command_child(p.pid) is None)
 finally:
  if p.poll()is None:p.terminate()
  rc=p.wait(timeout=2)
  check(name+' reaped own process',not pathlib.Path(f'/proc/{p.pid}').exists(),exitcode=rc)
run_case('actual direct own sleep3 new group found',['/usr/bin/sleep','3'])
run_case('wrong argument excluded',['/usr/bin/sleep','2'],expected='none')
run_case('different argv0 excluded',['unit-only-other-argv0','3'],executable='/usr/bin/sleep',expected='none')
run_case('matching argv without private group fails closed',['/usr/bin/sleep','3'],newsession=False,expected='unsafe-refused')
opened=[];real_open=pathlib.Path.open
def traced_open(self,*args,**kwargs):
 if self.name=='cmdline':opened.append(str(self))
 return real_open(self,*args,**kwargs)
with patch.object(m,'proc_parent_pid',return_value=os.getpid()+10000000),patch.object(pathlib.Path,'open',traced_open):
 result=m.owned_command_child(os.getpid())
check('foreign PPID metadata never opens argv',result is None and not opened,opened_cmdline=opened)
samples=[]
with patch.object(m,'proc_parent_pid',side_effect=PermissionError('review injected proc stat denial')):
 try:m.owned_command_child(os.getpid(),samples)
 except PermissionError:refused=True
 else:refused=False
check('metadata permission error propagates and is recorded',refused and samples[-1]['observer_error']['type']=='PermissionError',samples=samples)
old=ast.parse((D.parent/'final-160e/source.py').read_text());new=ast.parse(P.read_text());oldfn={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))};newfn={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))};modified={'owned_command_child','owner_only_driver'}
unchanged=[name for name,node in oldfn.items() if name not in modified and ast.dump(node,include_attributes=False)==ast.dump(newfn[name],include_attributes=False)]
check('every preexisting unrelated top-level declaration AST preserved',len(unchanged)==len(oldfn)-len(modified),count=len(unchanged),names=unchanged)
report={'status':'passed','dimension':'independent actual reviewer-owned short-lived Popen/procfs + explicitly injected lightweight controls; no Core/Chromium/Cargo','source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'checks':rows}
(D/'controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(rows),'source_sha256':report['source_sha256']}))
