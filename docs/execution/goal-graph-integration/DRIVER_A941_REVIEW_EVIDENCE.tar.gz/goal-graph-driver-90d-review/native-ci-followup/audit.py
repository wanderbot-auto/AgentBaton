import pathlib,json,hashlib,subprocess,re,shutil,difflib,ast,yaml
D=pathlib.Path('/workspace/.onboarding/goal-graph-driver-90d-review/native-ci-followup');A=pathlib.Path('/workspace/.onboarding/goal-graph-final-native');W=pathlib.Path('/workspace/.worktrees/goal-graph-integration');sha=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((A/'sources-before.json').read_text());after=json.loads((A/'sources-after.json').read_text());assert before==after and len(before)==94
for n,h in before.items():assert sha((W/n).read_bytes())==h,n
results=json.loads((A/'results.json').read_text())
for x in results:assert x['exit_code']==0 and sha(pathlib.Path(x['log']).read_bytes())==x['sha256']
native=(A/'native-tests.log').read_text();counts=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',native);assert [int(n)for n in counts]==[57,0,4,22,0]
for n in ['actual_data_and_command_native_review_preserves_complete_observations_and_private_receipts','actual_integrity_missing_observation_or_unjoined_pass_never_opens_native_review','actual_integrity_native_cancel_on_each_page_and_final_never_finalizes_or_rejects','actual_integrity_validator_observation_roundtrips_every_native_review_byte']:
 assert 'test approval::tests::'+n+' ... ok'in native
front=json.loads((A/'frontend-results.json').read_text())
for x,log in zip(front,['node-tests.log','frontend-build.log']):assert x['exit_code']==0 and sha((A/log).read_bytes())==x['sha256']
node=(A/'node-tests.log').read_text();assert re.search(r'Test Files\s+37 passed',node) and re.search(r'Tests\s+564 passed',node)
pyfail=(A/'python-native.log').read_text();pypass=(A/'python-native-with-daemon.log').read_text();assert "KeyError: 'AGENTBATON_OWNER_FIXTURE_DAEMON'"in pyfail and 'FAILED (errors=1)'in pyfail;assert 'Ran 36 tests'in pypass and pypass.rstrip().endswith('OK')
# Node source binding independently checked now; Native before/after inventory doesn't list UI.
ui=json.loads(pathlib.Path('/workspace/.onboarding/goal-validation-observation-ui-review/lossless-4fab/preservation-audit.json').read_text())['source_sha256']
ui_checked={}
for n,h in ui.items():
 if n.startswith('apps/desktop/src/')and not n.endswith('.json'):
  assert sha((W/n).read_bytes())==h,n;ui_checked[n]=h
# Pure four-line workflow addition on top of previously independently reviewed20line integration.
F='.github/workflows/product.yml';old=pathlib.Path('/workspace/.onboarding/goal-graph-ci-integration-review/product.reviewed.yml').read_bytes();current=(W/F).read_bytes();a=old.splitlines(keepends=True);b=current.splitlines(keepends=True);recovered=[];ins=[]
for kind,l,r,x,y in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
 assert kind in ['equal','insert'],kind
 if kind=='equal':recovered.extend(b[x:y])
 else:ins.extend(b[x:y])
assert b''.join(recovered)==old and len(ins)==4
base=yaml.safe_load(old);new=yaml.safe_load(current);assert all(new[k]==v for k,v in base.items()if k!='jobs');assert new['jobs']['frontend']==base['jobs']['frontend'] and new['jobs']['desktop']==base['jobs']['desktop']
oldcore=base['jobs']['core'];core=new['jobs']['core'];assert all(core[k]==v for k,v in oldcore.items()if k!='steps');which=[i for i,s in enumerate(core['steps'])if s.get('name')=='Native Owner runner contracts against actual Core database'];assert len(which)==1;i=which[0];step=core['steps'][i];assert core['steps'][:i]+core['steps'][i+1:]==oldcore['steps'];assert step=={'name':'Native Owner runner contracts against actual Core database','env':{'AGENTBATON_OWNER_FIXTURE_DAEMON':'${{ github.workspace }}/target/debug/batond'},'run':'python3 apps/desktop/src-tauri/tests/test_native_owner_dialog.py'}
assert core['steps'][i-1]['run']=='cargo build --locked --bin batond --bin baton && python3 scripts/smoke-local-product.py';assert core['steps'][i+1]['run']=='cargo clippy --workspace --all-targets --locked -- -D warnings'
script=W/'apps/desktop/src-tauri/tests/test_native_owner_dialog.py';st=ast.parse(script.read_bytes());tests=[n.name for n in ast.walk(st)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert len(tests)==11;assert "os.environ['AGENTBATON_OWNER_FIXTURE_DAEMON']"in script.read_text();assert any(isinstance(n,ast.If)and ast.unparse(n.test)=="__name__ == '__main__'"for n in st.body)
assert (W/'apps/desktop/src-tauri/tests/test_native_runner.py').exists();syntax=subprocess.run(['bash','-n'],input=step['run'].encode(),capture_output=True);assert syntax.returncode==0
for name in ['sources-before.json','sources-after.json','results.json','native-tests.log','native-clippy.log','native-fmt.log','frontend-results.json','node-tests.log','frontend-build.log','python-native.log','python-native-with-daemon.log']:
 p=D/'retained-root'/name;p.parent.mkdir(exist_ok=True);shutil.copyfile(A/name,p)
(D/'product.before-four-lines.yml').write_bytes(old);(D/'product.reviewed.yml').write_bytes(current);(D/'new-python-test-source.py').write_bytes(script.read_bytes())
result={'status':'PASS Root Linux Native evidence audit and four-line CI wiring only','current_root_head':subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip(),'Native_source_before_after_exact':94,'Native_actual_tests':{'library':57,'owner_controller':4,'readonly_harness':22,'Native_four_new_observation_callbacks':'all4 names present and passed in57lib'},'Native_commands':results,'frontend_logs':front,'current_UI_source_files_match_independent4fab':ui_checked,'UI_binding_limit':'Root Native before/after inventory94 covers Native/Core, not UI. Root Node log shows564/37; exact4fab independent Node review remains the directly source-pinned UI evidence, rather than inventing a UI before/after inventory.','python36_pass':True,'python_first_failure_preserved':"Missing required AGENTBATON_OWNER_FIXTURE_DAEMON;1error among36, not product permission failure",'new_python_test_count':11,'CI_inserted_lines':4,'CI_whole_prior_bytes_recovered':True,'old_CI_sha256':sha(old),'new_CI_sha256':sha(current),'new_CI_step':step,'no_remote_actions':True,'not_run':['new CI itself','macOS AppKit/NSAlert real dialog','human Owner approval','fresh dual packages/signatures'],'retained_raw_sha256':{p.name:sha(p.read_bytes())for p in (D/'retained-root').iterdir()}}
(D/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','current_root_head','Native_source_before_after_exact','Native_actual_tests','CI_inserted_lines','new_CI_sha256']},indent=2))
