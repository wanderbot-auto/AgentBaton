from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,gzip,ast,re,collections
OUT=Path(__file__).resolve().parent;SRC=OUT/'source';P=SRC/'docs/execution/goal-graph-integration';REPO='/workspace/.worktrees/goal-graph-integration';BASE='641be86e8b055920787cfebdd48270716d509309';REV='9448918d17ba3a1159edf7051e140ea04e04e6df'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(path,rev=BASE):return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=REPO)
R={}
changed=subprocess.check_output(['git','diff','--name-only',BASE,REV],cwd=REPO,text=True).splitlines();sources=[p for p in changed if not p.startswith('docs/') and p!='BOOTSTRAP_MANIFEST.json'];assert set(sources)=={'apps/desktop/src/CommandValidation.test.tsx','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','scripts/native-owner-dialog-smoke.py'};R['changed_source_paths']=sources
leaf={'apps/desktop/src/CommandValidation.test.tsx':'bdb2a8860c38abe4e42c67b173a3452c06a760b1','apps/desktop/src-tauri/tests/test_native_owner_dialog.py':'a43cbb181a52b9ebcc0c72a838f68497101759b8','scripts/native-owner-dialog-smoke.py':'a43cbb181a52b9ebcc0c72a838f68497101759b8'}
for p,r in leaf.items():assert (SRC/p).read_bytes()==obj(p,r)
R['leaf_bytes_exact']=True;R['production_locks_workflows_unchanged']=True;R['Factory13_not_added']=not any('factory' in p.lower() for p in changed if not p.startswith('docs/'))
old=json.loads(obj('BOOTSTRAP_MANIFEST.json'))['files'];new=json.loads((SRC/'BOOTSTRAP_MANIFEST.json').read_text())['files'];assert len(old)==len(new)==93 and old.keys()==new.keys();d=[p for p in old if old[p]!=new[p]];assert d==['docs/execution/STATUS.md'];assert old[d[0]]=='532f2d5edf3f4533e8e02558c626bd7d6cecd1ea123992d920a6444a9d8e0c02';assert new[d[0]]=='ff1cd0199804c7aa0a580053e50b5f05dae340a6039610cc8323efdf8f7fcb8d';assert all(sha((SRC/p).read_bytes())==h for p,h in new.items());assert all(obj(p)==(SRC/p).read_bytes() for p in old if p!=d[0]);R['bootstrap']={'paths':93,'changed_hash':d,'other92_bytes_and_hashes_equal':True,'status_sha256':new[d[0]]}
# Python original code and control class are independently compared using AST source spans.
name='scripts/native-owner-dialog-smoke.py';before=obj(name).decode();after=(SRC/name).read_text();a=ast.parse(before);z=ast.parse(after);nodes={n.name:n for n in z.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))};pres=[]
for n in a.body:
 if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name!='bootstrap':
  assert ast.get_source_segment(before,n)==ast.get_source_segment(after,nodes[n.name]),n.name;pres.append(n.name)
name='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';before=obj(name).decode();after=(SRC/name).read_text();a=ast.parse(before);z=ast.parse(after);c=lambda tree:next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OwnerRunnerControls');assert ast.get_source_segment(before,c(a))==ast.get_source_segment(after,c(z));R['owner_original_declarations_byte_preserved']=pres;R['owner_original11_class_byte_preserved']=True
before=obj('apps/desktop/src/CommandValidation.test.tsx').decode();after=(SRC/'apps/desktop/src/CommandValidation.test.tsx').read_text();cut=lambda s:(s.index("  it('folds by default"),s.index('  it.each(',s.index("  it('folds by default")));a,b=cut(before);c,d=cut(after);assert before[:a]==after[:c] and before[b:]==after[d:];R['command_outside_first_case_byte_preserved']=True;R['command_original_firstcase_expect_count']=before[a:b].count('expect(');R['command_new_firstcase_expect_count']=after[c:d].count('expect(');R['command_original_firstcase_review']='all10original literal assertions matched verbatim to new18; prefix and all other cases byte-identical; imported prior independent AST89→97 proof hashed, not rerun'
first_old=re.findall(r'expect\([\s\S]*?;',before[a:b]);first_new=re.findall(r'expect\([\s\S]*?;',after[c:d]);assert len(first_old)==10 and len(first_new)==18 and not (collections.Counter(first_old)-collections.Counter(first_new))
R['archives']={};configs=[('CI_641_LINUX','linux-641','LINUX_MANIFEST.json'),('CI_641_ARM','arm-641','ARM_MANIFEST.json'),('COMMAND_UI_AUTHOR','command-ui-author',None),('COMMAND_UI_REVIEW','command-ui-review','manifest.json'),('OWNER_BOOTSTRAP_AUTHOR','owner-bootstrap-author','FINAL_MANIFEST.json'),('OWNER_BOOTSTRAP_REVIEW','owner-bootstrap-review','manifest.json')]
for stem,prefix,internal in configs:
 imp=json.loads((P/(stem+'_IMPORT.json')).read_text());archive=P/imp['archive'];assert sha(archive.read_bytes())==imp['sha256'] and archive.stat().st_size==imp['bytes']
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names))
  for m in members:assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,m.name
  data={m.name:t.extractfile(m).read() for m in members}
  if internal:
   manifest_bytes=(P/(stem+'_MANIFEST.json')).read_bytes();assert data[f'{prefix}/{internal}']==manifest_bytes
   expected=imp.get('manifest_sha256',imp.get('source_manifest_sha256'));assert sha(manifest_bytes)==expected
   manifest=json.loads(manifest_bytes);records=manifest['files'];assert len(records)==imp.get('files',imp.get('declared_files'))
   for n,r in records.items():
    b=data[f'{prefix}/{n}'];h=r if isinstance(r,str) else r['sha256'];assert sha(b)==h,n
    if isinstance(r,dict) and 'bytes' in r:assert len(b)==r['bytes'],n
   assert set(data)=={f'{prefix}/{n}' for n in records}|{f'{prefix}/{internal}'}
  else:
   records=imp['path_mapping'];assert len(records)==imp['files'];assert set(data)=={r['archive_path'] for r in records.values()}|{f'{prefix}/AUTHOR_EVIDENCE.json'}
   for r in records.values():b=data[r['archive_path']];assert sha(b)==r['sha256'] and len(b)==r['bytes']
  R['archives'][stem]={'sha256':imp['sha256'],'payload_files':len(records),'members':len(data),'regular_safe_unique':True,'all_payload_hashes_verified':True,'bytes':archive.stat().st_size}
  # Export data into this review's directory only after all path/type/hash checks.
  for n,b in data.items():p=OUT/'imports'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
# Raw compressed CI log roundtrip.
ci=P/'ci-641';manifest=json.loads((ci/'MANIFEST.json').read_text())
for n,r in manifest['files'].items():
 p=ci/r.get('stored',n);b=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'],n
pj=json.loads((ci/'product-jobs-final.json').read_text())['jobs'];ej=json.loads((ci/'environment-jobs-final.json').read_text())['jobs'];assert len(pj)==4 and len(ej)==3;assert all(j['head_sha']==BASE for j in pj+ej);assert sorted(j['conclusion'] for j in pj+ej)==['failure','failure','success','success','success','success','success'];R['ci_jobs']=[{'name':j['name'],'conclusion':j['conclusion'],'run_id':j['run_id']} for j in pj+ej]
merge=json.loads((ci/'merge-candidate.json').read_text());assert merge['sha']=='d03313d5b9b1b575e1eb4a4ae35ec29c49ff446d' and merge['tree']['sha']=='67038b21828745f79905a169abb6e57e98bca5a0';R['actual_checkout_tree']={'checkout':merge['sha'],'tree':merge['tree']['sha']}
# Exactly the original130 requirement identities; append nine partial contributions only.
p='docs/execution/requirements-progress.json';old=json.loads(obj(p));new=json.loads((SRC/p).read_text());assert len(old['requirements'])==len(new['requirements'])==130
ids=lambda d:[r['id'] for r in d['requirements']];assert ids(old)==ids(new);modified=[]
for b,n in zip(old['requirements'],new['requirements']):
 if b!=n:
  prefix=dict(n);items=prefix.get('contributions');field='contributions'
  if not items:
   candidates=[k for k,v in n.items() if isinstance(v,list) and v and isinstance(v[-1],dict) and v[-1].get('slice')=='PR16_641_exact_CI_partial_dimensions_not_accepted'];assert len(candidates)==1;candidates=candidates[0];field=candidates;items=n[field]
  assert items[-1]['slice']=='PR16_641_exact_CI_partial_dimensions_not_accepted';prefix[field]=items[:-1];assert prefix==b;modified.append(n['id'])
assert len(modified)==9;R['requirements_partial_append_ids']=modified;R['requirement_count']=130
(OUT/'audit-results.json').write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(R,indent=2))
