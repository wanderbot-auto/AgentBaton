// inert helper
