#!/usr/bin/env python3
"""Fixed source review + inert installed-CLI discovery probes; no compilation."""
import hashlib,json,os,subprocess,tarfile,tomllib
from pathlib import Path
OUT=Path(__file__).parent;R=Path('/workspace/.worktrees/native-bundle-discovery')
HEAD='9c3850d40d78d2317142f604043fd0aaaceb2aa7';BASE='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4'
checks=[];commands=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def blob(commit,path):return git('show',commit+':'+path)
def check(name,value):
 assert value,name;checks.append({'name':name,'status':'passed'})
def run(name,argv,cwd=R,env=None):
 result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=60)
 (OUT/(name+'.stdout')).write_bytes(result.stdout);(OUT/(name+'.stderr')).write_bytes(result.stderr)
 commands.append({'name':name,'argv':argv,'cwd':str(cwd),'exitcode':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)})
 return result
check('fixed source commit exists',git('cat-file','-t',HEAD).strip()==b'commit')
check('working production files still frozen despite docs HEAD',subprocess.run(['git','diff','--quiet',HEAD,'--','apps/desktop/src-tauri','scripts','.github/workflows'],cwd=R).returncode==0)
check('source only expected three paths',set(git('diff','--no-renames','--name-only',BASE,HEAD).decode().splitlines())=={
 'apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs',
 'apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs',
 'apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs'})
entry='apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs'
expected=blob(BASE,entry).replace(b'"native_owner_dialog/controller.rs"',b'"../native_owner_dialog_test/controller.rs"').replace(b'"native_owner_dialog/macos.rs"',b'"../native_owner_dialog_test/macos.rs"')
check('only two path literal changes',blob(HEAD,entry)==expected==(R/entry).read_bytes())
helpers={}
for name in ['controller.rs','macos.rs']:
 old='apps/desktop/src-tauri/src/bin/native_owner_dialog/'+name;new='apps/desktop/src-tauri/src/native_owner_dialog_test/'+name
 raw=blob(HEAD,new);check('100 percent helper bytes '+name,raw==blob(BASE,old)==(R/new).read_bytes())
 check('file mode preserved '+name,git('ls-tree',HEAD,new).split()[0]==git('ls-tree',BASE,old).split()[0]==b'100644')
 check('new relative module path resolves '+name,(R/entry).parent.joinpath('../native_owner_dialog_test/'+name).resolve()==(R/new).resolve())
 helpers[name]=sha(raw)
protected=['apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','Cargo.lock',
 'apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/main.rs','apps/desktop/src-tauri/src/bin/native_smoke.rs',
 '.github/workflows/product.yml','scripts/native-audit-release.sh','scripts/package-development-macos.sh',
 'scripts/native-owner-dialog-smoke.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','apps/desktop/src-tauri/tauri.conf.json']
for path in protected:check('protected bytes unchanged '+path,blob(BASE,path)==blob(HEAD,path)==(R/path).read_bytes())
manifest=tomllib.loads(blob(HEAD,'apps/desktop/src-tauri/Cargo.toml').decode())
check('default-run remains production main',manifest['package']['default-run']=='agentbaton-desktop')
check('exact two feature-gated smoke binaries',len(manifest['bin'])==2 and {b['name']for b in manifest['bin']}=={'agentbaton-native-smoke','agentbaton-native-owner-dialog-smoke'} and all(b['required-features']==['native-smoke']for b in manifest['bin']))
check('release compile error remains on both smoke entrypoints',all(b'#[cfg(not(debug_assertions))]\ncompile_error!'in blob(HEAD,p)for p in [entry,'apps/desktop/src-tauri/src/bin/native_smoke.rs']))
check('new helper modules not referenced by production library/main',all(b'native_owner_dialog_test'not in blob(HEAD,p)for p in ['apps/desktop/src-tauri/src/main.rs','apps/desktop/src-tauri/src/lib.rs']))
env={**os.environ,'CARGO_TARGET_DIR':str(OUT/'metadata-target')}
r=run('project-metadata',['cargo','metadata','--offline','--locked','--no-deps','--format-version','1','--manifest-path',str(R/'apps/desktop/src-tauri/Cargo.toml')],env=env)
check('real actual project metadata command success without build',r.returncode==0)
package=next(p for p in json.loads(r.stdout)['packages']if p['name']=='agentbaton-desktop')
check('actual Cargo metadata only three legal bins',sorted(t['name']for t in package['targets']if t['kind']==['bin'])==['agentbaton-desktop','agentbaton-native-owner-dialog-smoke','agentbaton-native-smoke'])
CLI=Path('/workspace/AgentBaton/apps/desktop/node_modules/@tauri-apps/cli/tauri.js')
version=run('cli-version',['node',str(CLI),'--version'])
check('installed pinned CLI version2.12.4',version.returncode==0 and b'2.12.4'in version.stdout)
check('NPM package version pinned',json.loads(CLI.with_name('package.json').read_text())['version']=='2.12.4')
native=CLI.parent.parent/'cli-linux-x64-gnu/cli.linux-x64-gnu.node'
native_hash=sha(native.read_bytes());check('actual native CLI hash matches author evidence',native_hash=='957512456d56f1d62a6fe8325e584f4c22cf66f681c1bc3d966f427a9616fe75')
cached=Path('/workspace/.onboarding/native-bundle-discovery')
check('cached official tag is exact commit',json.loads((cached/'cli-tag.json').read_text())['object']['sha']=='993038c49185307dfc895ab7657d77ca0d5ed7c7')
pinned=(cached/'pinned-rust.rs').read_bytes()
check('cached pinned official source bytes',sha(pinned)=='0efada2885cdb6fb1e74832a2704dcbd7e22627709944968740bd8dca8d863ed')
scanner=pinned.decode().split('let mut binaries_paths = std::fs::read_dir')[1].split('if tauri_dir.join("src/main.rs")')[0]
check('actual pinned scanner projects every direntry without file filter','file_stem()'in scanner and 'is_file('not in scanner and 'file_type('not in scanner)
for phase in ['before','after']:
 fixture=OUT/('fixture-'+phase);(fixture/'src/bin').mkdir(parents=True)
 (fixture/'Cargo.toml').write_bytes(blob(HEAD,'apps/desktop/src-tauri/Cargo.toml').split(b'[build-dependencies]')[0].replace(b'build = "build.rs"\n',b'')+b'\n[features]\nnative-smoke=[]\n[[bin]]\nname="agentbaton-native-smoke"\npath="src/bin/native_smoke.rs"\nrequired-features=["native-smoke"]\n[[bin]]\nname="agentbaton-native-owner-dialog-smoke"\npath="src/bin/native_owner_dialog_smoke.rs"\nrequired-features=["native-smoke"]\n')
 (fixture/'src/main.rs').write_text('fn main() {}\n')
 for name in ['native_smoke.rs','native_owner_dialog_smoke.rs']:(fixture/'src/bin'/name).write_text('fn main() {}\n')
 helper=fixture/('src/bin/native_owner_dialog'if phase=='before'else'src/native_owner_dialog_test');helper.mkdir();(helper/'controller.rs').write_text('// inert helper\n')
 (fixture/'tauri.conf.json').write_text(json.dumps({'$schema':'https://schema.tauri.app/config/2','productName':'Independent Discovery Fixture','version':'0.1.0','identifier':'dev.agentbaton.independentdiscoveryfixture','bundle':{'active':True,'targets':['deb']}}))
 release=fixture/'target/release';release.mkdir(parents=True)
 (release/'agentbaton-desktop').write_text('INERT REVIEW FIXTURE TEXT: never executable product\n');(release/'agentbaton-desktop').chmod(0o755)
 r=run('cli-'+phase,['node',str(CLI),'bundle','--ci','--no-sign','--no-binary-patching','--bundles','deb'],cwd=fixture)
 if phase=='before':check('actual CLI old shape fails naming helper directory',r.returncode==1 and b'native_owner_dialog'in r.stderr)
 else:
  check('actual CLI relocated shape succeeds',r.returncode==0)
  files=list(release.rglob('*.deb'));check('one inert fixture package only',len(files)==1)
  r=run('fixture-list',['dpkg-deb','--fsys-tarfile',str(files[0])],cwd=fixture)
  import io
  with tarfile.open(fileobj=io.BytesIO(r.stdout))as archive:
   binaries={Path(m.name).name:archive.extractfile(m).read()for m in archive.getmembers()if m.isfile()and'/usr/bin/'in'/'+m.name}
  check('inert package only production-named placeholder',set(binaries)=={'agentbaton-desktop'}and binaries['agentbaton-desktop'].startswith(b'INERT REVIEW FIXTURE TEXT'))
  (OUT/'fixture-package.json').write_text(json.dumps({'path':str(files[0]),'bytes':files[0].stat().st_size,'sha256':sha(files[0].read_bytes()),'payload_bin_names':list(binaries),'scope':'inert scanner probe ONLY; NOT product, Mac package, installed or executed'},indent=2)+'\n')
check('all protected files still unchanged after lightweight commands',all(blob(HEAD,p)==(R/p).read_bytes()for p in protected))
(OUT/'results.json').write_text(json.dumps({'subject':HEAD,'base':BASE,'status':'passed','count':len(checks),'checks':checks,'commands':commands,'helpers_sha256':helpers,'CLI_native_sha256':native_hash,'not_run':['Rust compile/test/lint','real Core/daemon/Provider/GUI','macOS bundle/install/release audit','CI'], 'scope':'source and inert LinuxCLI scanner only, not product/package acceptance'},indent=2)+'\n')
print('PASS',len(checks),'finite review checks; no compile or product execution')
