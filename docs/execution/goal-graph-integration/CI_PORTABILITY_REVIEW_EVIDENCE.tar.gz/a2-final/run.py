from pathlib import Path
import os,subprocess,json,time,hashlib
b=Path(__file__).resolve().parent;r=Path('/workspace/.worktrees/goal-graph-ci-portability');env=os.environ.copy();env.update(PATH='/workspace/.toolchains/cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup',CARGO_TARGET_DIR='/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1')
names=[('capture','actual_capture_prestart_queue_exhaustion_never_spawns_or_claims_an_io_join'),('proposal','actual_graph_proposal_is_complete_new_authority_and_never_dispatches_before_executor_is_connected'),('owner','actual_graph_owner_decision_unlocks_dependent_summary_with_exact_candidate_input'),('integrity','actual_graph_integrity_validator_is_a_charged_owned_attempt_before_owner_and_summary'),('data','actual_graph_data_contract_passes_before_owner_and_summary_but_is_not_scientific_acceptance'),('command','actual_graph_fixed_command_observation_is_charged_without_recounting_checked_producer_bytes'),('recovery','actual_graph_interrupted_validator_snapshot_is_unknown_fenced_and_never_automatically_replayed')]
commands=[(name,['cargo','test','--locked','-p','agentbaton-core','--test','sessions_ipc',test,'--','--exact','--test-threads=1','--nocapture']) for name,test in names]
commands += [('io11',['cargo','test','--locked','-p','agentbaton-core','--lib','goal_validator_io::tests','--','--test-threads=1','--nocapture']),('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--locked','-p','agentbaton-core','--all-targets','--','-D','warnings'])]
art=r/'artifacts';prior=b/'author-artifacts-preserved';results=[];oldmask=os.umask(0o022)
assert not prior.exists()
if art.exists():art.rename(prior)
try:
 for name,cmd in commands:
  assert not art.exists()
  begin=time.monotonic()
  with (b/(name+'.log')).open('wb') as log:ret=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  item={'name':name,'command':cmd,'cwd':str(r),'umask':'022','fresh_artifact_parent_before':True,'returncode':ret.returncode,'seconds':time.monotonic()-begin,'log_sha256':hashlib.sha256((b/(name+'.log')).read_bytes()).hexdigest()}
  if art.exists():
   target=b/(name+'-artifacts');art.rename(target);item['artifact_directory']=str(target)
  results.append(item);(b/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(item),flush=True)
  if ret.returncode:break
finally:
 if art.exists():art.rename(b/'unexpected-final-artifacts')
 if prior.exists():prior.rename(art)
 os.umask(oldmask)
 (b/'fixture-restoration.json').write_text(json.dumps({'original_author_artifacts_restored':art.exists(),'no_original_artifacts_deleted':True,'all_test_processes_waited':True},indent=2)+'\n')
