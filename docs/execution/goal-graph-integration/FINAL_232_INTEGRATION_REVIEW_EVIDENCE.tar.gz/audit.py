from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,gzip,tomllib
OUT=Path(__file__).resolve().parent;SRC=OUT/'source';P=SRC/'docs/execution/goal-graph-integration';REPO='/workspace/.worktrees/goal-graph-integration';BASE='0aa20c968d493cad895e4a3853bdf106d6b54acf';REV='232b53a832b247964510b8660a7231d167fa9c90';LEAF='7a13cddef4316d520361071ff5e2a263ea058580'
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(path,rev=BASE):return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=REPO)
R={};changed=subprocess.check_output(['git','diff','--name-only',BASE,REV],cwd=REPO,text=True).splitlines();source_paths=[n for n in changed if not n.startswith('docs/') and n!='BOOTSTRAP_MANIFEST.json'];composition=json.loads((P/'NATIVE_TEXT_SOURCE_COMPOSITION.json').read_text());assert set(source_paths)==set(composition['files']) and len(source_paths)==4
for n,r in composition['files'].items():b=(SRC/n).read_bytes();assert b==obj(n,LEAF) and sha(b)==r['sha256'] and len(b)==r['bytes']
R['four_source_paths_exact_leaf']=source_paths;R['all_other_production_rootlock_workflows_unchanged']=True
old=json.loads(obj('BOOTSTRAP_MANIFEST.json'))['files'];new=json.loads((SRC/'BOOTSTRAP_MANIFEST.json').read_text())['files'];assert old.keys()==new.keys() and len(new)==93;delta=[n for n in old if old[n]!=new[n]];assert delta==['docs/execution/STATUS.md'];assert old[delta[0]]=='ff1cd0199804c7aa0a580053e50b5f05dae340a6039610cc8323efdf8f7fcb8d';assert new[delta[0]]=='4ac42f0fce63ed9f8b797893665bdb7a2f2144ee8777a9d68434cd672ed6fb32';assert all(sha((SRC/n).read_bytes())==h for n,h in new.items());assert all((SRC/n).read_bytes()==obj(n) for n in old if n!=delta[0]);R['bootstrap']={'registered_paths':93,'only_changed_hash':delta,'other92_actual_bytes_and_hashes_equal':True,'STATUS_SHA256':new[delta[0]]}
# Existing lock package set, exact dependencies and production defaults.
p='apps/desktop/src-tauri/Cargo.lock';a=tomllib.loads(obj(p).decode());b=tomllib.loads((SRC/p).read_text());assert len(a['package'])==len(b['package']);diff=[]
for x,y in zip(a['package'],b['package']):
 if x!=y:
  original=dict(y);original['dependencies']=[z for z in y['dependencies'] if z!='sha2'];assert original==x and y['name']=='agentbaton-desktop';diff.append(y['name'])
assert diff==['agentbaton-desktop'];p='apps/desktop/src-tauri/Cargo.toml';a=tomllib.loads(obj(p).decode());b=tomllib.loads((SRC/p).read_text());assert b['dependencies']['sha2']=={'version':'0.10','optional':True};original=json.loads(json.dumps(b));del original['dependencies']['sha2'];original['features']['native-smoke'].remove('dep:sha2');assert original==a;R['lock']={'package_count':len(a) if False else len(tomllib.loads((SRC/'apps/desktop/src-tauri/Cargo.lock').read_text())['package']),'package_versions_checksums_unchanged':True,'only_new_root_dependency_name':'sha2','NativeSmoke_optional_only':True,'repository_root_lock_byte_unchanged':(SRC/'Cargo.lock').read_bytes()==obj('Cargo.lock')}
p='apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs';before=obj(p).decode();after=(SRC/p).read_text();assert before[before.index('pub fn validate'):].rstrip() in after;R['controller_validate_and_original4_tests_verbatim']=True
# Five portable archives, manifest unions, relative paths, exact payload bytes.
configs=[('CI_0AA_INITIAL','CI_0AA_INITIAL_IMPORT.json'),('CI_0AA_LINUX','CI_0AA_LINUX_IMPORT.json'),('CI_0AA_MAC','CI_0AA_MAC_IMPORT.json'),('NATIVE_TEXT_AUTHOR_SOURCE','NATIVE_TEXT_AUTHOR_SOURCE_IMPORT.json'),('NATIVE_TEXT_REVIEW','NATIVE_TEXT_REVIEW_IMPORT.json')];R['archives']={}
for stem,impname in configs:
 imp=json.loads((P/impname).read_text());archive=P/imp['archive'];assert archive.stat().st_size==imp['bytes'] and sha(archive.read_bytes())==imp['sha256']
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers();assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members);assert len({m.name for m in members})==len(members);data={m.name:t.extractfile(m).read() for m in members}
 manifests={n:v for n,v in data.items() if n.lower().endswith('manifest.json')};assert len(manifests)==(3 if stem=='CI_0AA_MAC' else 1);declared=set(manifests);payload=set();counts={}
 for n,raw in manifests.items():
  prefix=n.rsplit('/',1)[0]+'/' if '/' in n else '';d=json.loads(raw);rs=d['files'];rs=rs if isinstance(rs,list) else [dict(path=k,**v) for k,v in rs.items()];counts[n]=len(rs)
  for r in rs:
   rel=r['path'];assert not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts;name=prefix+rel;b=data[name];assert sha(b)==r['sha256'] and len(b)==r['bytes'],name;declared.add(name)
   if name not in manifests:payload.add(name)
  declared_manifest=imp.get('original_manifests',{}).get(PurePosixPath(n).name)
  if declared_manifest:assert sha(raw)==declared_manifest['sha256'] and len(raw)==declared_manifest['bytes']
 assert set(data)==declared,(stem,set(data)-declared)
 # Fixed externally copied original manifests must be identical to archive members.
 external={'CI_0AA_INITIAL':{'manifest.json':'CI_0AA_INITIAL_MANIFEST.json'},'CI_0AA_LINUX':{'LINUX_MANIFEST.json':'CI_0AA_LINUX_MANIFEST.json'},'CI_0AA_MAC':{'ARM_MANIFEST.json':'CI_0AA_MAC_ARM_MANIFEST.json','INTEL_MANIFEST.json':'CI_0AA_MAC_INTEL_MANIFEST.json','SUMMARY_MANIFEST.json':'CI_0AA_MAC_SUMMARY_MANIFEST.json'},'NATIVE_TEXT_REVIEW':{'MANIFEST.json':'NATIVE_TEXT_REVIEW_MANIFEST.json'}}.get(stem,{})
 for n,raw in manifests.items():
  if PurePosixPath(n).name in external:assert (P/external[PurePosixPath(n).name]).read_bytes()==raw
 for n,b in data.items():p=OUT/'imports'/stem/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 R['archives'][stem]={'archive_sha256':imp['sha256'],'members':len(data),'payload_union':len(payload),'manifest_entries':counts,'all_payload_hashes_and_sizes_match':True,'safe_regular_unique_members':True,'external_manifests_exact':True}
# Lossless raw output matches historical bad commit and the already sealed peer archive.
storage=json.loads((P/'NATIVE_TEXT_ROOT_LOG_STORAGE.json').read_text());z=(P/storage['storage']).read_bytes();assert sha(z)==storage['gzip_sha256'];raw=gzip.decompress(z);assert len(raw)==storage['raw_bytes'] and sha(raw)==storage['raw_sha256'];assert raw==obj('docs/execution/goal-graph-integration/NATIVE_TEXT_ROOT_TESTS.log','15e4a7ee5b5f291dceb943588bdc9241ac1f7457');assert raw==(OUT/'imports/NATIVE_TEXT_REVIEW/owner-native-text-independent-review/root-lease-proof/controller-tests.log').read_bytes();R['lossless_log']={'raw_sha256':sha(raw),'gzip_sha256':sha(z),'raw_bytes':len(raw),'exact_bad_commit_and_peer_archive_raw':True,'results':[s for s in raw.decode().splitlines() if s.startswith('test result:')]};(OUT/'controller-original.log').write_bytes(raw)
root_before=json.loads((P/'NATIVE_TEXT_ROOT_BEFORE.json').read_text());root_after=json.loads((P/'NATIVE_TEXT_ROOT_RESULT.json').read_text());assert root_before['source_sha256']==root_after['source_sha256']=={n:r['sha256'] for n,r in composition['files'].items()};assert root_after['exit_code']==0 and root_after['tests']=={'total':6,'original':4,'new':2,'failed':0,'ignored':0} and root_after['log_sha256']==sha(raw);R['root_recorded_six_tests']=root_after;R['compile_link_paths_current']={r['path']:{'exists':Path(r['path']).exists(),'is_symlink':Path(r['path']).is_symlink()} for r in root_before['borrowed_compile_only_assets']};assert all(not r['is_symlink'] for r in R['compile_link_paths_current'].values())
peer=OUT/'imports/NATIVE_TEXT_REVIEW/owner-native-text-independent-review';assert sha((peer/'REVIEW.md').read_bytes())=='3c465e82308236f771d47a3fb207a615438bd6fd9f168b7687d0c9510d1596f6';assert (P/'NATIVE_TEXT_REVIEW.md').read_bytes()==(peer/'REVIEW.md').read_bytes();R['peer_review_sha256']=sha((peer/'REVIEW.md').read_bytes());R['peer_manifest_sha256']=sha((peer/'MANIFEST.json').read_bytes())
ci=P/'ci-0aa';cm=json.loads((ci/'MANIFEST.json').read_text())
for n,r in cm['files'].items():b=(ci/n).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes']
jobs=sum([json.loads((ci/n).read_text())['jobs'] for n in ['product-jobs-final.json','environment-jobs-final.json']],[]);assert len(jobs)==7 and all(j['head_sha']==BASE for j in jobs);assert [j['conclusion'] for j in jobs].count('success')==5 and [j['conclusion']for j in jobs].count('failure')==2;R['CI_jobs']=[{'name':j['name'],'conclusion':j['conclusion'],'run_id':j['run_id']}for j in jobs];R['CI_subject']=cm
# Exactly nine additive partial-evidence entries, original requirements/status intact.
p='docs/execution/requirements-progress.json';a=json.loads(obj(p));b=json.loads((SRC/p).read_text());assert len(a['requirements'])==len(b['requirements'])==130;assert [x['id'] for x in a['requirements']]==[x['id'] for x in b['requirements']];modified=[]
for x,y in zip(a['requirements'],b['requirements']):
 if x!=y:
  fields=[k for k,v in y.items() if isinstance(v,list) and len(v)==len(x.get(k,[]))+1 and v[:-1]==x.get(k)];assert len(fields)==1;field=fields[0];old=dict(y);old[field]=y[field][:-1];assert old==x;modified.append({'id':y['id'],'added_slice':y[field][-1].get('slice')})
assert len(modified)==9;R['requirement_partial_additions']=modified
# Earlier current-stage records were moved intact into labelled history, not erased.
eold=json.loads(obj('docs/execution/goal-graph-integration/EVIDENCE.json'));enew=json.loads((P/'EVIDENCE.json').read_text());assert enew['historical_stages'][:-1]==eold['historical_stages'] and enew['historical_stages'][-1]['current_at_that_stage']==eold['current_candidate'];assert enew['ci_641']==eold['ci_641'];R['previous_stage_and_641_evidence_preserved']=True;R['Root_failure_and_correction_record']=enew['current_candidate']['Root_final_record_failure_and_correction']
R['limits']=['Independent static review only; no Cargo/product tests rerun','Mac code not compiled/newGUI not run; prior readonly success does not make Owner success','Unknown actual field text/counts and historical cause not reconstructed','Source-only diagnosis is not proven remediation; no new installers/Factory13/formal approval']
(OUT/'audit-results.json').write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(R,indent=2))
