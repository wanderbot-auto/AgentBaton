from pathlib import Path
import subprocess,json,hashlib,re
R=Path(__file__).parent;T=Path('/workspace/.worktrees/goal-owner-grant-lifetime');A=Path('/workspace/.onboarding/goal-owner-grant-lifetime');BASE='2ceaa608d87b20e20e72068e4a143ab8e4126e48';SRC='5dc9b195e0d4fc21e06cd66ea7db27e32e545131';DOC='99c50a656f43cd6f41a80d102b1e4e1fce20b277';F='crates/core/tests/sessions_ipc.rs';H=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def ck(n,v,**details):assert v,(n,details);rows.append({'name':n,'status':'passed',**details})
def git(*args):return subprocess.check_output(['git',*args],cwd=T)
old=git('show',BASE+':'+F).decode();new=git('show',SRC+':'+F).decode();(R/'original-sessions_ipc.rs').write_text(old);(R/'subject-sessions_ipc.rs').write_text(new);patch=git('diff',BASE+'..'+SRC,'--',F);(R/'subject.patch').write_bytes(patch)
ck('exact source/doc/worktreeclean',git('rev-parse','HEAD').decode().strip()==DOC and not git('status','--porcelain')and (T/F).read_text()==new)
ck('source commit changes only requested integration test',git('diff','--name-only',BASE+'..'+SRC).decode().splitlines()==[F])
ck('docs commit changes own four records only',set(git('diff','--name-only',SRC+'..'+DOC).decode().splitlines())=={'docs/execution/goal-owner-grant-lifetime/'+x for x in ['PLAN.md','PROGRESS.md','CHECKPOINT.md','EVIDENCE.json']})
# Independent inverse normalization: remove exact dedicated block and added target probes, restore three original operations.
s=new;start=s.index('// Dedicated diagnostic for the two-Owner fixture.');end=s.index('#[test]\nfn actual_graph_owner_decision_unlocks_dependent_summary_with_exact_candidate_input()',start);helper=s[start:end];s=s[:start]+s[end:]
s=s.replace('    let clock = GraphOwnerGrantClock::new();\n','')
s=s.replace('    // This independently approved fixture window includes both Owner reviews.\n    // Graph/shared runtime and every node reservation stay unchanged below.\n','')
s=s.replace('    let f = Scenario::new(30_000);','    let f = Scenario::new(10_000);')
a=s.index('    assert_eq!(scope["root_budget"]["runtime_ms"], 10000);');b=s.index('    let approved = approve_graph_at(&f, &scope, 2);',a);s=s[:a]+s[b:]
s=''.join(line for line in s.splitlines(keepends=True)if not line.lstrip().startswith('clock.trace('))
s=s.replace('let decision = clock.approve(&f, &scope, p.clone(), "first-owner");','let decision = approve(&f.server, p.clone());').replace('let final_decision = clock.approve(&f, &scope, final_proposal.clone(), "second-owner");','let final_decision = approve(&f.server, final_proposal.clone());')
ck('independent wholefile inverse byteexact; alloriginal assertions/helpers/defaults retained',s==old,old_sha256=H(old.encode()),new_sha256=H(new.encode()),inverse_sha256=H(s.encode()))
oldtests=re.findall(r'#\[test\]\s*fn (\w+)',old);newtests=re.findall(r'#\[test\]\s*fn (\w+)',new)
ck('55 original tests retained; only one added expirynegative',len(oldtests)==55 and len(newtests)==56 and set(newtests)-set(oldtests)=={'actual_graph_owner_fixture_original_grant_expiry_still_refuses_new_dispatch'},unchanged_other_original_tests=54)
ck('trace only opens readonly DB; no Store open/recovery/mutation', 'rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY' in helper and not re.search(r'\b(?:UPDATE|INSERT|DELETE|CREATE|DROP)\b',helper)and 'Store::open('not in helper)
macro='json!({"method":"approvals.finalize","params":{"proposal_id":proposal["id"]},"expected_revision":proposal["revision"],"idempotency_key":format!("proposal:{}",proposal["id"])})'
ck('Owner wrapper exact original finalizerequest/CAS/key/result',macro in helper and macro in old and 'result(response)'in helper)
ck('new testcaps remain fixed root/project10k node5k reservation4k',all(x in new for x in ['assert_eq!(scope["root_budget"]["runtime_ms"], 10000);','assert_eq!(scope["project_budget"]["runtime_ms"], 10000);','assert_eq!(node["budget"]["runtime_ms"], 5000);','assert_eq!(node["reservation"]["runtime_ms"], 4000);']))
# Author actual logs, not reexecuted here. Record raw provenance before deriving summaries.
sourceindex=json.loads((A/'SOURCE_SNAPSHOT.json').read_text());allrefs=[]
for path,m in sourceindex['artifacts'].items():
 q=Path(path)if path.startswith('/')else T/path; b=q.read_bytes();assert H(b)==m['sha256']and len(b)==m['bytes'],path;allrefs.append({'path':str(q),'bytes':len(b),'sha256':H(b)})
ck('all declared author artifacts independently rehashed',True,files=len(allrefs))
for name,sourcehash,seconds in [('original10-normal-manifests',H((A/'old10-instrumented-sessions_ipc.rs').read_bytes()),6.34),('original10-expired-manifests',H((A/'old10-instrumented-sessions_ipc.rs').read_bytes()),10.63),('new30-normal',H(new.encode()),6.28)]:
 start=json.loads((A/(name+'-start.json')).read_text());result=json.loads((A/(name+'-result.json')).read_text());log=(A/(name+'.log')).read_bytes();text=log.decode();ck(name+' command/source/hash/exacttarget/exit0',start['source_sha256']==sourcehash and result['exit_code']==0 and result['interruption']is None and result['log_sha256']==H(log)and start['command'][:7]==['cargo','test','--locked','-p','agentbaton-core','--test','sessions_ipc']and start['command'][-3:]==['--','--exact','--nocapture'])
 ck(name+' actual1PASS0fail/ignored; whole56 not claimed',bool(re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 55 filtered out; finished in '+str(seconds),text)))
 ck(name+' bounded offline environment and no disk guard interruption',start['environment']['CARGO_NET_OFFLINE']=='true' and start['environment']['CARGO_BUILD_JOBS']=='2'and start['environment']['RUST_TEST_THREADS']=='1'and start['environment']['CARGO_PROFILE_TEST_DEBUG']=='0'and start['dev_debug']=='unset'and min(x['free_bytes']for x in result['disk_samples'])>=200*1024*1024)
# Parse samples from original raw logs; do not trust summary arrays as sole proof.
oldph=[];newph=[];expire=[]
for name,dest in [('original10-normal-manifests',oldph),('original10-expired-manifests',expire),('new30-normal',newph)]:
 for line in (A/(name+'.log')).read_text().splitlines():
  if 'GRAPH_OWNER_GRANT_PHASE ' in line:dest.append(json.loads(line.split('GRAPH_OWNER_GRANT_PHASE ',1)[1]))
 ck(name+' raw phase samples present',len(dest)==(2 if dest is expire else 8))
for label,ph,duration in [('old10',oldph,10000),('new30',newph,30000)]:
 first=ph[0];grant=first['grant'];ck(label+' original expiry immutable/notrevoked/rootgrant',all(x['grant']['expires_at_ms']==grant['expires_at_ms']and x['grant']['id']==grant['id']and x['grant']['revoked']is False and x['grant']['parent_id']is None and x['grant']['scope']['max_duration_ms']==duration and x['schema_version']==12 for x in ph))
 ck(label+' clock sane without injectedclock/reapproval',all(abs(x['utc_since_start_ms']-int(x['monotonic_ms']))<=1 and x['grant']['remaining_ms']==grant['expires_at_ms']-x['utc_ms']for x in ph))
 plan=next(x for x in ph if x['phase']=='plan-ready');proposal=plan['response']['proposal'];ck(label+' actualfournode caps unchanged',len(proposal['nodes'])==4 and all(n['budget']['runtime_ms']==5000 and n['reservation']['runtime_ms']==4000 for n in proposal['nodes'])and plan['goal_scope']['root_budget']['runtime_ms']==plan['goal_scope']['project_budget']['runtime_ms']==10000)
 replies=[x for x in ph if x['phase'].endswith('after-finalize')];ck(label+' bothrealOwner replies accepted with finalTaskAccepted',len(replies)==2 and all('error'not in x['response']for x in replies)and replies[0]['response']['result']['decision']=='accepted'and replies[1]['response']['result']['task_accepted']is True and all(x['grant']['remaining_ms']>0 for x in ph))
e=expire[-1];response=e['response'];ck('original10 realexpiry strictDENIED/notstarted, rootnotrevoked and unchangedexpiry',e['grant']['remaining_ms']<=0 and e['grant']['revoked']is False and e['grant']['parent_id']is None and e['grant']['expires_at_ms']==expire[0]['grant']['expires_at_ms']and response['error']['code']=='PERMISSION_DENIED'and response['error']['message']=='Execution grant or an ancestor is revoked or expired'and response['error']['side_effect_state']=='not_started')
ck('negative source preserves allseven tablecounts+zeroattempt+zerokey',all('"'+n+'"'in helper for n in ['attempts','sessions','dispatch_intents','workspace_leases','goal_run_reservations','idempotency','events'])and 'assert_eq!(counts(), original_counts);'in helper and 'expired-original-owner-grant-never-dispatches'in helper)
initial=(A/'original10-normal.log').read_text();ck('initial sparsemanifest failure preserved, not testfailure reclassified', 'failed to load manifest'in initial or 'No such file or directory'in initial)
intel=Path('/workspace/.onboarding/pr16-2ceaa-review/intel-job.log').read_bytes();it=intel.decode();ck('oldIntel54pass1fail preserved and no absoluteexpiry invented','test result: FAILED. 54 passed; 1 failed'in it and 'Execution grant or an ancestor is revoked or expired'in it and '"revision":68'in it)
(R/'audit.json').write_text(json.dumps({'verdict':'limited fixture source-ready; no blocking finding','source':SRC,'records':DOC,'source_sha256':H(new.encode()),'checks':rows,'count':len(rows),'author_artifacts':allrefs,'oldIntel_log_sha256':H(intel),'old10_normal_phases':oldph,'new30_normal_phases':newph,'old10_expiry_phases':expire,'reviewer_Cargo_browser_run':False,'not_run':['newsourcefull56','Clippy/fmt at finalsource','newMacIntel/ARM','newCI','productionProvider/model']},indent=2)+'\n');print('PASS',len(rows),'read-only source/evidence controls')
