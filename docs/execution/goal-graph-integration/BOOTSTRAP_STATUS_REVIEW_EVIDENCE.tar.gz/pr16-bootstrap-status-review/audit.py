from pathlib import Path
import subprocess,json,hashlib,gzip
D=Path(__file__).resolve().parent;R=Path('/workspace/.worktrees/goal-graph-integration');A=Path('/workspace/.onboarding/pr16-6912-ci/ui-artifact');C=R/'docs/execution/goal-graph-integration/ci-6912'
def sha(v):return hashlib.sha256(v).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='6912fa9b72bc3ab9fbc1ddba18cd76e7c052677c'
old=json.loads(git('show','HEAD:BOOTSTRAP_MANIFEST.json'));new=json.loads((R/'BOOTSTRAP_MANIFEST.json').read_bytes());assert set(old)==set(new)and old['algorithm']==new['algorithm']=='sha256'and old['note']==new['note']
assert set(old['files'])==set(new['files'])and len(new['files'])==93
changed=[name for name in old['files']if old['files'][name]!=new['files'][name]];assert changed==['docs/execution/STATUS.md']
checks={}
for name,value in new['files'].items():
 p=R/name;assert p.is_file()and not p.is_symlink()and p.resolve().is_relative_to(R)
 actual=sha(p.read_bytes());assert actual==value,name;checks[name]=actual
checker='scripts/verify_bootstrap_manifest.py';assert (R/checker).read_bytes()==git('show','HEAD:'+checker)
paths=['.github/workflows/environment-preflight.yml','.github/workflows/product.yml','scripts/validate_infrastructure.py']
for name in paths:assert (R/name).read_bytes()==git('show','HEAD:'+name)
rebase=json.loads((R/'docs/execution/goal-graph-integration/BOOTSTRAP_STATUS_REBASELINE.json').read_text());assert rebase['paths_count']==93 and rebase['changed_entries']=={changed[0]:{'before':old['files'][changed[0]],'after':new['files'][changed[0]]}}
archive=json.loads((C/'MANIFEST.json').read_text());restored=[]
for name,record in archive['files'].items():
 p=C/name;z=p.read_bytes();raw=gzip.decompress(z);assert sha(z)==record['sha256']and sha(raw)==record['raw_sha256']and len(raw)==record['raw_bytes'],name
 if name.startswith('ui-reports/'):
  original=A/name.removeprefix('ui-reports/').removesuffix('.gz').replace('__','/')
 else:
  original=Path('/workspace/.onboarding/pr16-6912-ci')/name.removesuffix('.gz')
  if not original.exists():original=D/name.removesuffix('.gz')
 assert original.read_bytes()==raw,name
 restored.append({'path':name,'compressed_sha256':sha(z),'raw_sha256':sha(raw),'raw_bytes':len(raw)})
summary=json.loads((C/'UI_SUCCESS_SUMMARY.json').read_text());assert summary==json.loads(Path('/workspace/.onboarding/pr16-6912-ci/UI_SUCCESS_SUMMARY.json').read_text())
rows=[];images=[];graphrows=[]
for row in summary['rows']:
 p=A/row['path'];raw=p.read_bytes();d=json.loads(raw);assert sha(raw)==row['sha256']and d.get('status','passed')=='passed'
 assert len(d['checks'])==row['checks']and all(x['status']=='passed'for x in d['checks']);assert len(d['screenshots'])==row['screenshots']
 assert d['daemon_sha256']==row['daemon_sha256']=='a07b00de7eb58128f2dde32397e9c49b3918ff0413195c574f9eb8feae4208c3'
 for image in d['screenshots']:
  file=p.parent/Path(image['path']if isinstance(image,dict)else image).name;assert file.is_file()
  h=sha(file.read_bytes());expected=image.get('sha256')if isinstance(image,dict)else d.get('screenshot_sha256',{}).get(file.name)
  if expected is not None:assert h==expected
  images.append({'path':str(file.relative_to(A)),'sha256':h,'matches_declared_sha256':expected is not None})
 if row['path'].startswith('goal-graph-'):
  assert d['candidate']['schema']==12 and d['candidate']['git_head']=='a11045e6a8f72bb5264c1f4cdbf792f51370bdfa'
  assert d['harness_sha256']==row['harness_sha256']=='4bc91fde76a61c4fdb829f3844f06cca20f94238add92d5b60bedb0edd00adc5'
  assert not d['http_unexpected_errors'];graphrows.append(row)
 rows.append(row)
assert len(rows)==12 and sum(r['checks']for r in rows)==114 and len(images)==70
assert len(graphrows)==6 and sum(r['checks']for r in graphrows)==34 and sum(r['screenshots']for r in graphrows)==14
assert len(list(A.rglob('*.png')))==70
api=json.loads((D/'ui-artifact-api.json').read_text());assert api['id']==12836776815 and api['workflow_run']['id']==40733070149 and api['workflow_run']['head_sha']==head
assert api['name']=='frontend-real-ipc-a11045e6a8f72bb5264c1f4cdbf792f51370bdfa'
commit=json.loads((D/'actual-checkout.json').read_text());assert commit['tree']['sha']==archive['tree']=='3a38fc51c4eb237d2ab0d25b4c9812d096e83f6b'and[p['sha']for p in commit['parents']]==['a1be94d26d10bb245bb35eb50226b82012c967da',head]
for n in ['environment-arm','environment-intel']:
 assert 'Bootstrap file changed; review before staging: docs/execution/STATUS.md'in(D/(n+'.log')).read_text()
assert 'Bootstrap file changed; review before staging: docs/execution/STATUS.md'in Path('/workspace/.onboarding/pr16-6912-ci/env-ubuntu.log').read_text()
product=json.loads((D/'product-jobs.json').read_text());env=json.loads((D/'environment-jobs.json').read_text())
assert all(x['conclusion']=='failure'for x in env['jobs'])and len(env['jobs'])==3
assert sum(x['conclusion']=='success'for x in product['jobs'])==1 and next(x for x in product['jobs']if x['name']=='Product / UI')['conclusion']=='success'
out={'status':'passed','head':head,'changed_bootstrap_paths':changed,'old_status_registered_hash':old['files'][changed[0]],'old_status_actual_HEAD_hash':sha(git('show','HEAD:docs/execution/STATUS.md')),'new_status_hash':new['files'][changed[0]],'all_93_current_hashes':checks,'algorithm_note_checker_workflows_and_other_92_entries_unchanged':True,'archive':restored,'UI_reports':rows,'PNG_hashes':images,'UI_total_checks':114,'UI_total_PNGs':70,'graph_checks':34,'graph_PNGs':14,'artifact_api':{'id':api['id'],'run':api['workflow_run']['id'],'name':api['name'],'archive_digest_from_API':api['digest'],'raw_ZIP_independent_hash':'not performed; ZIP not retained locally, no repeat download'},'jobs':[{'name':x['name'],'id':x['id'],'status':x['status'],'conclusion':x['conclusion']}for x in product['jobs']+env['jobs']],'limits':'Hash/report inventory review only, no actual new PNG visual judgment, new Mac/NSAlert/package/runtime not passed; product failure preserved'}
(D/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','paths':93,'changed_entries':1,'gzip_records':len(restored),'UI_reports':12,'checks':114,'PNGs':70,'graph':{'checks':34,'PNGs':14}}))
