from pathlib import Path
import json,hashlib,subprocess,re
D=Path(__file__).resolve().parent;A=D/'ui-artifact';R=Path('/workspace/.worktrees/goal-graph-integration');HEAD='641be86e8b055920787cfebdd48270716d509309';CO='d03313d5b9b1b575e1eb4a4ae35ec29c49ff446d';H='4bc91fde76a61c4fdb829f3844f06cca20f94238add92d5b60bedb0edd00adc5';B='a07b00de7eb58128f2dde32397e9c49b3918ff0413195c574f9eb8feae4208c3'
def sha(v):return hashlib.sha256(v).hexdigest()
def show(path,rev=HEAD):return subprocess.check_output(['git','show',rev+':'+path],cwd=R)
co=json.loads((D/'checkout.json').read_text());assert[p['sha']for p in co['parents']]==['a1be94d26d10bb245bb35eb50226b82012c967da',HEAD];assert co['tree']['sha']==subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=R,text=True).strip()=='67038b21828745f79905a169abb6e57e98bca5a0'
run=json.loads((D/'product-run.json').read_text());assert run['head_sha']==HEAD and run['run_attempt']==1
assert len(json.loads((D/'environment-jobs.json').read_text())['jobs'])==3 and all(j['conclusion']=='success'for j in json.loads((D/'environment-jobs.json').read_text())['jobs'])
assert sha(show('apps/desktop/tests/goal-graph-real-ipc.py'))==H
candidate=json.loads((A/'goal-execution-candidate.json').read_text());assert candidate['git_head']==CO and candidate['git_tree']==co['tree']['sha']and candidate['dirty']is False and candidate['schema']==12 and candidate['binaries']['batond']==B
reports=[];images=[]
for p in sorted(A.rglob('*.json')):
 d=json.loads(p.read_text())
 if 'checks'not in d:continue
 assert d.get('status','passed')=='passed'and all(c['status']=='passed'for c in d['checks']);assert d['daemon_sha256']==B
 for image in d['screenshots']:
  name=Path(image['path']if isinstance(image,dict)else image).name;f=p.parent/name;h=sha(f.read_bytes());declared=image.get('sha256')if isinstance(image,dict)else d.get('screenshot_sha256',{}).get(name)
  if declared is not None:assert h==declared
  images.append({'path':str(f.relative_to(A)),'sha256':h,'declared_digest_checked':declared is not None})
 if p.parent.name.startswith('goal-graph-'):assert d['candidate']==candidate and d['harness_sha256']==H
 reports.append({'path':str(p.relative_to(A)),'sha256':sha(p.read_bytes()),'checks':len(d['checks']),'PNGs':len(d['screenshots']),'harness_sha256':d.get('harness_sha256'),'daemon_sha256':B})
assert len(reports)==12 and sum(x['checks']for x in reports)==114 and len(images)==70==len(list(A.rglob('*.png')))
ui=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(D/'product-ui.log').read_text());assert 'Test Files  37 passed (37)'in ui and 'Tests  564 passed (564)'in ui
rust=(D/'product-rust.log').read_text();assert 'Ran 29 tests'in rust and 'Ran 11 tests'in rust and 'captured generated-child native contract; not live compatibility'in rust
sumtests=0;sumdocs=0;nested=0;phase='rust'
for line in rust.splitlines():
 if 'Doc-tests 'in line:phase='docs'
 m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.* (\d+) filtered out;',line)
 if not m:continue
 assert int(m[2])==int(m[3])==0
 if int(m[4]):nested+=int(m[1]);continue
 if phase=='docs':sumdocs+=int(m[1])
 else:sumtests+=int(m[1])
assert(sumtests,sumdocs,nested)==(593,7,2)
source_files=['apps/desktop/src/goal-graph-api.ts','apps/desktop/src/goal-graph-guards.ts','apps/desktop/src/goal-graph-observation-text.test.ts','apps/desktop/src/GoalGraphExecution.lossless-observation.test.tsx','apps/desktop/src/goal-graph-actual-lossless-command-fixture.json','apps/desktop/src/goal-graph-actual-lossless-data-fixture.json','apps/desktop/src/goal-graph-types.ts','apps/desktop/src/GoalGraphExecution.tsx'];sourceproof={}
for path in source_files:
 raw=show(path);assert raw==show(path,'4fab558fe126543c23b1410949e6fcd922b770d6'),path
 out=D/'exact-source'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);sourceproof[path]=sha(raw)
def large(v,p=''):
 if type(v)is int and abs(v)>9007199254740991:yield {'path':p,'value_decimal':str(v)}
 if isinstance(v,dict):
  for k,x in v.items():yield from large(x,p+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from large(x,p+'/'+str(i))
largeproof={}
for kind in ['command','data']:
 f='apps/desktop/src/goal-graph-actual-lossless-'+kind+'-fixture.json';fixture=json.loads(show(f));print('fixturekeys',kind,list(fixture))
 # Locate all original observation-text fields in the actual retained packet.
 found=[]
 def rawfields(v,p=''):
  if isinstance(v,dict):
   if 'observation_json'in v:
    text=v['observation_json'];assert sha(text.encode())==v['result_digest'];found.append({'path':p,'raw_bytes':len(text.encode()),'sha256':sha(text.encode()),'large_integers':list(large(json.loads(text)))})
   for k,x in v.items():rawfields(x,p+'/'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):rawfields(x,p+'/'+str(i))
 rawfields(fixture);assert found;largeproof[kind]={'fixture_sha256':sha(show(f)),'original_observations':found}
currentlarge={}
for kind in ['command','command-timeout']:
 r=json.loads((A/('goal-graph-'+kind)/'report.json').read_text())['observations']['real_validator'];currentlarge[kind]={'large_integer_values':list(large(r['receipt']['observation'])),'raw_bytes':len(r['observation_json'].encode()),'raw_sha256':sha(r['observation_json'].encode())}
assert all(not x['large_integer_values']for x in currentlarge.values())
out={'status':'passed','feature_head':HEAD,'actual_checkout':CO,'tree':co['tree']['sha'],'candidate':candidate,'reports':reports,'PNG_hashes':images,'UI_checks':114,'UI_PNGs':70,'Node':{'tests':564,'files':37},'Rust':{'unit_integration':sumtests,'compile_fail_doctests':sumdocs,'nested_process_summaries_not_recounted':nested},'Python_CI':{'existing_native_runner':29,'new_owner_dialog_contracts':11},'unchanged_4fab_UI_source':sourceproof,'large_u64_saved_real_packet_source':largeproof,'new_CI_command_observation_large_integer_scan':currentlarge,'limits':'Saved packet Node regression is distinct from this CI real command runtime; these new actual observations do not exercise >2^53 integer branch. No live official Provider or macOS claims.'}
(D/'linux-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','reports':12,'checks':114,'PNGs':70,'Rust':sumtests,'doctests':sumdocs,'Node':564,'sourcefiles_4fab_exact':len(sourceproof)}))
