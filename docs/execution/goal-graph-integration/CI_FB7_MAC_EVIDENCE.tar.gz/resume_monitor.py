"""Resume acquisition ledger after stdout BrokenPipe; never redownload evidence.

All stdout is redirected to a local file by the launcher. Previous failure and
all successful API bytes remain immutable. No workflow or source mutation.
"""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent
# Define the component in one namespace so its functions retain their globals.
namespace = {'__name__': 'acquisition_component', '__file__': str(ROOT / 'monitor.py')}
exec(compile((ROOT / 'monitor.py').read_text(), str(ROOT / 'monitor.py'), 'exec'), namespace)
namespace['ATTEMPTS'] = namespace['json'].loads((ROOT / 'monitor-api-attempts.json').read_text())
get, save, extract, wait_until = (namespace[k] for k in ['get', 'save', 'extract', 'wait_until'])
json, time, datetime, now = (namespace[k] for k in ['json', 'time', 'datetime', 'now'])
ARCH, REPO, HEAD, RUN = (namespace[k] for k in ['ARCH', 'REPO', 'HEAD', 'RUN'])

def main():
    save('monitor-resumed.json', {'at': now(), 'pid': os.getpid(),
                                'previous_failure': 'monitor-failure.json',
                                'stdout': 'resume-monitor.log',
                                'no_existing_downloads_repeated': True})
    # Root already read terminal Linux / ongoing Core Mac at 22:34; avoid a
    # duplicate metadata read. Next scheduled stage remains about five minutes.
    next_epoch = datetime.datetime.fromisoformat('2026-10-28T22:39:00+00:00').timestamp()
    wait_until(time.monotonic() + max(0, next_epoch - time.time()))
    finished = {a for a in ARCH if (ROOT / (a + '-job-terminal.json')).exists()}
    iteration = max(int(f.stem.rsplit('-', 1)[1]) for f in ROOT.glob('product-jobs-stage-*.json'))
    deadline_epoch = datetime.datetime.fromisoformat('2026-10-28T23:18:04+00:00').timestamp()
    while finished != set(ARCH):
        assert time.time() < deadline_epoch, 'Acquisition window ended; no unexecuted continuation'
        iteration += 1
        snapshot = json.loads(get(f'product-jobs-stage-{iteration:02}.json', f'{REPO}/actions/runs/{RUN}/jobs'))
        assert all(j['head_sha'] == HEAD for j in snapshot['jobs'])
        print(json.dumps({'at': now(), 'jobs': [{'id': j['id'], 'name': j['name'],
              'status': j['status'], 'conclusion': j['conclusion'],
              'current_steps': [s['name'] for s in j['steps'] if s['status'] == 'in_progress']}
              for j in snapshot['jobs']]}), flush=True)
        for arch, ident in ARCH.items():
            job = next(j for j in snapshot['jobs'] if j['id'] == ident)
            if arch in finished or job['status'] != 'completed':
                continue
            save(arch + '-job-terminal.json', job)
            get(arch + '-job.log', f'{REPO}/actions/jobs/{ident}/logs')
            artifacts = json.loads(get(arch + '-artifacts-terminal.json', f'{REPO}/actions/runs/{RUN}/artifacts'))
            os_label = 'macos-15' if arch == 'arm' else 'macos-15-intel'
            for prefix, kind in [('native-webview-', 'native-artifact'), ('development-', 'development-artifact')]:
                matches = [a for a in artifacts['artifacts'] if a['name'].startswith(prefix + os_label + '-')
                           and (os_label.endswith('-intel') or '-intel-' not in a['name'])]
                assert len(matches) <= 1
                if matches:
                    assert not matches[0]['expired']
                    extract(arch + '-' + kind, matches[0])
            finished.add(arch)
            save('monitor-state.json', {'at': now(), 'completed_arches': sorted(finished),
                                        'remaining_arches': sorted(set(ARCH) - finished)})
            print(json.dumps({'at': now(), 'terminal_arch_downloaded': arch,
                              'conclusion': job['conclusion']}), flush=True)
        if finished != set(ARCH):
            wait_until(time.monotonic() + 300)
    save('monitor-complete.json', {'at': now(), 'status': 'download_complete_review_pending',
                                 'images_reviewed_by_monitor': False})
    print('DOWNLOAD_COMPLETE_REVIEW_PENDING', flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('monitor-resume-failure.json', {'at': now(), 'type': type(error).__name__,
                                           'message': str(error), 'no_automatic_retry': True})
        raise
