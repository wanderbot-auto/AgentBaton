"""Independently inspect saved CI artifacts only; never starts product processes."""
from pathlib import Path
import hashlib, json, re, sys, datetime

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source-snapshot'
runner_path = SOURCE / 'scripts/native-owner-dialog-smoke.py'
runner = {'__name__': 'saved_evidence_reference_validator', '__file__': str(runner_path)}
exec(compile(runner_path.read_text(), str(runner_path), 'exec'), runner)

def read(path):
    return json.loads(path.read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def decode_prompts(prompts, message):
    """Decode actual fixture text without using production/mirror encoder."""
    restored, expected_row, offset = '', 1, 0
    pages = len(prompts) - 1
    ranges = []
    for index, prompt in enumerate(prompts[:-1]):
        lines = prompt.split('\n')
        assert lines[0] == f'Native review page {index + 1}/{pages}'
        match = re.fullmatch(r'Original UTF-8 bytes (\d+)\.\.(\d+) of (\d+)\.', lines[1])
        assert match
        start, end, total = map(int, match.groups())
        assert start == offset and total == len(message.encode())
        assert lines[2:4] == ['Read JSON strings in L order; escapes preserve ALL text.',
                              'OK reads this page only. Cancel stops this review.']
        assert 1 <= len(lines[4:]) <= 8
        for line in lines[4:]:
            match = re.fullmatch(r'L(\d{5}) (".*")', line)
            assert match and int(match.group(1)) == expected_row
            encoded = match.group(2)
            assert len(encoded[1:-1].encode()) <= 40
            text = json.loads(encoded)
            assert type(text) is str
            restored += text
            offset += len(text.encode())
            expected_row += 1
        assert offset == end
        ranges.append({'page_index': index, 'start': start, 'end': end, 'total': total,
                       'prompt_utf8_bytes': len(prompt.encode()), 'prompt_sha256': sha(prompt.encode())})
    assert restored.encode() == message.encode()
    expected_final = (f'FINAL display confirmation\nAll {pages} pages / {offset} original UTF-8 bytes were reviewed.\n'
                      'OK confirms the original request exactly as displayed.\nAny further required reviews still apply.\n'
                      'Cancel stops without private approval.')
    assert prompts[-1] == expected_final
    return {'lossless_original_utf8': True, 'original_utf8_bytes': offset,
            'original_sha256': sha(restored.encode()), 'data_pages': pages,
            'total_prompts_including_final': len(prompts), 'rows': expected_row - 1, 'ranges': ranges}

def main(arch):
    artifacts = ROOT / (arch + '-native-artifact')
    owner = artifacts / 'owner-dialog'
    result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'dimension': 'offline audit of saved actual CI; no product/test rerun', 'arch': arch, 'errors': []}
    fixture = read(owner / 'fixture.json')
    before = read(owner / 'before.json')
    prompts = fixture['presentation']
    result['presentation_roundtrip'] = decode_prompts(prompts, fixture['message'])
    result['production_formatter_matches_fixture'] = runner['expected_message'](
        fixture['proposal'], (SOURCE / 'apps/desktop/src-tauri/src/approval.rs').read_text()) == fixture['message']
    result['initial_pending_validator_error'] = runner['pending_error'](before, fixture['proposal'], fixture['baseline_sequence'])
    result['before'] = {'schema_version': before['schema_version'], 'sequence': before['sequence'],
                        'grants': len(before['grants']), 'counts': before['counts']}
    result['page_records'] = []
    for phase in ['cancel', 'approve']:
        previous_number = None
        for index, prompt in enumerate(prompts):
            key = f'{phase}-page-{index + 1:04}'
            ready_path = owner / (key + '-sheet-ready.json')
            if not ready_path.exists():
                continue
            observed = read(ready_path)
            error = runner['presentation_error'](observed, fixture['proposal'], prompts, phase, index)
            dbpath, permitpath = owner / (key + '-before-click-database.json'), owner / (key + '-database-permit.json')
            db, permit = read(dbpath) if dbpath.exists() else None, read(permitpath) if permitpath.exists() else None
            pending = runner['pending_error'](db, fixture['proposal'], fixture['baseline_sequence']) if db else 'missing'
            strict_db = bool(db) and type(db['schema_version']) is int and db['schema_version'] == 12 and len(db['counts']) == 19 and all(type(v) is int and v == 0 for v in db['counts'].values())
            expected_permit = {'phase': phase, 'presentation_index': index, 'presentation_count': len(prompts),
                               'proposal_id': fixture['proposal']['id'], 'proposal_revision': fixture['proposal']['revision'],
                               'before_click_sequence': fixture['baseline_sequence']}
            number = observed.get('window_number')
            windows_ok = type(number) is int and number > 0 and number != previous_number
            previous_number = number
            imagepath = owner / (key + '-sheet.png')
            image = imagepath.read_bytes() if imagepath.exists() else b''
            record = {'key': key, 'index': index, 'is_final': index + 1 == len(prompts),
                      'presentation_error': error, 'pending_db_error': pending, 'strict_schema12_19zero': strict_db,
                      'permit_matches_exact_refs': permit == expected_permit, 'positive_changed_window_number': windows_ok,
                      'ready_message_sha256': sha(observed.get('message', '').encode()),
                      'image_sha256': sha(image), 'image_exists': bool(image),
                      'parent_visible_fullcell_flags': {k: observed.get(k) for k in ['parent_matches', 'visible', 'complete_text_visible']}}
            result['page_records'].append(record)
            if error or pending or not strict_db or permit != expected_permit or not windows_ok or not image:
                result['errors'].append(record)
    for phase in ['cancel', 'approve']:
        reply = owner / (phase + '-reply.json')
        result[phase + '_reply'] = read(reply) if reply.exists() else None
    after = owner / 'after.json'
    if after.exists():
        after_value = read(after)
        result['approved_validator_error'] = runner['approved_error'](
            after_value, fixture['proposal'], fixture['baseline_sequence'], result['approve_reply'] or {})
        result['after'] = {'schema_version': after_value['schema_version'], 'sequence': after_value['sequence'],
                           'grants': len(after_value['grants']), 'counts': after_value['counts'],
                           'target_events': [e for e in after_value['events'] if e['sequence'] > fixture['baseline_sequence']]}
    else:
        result['after'] = None
    for name in ['result.json', 'owner-dialog.json', 'runner-failure.json', 'app-cleanup.json', 'daemon-cleanup.json']:
        path = owner / name
        result[name] = read(path) if path.exists() else None
    diagnostics = []
    for path in sorted(owner.glob('*-sheet-diagnostic.json')):
        diagnostic = read(path)
        observation = diagnostic.get('observation') or {}
        fields = []
        for view in observation.get('views', []):
            if 'text' in view:
                text = view['text']; data = text['text'].encode()
                assert sha(data) == text['sha256'] and len(data) == text['utf8_bytes']
                fields.append({'index': view['index'], 'class': view['class'], 'bytes': len(data), 'sha256': sha(data)})
        diagnostics.append({'file': path.name, 'first_reason': diagnostic['reason'],
                            'phase': observation.get('phase'), 'stage': observation.get('validation_stage'),
                            'title_matches': observation.get('title_matches'), 'message_matches': observation.get('message_matches'),
                            'on_screen': observation.get('on_screen'), 'sheet_frame': observation.get('sheet_frame'),
                            'parent_frame': observation.get('parent_frame'), 'actual_fields_hashes_verified': fields,
                            'capture': diagnostic.get('capture')})
    result['diagnostics'] = diagnostics
    native = read(artifacts / 'native-smoke.json')
    proofs = [native['webcrypto_checkpoints'][k] for k in ['before', 'after']] + [native[k]['webCrypto'] for k in ['first_webview', 'reopened_webview']]
    assert all(len(v['input'].encode()) == v['input_bytes'] == 109 and sha(v['input'].encode()) == v['sha256'] == 'd29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892' for v in proofs)
    result['native_readonly'] = {'status': native['status'], 'architecture': native['architecture'],
                                  'commit': native['commit'], 'webcrypto_four_original_utf8_proofs_verified': True}
    (ROOT / (arch + '-offline-page-audit.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'arch': arch, 'pages_per_phase': len(prompts), 'ready_pages': len(result['page_records']),
                      'audit_errors': len(result['errors']), 'after_present': result['after'] is not None,
                      'native_readonly': result['native_readonly'], 'diagnostics': diagnostics}, indent=2))

if __name__ == '__main__':
    main(sys.argv[1])
