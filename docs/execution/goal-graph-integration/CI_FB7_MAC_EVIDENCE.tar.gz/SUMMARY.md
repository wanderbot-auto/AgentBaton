# fb7 dual-mac CI evidence summary

Feature fb7ff7d861872eec18e010f7b64a0ead63740faa, actual checkout613166104190bedb3730a7510743137422ab05fa (both original logs), treebcfd8e5aaa3f06b63b88608e6b7ba05e9d5ca262, Product40779542803 / Environment40779542808 attempt1. Actual checkout commit API and fixed source snapshots bind all original evidence. Review does not mutate or approve the PR.

| Dimension | Apple Silicon123137412037 | Intel123137411644 |
| --- | --- | --- |
| Actual new Native pages compiled/run | observed | observed |
| Native host / readonly-smoke / Owner pure tests |62 /26 /8 passed |62 /26 /8 passed |
| Actual readonly WebView/lifecycle +4 original WebCrypto proofs |passed |passed |
| Complete original UTF-8 message |3132B,84 encoded rows |3136B,84 encoded rows |
| Actual data pages + separate Final per phase |11+1, twice |11+1, twice |
| Actual ready/before-click DB/permit/PNG sets |24 each |24 each |
| Per-page exact refs/text/parent/visible/fullcell/permit audit |0 page-level errors |0 page-level errors |
| Late Final Cancel |PERMISSION_DENIED/not_started; no Grant |PERMISSION_DENIED/not_started; no Grant |
| Final OK and persisted result |one Grant, sequence8→10, original19 tables0 |one Grant, sequence8→10, original19 tables0 |
| Original Owner acceptance |**failed: Grant response mismatch** |**failed: Grant response mismatch** |
| App cleanup status |exit1/quiescent/okfalse |exit1/quiescent/okfalse |
| Default release build/audit/development package |skipped |skipped |

Environment3 and ProductUI/Rust succeeded, total5 successes and2 Mac job failures. Actual presentation/late-Cancel/Final-OK side effects are retained as subordinate observations; the failed CI status is not rewritten. The association guard compares real Grant.approval_id to proposal.id, but fixed Core policy generates approval UUID independently. The successful response.result, persisted Grant and proposal_result agree, and proposal confirmation targets its separate proposal ID. The old Python approved predicate still reports failure. Root has assigned a separate test-contract fix; this evidence does not assert a corrected candidate has run on macOS.

Every page's raw prompt was independently decoded through ordered JSON-string L rows and continuous UTF-8 byte ranges back to the entire original message; no normalization or numeric JSON reserialization is used. All48 Owner PNGs and2 readonly PNGs were individually viewed, with image hashes recorded. Actual page/final content and buttons fit visibly within the app/desktop area; no prior oversized single-sheet result is borrowed. Source remains gated on exact text/complete measured cells/on-screen/caller-parent/500ms stability,4-second capture,75-second native watchdog,85-second Python deadline and exact page/proposal/sequence permit before actual button action.

Original evidence includes before/after databases: all24 per-page before-click snapshots in each architecture remain strict schema12/sequence8/unconsumed/no Grants/original19 counters0, including approve phase after late Cancel. Final after snapshot is sequence10, one Grant, original19 counters0, one grant-approved event9 and one proposal-confirmed event10. Factory schema13/28 is a separate line and was not tested here. Human Owner approval, graph private multipage OS flow, real Provider models, signing/notarization and production release are not claimed.

Raw logs and native ZIPs were downloaded once per architecture; API digests, CRC, safe paths, per-file original modes and SHA-256 are retained in manifests. Initial metadata monitor hit BrokenPipe; the failure was preserved and monitoring resumed from its ledger with file-backed stdout, collected both terminal jobs and exited. No acquisition continues and no unexecuted background continuation is promised. No local Cargo, source, target, daemon, remote/workflow, permission or approval mutation was performed. Release builds/audits/packages were skipped, so there are no new installer hashes or signing results to borrow from PR15 or other runs.
