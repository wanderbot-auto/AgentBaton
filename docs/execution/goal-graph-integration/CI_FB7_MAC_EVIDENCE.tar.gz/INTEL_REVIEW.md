# Actual Intel macOS review — fb7

Product40779542803 attempt1, Intel job123137411644, completed **failure**22:53:38 UTC. Feature fb7ff7d861872eec18e010f7b64a0ead63740faa; original log:103 confirms actual checkout613166104190bedb3730a7510743137422ab05fa. Saved commit API binds treebcfd8e5aaa3f06b63b88608e6b7ba05e9d5ca262, parents a1be94d26d10bb245bb35eb50226b82012c967da + fb7. Sources and artifacts are fixed snapshots; no reviewer source/Cargo/target/daemon/model/remote/CI mutation occurred.

New Native pagination compiled and executed on actual Intel macOS. Host tests62 passed(log3367), native-smoke26 passed(3435), Owner pure tests8 passed(3461), all zero failures/ignored. Actual readonly WebView/lifecycle succeeded. Owner step22:52:49–22:53:31 failed at final response association after actual page completion and persisted Grant. Release application build, default binary audit, development packaging and package upload were skipped; no current Intel development installer/signature/audit is supplied.

## Original failure and exact association

owner-dialog.json retains **Grant response mismatch**, observation_failure:null. Original Intel native failure is log3465; first Python ValueError Exact production Grant commit/CAS/result/zero execution evidence missing is3469; later cleanup RuntimeError is3478–3479.

Native record_report compares result.approval_id to fixture proposal.id. Intel proposal ID isd1c26327-d2c1-4a53-9cb3-dac50d6e0913; real Grant ID is9db3d37c-068b-4d02-abf0-9c79ff44f5ea; Grant.approval_id ise68f2792-a2ac-4a3f-8795-ba7c11413de0. The latter is an independently generated Core approval UUID (fixed policy.rs:814), not the proposal ID. Actual response.result, persisted Grant and proposal_result are equal; approval.confirmed targets the proposal and execution_grant.approved targets the Grant with its own approval UUID. Raw fields/events are preserved in grant-association-observation.json. The original old predicate still fails; this review does not apply Root's separately assigned correction or label a future candidate as macOS passed.

## Independent Intel page and database audit

The archive has24 complete ready/PNG/before-click DB/permit sets:11 data pages plus Final per phase, late-Cancel phase followed by approve phase. Independent decode of L00001–L00084 JSON string rows reconstructs3136 original UTF-8 bytes, SHA277d14ddaeea8b84172a5bcb51a3a30144401574932074518da2daadbf8bb6ad, exactly matching this Intel fixture and fixed production formatter. Continuous byte ranges, exact page/row indices,40-byte encoded rows, at most8 rows/page, complete original bytes and exact separate Final prompt all check. ARM's3132B fixture was not substituted. No normalization or reconstructed numeric JSON replaces original text.

All24 actual ready records bind exact prompt, proposal/revision, phase/index/count, positive changed page window number and true parent/visible/fullcell flags. Both real buttons are visible/enabled. Fixed compiled native observation includes same actual caller/attached-sheet parent, whole-sheet on-screen containment, complete measured text and500ms stability. Original capture4s/native75s/Python85s bounds remain;42-second Owner step includes compile/tests/bootstrap and is not separately measured per-page timing proof.

Every before-click DB record is strict integer schema12/sequence8, same unconsumed proposal, no Grants, exactly original19 counters0. Each permit binds the same phase/page/index/count/proposal/revision/baseline sequence before the real button action. All pages are read, then real Final Cancel returns PERMISSION_DENIED/not_started and no result; every subsequent approve-page before-click snapshot still shows no Grant/confirmation. Final approve OK produces a successful result and after.json: schema12/sequence10, one exact bounded root Grant, original19 counters0, consumed proposal/revision2. Baseline+1 event9 is one execution_grant.approved; baseline+2 event10 is one approval.confirmed with proposal ID/revision/payload. The final old approved_error failure remains recorded separately from0 page-level audit errors.

## Images, native actions and cleanup

Individually opened all24 Intel own-sheet PNGs and the actual readonly task PNG with view_image. Data pages and Final show complete visible text and OK/Cancel controls within the app/desktop area; the last data page and Final wrap in a narrower centered sheet without observed clipping. Original JSON escapes preserve indentation/control representation behind the L prefix; screenshots are original pixels, not composites or fabricated page evidence. All image SHA values and visual observations are in visual-review.json. Screenshots do not create human approval or override the failed job.

Actual source-controlled ready/capture/permit path uses real NSControl.performClick; no synthetic modal callback or target Grant finalize exists in bootstrap. Canonical private runtime/root uid501/0700/no symlinks,92-byte socket under103, daemon stderr APIready. The generated executable only runs a bounded --version fixture; no real Provider model invocation or private account state was used.

App pid70767 exited1 with quiescent group/no errors/signals, okfalse preserves failure. Daemon pid70510 was SIGTERM-stopped, exit0, group quiescent, oktrue. All page capture workers are joined by the fixed source before phase progression; no existing worker is replaced. Failed app exit is not a claim that owned processes remain alive, nor a successful cleanup result.

Actual x86_64 readonly report binds6131, strict schema12/sequence3/Goal+Graph zeros, product invoke/persistence/background survival/restart/reopen/draft cancel and owned cleanup. All four actual WebView109B original UTF-8 crypto proofs independently recompute to d29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892. This does not prove Factory schema13/28, graph private multipage Owner flow or real models.

## Artifact and conclusion boundaries

One raw Intel job log SHA31515ec6787d10d43e79bb70d998ad293740189ed6a0c44a6bc90c70a2532215; one native ZIP artifact12857582737,6665757B, SHA10689e357f0518f1a794b01aa55009852fac5c11bab5ff67106ee8c7ee7839d3 matches API digest. All115 entries CRC/safe paths/per-file hashes checked, original ZIP modes retained. No logs or artifacts were downloaded twice. The metadata-only BrokenPipe and later successful read-only resume are recorded honestly; collection is finished, no monitor continues.

The actual presentation, late Cancel, final OK and persisted side effect are observed; **the original Owner CI acceptance remains failed** at the approval association assertion and app exit1. No result.json, repaired candidate run, release audit, package, signing/notarization, Provider model call, production release or formal approval is claimed. Root owns any next contract fix and independent review; original fb7 evidence remains unchanged.
