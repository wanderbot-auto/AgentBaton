from pathlib import Path
import importlib.util,os,json,subprocess,time,hashlib
from unittest import mock
D=Path(__file__).resolve().parent/'actual-controls';D.mkdir(mode=0o700,exist_ok=True);R=Path('/workspace/.worktrees/owner-bootstrap-ci-stability');spec=importlib.util.spec_from_file_location('author_owner_fixture',R/'scripts/native-owner-dialog-smoke.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
binary=Path('/workspace/.worktrees/goal-validation-graph/artifacts/goal-validation-graph/candidate-70a48d416631/batond');assert hashlib.sha256(binary.read_bytes()).hexdigest()=='40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd';rows=[]
parents=D/'parents';parents.mkdir(mode=0o700,exist_ok=True);real=parents/'real';real.mkdir(mode=0o700);alias=parents/'alias';alias.symlink_to(real,target_is_directory=True)
def output(name):
 p=D/name;p.mkdir(mode=0o700);return p
def positive(name,parent=None):
 p=output(name)
 with mock.patch.object(m.tempfile,'tempdir',str(parent))if parent else mock.patch.object(m.tempfile,'tempdir',m.tempfile.tempdir):
  with m.bootstrap(binary,p)as f:
   observed=m.database(f['runtime'],f['proposal']['id']);assert m.pending_error(observed,f['proposal'],observed['sequence'])is None
   assert observed['schema_version']==12 and len(observed['counts'])==19 and all(v==0 for v in observed['counts'].values())and not observed['grants']
   m.save(p/'actual-pending-database.json',observed)
   try:f['client'].call('approvals.finalize',{'proposal_id':f['proposal']['id']})
   except ValueError as e:assert 'never a Grant'in str(e)
   else:raise AssertionError('Host crossed Grant approval boundary')
 state=json.loads((p/'bootstrap-state.json').read_text());assert state['status']=='completed'and state['cleanup_ok']is True and state['original_failure']is None
 cleanup=json.loads((p/'daemon-cleanup.json').read_text());assert not any(x['signal']=='SIGKILL'for x in cleanup['signals'])
 rows.append({'name':name,'kind':'actual frozen70a/schema12 Core pending Grant/bootstrap only','status':'passed','state':state,'cleanup':cleanup})
positive('normal')
# Actual current Linux Core refusal for an explicitly constructed symlink alias;
# this is NOT the historical Mac failure's missing stderr or path.
raw=output('controlled-raw-alias-refusal');runtime=real/'denied-runtime';runtime.mkdir(mode=0o700);env={**os.environ,'BATON_RUNTIME_DIR':str(alias/'denied-runtime')}
with os.fdopen(os.open(raw/'stdout.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb')as out,os.fdopen(os.open(raw/'stderr.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb')as err:
 child=subprocess.Popen([str(binary)],env=env,start_new_session=True,stdout=out,stderr=err)
 try:
  deadline=time.monotonic()+3
  while not m.exited_without_reaping(child):
   assert time.monotonic()<deadline;time.sleep(.02)
  cleanup=m.stop_owned(child,'daemon')
 finally:
  if child.returncode is None:m.stop_owned(child,'daemon')
assert cleanup['returncode']==1 and cleanup['ok']is False and cleanup['signals']==[]
stderr=(raw/'stderr.log').read_text();assert'Runtime paths must not contain symbolic links'in stderr
m.save(raw/'observation.json',{'dimension':'controlled own Linux symlink refusal; historical ARM cause remains unknown','raw_runtime':str(alias/'denied-runtime'),'canonical_runtime':str(runtime.resolve()),'cleanup':cleanup,'stderr_sha256':hashlib.sha256((raw/'stderr.log').read_bytes()).hexdigest()});rows.append({'name':'controlled-raw-alias-refusal','kind':'actual Core negative private path, not historical reconstruction','status':'passed','cleanup':cleanup,'stderr':stderr})
positive('canonical-alias-parent',alias)
long=parents/('long-parent-'+'x'*120);long.mkdir(mode=0o700);positive('private-short-fallback',long);assert rows[-1]['state']['paths']['private_short_fallback']is True
for code in [0,23]:
 p=output('exited-'+str(code));fake=parents/('own-exit-'+str(code));fake.write_text(f'#!/bin/sh\nprintf "controlled owned stdout\\n"\nprintf "controlled owned stderr\\n" >&2\nexit {code}\n');fake.chmod(0o700)
 try:
  with m.bootstrap(fake,p):raise AssertionError('Exited daemon yielded ready')
 except RuntimeError as error:assert str(error)=='Fixture daemon exited before readiness'
 state=json.loads((p/'bootstrap-state.json').read_text());assert state['status']=='failed'and state['daemon_exitcode']==code and state['cleanup_ok']is False and state['original_failure']['message']=='Fixture daemon exited before readiness'
 assert (p/'daemon-stderr.log').read_bytes()==b'controlled owned stderr\n'and state['stderr']['mode']==0o600
 rows.append({'name':'exited-'+str(code),'kind':'actual own generated process failure; no fake Core DB/GUI','status':'passed negative/refused','state':state})
report={'status':'passed','dimension':'six actual local bootstrap/process controls; Linux not OS dialog/Mac/historical root-cause proof','source_sha256':hashlib.sha256((R/'scripts/native-owner-dialog-smoke.py').read_bytes()).hexdigest(),'daemon':str(binary),'daemon_source':'frozen70a/schema12, not new Mac CI binary','daemon_sha256':'40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd','controls':rows};(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','controls':len(rows),'fallback_initial_socket_bytes':rows[3]['state']['paths']['initial_socket_utf8_bytes'],'fallback_final_socket_bytes':rows[3]['state']['paths']['socket']['utf8_bytes'],'historical_ARM_cause':'unknown'}))
