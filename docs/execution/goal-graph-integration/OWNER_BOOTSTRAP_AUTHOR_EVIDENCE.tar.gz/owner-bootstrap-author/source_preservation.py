from pathlib import Path
import ast,subprocess,json,hashlib
D=Path(__file__).resolve().parent;R=Path('/workspace/.worktrees/owner-bootstrap-ci-stability');P='scripts/native-owner-dialog-smoke.py';T='apps/desktop/src-tauri/tests/test_native_owner_dialog.py'
def old(p):return subprocess.check_output(['git','show','641be86e8b055920787cfebdd48270716d509309:'+p],cwd=R).decode()
a=old(P);b=(R/P).read_text();ta=ast.parse(a);tb=ast.parse(b)
oldnodes={n.name:n for n in ta.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))};newnodes={n.name:n for n in tb.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
unchanged=[]
for name,node in oldnodes.items():
 if name=='bootstrap':continue
 assert ast.get_source_segment(a,node)==ast.get_source_segment(b,newnodes[name]),name;unchanged.append(name)
def assignment(tree,name):return next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
for name in ['GOAL_TABLES','ZERO_TABLES']:assert ast.get_source_segment(a,assignment(ta,name))==ast.get_source_segment(b,assignment(tb,name))
def literals(fn):
 return [(ast.dump(n.func),ast.dump(n.args[0]))for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and isinstance(n.func.value,ast.Name)and n.func.value.id=='client'and n.func.attr=='call']
assert literals(oldnodes['bootstrap'])==literals(newnodes['bootstrap'])
def named_assign(fn,name):return next(n for n in ast.walk(fn)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
for name in ['params','invoke']:assert ast.dump(named_assign(oldnodes['bootstrap'],name))==ast.dump(named_assign(newnodes['bootstrap'],name))
def deadlines(fn):
 return sorted(ast.dump(n)for n in ast.walk(fn)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='deadline'for t in n.targets))
assert deadlines(oldnodes['bootstrap'])==deadlines(newnodes['bootstrap'])
x=old(T);y=(R/T).read_text();xa=ast.parse(x);ya=ast.parse(y);oldclass=next(n for n in xa.body if isinstance(n,ast.ClassDef)and n.name=='OwnerRunnerControls');newclass=next(n for n in ya.body if isinstance(n,ast.ClassDef)and n.name=='OwnerRunnerControls');assert ast.get_source_segment(x,oldclass)==ast.get_source_segment(y,newclass)
assert len([n for n in oldclass.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')])==11
newtests=[n.name for n in ast.walk(ya)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert len(newtests)==15
out={'status':'passed','baseline':'641be86e8b055920787cfebdd48270716d509309','unchanged_original_top_level_bodies_except_bootstrap':unchanged,'original_owner_controls_class_11_whole_bytes_unchanged':True,'total_tests':15,'new_test_names':[n for n in newtests if n not in {n.name for n in oldclass.body if isinstance(n,ast.FunctionDef)}],'schema12_GOAL_and_ZERO_assignments_exact':True,'ZERO_table_count':19,'bootstrap_original_client_method_set_sequence_and_Grant_params_invoke_deadlines_AST_exact':True,'all_original_run_OS_message_Parent_Cancel_OK_and_cleanup_logic_bodies_exact':True,'source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in [P,T]}}
for p in [P,T]:q=D/'exact-source'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((R/p).read_bytes())
(D/'source-preservation.json').write_text(json.dumps(out,indent=2)+'\n');(D/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',P,T],cwd=R));print(json.dumps({'status':'passed','unchanged_original_declarations':len(unchanged),'original_tests':11,'new_total_tests':15,'source_sha256':out['source_sha256']}))
