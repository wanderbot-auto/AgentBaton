from pathlib import Path
import subprocess,json,hashlib,ast,importlib.util,sys
R=Path(__file__).parent;A=Path('/workspace/AgentBaton/.onboarding/native-grant-contract/scalar-cas');repo=Path('/workspace/.worktrees/native-grant-contract');rev='655c6d2985dd8d2d0dcfa16864d12edf2dfca374';base='1839c6c8ca82319ad18cd6c5dd3825b19dde5ee7';sha=lambda b:hashlib.sha256(b).hexdigest();E=R/'evidence';E.mkdir(exist_ok=True);mb=(A/'MANIFEST.json').read_bytes();assert sha(mb)=='483d0ccac98bf44733d13f641dd45ec5d51d559f236ca6be65ab67064d33d0f6';m=json.loads(mb);(E/'author-MANIFEST.json').write_bytes(mb)
for n,h in m['evidence_sha256'].items():
 b=(A/n).read_bytes();assert sha(b)==h;(E/n).write_bytes(b)
for row in json.loads((R/'source-manifest.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{rev}:{row["path"]}'],cwd=repo);assert b==(R/'source'/row['path']).read_bytes() and sha(b)==row['sha256']
p='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();new=(R/'source'/p).read_text()
def tests(s):return {c.name+'.'+f.name:ast.dump(f,include_attributes=False) for c in ast.parse(s).body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
a,b=tests(old),tests(new);assert len(a)==28 and len(b)==29 and all(b[k]==v for k,v in a.items())
p='scripts/native-owner-dialog-smoke.py';old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();new=(R/'source'/p).read_text()
def nodes(s):return {f.name:ast.get_source_segment(s,f) for f in ast.parse(s).body if isinstance(f,(ast.FunctionDef,ast.ClassDef))}
a,b=nodes(old),nodes(new)
for n in ['run','database','NativeCoreClient','expected_message','presentation_prompts','opaque_id','grant_scope','grant_enforcement','json_exact']:assert a[n]==b[n],n
for p,h in m['unchanged_rust_sha256'].items():assert sha((R/'source'/p).read_bytes())==h and (R/'source'/p).read_bytes()==subprocess.check_output(['git','show',f'fbfd66e:{p}'],cwd=repo)
prior=[]
for folder,hashes in [('native-grant-fbfd-review',{'REVIEW.md':'3890ff0bd15eac6d0ad5339910420dc464d3d3d9d5995453adc603d0ed627e97','REVIEW_MANIFEST.json':'98a3f10e0a26f20330880f6a32fdbb9ede28bc43a916da46f702d4dfa9b4b20c'}),('native-grant-1839-review',{'REVIEW.md':'fb151d688b989bdb40ef1456e3d0adef0e5932239e956f387126cd7570db23b5','REVIEW_MANIFEST.json':'486418c46506484c39cb8bf1de3fa41a0febcabc25f3e66ac30c8074df1d4e36'})]:
 for n,h in hashes.items():assert sha((R.parent/folder/n).read_bytes())==h
 prior.append({'directory':folder,'unchanged_hashes':hashes})
spec=importlib.util.spec_from_file_location('final655guard',R/'source/scripts/native-owner-dialog-smoke.py');runner=importlib.util.module_from_spec(spec);sys.modules[spec.name]=runner;spec.loader.exec_module(runner);mac=[]
for arch in ['arm','intel']:
 D=Path('/workspace/.onboarding/pr16-fb7-mac-review')/(arch+'-native-artifact/owner-dialog');vals={};hashes={}
 for n in ['after.json','approve-reply.json','fixture.json']:
  raw=(D/n).read_bytes();p=E/arch/n;p.parent.mkdir(exist_ok=True);p.write_bytes(raw);vals[n]=json.loads(raw);hashes[n]=sha(raw)
 fixture=vals['fixture.json'];assert runner.approved_error(vals['after.json'],fixture['proposal'],fixture['baseline_sequence'],vals['approve-reply.json']) is None;mac.append({'arch':arch,'saved_original_packet_hashes':hashes,'final_typed_guard_offline_pass':True,'new_OS_execution':False})
out={'revision':rev,'baseline':base,'author_manifest_sha256':sha(mb),'author_evidence_count':len(m['evidence_sha256']),'old28_AST_unchanged':True,'new_test_count':29,'Rust_two_byte_identical_to_fbfd':True,'json_exact_helper_unchanged_from1839':True,'full_OS_run_other_mechanics_bytes_unchanged':True,'prior_seals':prior,'original_twoMac_packets':mac,'scalar_audit':json.loads((A/'SCALAR_AUDIT.json').read_text()),'scope':'NG-FBFD-01 fourrecords+threeknownscalarcounterexamples allreplayedPASS;independent29PASS;noCoreauth/Macclaim'};(R/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('Final655provenancePASS:8fixedfiles/author483+6evidence/old28AST/Rust2same/oldsealsintact/original2MacofflinePASS;scopeclosedwithoutnewMacclaim.')
