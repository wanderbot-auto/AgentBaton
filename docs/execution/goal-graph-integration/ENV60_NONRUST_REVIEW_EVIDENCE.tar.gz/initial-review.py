#!/usr/bin/env python3
"""Exact policy-test revision + full existing non-Rust Environment checks."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,subprocess,sys,yaml
sys.dont_write_bytecode=True
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent
HEAD='9d11a6d0723144a245994a5e7531c282cc60702e';BASE='2ea01821655cf496354f4daedc4fa33d45ce2222'
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PATH':'/workspace/.toolchains/cargo/bin:'+os.environ.get('PATH',''),'CARGO_HOME':'/workspace/.toolchains/cargo','RUSTUP_HOME':'/workspace/.toolchains/rustup'}
checks=[];commands=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def check(name,value):
 assert value,name;checks.append({'name':name,'status':'passed'})
path='tests/infrastructure/test_runtime_policy.py';old=git('show',BASE+':'+path);new=git('show',HEAD+':'+path)
(O/'before-test.py').write_bytes(old);(O/'after-test.py').write_bytes(new)
expected=old.replace(b'finite_45_minute_budget',b'finite_60_minute_budget').replace(b"self.desktop['timeout-minutes'], '45'",b"self.desktop['timeout-minutes'], '60'").replace(b"('46', '120', '0', '-1')",b"('61', '120', '0', '-1')")
check('exact three replacements only',new==expected)
check('working frozen source unchanged',new==(R/path).read_bytes()and git('show',HEAD+':BOOTSTRAP_MANIFEST.json')==(R/'BOOTSTRAP_MANIFEST.json').read_bytes())
check('only test and registered manifest changed',git('diff','--name-only',BASE,HEAD).decode().splitlines()==['BOOTSTRAP_MANIFEST.json',path])
def methods(raw):
 c=next(n for n in ast.parse(raw).body if isinstance(n,ast.ClassDef)and n.name=='RuntimePolicyTests')
 return [n for n in c.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')]
check('six existing runtime-policy cases preserved',len(methods(old))==len(methods(new))==6)
check('no original negative or ordinary-budget assertions removed',new==expected and b"('31', '45', '0', '-1')"in new and b"(None, True, 45.9, '45.9', '${{ matrix.timeout }}', 'unlimited')"in new)
a=git('show',BASE+':BOOTSTRAP_MANIFEST.json');b=git('show',HEAD+':BOOTSTRAP_MANIFEST.json');aa=json.loads(a);bb=json.loads(b)
oldhash=aa['files'][path];newhash=bb['files'][path]
check('single manifest hash byte replacement',a.count(oldhash.encode())==1 and b==a.replace(oldhash.encode(),newhash.encode()))
check('new registered test hash matches exact file',newhash==sha(new)=='0474127b8fbf0432692b2460978d5a07e276583f2c7621a057719b7be3c097de')
check('other92 file hashes match actual files',len(bb['files'])==93 and all(sha((R/p).read_bytes())==h for p,h in bb['files'].items()if p!=path))
for p in ['scripts/validate_infrastructure.py','.github/workflows/product.yml','.github/workflows/environment-preflight.yml','docs/execution/STATUS.md','Cargo.lock','apps/desktop/src-tauri/Cargo.lock']:
 check('protected unchanged '+p,git('show',BASE+':'+p)==git('show',HEAD+':'+p)==(R/p).read_bytes())
log=Path('/workspace/.onboarding/pr16-bb343-ci/environment-linux.log').read_bytes()
check('original bb actualEnvironment failure hash preserved',sha(log)=='b4ce1b1523df1b7a174a954145780b6cca4c8efc122c6b0b28cffc2a7dfa6e9e')
check('actual original full34 twoFAIL retained',b'Ran 34 tests'in log and b'FAILED (failures=2)'in log and b'45_minute_budget'in log and b'AssertionError: AssertionError not raised'in log)
sys.path.insert(0,str(R/'scripts'))
from validate_infrastructure import validate_job_timeout
workflow=yaml.load((R/'.github/workflows/product.yml').read_text(),Loader=yaml.BaseLoader)
job=workflow['jobs']['desktop'];validate_job_timeout('product.yml','desktop',job)
check('approved actualdesktop60 allowed',job['timeout-minutes']=='60')
for name,w,j,x in [('61','product.yml','desktop',{**job,'timeout-minutes':'61'}),('ordinary31','other.yml','job',{'timeout-minutes':'31'}),('wrongselector','other.yml','desktop',job)]:
 try:validate_job_timeout(w,j,x)
 except AssertionError:check('reject '+name,True)
 else:raise AssertionError(name)
validate_job_timeout('other.yml','job',{'timeout-minutes':'30'});check('ordinary30 remains allowed',True)
for name,argv in [
 ('gate',[sys.executable,'scripts/check_gate.py','--scope','preparation']),
 ('doctor',[sys.executable,'scripts/doctor.py','--strict','--output',str(O/'doctor.json')]),
 ('bootstrap',[sys.executable,'scripts/verify_bootstrap_manifest.py']),
 ('design',[sys.executable,'scripts/validate_design.py']),
 ('infrastructure',[sys.executable,'scripts/validate_infrastructure.py']),
 ('python34',[sys.executable,'-m','unittest','discover','-s','tests/infrastructure','-p','test_*.py','-v']),
 ('node4',['npm','test'])]:
 result=subprocess.run(argv,cwd=R,env=ENV,capture_output=True,timeout=60)
 (O/(name+'.stdout')).write_bytes(result.stdout);(O/(name+'.stderr')).write_bytes(result.stderr)
 commands.append({'name':name,'argv':argv,'cwd':str(R),'exitcode':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)})
 check('actual full chain command '+name+' exits0',result.returncode==0)
 if name=='python34':check('actual original34 allPASS',b'Ran 34 tests'in result.stderr and b'\nOK\n'in result.stderr)
 if name=='node4':check('actual original4 Node tests allPASS',b'# tests 4'in result.stdout and b'# fail 0'in result.stdout)
check('source still frozen after commands',new==(R/path).read_bytes()and b==(R/'BOOTSTRAP_MANIFEST.json').read_bytes())
(O/'results.json').write_text(json.dumps({'subject':HEAD,'base':BASE,'finite_count':len(checks),'checks':checks,'commands':commands,'python_cases':34,'runtime_policy_subset_cases':6,'root_Node_cases':4,'status':'nonRust_chain_passed_Rust_pending','not_run':['Environment Rust fixture test/clippy pending Core lease','newremoteCI','product/Core/Native/browser/Provider'],'scope':'existing fullPython/Node/static chain, not product or complete requiredCI signoff'},indent=2)+'\n')
print('PASS',len(checks),'review controls; fullPython34/Node4/static0; Environment Rust pending')
