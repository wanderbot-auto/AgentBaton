import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/workspace/.worktrees/owner-native-text-diagnostics'); out=Path('/workspace/.onboarding/owner-native-text-diagnostics')
env=os.environ.copy();env.update(CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup');env['PATH']='/workspace/.toolchains/cargo/bin:/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:'+env['PATH']
commands=[('rustfmt',['/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2021','--check','apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs']),('metadata',['cargo','metadata','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--locked','--offline','--no-deps','--format-version','1']),('static-proof',['python',str(out/'static-proof.py')]),('diff',['git','diff','--check'])]
results=[]
for name,cmd in commands:
    start=time.monotonic();p=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
    results.append(dict(name=name,command=cmd,exit=p.returncode,elapsed_seconds=round(time.monotonic()-start,3)))
(out/'checks.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=results,Rust_tests='NOT_RUN_no_Cargo_lease',Mac_compile_and_GUI='NOT_RUN'),indent=2)+'\n')
assert all(x['exit']==0 for x in results)
