import hashlib,json,re,subprocess,tomllib
from pathlib import Path
r=Path('/workspace/.worktrees/owner-native-text-diagnostics'); base='0aa20c968d493cad895e4a3853bdf106d6b54acf'
def old(p): return subprocess.check_output(['git','show',base+':'+p],cwd=r).decode()
def block(s,name):
    starts=list(re.finditer(r'^(?:(?:pub )?fn |struct |impl |type |#\[)',s,re.M))
    a=next(m.start() for m in starts if re.match(r'(?:pub )?fn '+re.escape(name)+r'\(',s[m.start():]))
    b=next((m.start() for m in starts if m.start()>a),len(s))
    return s[a:b].rstrip()
paths=['apps/desktop/src-tauri/Cargo.toml','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs','apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs']
m=paths[-1]; original=old(m); now=(r/m).read_text(); c=paths[-2]; oc=old(c);nc=(r/c).read_text()
proof={}
for name in ['write','invoke_script','owner_dialog_report','contains','view_visible','capture']:
    assert block(original,name)==block(now,name),name
    proof[name+'_byte_identical']=True
for name in ['run','record_report']:
    actual=block(now,name)
    actual=re.sub(r'^[ \t]*observation_failure: None,\n','',actual,flags=re.M)
    assert block(original,name)==actual,name
    proof[name+'_only_failure_state_initialization']=True
assert block(oc,'validate')==block(nc,'validate');proof['controller_acceptance_byte_identical']=True
old_tests=oc[oc.index('#[cfg(test)]'):].strip(); assert old_tests in nc;proof['all_original_four_controller_tests_byte_identical']=True
for exact in ['if title.len() != 1 || message.len() != 1 {','controller::validate(&value, expected, phase)?;', 'Some((_, when)) if when.elapsed() < Duration::from_millis(500) => return Ok(None),']:
    assert exact in now
for exact in ['let deadline = Instant::now() + Duration::from_secs(4);','Duration::from_secs(75)','worker.join().map_err(|_| "OS dialog poller panicked")?;','if permit["phase"] != phase.name','unsafe { button.performClick(None) };']:
    assert exact in original and exact in now
proof['exact_gate_stability_capture_poll_and_click_invariants_retained']=True
assert now.index('controller::validate(&value, expected, phase)?;') < now.index('unsafe { button.performClick(None) };')
poll=block(now,'poll'); assert poll.index('Host database permit')<poll.index('phase.clicked = true;')<poll.index('button.performClick')
assert 'if phase.capture.is_none()' in block(now,'start_capture')
assert block(now,'poll_failure').index('save_failure(state, phase)')<block(now,'poll_failure').index('Err(phase.observation_failure')
assert 'window_number' in now and '.args(["-x", "-l", &number.to_string()])' in block(now,'capture')
proof['one_phase_capture_owned_number_and_rejection_before_click_source_checks']=True
for p in paths[:2]:
    a=tomllib.loads(old(p));b=tomllib.loads((r/p).read_text())
    if p.endswith('Cargo.toml'):
        assert b['dependencies'].pop('sha2')=={'version':'0.10','optional':True}
        b['features']['native-smoke'].remove('dep:sha2')
    else:
        pkg=next(x for x in b['package'] if x['name']=='agentbaton-desktop');pkg['dependencies'].remove('sha2')
    assert a==b,p
proof['manifest_only_optional_sha2_feature_root_dependency_no_package_changes']=True
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=r,text=True).splitlines()
assert sorted(changed)==sorted(paths),changed
proof['only_four_authorized_source_files_changed']=True
proof['source_hashes']={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths}
proof['source_tests_not_run_no_Cargo_lease']=True
print(json.dumps(proof,indent=2))
