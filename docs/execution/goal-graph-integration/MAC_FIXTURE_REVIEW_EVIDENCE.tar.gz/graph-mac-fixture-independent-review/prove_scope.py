from pathlib import Path
import subprocess,re,json,hashlib,difflib
r=Path('/workspace/.worktrees/graph-mac-fixture-stability');o=Path(__file__).resolve().parent;f='crates/core/tests/sessions_ipc.rs';old=subprocess.check_output(['git','show','652c5f0:'+f],cwd=r,text=True);new=subprocess.check_output(['git','show','c05f8ce:'+f],cwd=r,text=True);inverse=new
marker='    fn request(&self, v: Value) -> Value {';end='    fn shutdown(&mut self) {';a=inverse.index(marker);z=inverse.index(end,a);a0=old.index(marker);z0=old.index(end,a0);inverse=inverse[:a]+old[a0:z0]+inverse[z:]
a=inverse.index('fn trace_integrity_grant(');z=inverse.index('fn actual_integrity_definition_graph_fixture_with_budget(',a);inverse=inverse[:a]+inverse[z:]
call_lines=re.findall(r'^    trace_integrity_grant\([^\n]+\);\n',inverse,re.M);assert len(call_lines)==9
inverse=re.sub(r'^    trace_integrity_grant\([^\n]+\);\n','',inverse,flags=re.M)
inverse=inverse.replace('    // Enclosing fixture lifetime includes bootstrap and two Owner reviews.\n    // Match Data/Command\'s 30s Grant; Graph runtime/node/negative limits stay fixed.\n','',1)
needle='"max_duration_ms":30000},"idempotency_key":"initial-eight-shared-attempt-policy"';pos=inverse.index(needle,inverse.index('fn actual_integrity_definition_graph_fixture_with_budget('));inverse=inverse[:pos]+inverse[pos:].replace(needle,'"max_duration_ms":10000},"idempotency_key":"initial-eight-shared-attempt-policy"',1)
inverse=inverse.replace('let recovery = f.root.join("restore");','let recovery = f.root.join("validator-interrupted-runtime");',1);a=inverse.index('    // Probe the original socket-length shape only');z=inverse.index('    let recovered = Server::start(&recovery);',a);inverse=inverse[:a]+inverse[z:]
if inverse!=old:(o/'unexpected-inverse-residual.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),inverse.splitlines(True))));raise AssertionError('unexpected inverse residual')
names=lambda x:re.findall(r'#\[test\]\s*fn\s+(\w+)',x);assert names(new)==names(old) and len(names(old))==55
paths=[p for p in subprocess.check_output(['git','ls-files'],cwd=r,text=True).splitlines() if p.endswith('.rs') or p.endswith('Cargo.lock') or p.endswith('Cargo.toml')];changed=[];actual={}
for p in paths:
 raw=(r/p).read_bytes();base=subprocess.check_output(['git','show','652c5f0:'+p],cwd=r);actual[p]=hashlib.sha256(raw).hexdigest()
 if raw!=base:changed.append(p)
assert changed==[f];(o/'source-c05.rs').write_text(new);result={'source':'c05f8cee4966b8c76b6e8de7181d5b9a21572dfe','baseline':'652c5f0bc4983f53375ccb10d897c1088cd0e57f','source_sha256':hashlib.sha256(new.encode()).hexdigest(),'names55_identical':True,'inverse_only_permitted_changes_byte_identical_to_base':True,'trace_phases':9,'changed_Rust_Cargo_locks':changed,'all104_source_map':actual,'cargo_run':False};(o/'STATIC_PROOF.json').write_text(json.dumps(result,indent=2)+'\n');print(result['source_sha256']);print(len(paths))
