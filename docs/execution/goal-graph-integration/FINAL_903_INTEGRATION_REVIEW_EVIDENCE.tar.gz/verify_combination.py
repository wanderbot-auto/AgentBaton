from pathlib import Path,PurePosixPath
import subprocess,hashlib,json,tarfile,zipfile,io,stat,re
r=Path(__file__).parent;s=r/'snapshot';d=s/'docs/execution/goal-graph-integration';repo=Path('/workspace/.worktrees/goal-graph-integration');rev='903b9791c80aa6c363053c284650747fa7ad50e3';base='e3ccf86a8b12e7ed1371074de095bb454c0b62aa';sha=lambda b:hashlib.sha256(b).hexdigest();out={'revision':rev,'baseline':base,'source_checks':[],'archives':[]}
def git(rev,p):return subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo)
comp=json.loads((d/'NATIVE_PAGES_SOURCE_COMPOSITION.json').read_text());allowed=set(comp['changed_source_files_sha256'])
for p,h in comp['changed_source_files_sha256'].items():
 b=(s/p).read_bytes();assert sha(b)==h;assert b==git(comp['source'],p);out['source_checks'].append({'path':p,'sha256':h,'equals_fixed407':True})
changed=subprocess.check_output(['git','diff','--name-only',base,rev],cwd=repo).decode().splitlines();assert set(p for p in changed if not p.startswith('docs/') and p!='BOOTSTRAP_MANIFEST.json')==allowed
for p in ['CHECKPOINT.md','EVIDENCE.md','PLAN.md','PROGRESS.md']:
 path='docs/execution/native-review-presentation/'+p;assert (s/path).read_bytes()==git('1864e8af46a1fa26bc09f0b7c80d74c5affcd778',path)
out['only_five_source_files_changed']=True;out['author_docs_equal1864']=True
bm=json.loads((s/'BOOTSTRAP_MANIFEST.json').read_text());old=json.loads(git(base,'BOOTSTRAP_MANIFEST.json'));assert len(bm['files'])==93 and set(bm['files'])==set(old['files']);diff=[p for p in bm['files'] if bm['files'][p]!=old['files'][p]];assert diff==['docs/execution/STATUS.md'];assert old['files'][diff[0]]=='4ac42f0fce63ed9f8b797893665bdb7a2f2144ee8777a9d68434cd672ed6fb32';assert bm['files'][diff[0]]=='8f8c158e965b520e64bab15c5d8ea2b7a1b4c00ec0def24c78c1fc75bea0a3bd'
for p,h in bm['files'].items():assert sha((s/p).read_bytes())==h
assert {k:v for k,v in bm.items() if k!='files'}=={k:v for k,v in old.items() if k!='files'};out['bootstrap']={'files':93,'changed_registered_hashes':diff,'other92_actual_match':True,'status_sha256':bm['files'][diff[0]]}
req=json.loads((s/'docs/execution/requirements-progress.json').read_text())['requirements'];oldreq=json.loads(git(base,'docs/execution/requirements-progress.json'))['requirements'];a={x['id']:x for x in req};b={x['id']:x for x in oldreq};assert len(a)==130 and set(a)==set(b);out['requirements_changes']=[{'id':k,'old_status':b[k]['status'],'new_status':a[k]['status']} for k in a if a[k]!=b[k]]
assert all(x['old_status']==x['new_status'] for x in out['requirements_changes'])
def safe(name):
 p=PurePosixPath(name);assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name;return str(p)
def mapping(x):
 return {i['path']:i for i in x} if isinstance(x,list) else x
archive_data={}
for prefix,want in [('CI_E3CC_MAC',95),('CI_E3CC_INITIAL',23),('CI_E3CC_LINUX',108),('NATIVE_PAGES_AUTHOR',11),('NATIVE_PAGES_87_REVIEW',49),('NATIVE_PAGES_407_REVIEW',32),('NATIVE_PAGES_ROOT',13)]:
 imp=json.loads((d/(prefix+'_IMPORT.json')).read_text());ab=(d/imp['archive']).read_bytes();assert sha(ab)==imp['sha256'] and len(ab)==imp['bytes'];members={};nested=[]
 with tarfile.open(fileobj=io.BytesIO(ab),mode='r:gz') as t:
  for m in t:
   assert m.isfile() and not m.issym() and not m.islnk();name=safe(m.name);assert name not in members;members[name]=t.extractfile(m).read()
 assert len(members)==want==imp.get('members',imp.get('regular_members'))
 if 'files' in imp:
  expect=imp['files'];assert set(expect)==set(members)
 else:
  side=json.loads((d/(prefix+'_MANIFEST.json')).read_text());expect=mapping(side['files']);assert set(expect).issubset(members)
 for name,item in expect.items():assert sha(members[name])==item['sha256'] and len(members[name])==item['bytes'],(prefix,name)
 if 'original_manifest_sha256' in imp:assert any(sha(raw)==imp['original_manifest_sha256'] for raw in members.values()),prefix
 # A portable original manifest must cover all original members except itself.
 if 'files' not in imp:
  assert len(members)-len(expect)==1;missing=set(members)-set(expect);assert sha(members[missing.pop()])==imp['original_manifest_sha256']
 # Every retained original manifest file list resolves to exact archived raw bytes.
 for name,raw in members.items():
  if name in ['MANIFEST.json','REVIEW_MANIFEST.json']:
   md=json.loads(raw)
   if 'files' in md:
    for pn,pi in mapping(md['files']).items():
     assert pn in members,(prefix,name,pn);assert sha(members[pn])==pi['sha256'] and len(members[pn])==pi['bytes']
 for name,raw in members.items():
  if name.endswith('.zip'):
   with zipfile.ZipFile(io.BytesIO(raw)) as z:
    seen=set();total=0
    for info in z.infolist():
     n=safe(info.filename);assert n not in seen;seen.add(n);assert not stat.S_ISLNK(info.external_attr>>16)
     if not info.is_dir():total+=len(z.read(info))
    assert z.testzip() is None;nested.append({'path':name,'sha256':sha(raw),'members':len(seen),'uncompressed_bytes':total,'crc_paths_nosymlink':True})
 out['archives'].append({'archive':imp['archive'],'sha256':sha(ab),'regular_members':len(members),'all_import_and_original_manifest_paths_hashes_sizes_match':True,'nested_zips':nested});archive_data[prefix]=members
# Preserve and inspect exact source/failure stage distinctions.
auth=archive_data['NATIVE_PAGES_AUTHOR'];assert b'KeyError' in auth['python-first.log'] and b'AGENTBATON_OWNER_FIXTURE_DAEMON' in auth['python-first.log'];assert b'SyntaxError' in auth['python-bidi12-final.log'];assert b'Ran 20 tests' in auth['python-bidi12-final2.log'] and b'OK' in auth['python-bidi12-final2.log']
old87=archive_data['NATIVE_PAGES_87_REVIEW'];fixed=archive_data['NATIVE_PAGES_407_REVIEW'];assert b'U+061C' in old87['boundary.stderr'] and b'FAILED (failures=1)' in old87['boundary.stderr'];assert b'Ran 2 tests' in fixed['boundary_controls.stderr'] and b'OK' in fixed['boundary_controls.stderr']
root=archive_data['NATIVE_PAGES_ROOT'];root_results=[]
for stage,lib,ctrl in [('first87',61,8),('second407',62,8)]:
 result=json.loads(root[stage+'/RESULT.json']);assert result['tracked_source_before_after_equal'] and result['changed']==[] and result['owned_temporary_links_removed'];before=json.loads(root[stage+'/BEFORE.json'])
 for cmd in result['commands']:assert cmd['exit_code']==0 and sha(root[stage+'/'+cmd['log']])==cmd['sha256']
 log=root[stage+'/native-0.log'].decode();assert f'test result: ok. {lib} passed' in log and f'test result: ok. {ctrl} passed' in log
 for tool in result['tool_restoration']:assert tool['before']==tool['after_restore'] and tool['same_inode_restored']
 root_results.append({'stage':stage,'source':result['source'],'library':lib,'controller':ctrl,'total':lib+ctrl,'command_exits':[x['exit_code'] for x in result['commands']],'recorded_all_tracked_unchanged':True,'recorded_tool_sha_inode_restoration':True})
out['Root_native_existing_evidence']=root_results
out['failure_stage_preservation']={'missing_daemon_env':True,'initial_bidi_SyntaxError':True,'old87_U061C_independent_counterexample':True,'fixed407_boundary_pass':True,'no_product_tests_executed_by_this_review':True}
(r/'combination-checks.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified five407 source files;93 bootstrap onlySTATUSrebaseline;130IDs statuses retained;',len(out['requirements_changes']),'requirement evidence changes;7portable archives',sum(x['regular_members'] for x in out['archives']),'members;oldfailures and stage-specific69/70 retained.')
