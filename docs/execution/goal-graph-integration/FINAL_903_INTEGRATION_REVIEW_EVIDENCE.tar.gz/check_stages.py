from pathlib import Path
import tarfile,json,re,hashlib,subprocess
r=Path(__file__).parent;d=r/'snapshot/docs/execution/goal-graph-integration';sha=lambda b:hashlib.sha256(b).hexdigest();out={}
def readtar(name):
 with tarfile.open(d/name) as t:return {m.name:t.extractfile(m).read() for m in t if m.isfile()}
mac=readtar('CI_E3CC_MAC_EVIDENCE.tar.gz');env=json.loads(mac['environment-jobs-final.json'])['jobs'];product=json.loads(mac['product-jobs-stage-07.json'])['jobs'];jobs=env+product;assert len(jobs)==7;assert sum(j['conclusion']=='success' for j in jobs)==5 and sum(j['conclusion']=='failure' for j in jobs)==2
api=json.loads(mac['actual-checkout-commit-api.json']);bind=json.loads(mac['checkout-binding.json']);assert api['sha']==bind['sha']=='4a9ade282b3babefbc3cdbe2e93fd037f89bcdaa';assert api['tree']['sha']==bind['tree']=='144ab4e890c06b537c018b609016268513051a56';assert [x['sha'] for x in api['parents']]==bind['parents'];assert bind['parents'][-1]=='e3ccf86a8b12e7ed1371074de095bb454c0b62aa';tree=subprocess.check_output(['git','rev-parse','e3ccf86^{tree}'],cwd='/workspace/.worktrees/goal-graph-integration').decode().strip();assert tree==bind['tree'];out['e3cc_CI']={'success':5,'failure':2,'jobs':[{k:j[k] for k in ['id','name','conclusion']} for j in jobs],'checkout':api['sha'],'tree':tree}
linux=readtar('CI_E3CC_LINUX_EVIDENCE.tar.gz');a=json.loads((d/'CI_E3CC_LINUX_ROOT_AUDIT.json').read_text());rust=linux['rust-job.log'].decode();ui=linux['ui-job.log'].decode();summaries=a['rust_raw_summaries']
for x in summaries:assert x['raw_line'] in rust
assert sum(x['passed'] for x in summaries if x['dimension']=='outer')==593;assert sum(x['passed'] for x in summaries if x['dimension']=='docs')==7;assert sum(x['passed'] for x in summaries if x['dimension']=='nested_excluded')==2
plain=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',ui);assert re.search(r'Test Files\s+37 passed',plain) and re.search(r'Tests\s+564 passed',plain);assert 'Ran 29 tests' in rust and 'Ran 15 tests' in rust
n=0
for item in a['browser_reports']:
 raw=linux[item['path']];assert sha(raw)==item['sha256'];report=json.loads(raw);assert len(report['checks'])==item['checks'];assert all(x['status']=='passed' for x in report['checks']);n+=len(report['checks'])
assert len(a['browser_reports'])==12 and n==114;assert len([n for n in linux if n.endswith('.png')])==70;assert len(a['Root_actual_images_viewed'])==2
out['Linux_existing_records']={'role':a['mode'],'Rust_outer':593,'compilefail_docs':7,'nested_not_added':2,'Node':564,'Nodefiles':37,'Python':[29,15],'browser_reports':12,'checks':n,'PNGs':70,'Root_viewed_images':a['Root_actual_images_viewed'],'reviewer_opened_no_images_or_ran_product_tests':True}
# Every Root precompile tracked-source hash binds its own recorded author head.
root=readtar('NATIVE_PAGES_ROOT_EVIDENCE.tar.gz');out['Root_before_bindings']=[]
for stage in ['first87','second407']:
 before=json.loads(root[stage+'/BEFORE.json']);head=before['head'];count=0
 for p,h in before['tracked_source_sha256'].items():
  b=subprocess.check_output(['git','show',f'{head}:{p}'],cwd='/workspace/.worktrees/goal-graph-integration');assert sha(b)==h,(stage,p);count+=1
 out['Root_before_bindings'].append({'stage':stage,'head':head,'source':before['source'],'tracked_hashes_match_fixed_head':count})
(r/'stage-checks.json').write_text(json.dumps(out,indent=2)+'\n');print('Raw savedAPI confirms5success2fail/e3cc exactcheckout tree;Linux rawlogs+12reports114checks70PNGs matchRootselfaudit;Root both before inventories bind own fixed authorheads.')
