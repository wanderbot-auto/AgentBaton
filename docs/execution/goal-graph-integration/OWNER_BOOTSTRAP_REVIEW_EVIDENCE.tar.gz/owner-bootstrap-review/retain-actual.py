from pathlib import Path
import importlib.util,os,json,subprocess,time,hashlib,tempfile
from unittest import mock
D=Path(__file__).resolve().parent
S=D/'source'
spec=importlib.util.spec_from_file_location('independent_owner',S/'scripts/native-owner-dialog-smoke.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
binary=Path('/workspace/.worktrees/goal-validation-graph/artifacts/goal-validation-graph/candidate-70a48d416631/batond')
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd'
A=D/'actual';A.mkdir(mode=0o700)
rows=[]
def output(name):
 p=A/name;p.mkdir(mode=0o700);return p
def positive(name,parent=None):
 p=output(name)
 with mock.patch.object(m.tempfile,'tempdir',str(parent)if parent else m.tempfile.tempdir):
  with m.bootstrap(binary,p)as f:
   db=m.database(f['runtime'],f['proposal']['id'])
   assert m.pending_error(db,f['proposal'],db['sequence'])is None
   assert len(db['counts'])==19 and all(type(v)is int and v==0 for v in db['counts'].values())and not db['grants']
   m.save(p/'pending-db.json',db)
   try:f['client'].call('approvals.finalize',{'proposal_id':f['proposal']['id']})
   except ValueError as e:assert'never a Grant'in str(e)
   else:raise AssertionError('Host crossed Grant approval boundary')
  state=json.loads((p/'bootstrap-state.json').read_text());cleanup=json.loads((p/'daemon-cleanup.json').read_text())
  assert state['status']=='completed'and state['cleanup_ok']is True and cleanup['returncode']==0
  assert cleanup['group_quiescent_before_reaping']and not cleanup['errors']and not any(s['signal']=='SIGKILL'for s in cleanup['signals'])
  for name in ['root','runtime']:assert state['paths'][name]['mode']==0o700 and state['paths'][name]['uid']==os.geteuid()
  for name in ['stdout','stderr']:assert state[name]['mode']==0o600
  rows.append({'name':name,'output':str(p.relative_to(D)),'state':state,'cleanup':cleanup})
  return state
positive('normal')
with tempfile.TemporaryDirectory(prefix='or-')as parent:
 parent=Path(parent).resolve();real=parent/'real';real.mkdir(mode=0o700);alias=parent/'alias';alias.symlink_to(real,target_is_directory=True)
 p=output('raw-alias');runtime=real/'runtime';runtime.mkdir(mode=0o700)
 env={**os.environ,'BATON_RUNTIME_DIR':str(alias/'runtime')}
 with (p/'stdout.log').open('wb')as out,(p/'stderr.log').open('wb')as err:
  child=subprocess.Popen([str(binary)],env=env,start_new_session=True,stdout=out,stderr=err)
  try:
   deadline=time.monotonic()+3
   while not m.exited_without_reaping(child):assert time.monotonic()<deadline;time.sleep(.02)
   cleanup=m.stop_owned(child,'daemon')
  finally:
   if child.returncode is None:m.stop_owned(child,'daemon')
 assert cleanup['returncode']==1 and not cleanup['ok']and not cleanup['signals']
 assert b'Runtime paths must not contain symbolic links'in(p/'stderr.log').read_bytes()
 m.save(p/'observation.json',{'raw_runtime':str(alias/'runtime'),'canonical_runtime':str(runtime),'cleanup':cleanup,'historical_causality':'not established'})
 rows.append({'name':'raw-alias-refusal','output':str(p.relative_to(D)),'cleanup':cleanup})
 state=positive('canonical-alias',alias)
 assert not state['paths']['private_short_fallback']and'/alias/'in state['paths']['requested_root']and'/alias/'not in state['paths']['root']['path']
 # 40 CJK characters exceed the byte cap without a comparably long character count.
 long=parent/('长'*40);long.mkdir(mode=0o700)
 state=positive('unicode-long-parent',long)
 assert state['paths']['initial_socket_utf8_bytes']>103 and state['paths']['private_short_fallback']
 assert state['paths']['socket']['utf8_bytes']<=103
 for code in [0,23]:
  p=output('exit-'+str(code));exe=parent/('exit-'+str(code));exe.write_text(f'#!/bin/sh\nprintf "own stdout marker\\n"\nprintf "own stderr marker\\n" >&2\nexit {code}\n');exe.chmod(0o700)
  try:
   with m.bootstrap(exe,p):raise AssertionError('Exited daemon became ready')
  except RuntimeError as error:assert str(error)=='Fixture daemon exited before readiness'
  state=json.loads((p/'bootstrap-state.json').read_text());cleanup=json.loads((p/'daemon-cleanup.json').read_text())
  assert state['status']=='failed'and state['original_failure']['message']=='Fixture daemon exited before readiness'
  assert state['daemon_exitcode']==code and state['cleanup_ok']is False and cleanup['signals']==[]
  assert(p/'daemon-stderr.log').read_bytes()==b'own stderr marker\n'and(p/'daemon-stdout.log').read_bytes()==b'own stdout marker\n'
  assert json.loads((p/'core-bootstrap-transcript.json').read_text())==[]
  rows.append({'name':'exit-'+str(code),'output':str(p.relative_to(D)),'state':state,'cleanup':cleanup})
report={'status':'passed','controls':rows,'control_count':len(rows),'dimension':'independent retained Linux pre-OS bootstrap controls, not additional unique unittest cases, Mac or historical causality','daemon_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
m.save(A/'report.json',report)
print(json.dumps({'status':'passed','count':len(rows),'positive_exit_codes':[r['cleanup']['returncode']for r in rows if r['cleanup']['ok']],'historical_ARM_cause':'UNKNOWN'}))
