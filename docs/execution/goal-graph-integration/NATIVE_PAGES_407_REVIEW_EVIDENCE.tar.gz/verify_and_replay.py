from pathlib import Path
import json,hashlib,subprocess,importlib.util,re
r=Path(__file__).parent;ev=r/'evidence';ev.mkdir(exist_ok=True);repo=Path('/workspace/.worktrees/native-review-presentation');rev='407ab9e7b014a1af81e39bf90ffac5034708285f';base='87ec9ad8647b549311fc90077e9757bc257c4b70';sha=lambda b:hashlib.sha256(b).hexdigest()
for x in json.loads((r/'manifest.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{rev}:{x["path"]}'],cwd=repo);assert b==(r/'source'/x['path']).read_bytes();assert sha(b)==x['sha256']
a=Path('/workspace/.onboarding/native-review-presentation');manifest=(a/'BIDI12_MANIFEST.json').read_bytes();assert sha(manifest)=='698b08a023d654f83c0052fbd72388fd741363b361f29464df662b48d12e5867';m=json.loads(manifest);(ev/'BIDI12_MANIFEST.json').write_bytes(manifest)
for row in [m['verification'][0],m['preserved_new_failure']]:
 b=(a/row['log']).read_bytes();assert sha(b)==row['sha256'];(ev/row['log']).write_bytes(b)
sm=(a/'BIDI12_SOURCE_MAP.json').read_bytes();(ev/'BIDI12_SOURCE_MAP.json').write_bytes(sm);checks=[]
for p,h in json.loads(sm).items():
 b=subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo);assert sha(b)==h,p;checks.append({'path':p,'sha256':h,'fixed_git_match':True})
for p,h in m['allowed_changed_source_sha256'].items():assert sha((r/'source'/p).read_bytes())==h
# Compare complete production portions, excluding only the explicitly added bidi condition/tests.
p='apps/desktop/src-tauri/src/native_parent.rs';old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();new=(r/'source'/p).read_text();new=re.sub(r'    #\[test\]\n    fn all_twelve_unicode_bidi_controls_are_visible_escaped_and_lossless\(\) \{.*?\n    }\n','',new,flags=re.S);assert new.replace("if ch == '\\u{061c}'\n            || ch == '\\x7f'","if ch == '\\x7f'")==old
p='scripts/native-owner-dialog-smoke.py';old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo);new=(r/'source'/p).read_text();assert new.replace('code in (127, 0x061c)','code == 127').encode()==old;(ev/'old-runner.py').write_bytes(old)
p='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';oldtest=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newtest=(r/'source'/p).read_text();newtest=re.sub(r'    def test_all_twelve_unicode_bidi_controls_are_visible_escaped_and_lossless\(self\):.*?(?=    def test_canonical_json)', '',newtest,flags=re.S);assert newtest==oldtest
oldr=Path('/workspace/AgentBaton/.onboarding/native-presentation-87ec-review')
for n in ['REVIEW.md','REVIEW_MANIFEST.json','boundary.stderr']:(ev/('old87-'+n)).write_bytes((oldr/n).read_bytes())
assert sha((oldr/'REVIEW.md').read_bytes())=='fdf12232867ae5984ce87433ef80126a1e547e8fb2bfec9ac1363656a4302818';assert sha((oldr/'REVIEW_MANIFEST.json').read_bytes())=='4ff7c53ee91b0bf7020b11f04e127dc44b675e99a48f4e984641cde748b571b4'
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
before=load('before87',ev/'old-runner.py');after=load('after407',r/'source/scripts/native-owner-dialog-smoke.py');x='recipient: abc\u061c123';replay=[]
for name,runner in [('old87',before),('new407',after)]:
 pages=runner.presentation_prompts(x);decoded=''.join(json.loads(line.split(' ',1)[1]) for page in pages[:-1] for line in page.splitlines() if line.startswith('L'));replay.append({'revision':name,'raw_u061c':any('\u061c' in p for p in pages),'visible_u061c_escape':any('\\u061c' in p for p in pages),'roundtrip_utf8_exact':decoded.encode()==x.encode()})
assert replay[0]['raw_u061c'] and not replay[0]['visible_u061c_escape'];assert not replay[1]['raw_u061c'] and replay[1]['visible_u061c_escape'];assert all(x['roundtrip_utf8_exact'] for x in replay)
out={'revision':rev,'baseline':base,'author_manifest_sha256':sha(manifest),'source_checks':checks,'source_delta':'3 source files only; four87-era docs also present in cumulative diff; no other production changes','original_presentation_and_tests_preserved_except_bidi_condition_and_added_tests':True,'old_report_hashes_unchanged':True,'replay':replay,'independent_daemon_or_cargo_execution':False,'author_twenty_tests':'20 PASS6.124s; existing19+one12-subcase test; not20newtests; original syntax error retained','rust_or_new_macos_execution_by_reviewer':False}
(r/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified104 author source bindings;3-file narrow source delta;old87reports immutable;original U061C reproducer old=raw/new=escaped,both exactbytes.')
