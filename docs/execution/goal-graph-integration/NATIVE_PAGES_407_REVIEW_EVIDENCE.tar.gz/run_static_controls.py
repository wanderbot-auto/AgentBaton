from pathlib import Path
import importlib.util,unittest,json,hashlib,random,unicodedata
r=Path(__file__).parent;p=r/'source/apps/desktop/src-tauri/tests/test_native_owner_dialog.py'
spec=importlib.util.spec_from_file_location('review_native_tests',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
res=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(m.PresentationControls))
assert res.wasSuccessful()
runner=m.runner
rng=random.Random(8701)
chars=['a','中','文','🔒','🧪',' ','\t','\n','\0','\r','"','\\','\u061c','\u202e','\u2066','\x85','\ufeff','é','\u0301']
cases=[''.join(chr(i) for i in range(160)),''.join(chr(i) for i in [0x61c,0x200e,0x200f,*range(0x202a,0x202f),*range(0x2066,0x206a)])]
cases += [''.join(rng.choice(chars) for _ in range(n)) for n in [0,1,7,39,40,41,300,1300,4096]]
summary=[]
for x in cases:
 pages=runner.presentation_prompts(x);rows=[line for p in pages[:-1] for line in p.splitlines() if line.startswith('L')]
 restored=''.join(json.loads(line.split(' ',1)[1]) for line in rows)
 assert restored.encode()==x.encode()
 assert all(len(json.loads(line.split(' ',1)[1]).encode())<=40 for line in rows)
 assert all(len(line.split(' ',1)[1][1:-1].encode())<=40 for line in rows)
 assert all(p.splitlines() and len(p.splitlines())<=12 and len(p.encode())<1024 for p in pages)
 summary.append({'bytes':len(x.encode()),'sha256':hashlib.sha256(x.encode()).hexdigest(),'pages':len(pages),'roundtrip':True})
(r/'independent-controls.json').write_text(json.dumps({'python_presentation_unittests':res.testsRun,'extra_vectors':summary,'daemon_executed':False,'rust_executed':False},indent=2)+'\n')
print('Extra deterministic roundtrip/UTF8 row/page bound vectors:',len(cases))
