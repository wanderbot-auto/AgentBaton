from pathlib import Path
import importlib.util,json,unittest,sys
r=Path(__file__).parent;spec=importlib.util.spec_from_file_location('boundary_runner',r/'source/scripts/native-owner-dialog-smoke.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class BoundaryControls(unittest.TestCase):
 def test_line_and_paragraph_separator_are_visible_escapes_and_roundtrip(self):
  for ch in ['\u2028','\u2029']:
   x='left'+ch+'right';pages=m.presentation_prompts(x)
   self.assertFalse(any(ch in p for p in pages));self.assertTrue(any(f'\\u{ord(ch):04x}' in p for p in pages))
   self.assertEqual(''.join(json.loads(line.split(' ',1)[1]) for p in pages[:-1] for line in p.splitlines() if line.startswith('L')),x)
 def test_all_twelve_bidi_controls_are_visible_escapes(self):
  chars=[0x61c,0x200e,0x200f,*range(0x202a,0x202f),*range(0x2066,0x206a)]
  self.assertEqual(len(chars),12)
  for cp in chars:
   with self.subTest(codepoint=f'U+{cp:04X}'):
    pages=m.presentation_prompts('recipient: abc'+chr(cp)+'123')
    self.assertFalse(any(chr(cp) in p for p in pages),'Bidi control remains raw in displayed JSON rows')
if __name__=='__main__':unittest.main(verbosity=2)
