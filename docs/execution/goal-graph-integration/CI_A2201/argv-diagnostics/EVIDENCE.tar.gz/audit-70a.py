from pathlib import Path
import json,hashlib
O=Path(__file__).parent;D=O/'author-70a-single-run';b=json.loads((D/'before.json').read_text());r=json.loads((D/'result.json').read_text());p=json.loads((D/'evidence/report.json').read_text());H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert r['exitcode']==0 and r['inputs_unchanged'] is True and r['source_commit']==b['source_commit']=='a2a401e3f2b7de95e9bddcd688bcc4ef1578f9d1';assert H(D/'runner.log')==r['runner_log_sha256'];assert p['status']=='passed' and len(p['checks'])==5 and len(p['screenshots'])==1 and p['harness_sha256']==H(O/'source.py');assert p['daemon_sha256']=='40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd';assert p['candidate']['git_head']=='70a48d41663108337529915358109026e98ddf98'
checks=[]
for name,h in b['inputs'].items():
 f=Path(name)
 with f.open('rb')as s:actual=hashlib.file_digest(s,'sha256').hexdigest()
 assert actual==h;checks.append({'path':name,'sha256':actual})
for i in p['cleanup']:
 if 'thread_alive'in i:assert i['thread_alive']is False
 if 'active_handlers'in i:assert i['active_handlers']==[]
 if 'wait_exitcode'in i:assert i['wait_exitcode']==0 and i['forced_sigkill']is False and i['process_not_alive']is True
 if 'original_process_not_alive'in i:assert i['original_process_not_alive']is True and i['signal_sent']is False
shot=p['screenshots'][0];assert H(D/'evidence'/Path(shot['path']).name)==shot['sha256']
obs=p['observations'];proof=obs['real_validator'];print('VALIDATORkeys',list(proof));print('BUDGETS',obs['observed_budgets']);print('command',obs['owned_command_child']);print('proof',json.dumps(proof)[:1800])
(O/'70a-audit.json').write_text(json.dumps({'report_sha256':H(D/'evidence/report.json'),'runner_log_sha256':H(D/'runner.log'),'source':p['harness_sha256'],'daemon':p['daemon_sha256'],'candidate':p['candidate']['git_head'],'checks':5,'PNGs':1,'current_original_inputs_rehashed':checks,'cleanup_all_gone_thread_handlers_join_daemon0_noForcedKill':True,'no_reproduction_of_original_failure':True,'NOT_exact_a220_CI':'different daemon SHA/candidate/frontend inputs; no promotion of original failure to passed','screenshot_hash_checked_not_viewed':shot['sha256']},indent=2)+'\n');print('PASS actual author70a single run/source/inputs/cleanup evidence; no reviewer runtime')
