import types,sys,io,json,hashlib,os
from pathlib import Path
from unittest.mock import patch
O=Path(__file__).parent;P=O/'source.py';sys.dont_write_bytecode=True;m=types.ModuleType('independent_diagnostic_subject');m.__file__=str(P);sys.modules[m.__name__]=m;exec(compile(P.read_bytes(),str(P),'exec'),m.__dict__);rows=[];parent=211111;child=222222
class Scan:
 def __enter__(self):return iter([types.SimpleNamespace(name=str(child))])
 def __exit__(self,*_):pass
def scan(path):
 if str(path)=='/proc':return Scan()
 return type('EmptyScan', (), {'__enter__': lambda self: iter([]), '__exit__': lambda self,*args: None})()
for label,raw,diagfail,foreign,drift in [('empty',b'',False,False,False),('over-cap',b'RAW_SECRET_VALUE'+b'x'*1010,False,False,False),('missing-NUL',b'RAW_SECRET_VALUE',False,False,False),('secondary-diagnostic-error',b'',True,False,False),('foreign-parent-never-read',b'',False,True,False),('identity-drift-never-accepted',b'/usr/bin/sleep\x003\x00',False,False,True)]:
 samples=[];readcalls=[];calls=0
 def ident(pid):
  global calls
  if pid==parent:return {'pid':parent,'parent_pid':1,'start_ticks':'10','state':'S'}
  assert pid==child;calls+=1
  if calls==3 and diagfail:raise PermissionError('SECRET secondary diagnostic text must not escape')
  return {'pid':child,'parent_pid':parent,'start_ticks':'changed'if drift and calls==2 else'start-20','state':'S'}
 def fileopen(path,*a,**k):
  assert str(path)==f'/proc/{child}/cmdline';readcalls.append(str(path));return io.BytesIO(raw)
 try:
  with patch.object(m.os,'scandir',scan),patch.object(m,'proc_identity',ident),patch.object(m,'proc_parent_pid',return_value=parent+1 if foreign else parent),patch.object(m.Path,'open',fileopen),patch.object(m.os,'getpgid',return_value=child):result=m.owned_command_child(parent,samples)
 except AssertionError as e:
  assert not foreign and not drift and str(e)=='Complete bounded private argv required';v=samples[-1]['failing_private_child_observation'];assert v['raw_len']==len(raw[:1025])and v['raw_sha256']==hashlib.sha256(raw[:1025]).hexdigest()and v['trailing_nul']==raw[:1025].endswith(b'\0')and v['before']['pid']==child;assert 'RAW_SECRET_VALUE'not in json.dumps(samples)
  if diagfail:assert v['after_failure']=={'diagnostic_error':'PermissionError'}and 'SECRET secondary'not in json.dumps(samples)
 else:
  assert result is None and (foreign or drift)
  if foreign:assert readcalls==[] and samples[-1]['private_child_observations']==[]
  if drift:assert len(readcalls)==1 and samples[-1]['private_child_observations'][0]['after_read']['start_ticks']=='changed'
 rows.append({'name':label,'status':'passed','dimension':'synthetic private proc identities/read stream; not actual process or CIcause'})
(O/'first-cause-controls.json').write_text(json.dumps({'subject_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'count':len(rows),'checks':rows},indent=2)+'\n');print('PASS',len(rows),'independent first-cause/metadata confidentiality/identity controls')
