import subprocess,json,os
from pathlib import Path
O=Path(__file__).parent;env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[]
for name,args in [('own13',['python3',str(O/'author-controls/controls.py')]),('guard4',['python3',str(O/'author-controls/guard_controls.py')]),('short6',['python3',str(O/'lifecycle-controls/controls.py')]),('padded7',['python3',str(O/'lifecycle-controls/controls.py'),'--padded','X'*1600])]:
 p=subprocess.run(args,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':args,'exitcode':p.returncode});assert p.returncode==0,(name,p.stderr)
(O/'control-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS independent executions of13+4+6+7 own/injected controls, no Core/browser')
