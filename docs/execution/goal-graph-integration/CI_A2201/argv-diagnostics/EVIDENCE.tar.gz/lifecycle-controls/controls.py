#!/usr/bin/env python3
"""Real own fork/pre-exec/exec; synthetic empty read is a negative only."""
import hashlib,importlib.util,io,json,os,signal,sys
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).parent;P=D.parent/'author-controls/source.py'
spec=importlib.util.spec_from_file_location('life_subject',P);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
rows=[]
def check(name,value):
 assert value,name;rows.append({'name':name,'status':'passed'})
ready_r,ready_w=os.pipe2(os.O_CLOEXEC);release_r,release_w=os.pipe2(os.O_CLOEXEC)
pid=os.fork()
if pid==0:
 try:
  os.close(ready_r);os.close(release_w);os.setpgid(0,0);os.write(ready_w,b'R');assert os.read(release_r,1)==b'X'
  os.execv('/usr/bin/sleep',['/usr/bin/sleep','3'])
 finally:os._exit(3)
os.close(ready_w);os.close(release_r);snapshots=[];padded='--padded'in sys.argv
try:
 assert os.read(ready_r,1)==b'R'
 before=m.proc_identity(pid);check('preexec own child exact PPID/start/group live',before['parent_pid']==os.getpid()and before['state']not in('Z','X')and os.getpgid(pid)==pid)
 samples=[]
 try:found=m.owned_command_child(os.getpid(),samples)
 except AssertionError as error:
  check('oversized inherited preexec argv still strictly rejected',padded and str(error)=='Complete bounded private argv required')
  item=samples[-1]['failing_private_child_observation'];check('actual failing PID/rawcap/NUL/digest/prepost are retained',item['pid']==pid and item['raw_len']==1025 and item['trailing_nul']is False and item['before']==before and item['after_read']['start_ticks']==before['start_ticks']and len(item['raw_sha256'])==64)
 else:check('unrelated short preexec argv is not accepted as approved sleep',not padded and found is None)
 snapshots.append({'phase':'actual own preexec','samples':samples})
 original=m.Path.open
 def empty_only_own(path,*args,**kwargs):
  if str(path)==f'/proc/{pid}/cmdline':return io.BytesIO(b'')
  return original(path,*args,**kwargs)
 samples=[]
 with patch.object(m.Path,'open',empty_only_own):
  try:m.owned_command_child(os.getpid(),samples)
  except AssertionError as error:check('synthetic empty own read remains hard failure',str(error)=='Complete bounded private argv required')
  else:raise AssertionError('empty argv accepted')
 item=samples[-1]['failing_private_child_observation'];check('empty-read negative records exactzero/NULfalse/SHA without rawbytes',item['pid']==pid and item['raw_len']==0 and item['trailing_nul']is False and item['raw_sha256']==hashlib.sha256(b'').hexdigest())
 snapshots.append({'phase':'explicit synthetic empty-read negative, not observed OS race','samples':samples})
 os.write(release_w,b'X');os.close(release_w);release_w=None
 assert os.read(ready_r,1)==b''  # CLOEXEC handshake, not a sleep or timing guess.
 samples=[];found=m.owned_command_child(os.getpid(),samples)
 check('same own child accepted only after realexec exactsleep3',found is not None and found['pid']==pid and found['start_ticks']==before['start_ticks']and found['parent_pid']==os.getpid()and found['pgid']==pid and found['argv']==['/usr/bin/sleep','3'])
 snapshots.append({'phase':'actual own execsleep3','samples':samples})
finally:
 current=m.proc_identity(pid);assert current['start_ticks']==before['start_ticks']and current['parent_pid']==os.getpid()
 os.kill(pid,signal.SIGTERM);waited,status=os.waitpid(pid,0);assert waited==pid
 if release_w is not None:os.close(release_w)
 os.close(ready_r)
 check('only own child signaled waited and originalidentity absent',not Path(f'/proc/{pid}').exists())
(D/('padded.json'if padded else'short.json')).write_text(json.dumps({'status':'passed','count':len(rows),'checks':rows,'subject_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'samples':snapshots,'scope':'real own preexec/exec+explicit synthetic emptyread negative; NOT CIcause/Core/browser','CI_rootcause':'unproven; real70a singlecase did not reproduce'},indent=2)+'\n')
print('PASS',len(rows),'own lifecycle controls', 'padded'if padded else'short')
