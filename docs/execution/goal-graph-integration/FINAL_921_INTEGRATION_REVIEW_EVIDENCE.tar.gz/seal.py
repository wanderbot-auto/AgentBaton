from pathlib import Path
import json, hashlib, datetime, tarfile

p = Path(__file__).resolve().parent
static = {n: json.loads((p / (n + '-result.json')).read_text()) for n in ['bootstrap', 'design', 'infrastructure', 'diff']}
static['design_fixed_index'] = json.loads((p / 'design-with-fixed-index-result.json').read_text())
assert all(static[n]['exit_code'] == 0 for n in ['bootstrap', 'infrastructure', 'diff'])
assert static['design']['exit_code'] == 1 and static['design_fixed_index']['exit_code'] == 0
(p / 'STATIC_RESULTS.json').write_text(json.dumps({'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'final_checks_passed': 4, 'initial_design_export_metadata_failure_preserved': True, 'results': static, 'no_product_tests_executed_by_reviewer': True}, indent=2) + '\n')
files = []
for f in sorted(p.iterdir()):
    if f.is_file() and f.name not in ['MANIFEST.json', 'REVIEW_EVIDENCE.tar.gz', 'REVIEW_EVIDENCE_IMPORT.json']:
        b = f.read_bytes()
        files.append({'path': f.name, 'bytes': len(b), 'mode': oct(f.stat().st_mode & 0o777), 'sha256': hashlib.sha256(b).hexdigest()})
snap = json.loads((p / 'GIT_SNAPSHOT.json').read_text())
inventory = json.loads((p / 'ARCHIVE_INVENTORY.json').read_text())
manifest = {
    'schema': 1, 'sealed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review': 'REVIEW.md', 'fixed_source': '92120ed4f613522422c7cf0da3de55cf2c3afb56',
    'tree': snap['tree'], 'baseline': 'fb7ff7d861872eec18e010f7b64a0ead63740faa',
    'disposition': 'no must-fix within fixed source/composition/records scope; source-ready for Root next exact CI, not formal approval or merge clearance',
    'must_fix_findings': [],
    'complete_Git_snapshot': {'manifest': 'GIT_SNAPSHOT.json', 'blobs': snap['files'], 'bytes': snap['bytes'], 'mode_counts': snap['mode_counts'], 'all_Git_blob_SHA1_and_SHA256_verified': True, 'all_after_hash_size_mode_unchanged': True},
    'product_source_delta': {'exact_files': 5, 'workflow': '65f7fd26bec8a88307178a69381389de6188efaa', 'Native_Rust': '655c6d2985dd8d2d0dcfa16864d12edf2dfca374 (byte-identical Root10 fbfd)', 'Python': '655c6d2985dd8d2d0dcfa16864d12edf2dfca374', 'remaining_non_document_blobs_unchanged': 297},
    'new_archives': {'count': len(inventory['records']), 'all_member_modes_sizes_hashes': 'ARCHIVE_INVENTORY.json', 'original_Mac_regular_members': 298, 'original_Linux_regular_members': 135, 'payload_manifest_references_verified': 1352, 'unresolved': 0, 'nested_ZIPs': 4, 'CRC_digest_modes_sizes_hashes_safe_paths': 'passed'},
    'fresh_static_checks': {'bootstrap93': 0, 'design130_14WP_27answers_after_private_fixedindex': 0, 'infrastructure': 0, 'diff': 0, 'initial_design_no_Git_export': 1},
    'old_SourceBound_runtime_evidence_not_rerun': {'Root_Linux_Owner': 10, 'fmt_Clippy': 0, 'author_Python': 29, 'independent_Python': 29, 'same_unique_cases': 29, 'Root_restoration': 'then-recorded1ee/fec7 inode/nlink restored; fc5/906 macro resources only; no current shared tools inspected'},
    'requirements': {'IDs': 130, 'unchanged_statuses': {'implementing': 93, 'not_started': 37}, 'all_workpackages_preserved': True, 'SEC003_native_presentation_support_not_credential_expiry': True},
    'new_exact_CI_Mac_Owner_defaultrelease_audit_current_installers': 'not_run',
    'historical_failures_and_limited_P2_open_to_closed_stages': 'preserved',
    'Cargo_browser_Provider_remote_CI_or_authority_mutations_by_reviewer': False,
    'formal_approval': False, 'files': files,
}
(p / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
# Portable review metadata only. Fixed source/archive payloads already live in
# Git; complete source/member hashes are in included inventories.
package = p / 'REVIEW_EVIDENCE.tar.gz'
selected = [p / e['path'] for e in files] + [p / 'MANIFEST.json']
with tarfile.open(package, 'w:gz', format=tarfile.PAX_FORMAT) as archive:
    for f in selected:
        archive.add(f, arcname=f.name, recursive=False)
with tarfile.open(package, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(selected)
    for member in members:
        assert member.isfile() and member.name == Path(member.name).name
        assert archive.extractfile(member).read() == (p / member.name).read_bytes()
info = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'archive': package.name, 'sha256': hashlib.sha256(package.read_bytes()).hexdigest(), 'bytes': package.stat().st_size, 'regular_members': len(selected), 'all_payloads_roundtrip_verified': True, 'scope': 'compact review metadata/static stdout/stderr/fullGitblobhash snapshot/archive inventories; no duplicate150MB fixed Git export or extracted history'}
(p / 'REVIEW_EVIDENCE_IMPORT.json').write_text(json.dumps(info, indent=2) + '\n')
for name in ['REVIEW.md', 'MANIFEST.json', 'GIT_SNAPSHOT.json', 'REVIEW_EVIDENCE.tar.gz', 'REVIEW_EVIDENCE_IMPORT.json']:
    data = (p / name).read_bytes()
    print(name, hashlib.sha256(data).hexdigest(), len(data))
print('archive members', len(selected))
