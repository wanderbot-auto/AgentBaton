# Independent fixed-source Native Grant contract review — fbfd66e

**Disposition: one open P2 (NG-FBFD-01).** The correction accurately recognizes Core's independent opaque Grant approval ID and retains the real OS/page/DB gates. Independent fixed-source Python24 passes, including actual generated Core fixtures. However, the new host cross-record/payload equality still accepts boolean/integer JSON type substitution. This report does not approve integration as a complete exact-record check, or certify a new Mac run.

Source `fbfd66e0bac5f167592adf9bc75a5e6c70a0655a`, baseline `fb7ff7d861872eec18e010f7b64a0ead63740faa`. Four changed files are exported from fixed Git, with four unchanged supporting files. No moving author source was used. Factory CI work was paused first and remains separately checkpointed; no production, permission, schema, CI, Cargo, STATUS, remote or author source was changed by this review.

## NG-FBFD-01 — P2: cross-record equality loses JSON type identity

Paths: `scripts/native-owner-dialog-smoke.py:150` (proposal_result/response versus persisted Grant) and `:175–179` (full Grant event payload); associated helper fixture `approved()` in the test file.

Python dictionary/list equality treats `True == 1` and `False == 0`. The predicate adds explicit types for the persisted Grant's limits/enforcement, but uses ordinary equality to compare the separately parsed response, stored proposal result and event payload to that Grant.

Independent controlled reproduction uses the existing positive fixture, **JSON-serializes/parses it to break shared object aliases**, matching `database()`'s independent parsing of rows/event documents and the separately parsed IPC response. Only one field in one record is changed at a time:

1. `event.payload.scope.max_attempts = True` instead of1.
2. `event.payload.enforcement.baton_mediated_scope = 1` instead oftrue.
3. `response.result.scope.max_attempts = True` instead of1.
4. `proposal_result.scope.max_attempts = True` instead of1.

All four return `None` (accepted) on fixed fbfd. The new independent unittest runs one test with four subcases and fails all four, **exit1 / failures4**, in `typed-negative.stderr`. `typed_record_negative.py` and `typed-tamper-observation.json` preserve the exact reproduction without Core/browser execution. The initial aliased-fixture observation is also retained: deepcopy preserves alias relationships inside the synthetic fixture, so changing a nested event can also change the Grant and hit its explicit type guard. That is not the real independent-record shape and is not used as the final counterexample.

Impact is limited to the test host's claim of exact complete evidence association. It is not evidence of production authority escalation or a real Core writing these malformed types; the Rust controller's typed JSON comparisons are separate. Still, this change specifically claims complete response/proposal_result/Grant/event binding and needs to distinguish their JSON types.

Required repair: use a small type-sensitive JSON comparison for these related full records/payloads and other compared JSON binding domains, with independent JSON-parsed-record regression cases. Preserve the existing scope/CAS/event/zero-count requirements; do not coerce/normalize numeric booleans or replace comparisons with partial fields. The author acknowledged the gap; any fix needs a new fixed revision and narrow re-review. This fbfd report remains open and immutable.

## Correct contract and preserved boundaries

Fixed Core `policy.rs:803–818` creates the root Grant ID and a separate `Uuid::new_v4()` approval ID. `sessions.rs:1876–1906` returns that actual Grant, stores the exact result in the original Owner proposal, consumes/increments the proposal and emits `approval.confirmed` for **the proposal ID**. The Grant-approved event separately carries its own Grant approval ID. No equality or inequality between the two opaque roles is an authority rule.

The new Rust controller validates a nonempty bounded (512 UTF-8 byte) opaque Grant/result identity, root shape, original project, exact scope, enforcement and resolved workspace/connection bindings. macOS calls that test-driver response validator after genuine OS buttons instead of the incorrect approval_id==proposal_id condition. Production Core, Native parent, formatter, public authority and permissions are unchanged.

The host now requires one persisted Grant, consumed proposal/CAS and baseline+2 sequence, matching response/result/Grant records, complete expected scope/enforcement/bindings, one matching full `execution_grant.approved` event atbaseline+1, and one original-proposal confirmation atbaseline+2. Those are the correct associations, subject to NG-FBFD-01's JSON type gap. Opaque strings are bounded rather than forced to a guessed ID format or invented inequality.

Mechanical preservation was independently checked against fixed Git:

- All original **20 Python test ASTs are unchanged**; the fixture is corrected and one actual-Core plus three contract tests are added.
- `NativeCoreClient`, pending guard, production message formatter reader and complete host `run` ASTs are unchanged. The host bootstrap still cannot finalize a target Grant or make arbitrary mutation calls. The added actual-Core test explicitly performs a private generated Owner fixture outside HTTP; it does not change bootstrap or shipping authority.
- Apart from the one response condition, macOS source is byte-identical. Original parent/window/page ordering,24 total page sets, exact full text/cell/on-screen requirements, actual captures/buttons, per-page DB permits, late Final Cancel and no-finalize denial are retained.
- The controller's existing exact page-validation function is byte-identical. No scope, refs, CAS, original19 zero counters,500ms stability,4s capture,75s watchdog or85s host limit is removed or enlarged.

## Actual verification and provenance

After Root granted a short execution window, this reviewer independently ran the **complete fixed24 Python tests: PASS24 /6.838s**. This includes the original three actual generated Core bootstrap/SQLite cases and the new actual Core Grant contract case. Exact argv/cwd/time/exit and raw stdout/stderr are saved. The stdout retains the new real proposal, persisted result, response and event records. These are generated local fixtures, not actual macOS or human approvals.

The explicitly selected frozen `batond` is SHA **`40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd`**, rehashed unchanged before/after. The relevant Core policy/session files match the baseline and the author's source binding to that frozen candidate. The test window ended and was returned to Core immediately. No Cargo/browser/real Provider or private account operation occurred.

Independent source/evidence verification exited0: all eight exported files, **104 author source-map entries**, seven author log/metadata hashes and the original six Mac packet copies match fixed Git/original evidence. Fixed-range diff check exits0. Exact commands and raw output are retained separately. This source/hash replay is not another product execution.

Author stage records are distinguished:

- `final-python24.log`:24PASS7.309s for the exact fixed source; not added to this reviewer's24 as48 unique cases.
- `old-real-core-contract.log`: the newly added actual-Core case **fails once** on the old predicate,0.743s. This is an earlier WIP test against the old association, not a full old-source suite.
- `first-fixed-python.log`:21PASS before three additional negative tests.
- Original two Mac packet replay: old predicate rejects; new fbfd predicate accepts both saved packets offline.

Root's separate safe Native compilation log records **10 Owner pure Rust tests passed**, formatting0 and all-target Clippy `-D warnings`0. All four source hashes match this fixed export and command-log hashes verify; source before/after equality is recorded. The Root BEFORE/RESULT/run/logs are copied. This is Root-executed **Linux pure controller/lint evidence**, not independent Cargo execution by this reviewer or new AppKit execution. Author's original Rust NOT_RUN manifest entry is historical, before that Root run.

## Original Mac evidence and limits

The original desktop review remains sealed at `/workspace/.onboarding/pr16-fb7-mac-review`. The six original arm/intel `after.json`, `approve-reply.json`, `fixture.json` copies were byte-compared with those originals. In each, baseline8→after10, one Grant and original19 zero counters remain; response/result/Grant agree and Grant approval_id differs from proposal ID in the observed actual output. The new predicate accepts these original valid packets offline. Their old rejection is genuine evidence of the mistaken association, not permission to rewrite failed CI green.

The sealed desktop review records actual11 content pages +Final for each Cancel/approve phase (24 sets per architecture), all exact refs/cell/visibility/permit checks, real late Cancel and final OK effects. Both jobs still failed `Grant response mismatch` and produced no new package. This task reused that sealed review and packet hashes; it did not reopen its48 images or rerun OS interaction. New corrected-source dualMac, release/audit/package and full product acceptance remain NOT_RUN.

The fixed24 suite success, Root10 controller tests, original Mac packet positive replay and the new four-subcase failure all remain separate. NG-FBFD-01 prevents claiming complete typed cross-record closure until fixed and re-reviewed. No Cargo/target, author source, CI, remote, formal Approve or production authority was changed by this reviewer.
