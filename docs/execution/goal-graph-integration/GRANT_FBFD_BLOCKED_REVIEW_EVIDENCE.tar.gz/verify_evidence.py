from pathlib import Path
import json,hashlib,subprocess,ast,importlib.util,sys
R=Path(__file__).parent;A=Path('/workspace/AgentBaton/.onboarding/native-grant-contract');D=Path('/workspace/.onboarding/pr16-fb7-mac-review');C=Path('/workspace/.onboarding/native-grant-contract-root');repo=Path('/workspace/.worktrees/native-grant-contract');rev='fbfd66e0bac5f167592adf9bc75a5e6c70a0655a';base='fb7ff7d861872eec18e010f7b64a0ead63740faa';sha=lambda b:hashlib.sha256(b).hexdigest();E=R/'evidence';E.mkdir(exist_ok=True);out={'revision':rev,'baseline':base,'author_logs':[],'source_checks':[],'original_mac_replay':[],'Root_compilation':{}}
mb=(A/'MANIFEST.json').read_bytes();assert sha(mb)=='496d9f5981224909f0b6e5c3220b7aa01e81abf6e780c35c06d98bba8bfb1732';m=json.loads(mb);(E/'author-MANIFEST.json').write_bytes(mb)
for n,h in m['evidence_sha256'].items():
 b=(A/n).read_bytes();assert sha(b)==h;(E/n).write_bytes(b);out['author_logs'].append({'path':n,'sha256':h})
for p,h in json.loads((A/'SOURCE_MAP.json').read_text()).items():
 b=subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo);assert sha(b)==h;out['source_checks'].append({'path':p,'sha256':h,'fixed_git_match':True})
for row in json.loads((R/'source-manifest.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{rev}:{row["path"]}'],cwd=repo);assert b==(R/'source'/row['path']).read_bytes() and sha(b)==row['sha256']
spec=importlib.util.spec_from_file_location('native_review_guard',R/'source/scripts/native-owner-dialog-smoke.py');runner=importlib.util.module_from_spec(spec);sys.modules[spec.name]=runner;spec.loader.exec_module(runner)
for arch in ['arm','intel']:
 values={}
 for n in ['after.json','approve-reply.json','fixture.json']:
  b=(A/'original'/arch/n).read_bytes();assert b==(D/(arch+'-native-artifact/owner-dialog')/n).read_bytes();p=E/arch/n;p.parent.mkdir(exist_ok=True);p.write_bytes(b);values[n]=json.loads(b)
 fixture=values['fixture.json'];after=values['after.json'];response=values['approve-reply.json'];grant=after['grants'][0];assert runner.approved_error(after,fixture['proposal'],fixture['baseline_sequence'],response) is None;assert grant['approval_id']!=fixture['proposal']['id'];assert after['sequence']==10 and all(v==0 for v in after['counts'].values())
 out['original_mac_replay'].append({'arch':arch,'original_file_hashes':{n:sha((E/arch/n).read_bytes()) for n in values},'baseline_sequence':fixture['baseline_sequence'],'after_sequence':after['sequence'],'original_19_zero_counts':len(after['counts']),'proposal_id':fixture['proposal']['id'],'approval_id':grant['approval_id'],'new_predicate_original_packet_pass':True,'old_predicate_required_equality_false':True,'offline_only_not_new_OS_execution':True})
for n in ['SUMMARY.md','MANIFEST.json']:(E/('desktop-'+n)).write_bytes((D/n).read_bytes())
for n in ['BEFORE.json','RESULT.json','native-0.log','native-1.log','native-2.log','run.py']:(E/('Root-'+n)).write_bytes((C/n).read_bytes())
before=json.loads((C/'BEFORE.json').read_text());result=json.loads((C/'RESULT.json').read_text());assert result['source_before_after_equal'] and not result['changed'];hashes=before['source_hashes']
for p,h in m['changed_four_test_files'].items():assert hashes[p]==h and sha((R/'source'/p).read_bytes())==h
for row in result['commands']:assert row['exit_code']==0 and sha((C/row['log']).read_bytes())==row['sha256']
assert b'test result: ok. 10 passed' in (C/'native-0.log').read_bytes();out['Root_compilation']={'source':result['source'],'integration_head':result['integration_head'],'commands':result['commands'],'source_hashes_match_fixed_four':True,'source_before_after_equal':True,'scope':result['dimension'],'no_reviewer_Cargo':True}
# Original tests, page/control gate and host bootstrap remain intact.
p='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';oldtest=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newtest=(R/'source'/p).read_text()
def testnodes(text):
 return {cl.name+'.'+fn.name:ast.dump(fn,include_attributes=False) for cl in ast.parse(text).body if isinstance(cl,ast.ClassDef) for fn in cl.body if isinstance(fn,ast.FunctionDef) and fn.name.startswith('test_')}
a,b=testnodes(oldtest),testnodes(newtest);assert len(a)==20 and len(b)==24 and all(b[n]==v for n,v in a.items());out['original_20_test_ASTs_unchanged']=True
p='scripts/native-owner-dialog-smoke.py';oldrunner=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newrunner=(R/'source'/p).read_text()
def nodes(text):return {fn.name:ast.dump(fn,include_attributes=False) for fn in ast.parse(text).body if isinstance(fn,(ast.FunctionDef,ast.ClassDef))}
a,b=nodes(oldrunner),nodes(newrunner)
for name in ['NativeCoreClient','pending_error','expected_message','run']:assert a[name]==b[name],name
out['page_host_bootstrap_pending_run_ASTs_unchanged']=True
p='apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs';oldmac=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newmac=(R/'source'/p).read_text();newcondition='        if controller::validate_grant_response(&response, &state.expected).is_err() {';oldcondition='        if response.get("error").is_some()\n            || response["result"]["approval_id"] != state.expected["proposal"]["id"]\n        {';assert newmac.replace(newcondition,oldcondition)==oldmac
p='apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs';oldctrl=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newctrl=(R/'source'/p).read_text();assert oldctrl[oldctrl.index('pub fn validate('):oldctrl.index('#[cfg(test)]')]==newctrl[newctrl.index('pub fn validate('):newctrl.index('#[cfg(test)]')]
out['original_OS_page_capture_permit_timing_logic_unchanged']=True
(R/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified104 source bindings/7author evidence hashes;original6Macpackets exact+offline2pass;Root10tests/fmt/clippylogs0;original20testASTs and page/host/pending/run unchanged. Fixedfbfd P2typedrecordfinding remains open.')
