import fs from 'node:fs';
import { parseSync } from '/workspace/AgentBaton/apps/desktop/node_modules/rolldown/dist/utils-index.mjs';
const before=fs.readFileSync('/workspace/.onboarding/command-ui-ci-stability/baseline-source.tsx','utf8');
const after=fs.readFileSync('/workspace/.worktrees/command-ui-ci-stability/apps/desktop/src/CommandValidation.test.tsx','utf8');
function assertions(source){
 const parsed=parseSync('CommandValidation.test.tsx',source);if(parsed.errors.length)throw Error(JSON.stringify(parsed.errors));
 const result=[];
 function visit(node){
  if(!node||typeof node!=='object')return;
  if(node.type==='CallExpression'){
   let callee=node.callee;
   while(callee.type==='MemberExpression')callee=callee.object;
   if(callee.type==='CallExpression'&&callee.callee.type==='Identifier'&&callee.callee.name==='expect')result.push(source.slice(node.start,node.end));
  }
  for(const [key,value] of Object.entries(node)){
   if(key==='parent')continue;
   if(Array.isArray(value))value.forEach(visit);else if(value&&typeof value==='object')visit(value);
  }
 }
 visit(parsed.program);return result;
}
const original=assertions(before),current=assertions(after),remaining=[...current];
for(const expression of original){const i=remaining.indexOf(expression);if(i===-1)throw Error('Lost assertion: '+expression);remaining.splice(i,1);}
const begin=s=>s.indexOf("  it('folds by default");const end=s=>s.indexOf('  it.each(',begin(s));
if(before.slice(0,begin(before))!==after.slice(0,begin(after)))throw Error('Changed prefix/helper/import');
if(before.slice(end(before))!==after.slice(end(after)))throw Error('Changed another test');
const report={status:'passed',parser:'existing cached rolldown TSX AST; no installation',original_assertions:original.length,current_assertions:current.length,all_original_assertions_preserved:true,extra_assertions:remaining,outside_first_test_bytes_equal:true};
fs.writeFileSync('/workspace/.onboarding/command-ui-ci-stability/final/assertion-audit.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
