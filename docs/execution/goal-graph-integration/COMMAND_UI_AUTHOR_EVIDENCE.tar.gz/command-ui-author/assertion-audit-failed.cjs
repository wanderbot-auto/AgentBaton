const fs=require('fs');
const ts=require('/workspace/AgentBaton/apps/desktop/node_modules/typescript');
const old=fs.readFileSync('/workspace/.onboarding/command-ui-ci-stability/baseline-source.tsx','utf8');
const fresh=fs.readFileSync('/workspace/.worktrees/command-ui-ci-stability/apps/desktop/src/CommandValidation.test.tsx','utf8');
const parse=s=>ts.createSourceFile('CommandValidation.test.tsx',s,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const printer=ts.createPrinter({removeComments:true});
const assertions=source=>{
 const result=[]; const sf=parse(source);
 const visit=node=>{
  if(ts.isCallExpression(node)){
   let callee=node.expression;
   while(ts.isPropertyAccessExpression(callee))callee=callee.expression;
   if(ts.isCallExpression(callee)&&ts.isIdentifier(callee.expression)&&callee.expression.text==='expect')result.push(printer.printNode(ts.EmitHint.Expression,node,sf));
  }
  ts.forEachChild(node,visit);
 };visit(sf);return result;
};
const original=assertions(old),current=assertions(fresh), remaining=[...current];
for(const expression of original){const index=remaining.indexOf(expression);if(index===-1)throw Error('Lost original assertion: '+expression);remaining.splice(index,1);}
const begin=s=>s.indexOf("  it('folds by default"); const end=s=>s.indexOf('  it.each(',begin(s));
if(old.slice(0,begin(old))!==fresh.slice(0,begin(fresh)))throw Error('Changed prefix/helper/import');
if(old.slice(end(old))!==fresh.slice(end(fresh)))throw Error('Changed another test');
const report={status:'passed',dimension:'TypeScript AST assertion preservation and outside-first-test byte comparison',original_assertions:original.length,current_assertions:current.length,all_original_assertions_preserved:true,extra_assertions:remaining,outside_first_test_bytes_equal:true};
fs.writeFileSync('/workspace/.onboarding/command-ui-ci-stability/final/assertion-audit.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
