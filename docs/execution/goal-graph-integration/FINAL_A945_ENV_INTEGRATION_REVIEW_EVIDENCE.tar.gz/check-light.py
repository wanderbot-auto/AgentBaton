from pathlib import Path
import subprocess,json,hashlib,os,datetime,re
O=Path(__file__).parent;R=Path('/workspace/.worktrees/goal-graph-integration');src='a94517ce373e279a29176ab8ab4f210897ea1a9b';rows=[];sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O/'tmp'),npm_config_cache=str(O/'npm-cache'),npm_config_update_notifier='false');(O/'tmp').mkdir(exist_ok=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==src
for tag,argv in [('runtime6',['python3','-B','-m','unittest','discover','-s','tests/infrastructure','-p','test_runtime_policy.py','-v']),('Node4',['npm','test'])]:
 p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=60);(O/(tag+'.stdout')).write_bytes(p.stdout);(O/(tag+'.stderr')).write_bytes(p.stderr);rows.append({'tag':tag,'argv':argv,'cwd':str(R),'source':src,'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert p.returncode==0
 if tag=='runtime6':assert b'Ran 6 tests' in p.stderr and b'\nOK' in p.stderr
 else:
  s=(p.stdout+p.stderr).decode();assert re.search(r'(?:#|ℹ) tests 4',s) and re.search(r'(?:#|ℹ) pass 4',s) and re.search(r'(?:#|ℹ) fail 0',s) and re.search(r'(?:#|ℹ) skipped 0',s)
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b'';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==src
(O/'light-commands.json').write_text(json.dumps({'commands':rows,'tracked_before_after_clean':True,'Rust_executed_by_this_reviewer':False,'fullPython34_this_reviewer':False},indent=2)+'\n');print('PASS actual selected runtime6 + Node4; no Cargo or product run')
# Verify delivery metadata from preserved official API responses, no API acquisition.
B=Path('/workspace/.onboarding/pr16-bb343-review');d=json.loads((R/'docs/execution/goal-graph-integration/CI_BB343_MANIFEST.json').read_bytes());artifacts=json.loads((B/'arm-artifacts-terminal.json').read_bytes())['artifacts'];delivery=[]
for arch,aid in [('arm',12866209525),('intel',12866603973)]:
 a=next(x for x in artifacts if x['id']==aid);z=B/(arch+'-development-artifact.zip');assert z.stat().st_size==a['size_in_bytes'] and 'sha256:'+hashlib.file_digest(z.open('rb'),'sha256').hexdigest()==a['digest'];assert a['workflow_run']['id']==40799957452 and a['workflow_run']['head_sha']=='bb343be5bb0403e995a97441ce16670c03bd0f33';delivery.append({'arch':arch,'artifact':a,'URL':f'https://github.com/wanderbot-auto/AgentBaton/actions/runs/40799957452/artifacts/{aid}'})
for arch in ['arm','intel','linux']:
 p=B/('env-'+arch+'-artifact')/'python-tests.log';b=p.read_bytes();assert b'Ran 34 tests' in b and b'FAILED (failures=2)' in b and b'AssertionError' in b;dest=O/'metadata'/('bb-env-'+arch+'-python-tests.log');dest.write_bytes(b)
(O/'delivery-api-binding.json').write_text(json.dumps({'source':'preserved original arm-artifacts-terminal.json; no API call','delivery':delivery,'old34twoFAIL_all3arch_retained':True},indent=2)+'\n');print('PASS two actual official ZIP/API/URL bindings + original3arch34twoFAIL')
