from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,ast,tarfile,stat,re,datetime
O=Path(__file__).parent;R=Path('/workspace/.worktrees/goal-graph-integration');D=R/'docs/execution/goal-graph-integration';SRC='a94517ce373e279a29176ab8ab4f210897ea1a9b';BASE='bb343be5bb0403e995a97441ce16670c03bd0f33';checks=[];refs=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(n,b):assert b,n;checks.append(n)
def raw(p,rev=SRC):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
def load(p):return json.loads(p.read_bytes())
def hfile(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def copy(p,rel):q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
check('exact current source/clean',subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==SRC and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b'')
delta=subprocess.check_output(['git','diff','--name-only',BASE,SRC],cwd=R,text=True).splitlines();nonmetadata=[x for x in delta if not x.startswith('docs/') and x!='BOOTSTRAP_MANIFEST.json'];check('sole nonmetadata delta actual test',nonmetadata==['tests/infrastructure/test_runtime_policy.py'])
test='tests/infrastructure/test_runtime_policy.py';old=raw(test,BASE);new=raw(test);trans=old.replace(b'test_actual_same_architecture_build_has_a_finite_45_minute_budget',b'test_actual_same_architecture_build_has_a_finite_60_minute_budget').replace(b"self.assertEqual(self.desktop['timeout-minutes'], '45')",b"self.assertEqual(self.desktop['timeout-minutes'], '60')").replace(b"for value in ('46', '120', '0', '-1')",b"for value in ('61', '120', '0', '-1')");check('entire test exactly three approved replacements',trans==new)
for b,label in [(old,'before'),(new,'after')]:
 fs=[x for x in ast.walk(ast.parse(b)) if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')];check(label+' all six test bodies remain',len(fs)==6)
copy(R/test,'after-test.py');(O/'before-test.py').write_bytes(old)
for p in ['.github/workflows/product.yml','.github/workflows/environment-preflight.yml','scripts/validate_infrastructure.py','specs/requirements.json','specs/decisions.json','infra/execution-gate.json']:
 b=raw(p);check(p+' unchanged vsbb',b==raw(p,BASE));refs.append({'path':p,'commit':SRC,'bytes':len(b),'sha256':sha(b)})
baseb=json.loads(raw('BOOTSTRAP_MANIFEST.json',BASE));finalb=json.loads(raw('BOOTSTRAP_MANIFEST.json'));check('bootstrap same93paths only test+STATUS2values changed',len(finalb['files'])==93 and set(baseb['files'])==set(finalb['files']) and {p for p in baseb['files'] if baseb['files'][p]!=finalb['files'][p]}=={test,'docs/execution/STATUS.md'})
for p,digest in finalb['files'].items():check('bootstrap fixed actualblob '+p,sha(raw(p))==digest)
# Fixed source equality extends full local validation chain (including original env Rust2), not just a compile label.
chain=load(Path('/workspace/.onboarding/native-env-policy60-full-chain-review/integration-chain.json'));critical=chain['identical_validation_input_files'];check('21 workflow/test/validator/Rust inputs preserved',len(critical)==21)
for row in critical:
 b=raw(row['path']);check('three precise subjects equivalent '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'] and b==raw(row['path'],'9d11a6d0723144a245994a5e7531c282cc60702e')==raw(row['path'],'3a91bcec76a34f21edf800df16709b5e958b8012'))
refs.extend(critical);copy(Path('/workspace/.onboarding/native-env-policy60-full-chain-review/integration-chain.json'),'metadata/critical-source-chain.json')
for name,expected in [('ENV60_NONRUST_REVIEW.md','9bb690256ce8df28585f06ddc8a944a7c301d9af43baf5845743dc809f2f16cd'),('ENV60_NONRUST_REVIEW_MANIFEST.json','380f5fa59e59c660fbae43cca78952ff7121e105a77efeba409566ba9e536fc5'),('ENV60_FULL_CHAIN_REVIEW.md','c7b4352905cbd9fb3e63760a00efae79016603f0dc054c8599caa6d91fca43e5'),('ENV60_FULL_CHAIN_REVIEW_MANIFEST.json','25509cf92efad610d6faf771a827f99ee6455529469abf9272b4eb5dbc01733d')]:check('prior review exactimmutable '+name,hfile(D/name)==expected);copy(D/name,Path('metadata')/name)
archives={};smallmetadata={}
def tar_audit(path,expected,count):
 check(path.name+' exact archiveSHA',hfile(path)==expected);rows={}
 with tarfile.open(path,'r|gz') as t:
  for m in t:
   n=PurePosixPath(m.name);check(path.name+' safeunique regular '+m.name,m.isfile() and not n.is_absolute() and '..' not in n.parts and '\\' not in m.name and m.name not in rows);f=t.extractfile(m);h=hashlib.sha256();size=0;capture=m.size<800000 and (m.name.endswith('.json') or m.name.endswith('.md') or m.name.endswith('.stdout') or m.name.endswith('.stderr'));chunks=[]
   while True:
    b=f.read(65536)
    if not b:break
    h.update(b);size+=len(b)
    if capture:chunks.append(b)
   check(path.name+' actualsize '+m.name,size==m.size);rows[m.name]={'bytes':size,'sha256':h.hexdigest(),'mode':oct(m.mode)}
   if capture:smallmetadata[(path.name,m.name)]=b''.join(chunks)
 check(path.name+' exactmembercount',len(rows)==count);archives[path.name]={'path':str(path),'bytes':path.stat().st_size,'sha256':expected,'members':rows};return rows
for name,digest,count in [('CI_BB343_PRODUCT_NATIVE_AUDIT.tar.gz','244781d5ac97e69636efbd0913058f8c96c84a8b1d7ce26dce40b382b0ba3b16',355),('CI_BB343_ENV_FAILURE_EVIDENCE.tar.gz','35650054090644d8369ecb49ad4e860d314fa5c8a05e7823e94879c5f0d4eb8d',43),('ENV60_NONRUST_REVIEW_EVIDENCE.tar.gz','f2de730ae1cd7088d41b42aabdc3bf3a9785d6318e5279a16728366a1a3ca219',47),('ENV60_FULL_CHAIN_REVIEW_EVIDENCE.tar.gz','42cc2e577effb12a6e03881f461bcae0aca5fd7b8a1ee44cd157621489c479dd',23)]:tar_audit(D/name,digest,count)
for tarname,mname in [('ENV60_NONRUST_REVIEW_EVIDENCE.tar.gz','ENV60_NONRUST_REVIEW_MANIFEST.json'),('ENV60_FULL_CHAIN_REVIEW_EVIDENCE.tar.gz','ENV60_FULL_CHAIN_REVIEW_MANIFEST.json'),('CI_BB343_ENV_FAILURE_EVIDENCE.tar.gz','CI_BB343_ENV_FAILURE_MANIFEST.json')]:
 m=load(D/mname)
 for row in m['files']:
  got=archives[tarname]['members'][row['path']];check(tarname+' manifest payload '+row['path'],got['bytes']==row['bytes'] and got['sha256']==row['sha256'])
# Product Git subset is deliberately NOT the self-contained installer archive.
tarname='CI_BB343_PRODUCT_NATIVE_AUDIT.tar.gz';members=archives[tarname]['members'];subset=json.loads(smallmetadata[(tarname,'SUBSET_MANIFEST.json')]);full=load(D/'CI_BB343_MANIFEST.json');expected={x['path']:x for x in full['files']};omitted={x['path']:x for x in subset['omitted_binary_members']};check('exact9 omitted7ZIP+2DMG declared, all50PNG retained',len(omitted)==9 and sum(x.endswith('.zip') for x in omitted)==7 and sum(x.endswith('.dmg') for x in omitted)==2 and set(expected)-set(members)==set(omitted) and len([x for x in members if x.endswith('.png')])==50)
check('subset declaration and originalMANIFESTexact',subset['original_full_archive_sha256']=='08b76e059993338f484478948384355f8e4dd206645bd2be1680dceae8ed675e' and smallmetadata[(tarname,'MANIFEST.json')]==(D/'CI_BB343_MANIFEST.json').read_bytes())
for name,row in members.items():
 if name in ['SUBSET_MANIFEST.json','MANIFEST.json']:continue
 check('all productsubset originalmember hashes/modes '+name,row=={k:expected[name][k] for k in ['bytes','sha256','mode']})
fullpath=Path(subset['original_full_archive']);check('fulloriginal60MB still actual exactdigest',hfile(fullpath)==subset['original_full_archive_sha256']);refs.append({'path':str(fullpath),'bytes':fullpath.stat().st_size,'sha256':subset['original_full_archive_sha256'],'not_copied':True})
B=fullpath.parent
for name,row in omitted.items():p=B/name;check('original omitted binary bytes still present '+name,p.stat().st_size==row['bytes'] and hfile(p)==row['sha256'])
# Actualbb terminal metadata and delivery are historical; no network request or fresh signing is performed.
prod_stages=sorted([x for x in members if re.fullmatch(r'product-jobs-stage-\d+\.json',x)])
latest=json.loads(smallmetadata[(tarname,prod_stages[-1])]);check('bb old Product4success onlyatbb',len(latest['jobs'])==4 and all(x['head_sha']==BASE and x['status']=='completed' and x['conclusion']=='success' for x in latest['jobs']))
env=json.loads(smallmetadata[(tarname,'environment-jobs-initial.json')]);check('bb requiredEnv3remainFAIL',len(env['jobs'])==3 and all(x['head_sha']==BASE and x['conclusion']=='failure' for x in env['jobs']))
for arch in ['arm','intel']:
 p=next((B/(arch+'-development-artifact')).glob('*.dmg'));row=full['architecture_delivery'][arch]['DMG'];check(arch+' trueDMG digest,size,UDIF',p.stat().st_size==row['bytes'] and hfile(p)==row['sha256'])
 with p.open('rb') as f:f.seek(-512,2);check(arch+' actualUDIFkoly footer',f.read(4)==b'koly')
 sums=(p.parent/'SHA256SUMS').read_text();record=(p.parent/'build-record.txt').read_text();check(arch+' SHA256SUMS/exact actualcheckout bound',row['sha256'] in sums and p.name in sums and 'commit=1a7682e60354d4a80200ea487725edfc99068a4c' in record)
 check(arch+' genuine recorded signature state',('Signature=adhoc' in record and 'TeamIdentifier=not set'in record) if arch=='arm' else 'code object is not signed at all'in record)
 copy(p.parent/'build-record.txt',Path('metadata')/(arch+'-build-record.txt'));copy(p.parent/'SHA256SUMS',Path('metadata')/(arch+'-SHA256SUMS'))
delivery=(D/'DEVELOPMENT_DELIVERY_BB343.md').read_text();check('delivery honest IDsURLsSHA signature/uninstalled',all(x in delivery for x in ['12866209525','12866603973','d1e479eb701efa13ea7d62e9d5f6496f0877764aa09e1dbfe2ad0feca25af0d8','c23937dd321e890cd881f9a10097d4ff15b53ab8840a9d2f95b4b6dc7624bf25','未签名','人工验收（尚未执行）','该提交仍不得合入']))
# Recheck actual returned Rust lease evidence without running Cargo or accessing target files.
F=Path('/workspace/.onboarding/native-env-policy60-full-chain-review/Rust-raw');cmd=load(F/'commands.json');environment=load(F/'environment.json');check('actual Rust3a91 two exact commands exit0',len(cmd)==2 and cmd[0]['argv']==['cargo','test','--locked','--manifest-path','tools/environment-smoke/Cargo.toml'] and cmd[1]['argv']==['cargo','clippy','--locked','--manifest-path','tools/environment-smoke/Cargo.toml','--all-targets','--','-D','warnings'] and all(x['exit']==0 and x['cwd']==str(R) for x in cmd) and environment['commit']=='3a91bcec76a34f21edf800df16709b5e958b8012')
for c in cmd:
 for suffix in ['stdout','stderr']:check('Rust original raw log '+c['tag']+'.'+suffix,hfile(F/(c['tag']+'.'+suffix))==c[suffix+'_sha256']);copy(F/(c['tag']+'.'+suffix),Path('metadata/Rust')/(c['tag']+'.'+suffix))
check('actual Rust2 no skip/filter and actual Clippyfinish','2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (F/'test.stdout').read_text() and 'Compiling agentbaton-environment-smoke' in (F/'test.stderr').read_text() and 'Checking agentbaton-environment-smoke' in (F/'clippy.stderr').read_text() and 'Finished' in (F/'clippy.stderr').read_text())
a=load(F/'before-tracked.json');b=load(F/'after-tracked.json');check('actual Rust1296tracked record beforeafter identical',a==b and load(F/'preservation.json')['tracked_count']==1296)
for p in ['commands.json','environment.json','preservation.json','versions.json']:copy(F/p,Path('metadata/Rust')/p)
# Root final8 logs are fresh output records; source equivalence is explicit, no invented a945 execution stamp.
rootrows=load(D/'ENV60_ROOT_NONRUST_CHECKS/RESULT.json');check('Root fresh8commands all0',len(rootrows)==8 and all(x['exit']==0 for x in rootrows))
for i,c in enumerate(rootrows):p=D/f'ENV60_ROOT_NONRUST_CHECKS/{i}.log';check('Root8 log actualhash '+str(i),hfile(p)==c['log_sha256']);copy(p,Path('metadata/Root-final8')/(str(i)+'.log'))
check('Root final Python34 and Node4 raw outputs','Ran 34 tests' in (D/'ENV60_ROOT_NONRUST_CHECKS/5.log').read_text() and '\nOK' in (D/'ENV60_ROOT_NONRUST_CHECKS/5.log').read_text() and re.search(r'(?:#|ℹ) tests 4',(D/'ENV60_ROOT_NONRUST_CHECKS/6.log').read_text()) is not None)
for p in ['ENV60_ROOT_NONRUST_CHECKS/RESULT.json','ENV60_FULL_CHAIN_IMPORT.json','CI_BB343_PRODUCT_IMPORT.json','CI_BB343_ENV_FAILURE_IMPORT.json','DEVELOPMENT_DELIVERY_BB343.md','ENV60_FINAL_STATUS_REBASELINE.json']:copy(D/p,Path('metadata')/p)
check('candidate still exactclean at auditend',subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==SRC and subprocess.check_output(['git','status','--porcelain'],cwd=R)==b'')
(O/'audit-results.json').write_text(json.dumps({'subject':SRC,'base':BASE,'verdict':'source/records ready for accurate newCI; not merge-ready','controls':checks,'passed_controls':len(checks),'source_references':refs,'source_delta':delta,'prior_source_equivalent_Rust':'3a91bcec76a34f21edf800df16709b5e958b8012','archive_inventories':archives,'Product_old':'4success on bb, not transferable','Env_old':'3failure on bb, not waived','new_head_CI':'not_run','50PNGs_rehashed_not_viewed':True,'full_original_zip_DMG_not_copied':True},indent=2)+'\n');print('PASS',len(checks),'source/record/archive checks; source-ready only, new exact7CI required')
