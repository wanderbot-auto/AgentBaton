from pathlib import Path
import subprocess,json,hashlib,os,time,sys
D=Path(__file__).resolve().parent;R=Path('/workspace/.worktrees/graph-mac-fixture-stability');mode=sys.argv[1]
assert hashlib.sha256((R/'crates/core/tests/sessions_ipc.rs').read_bytes()).hexdigest()=='227d3fcb499969d81ae3777ff3f72441b0aea7096f8452fa15492ce22c0b245b'
assert subprocess.check_output(['git','diff','c05f8cee4966b8c76b6e8de7181d5b9a21572dfe','--','crates','apps','Cargo.toml','Cargo.lock'],cwd=R)==b''
paths=subprocess.check_output(['git','ls-files','crates','apps','Cargo.toml','Cargo.lock'],cwd=R,text=True).splitlines();paths=[x for x in paths if x.endswith('.rs')or Path(x).name in ['Cargo.toml','Cargo.lock']]
def snapshot():return{x:hashlib.sha256((R/x).read_bytes()).hexdigest()for x in paths}
if mode=='tests':
 (D/'sources-before.json').write_text(json.dumps(snapshot(),indent=2)+'\n');touch=[]
 for name in ['crates/config/src/lib.rs','crates/providers/src/lib.rs','crates/workspaces/src/lib.rs','crates/core/src/lib.rs','crates/core/tests/sessions_ipc.rs']:
  p=R/name;h=hashlib.sha256(p.read_bytes()).hexdigest();mtime=p.stat().st_mtime_ns;os.utime(p,None);assert hashlib.sha256(p.read_bytes()).hexdigest()==h;touch.append({'path':name,'sha256':h,'before_mtime_ns':mtime,'after_mtime_ns':p.stat().st_mtime_ns,'bytes_unchanged':True})
 (D/'entrypoint-mtime-touch.json').write_text(json.dumps(touch,indent=2)+'\n')
env=os.environ.copy();env.update({'CARGO_HOME':'/workspace/.toolchains/cargo','RUSTUP_HOME':'/workspace/.toolchains/rustup','CARGO_TARGET_DIR':'/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'2','RUST_TEST_THREADS':'1','PATH':'/workspace/.toolchains/cargo/bin:/workspace/.toolchains/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:'+env.get('PATH','')})
commands={'tests':['cargo','test','--locked','--offline','-p','agentbaton-core','--test','sessions_ipc','--','--test-threads=1','--nocapture'],'clippy':['cargo','clippy','--locked','--offline','-p','agentbaton-core','--all-targets','--','-D','warnings'],'fmt':['cargo','fmt','--all','--','--check']};cmd=commands[mode];start=time.monotonic();print(json.dumps({'running':mode,'command':cmd,'log':str(D/(mode+'.log'))}),flush=True)
with(D/(mode+'.log')).open('wb')as out:result=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT)
row={'mode':mode,'command':cmd,'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'log_sha256':hashlib.sha256((D/(mode+'.log')).read_bytes()).hexdigest(),'environment':{k:env[k]for k in ['CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','RUST_TEST_THREADS']},'source_commit':'c05f8cee4966b8c76b6e8de7181d5b9a21572dfe','source_sha256':'227d3fcb499969d81ae3777ff3f72441b0aea7096f8452fa15492ce22c0b245b'};(D/(mode+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
if mode=='fmt':
 after=snapshot();(D/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n');assert after==json.loads((D/'sources-before.json').read_text())
sys.exit(result.returncode)
