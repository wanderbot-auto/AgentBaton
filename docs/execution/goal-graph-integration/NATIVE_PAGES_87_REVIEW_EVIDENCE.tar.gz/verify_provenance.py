from pathlib import Path
import json,subprocess,hashlib,importlib.util
r=Path(__file__).parent;repo=Path('/workspace/.worktrees/native-review-presentation');rev='87ec9ad8647b549311fc90077e9757bc257c4b70';base='e3ccf86a8b12e7ed1371074de095bb454c0b62aa';ev=r/'evidence';ev.mkdir(exist_ok=True)
sha=lambda x:hashlib.sha256(x).hexdigest();out={'revision':rev,'baseline':base,'source_checks':[],'author_evidence':[],'old_actual_mac':[],'unchanged':[]}
for item in json.loads((r/'manifest.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{rev}:{item["path"]}'],cwd=repo);assert sha(b)==item['sha256'];assert b==(r/'source'/item['path']).read_bytes()
a=Path('/workspace/.onboarding/native-review-presentation');m=json.loads((a/'MANIFEST.json').read_text())
for name in ['MANIFEST.json',*m['raw_evidence_sha256']]:
 b=(a/name).read_bytes()
 if name!='MANIFEST.json':assert sha(b)==m['raw_evidence_sha256'][name]
 (ev/name).write_bytes(b);out['author_evidence'].append({'path':name,'sha256':sha(b),'bytes':len(b)})
for p,h in json.loads((a/'SOURCE_MAP.json').read_text()).items():
 b=subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo);assert sha(b)==h,p;out['source_checks'].append({'path':p,'sha256':h,'fixed_git_match':True})
for p in ['apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs','Cargo.lock','apps/desktop/src-tauri/Cargo.lock','apps/desktop/src-tauri/Cargo.toml']:
 x=subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo);y=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo);assert x==y;out['unchanged'].append({'path':p,'sha256':sha(x)})
p='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();new=(r/'source'/p).read_text();assert old.split("if __name__ == '__main__':")[0]==new.split('class PresentationControls')[0];out['original_python_test_body_preserved']=True
spec=importlib.util.spec_from_file_location('review_runner',r/'source/scripts/native-owner-dialog-smoke.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
mac=Path('/workspace/.onboarding/pr16-e3cc-mac-review')
for n in ['MANIFEST.json','ARM_REVIEW.md','INTEL_REVIEW.md']:
 b=(mac/n).read_bytes();(ev/('mac-'+n)).write_bytes(b)
for arch in ['arm','intel']:
 sub=mac/(arch+'-native-artifact/owner-dialog');raw=(sub/'cancel-sheet-diagnostic.json').read_bytes();d=json.loads(raw);o=d['observation'];expected=o['expected_message']['text'];actual=o['views'][7]['text']['text'];assert ''.join(line.lstrip(' \t') for line in expected.splitlines(keepends=True))==actual;assert len(expected.encode())-len(actual.encode())==252
 fixture=json.loads((sub/'fixture.json').read_text());assert fixture['message']==expected
 for val in [o['expected_message'],o['views'][7]['text']]:assert sha(val['text'].encode())==val['sha256']
 pages=runner.presentation_prompts(expected);restored=''.join(json.loads(line.split(' ',1)[1]) for p in pages[:-1] for line in p.splitlines() if line.startswith('L'));assert restored==expected
 assert o['title_matches']==1 and o['message_matches']==0 and o['on_screen']==False
 for n in ['fixture.json','cancel-sheet-diagnostic.json']:(ev/(arch+'-'+n)).write_bytes((sub/n).read_bytes())
 out['old_actual_mac'].append({'arch':arch,'expected_utf8_bytes':len(expected.encode()),'actual_utf8_bytes':len(actual.encode()),'leading_whitespace_delta':252,'sheet_frame':o['sheet_frame'],'on_screen':False,'old_first_failure':d['reason'],'original_diagnostic_sha256':sha(raw),'new_offline_page_count_with_final':len(pages),'max_page_utf8_bytes':max(len(p.encode()) for p in pages),'new_offline_roundtrip':True,'new_macos_presentation_executed':False})
(r/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified',len(out['source_checks']),'author source bindings;',len(out['author_evidence']),'author evidence files; 2 old actual Mac diagnostics; original tests and formatter/route/locks unchanged.')
