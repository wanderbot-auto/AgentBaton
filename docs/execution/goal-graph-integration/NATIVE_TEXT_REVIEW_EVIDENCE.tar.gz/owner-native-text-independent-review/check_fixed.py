from pathlib import Path
import subprocess, hashlib, json, datetime

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/.worktrees/owner-native-text-diagnostics')
BASE = '0aa20c968d493cad895e4a3853bdf106d6b54acf'
HEAD = '7a13cddef4316d520361071ff5e2a263ea058580'
MAC = 'apps/desktop/src-tauri/src/bin/native_owner_dialog/macos.rs'
CONTROL = 'apps/desktop/src-tauri/src/bin/native_owner_dialog/controller.rs'
ALLOWED = [MAC, CONTROL, 'apps/desktop/src-tauri/Cargo.toml', 'apps/desktop/src-tauri/Cargo.lock']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def source(ref, path):
    data = git('show', ref + ':' + path)
    dest = OUT / ('baseline' if ref == BASE else 'candidate') / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return data.decode()

def block(text, start, end):
    return text[text.index(start):text.index(end, text.index(start))]

before = source(BASE, MAC)
after = source(HEAD, MAC)
cb = source(BASE, CONTROL)
ca = source(HEAD, CONTROL)
checks = {}
for start, end in [('fn write(', 'fn fail('), ('fn invoke_script(', 'fn record_report('),
                   ('#[tauri::command]\nfn owner_dialog_report(', 'fn contains('),
                   ('fn contains(', 'struct Observation'), ('struct OwnedCapture(', 'fn capture(')]:
    checks[start] = block(before, start, end) == block(after, start, end)
checks['capture_exact_with_OwnedCapture'] = block(before, 'struct OwnedCapture(', 'fn poll(') == block(after, 'struct OwnedCapture(', 'fn start_capture(')
checks['record_report_only_None_initialization'] = block(before, 'fn record_report(', '#[tauri::command]') == block(after, 'fn record_report(', '#[tauri::command]').replace('            observation_failure: None,\n', '')
checks['run_only_None_initialization'] = before[before.index('pub fn run()'):] == after[after.index('pub fn run()'):].replace('            observation_failure: None,\n', '')
checks['controller_validate_and_all_original_four_tests_exact'] = cb[cb.index('pub fn validate('):] == ca[ca.index('pub fn validate('):ca.index('\n#[cfg(test)]\nmod diagnostic_tests')]
checks['parent_visible_stability_500ms_exact'] = block(before, '    let _main = MainThreadMarker', '    let content = sheet.contentView()') == block(after, '    let _main = MainThreadMarker', '    *diagnostic = Some(SheetDiagnostic')
oldmatch = block(before, '            if value\n', '        if let Some(button)')
newmatch = block(after, '            if value\n', '        if let Some(button)').replace('                diagnostic["views"][index]["required_cell_size"] =\n                    json!({"width":required.width,"height":required.height});\n', '')
checks['exact_message_title_and_complete_visible_cell_gate'] = oldmatch == newmatch
checks['permit_to_click_exact'] = block(before, '    write(\n        &state\n            .output\n            .join(format!("{}-sheet-ready.json"', '\npub fn run()') == block(after, '    write(\n        &state\n            .output\n            .join(format!("{}-sheet-ready.json"', '\npub fn run()')
checks['original_RPC_script_exact'] = checks['fn invoke_script(']
checks['all_mechanical_preservation_checks'] = all(checks.values())
changed = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
assert set(changed) == set(ALLOWED), changed
for name in ALLOWED[2:]:
    source(BASE, name)
    source(HEAD, name)
checks['only_authorized_four_files'] = True
checks['original_python85sec_runner_and_original_native_smoke_unchanged'] = all(git('show', BASE + ':' + n) == git('show', HEAD + ':' + n) for n in ['scripts/native-owner-dialog-smoke.py', 'scripts/native-run.py', 'apps/desktop/src-tauri/src/bin/native_smoke.rs', 'apps/desktop/src-tauri/src/lib.rs', 'apps/desktop/src-tauri/src/approval.rs', 'apps/desktop/src-tauri/src/native_parent.rs', 'Cargo.lock'])
assert all(checks.values()), checks
mapping = []
for ref, prefix in [(BASE, 'baseline'), (HEAD, 'candidate')]:
    for name in ALLOWED:
        data = (OUT / prefix / name).read_bytes()
        mapping.append({'ref': ref, 'file': name, 'sha256': hashlib.sha256(data).hexdigest(), 'blob': git('rev-parse', ref + ':' + name).decode().strip()})
result = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'dimension': 'independent_fixed_Git_byte_comparison_no_Cargo', 'base': BASE, 'candidate': HEAD, 'candidate_tree': git('rev-parse', HEAD + '^{tree}').decode().strip(), 'checks': checks, 'source_map': mapping}
(OUT / 'mechanical-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
