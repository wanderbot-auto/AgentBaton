"""Offline read of actual artifact JSON through pinned report contracts; no execution."""
from pathlib import Path
import runpy,json,sys,datetime,hashlib
ROOT=Path(__file__).resolve().parent

def main(arch):
 report=json.loads((ROOT/(arch+'-native-artifact/native-smoke.json')).read_text())
 runner=json.loads((ROOT/(arch+'-native-artifact/native-runner.json')).read_text())
 source=ROOT/'source-snapshot/scripts/native-run.py'
 ns=runpy.run_path(str(source),run_name='pinned_native_contract_for_saved_evidence')
 error=ns['native_report_error'](report)
 assert error is None,error
 assert report['commit']=='e963523c04b27d99d44a7893b161b5180b9818e3'
 assert report['architecture']==('aarch64' if arch=='arm' else 'x86_64')
 assert report['os']=='macos' and report['status']=='passed'
 for key in ['window_close_daemon_survived','owned_daemon_restarted','owned_daemon_cleanup','second_writer_rejected']:assert report[key] is True,key
 for key in ['goal_readonly_database','goal_execution_readonly_database','goal_graph_readonly_database']:
  for stage in ['before','after']:assert type(report[key][stage]['sequence']) is int and report[key][stage]['sequence']==3
 assert runner['exit_code']==0 and runner['timeout'] is False and runner['owned_group_cleanup'] is True and runner['status']=='passed'
 output={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'arch':arch,'dimension':'offline saved actual macOS report only; no WebView/browser/process launched by reviewer','fixed_runner_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'strict_pinned_native_report_error':error,'actual_checkout':report['commit'],'architecture':report['architecture'],'readonly_schema':12,'readonly_sequence':3,'readonly_goal_and_execution_and_all_six_graph_counts':0,'actual_WebCrypto_original_109B_four_context_proofs':'passed exact source/algorithm/checkpoint/input/UTF8/SHA contract','lifecycle_second_writer_windowclose_survival_restart_reopen_draft_cancel_stop_owned_cleanup':'passed report evidence','native_runner':runner,'readonly_fixture_native_dialog':report['native_dialog'],'separate_Owner_fixture':'read owner-dialog result separately','provider_models':report['provider_models'],'formal_approval':False}
 (ROOT/(arch+'-offline-native-audit.json')).write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
if __name__=='__main__':main(sys.argv[1])
