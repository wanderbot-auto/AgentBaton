"""Seal already acquired/inspected read-only CI evidence. No remote commands."""
from pathlib import Path
import json,hashlib,datetime,tarfile,io,os
R=Path(__file__).resolve().parent
H='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4';C='e963523c04b27d99d44a7893b161b5180b9818e3';T='32b2747d4541b7f09d05cf21332f6232b081d8a5'
def read(n):return json.loads((R/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def entry(p):
 assert p.is_file() and not p.is_symlink()
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'mode':oct(p.stat().st_mode&0o777),'sha256':sha(b)}
def save(n,d):
 p=R/n;assert not p.exists(),n;p.write_text(json.dumps(d,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Verify all already sealed files before packaging; do not rewrite prior records.
verified=0
for name in ['ARM_MANIFEST.json','INTEL_MANIFEST.json']:
 for row in read(name)['files']:
  got=entry(R/row['path']);assert all(got[k]==row[k] for k in got),(name,row['path']);verified+=1
for row in read('source-manifest.json')['files']:
 b=(R/'source-snapshot'/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
for arch in ['arm','intel']:
 assert len(read(arch+'-visual-review.json')['images'])==25
 audit=read(arch+'-offline-page-audit.json');assert audit['errors']==[] and audit['approved_validator_error'] is None and len(audit['page_records'])==24
 assert audit['production_formatter_matches_fixture'] is True and audit['initial_pending_validator_error'] is None
 assert read(arch+'-offline-native-audit.json')['strict_pinned_native_report_error'] is None
 assert read(arch+'-native-artifact-inventory.json')['api_digest_matches'] is True
 assert read(arch+'-native-artifact-inventory.json')['crc']=='passed'
 assert len(read(arch+'-native-artifact-inventory.json')['entries'])==115
 assert not (R/(arch+'-development-artifact.zip')).exists()
assert not any(x['name'].startswith('development-') for x in read('intel-artifacts-terminal.json')['artifacts'])
assert any('maximum execution time of 45m0s' in a['message'] for a in read('intel-check-annotations.json'))
assert read('product-run-final.json')['conclusion']=='failure'
assert read('environment-run-initial.json')['conclusion']=='success'
assert len(read('environment-jobs-initial.json')['jobs'])==3
assert all(j['conclusion']=='success' for j in read('environment-jobs-initial.json')['jobs'])
last=read('product-jobs-stage-09.json')['jobs']
assert {j['name']:j['conclusion'] for j in last}=={'Product / UI':'success','Product / Rust':'success','Product / macos-15':'failure','Product / macos-15-intel':'cancelled'}
try:os.kill(read('monitor-started.json')['pid'],0)
except ProcessLookupError:monitor_exited=True
else:monitor_exited=False
assert monitor_exited
api=read('monitor-api-attempts.json')
assert all(x['exit_code']==0 for x in api)
for arch in ['arm','intel']:
 for suffix in ['-job.log','-native-artifact.zip']:assert sum(a['file']==arch+suffix for a in api)==1
save('final-integrity-checks.json',{'at':now,'arch_sealed_file_references_verified':verified,'fixed_source_files_unchanged':23,'official_arch_log_ZIP_single_download_each':True,'monitor_exited':True,'each_arch_24pages_and25PNGs':True,'all_images_individually_viewed':True,'both_strict_Owner_and_native_offline_audits':'passed','Product':'failure','Environment':'success','development_artifacts_absent':True,'original45min_cancellation_annotation_verified':True})
summary=f'''# PR16 c6f6 actual CI independent Mac review

Sealed {now}. Feature `{H}`; actual checkout `{C}`, tree `{T}`, parents `a1be94d26d10bb245bb35eb50226b82012c967da` +feature. Both Mac original checkout logs and actual native reports confirm this candidate; signed Git commit API is retained. Product40790894775 attempt1 is **failure**. Environment40790894815 attempt1 is **success**. PR16 remains draft; no formal approval or merge is supplied by this review.

| Dimension | ARM job123175557753 | Intel job123175557621 |
| --- | --- | --- |
| Host / native smoke / Owner controller tests | 62 / 26 / 10 passed | 62 / 26 / 10 passed |
| Actual readonly WebView and owned lifecycle | success | success |
| Four actual WebCrypto original109B proofs | passed | passed |
| Actual native Owner11 pages+Final, both phases | success | success |
| Typed schema12/seq8→10, oneGrant/original19zero | passed | passed |
| Current25 original PNGs individually viewed | yes | yes |
| Default release executable/build | compiled; application bundling failed | compilation cancelled |
| Job terminal | failure00:29:51 | cancelled00:43:25 |
| Default release test-control audit | skipped | skipped |
| Development package/upload/signature/install acceptance | skipped/no artifact/not_run | skipped/no artifact/not_run |

ARM first failure is original arm-job.log:3708: bundler cannot copy nonexistent `target/release/native_owner_dialog`; :3706 proves default executable compilation completed, not a complete verified app. Intel first actual log error is :3814 `The operation was canceled.`; official annotation independently states `The job has exceeded the maximum execution time of 45m0s`. Intel stopped during release desktop/Core compilation without the ARM missing-binary error. These are separate observed failures; this review does not invent a common cause or repair either. Runner-terminated compiler/node processes at Intel job cancellation are separate from already-successful owned fixture cleanup. Required default build/audit/dual installer gates remain open; no old PR15/package is substituted.

Both actual Owner dimensions now pass the corrected exact contract: all11 pages and a distinct Final were presented twice, with original24 before-click schema12 DB/permit snapshots perarchitecture.84 L rows restore3132 ARM/3136 Intel bytes losslessly to original formatter text, exact refs/parent/fullcell/visibility and realcontrol flags match. Late Final Cancel leaves no Grant/finalization; Final OK creates exactly one persisted Grant and two matching events, consumed proposal revision2,19counters0. The distinct server approvalUUID is bound to the Grant event, not invented equal to proposalID. Savedresponse/proposalresult/persistence and exact typed scope/enforcement/bindings agree. Every current Owner screenshot48 and readonly screenshot2 was individually opened with tools.view_image. Page11/Final wrap within narrower centered sheets; no clipping observed. These are automated fixture decisions, not human owner approvals. The source still enforces500ms/4s/75s/85s gates; no new per-gate telemetry is invented.

Actual readonly WebView evidence remains separate from Owner: schema12/sequence3, zero Goal/execution/all6Graph counts, exact missing-run denials, real productioninvoke/persistence/close-survival/restart/reopen/draftcancel/stop/ownedcleanup. All four actual crypto.subtle.digest/TextEncoder proofs perarchitecture preserve the original109B Chinese/emoji/unsafe-u64 literal bytes and SHA d29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892. Factoryschema13/28tables, Graph private Owner OS flows, real Provider model calls, trusted signing/notarization/production and human installation are not established by this fixture.

Environment3 and ProductLinux2 jobs are all success in saved API records (five success jobs total). Root owns the independent Linux rawlog/artifact review; this reviewer did not download their logs/ZIPs. Product Mac outcomes are ARMfailure and Intelcancelled, not two success jobs. Exact Product overallstatus remains failure.

Each official Mac rawlog/nativeZIP was downloaded once after that job's terminal state. ARM artifact12862732050/SHA c92f2bb3869475ff90487d4d525ce427f7b9b507e1445c1fe64395606c844122; Intel artifact12862609620/SHA96606ed6b588225f6bdac3245e3ada8c4f0fbb30eda3d1d5557afbeb2de6df41. API digests, CRCs, safe normalized unique paths/permitted ZIPmodes/size bounds and all115 regular payload hashes perZIP were verified. Original capture modes and local extracted modes are both recorded, not conflated. Fixed source23 blobs and original raw files are bound by manifest. Early existing-blob source capture AssertionError is retained in source-capture-note.json; corrected logic verified bytes before reusing them, no source was overwritten. monitor-complete.json's images-not-yet-reviewed flag is its historical acquisition snapshot; subsequent independent visual reports above complete that dimension.

The bounded actual monitor has exited; all future monitoring is stopped. No Cargo/target/source/STATUS/browser/productdaemon/Provider/credential/timeout/workflow/remote mutation, CIretry/cancel/trigger, formalapproval/merge/push or paidresource operation was performed. Evidence writes are confined to this review directory. Earlier fb7/final921/otherMac reports remain unchanged. ARM_REVIEW/ARM_MANIFEST and INTEL_REVIEW/INTEL_MANIFEST retain each architecture's original evidence separately; MANIFEST covers this completed acquisition/review.
'''
(R/'SUMMARY.md').write_text(summary)
reports=['ARM_REVIEW.md','INTEL_REVIEW.md','SUMMARY.md']
files=[entry(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name not in {'MANIFEST.json','EVIDENCE.tar.gz','EVIDENCE_IMPORT.json'}]
save('MANIFEST.json',{'schema':1,'sealed_at_utc':now,'feature':H,'checkout':C,'tree':T,'product_run':40790894775,'environment_run':40790894815,'jobs':{'Environment':'3success','ProductLinux':'2success','ARM':'failure,bundling missing native_owner_dialog','Intel':'cancelled,official45minlimit'},'actual_native_and_Owner_both_arches':'passed dimensions, not overall CI acceptance','strict_schema':12,'original_zero_tables':19,'visual_review':{'Owner_PNGs':48,'readonly_PNGs':2,'all_individually_viewed':True},'official_download_count':{'arch_logs':2,'native_ZIPs':2,'development_ZIPs':0,'each_once':True},'archive_API_digest_CRC_safety_member_hashes_modes':'passed','source_snapshot_files':23,'old_failures_immutable':True,'current_default_release_audit_development_installers_signature_install_acceptance':'skipped/no artifacts/not_run','monitor_exited':True,'no_local_Cargo_target_source_STATUS_browser_daemon_Provider_credentials_remote_workflow_authority_mutations':True,'formal_approval':False,'reports':reports,'files':files})
# Package each evidence payload as a regular member with local mode, never links.
paths=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name not in {'EVIDENCE.tar.gz','EVIDENCE_IMPORT.json'}]
with tarfile.open(R/'EVIDENCE.tar.gz','w:gz') as archive:
 for p in paths:
  row=entry(p);info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=p.stat().st_mode&0o777;info.mtime=0;archive.addfile(info,io.BytesIO(p.read_bytes()))
with tarfile.open(R/'EVIDENCE.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(paths)
 for item in members:
  assert item.isreg() and (R/item.name).is_file();assert archive.extractfile(item).read()==(R/item.name).read_bytes();assert item.mode==((R/item.name).stat().st_mode&0o777)
b=(R/'EVIDENCE.tar.gz').read_bytes()
save('EVIDENCE_IMPORT.json',{'schema':1,'sealed_at_utc':now,'file':'EVIDENCE.tar.gz','bytes':len(b),'sha256':sha(b),'regular_members':len(paths),'payload_roundtrip_bytes_modes_verified':True,'source_feature':H,'actual_checkout':C,'review_scope':'new actual dualMac CI; separate native success/defaultpackage failures; no formal approval'})
for n in ['ARM_REVIEW.md','ARM_MANIFEST.json','INTEL_REVIEW.md','INTEL_MANIFEST.json','SUMMARY.md','MANIFEST.json','EVIDENCE.tar.gz','EVIDENCE_IMPORT.json']:print(json.dumps(entry(R/n)))
