from pathlib import Path
import json,hashlib,subprocess,tarfile,stat
R=Path(__file__).resolve().parent;G=Path('/workspace/.worktrees/goal-graph-integration')
def rd(n):return json.loads((R/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=G)
def save(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
docs=rd('ARCHIVE_JSON_DOCUMENTS.json');archives=rd('ARCHIVE_INVENTORY.json');index={x['archive']:{e['path']:e for e in x['entries']} for x in archives}
root_arc='docs/execution/goal-graph-integration/NATIVE_MODULE_CHECK_ROOT_EVIDENCE.tar.gz'
def doc(arc,path):return next(d['document'] for d in docs if d['archive']==arc and d['path']==path)
before=doc(root_arc,'native-module-check/BEFORE.json');result=doc(root_arc,'native-module-check/RESULT.json')
current={x['path']:x for x in rd('GIT_SNAPSHOT.json')['files']};cache={}
def verify_git(ref,path,expected,gitblob=None):
 # Most historical blobs remain identical; still bind each source path to its fixed commit object.
 if ref not in cache:
  cache[ref]={}
  for row in git('ls-tree','-rz',ref).split(b'\0'):
   if not row:continue
   meta,p=row.split(b'\t',1);mode,kind,obj=meta.decode().split();cache[ref][p.decode()]=(mode,obj)
 mode,obj=cache[ref][path]
 if gitblob is not None:assert obj==gitblob
 if path in current and current[path]['git_blob']==obj:observed=current[path]['sha256']
 else:observed=sha(git('cat-file','blob',obj))
 assert observed==expected,(ref,path);return {'path':path,'git_blob':obj,'mode':mode,'sha256':observed}
rootmap=[verify_git(before['integration_head'],p,h) for p,h in before['source_hashes'].items()]
assert len(rootmap)==len(cache[before['integration_head']])
retire=doc(root_arc,'reconstructible-cache-retirement/BEFORE.json');retire_result=doc(root_arc,'reconstructible-cache-retirement/RESULT.json')
retiremap=[verify_git(retire['ref'],x['path'],x['sha256'],x['git_blob']) for x in retire['files']]
assert len(retiremap)==1239 and sum(x['size'] for x in retire['files'])==149922362
old_snapshot=json.loads(Path('/workspace/.onboarding/pr16-final-921-review/GIT_SNAPSHOT.json').read_text());oldrows=old_snapshot['files'];oldmap={x['path']:x for x in oldrows}
for x in retire['files']:
 old=oldmap[x['path']];assert old['git_blob']==x['git_blob'] and old['sha256']==x['sha256']
original_report=Path('/workspace/.onboarding/pr16-final-921-review/snapshot/DESIGN_VALIDATION.json')
assert original_report.is_file()
oldvalid=json.loads(original_report.read_text());assert oldvalid['status']=='passed' and oldvalid['requirements']==130
for cmd in result['commands']:
 assert cmd['exit_code']==0;assert index[root_arc]['native-module-check/'+cmd['log']]['sha256']==cmd['sha256']
assert result['commands'][0]['command'][1]=='check' and result['commands'][1]['command'][1]=='fmt'
for tool,restored in zip(before['tools'],result['tool_restoration']):
 assert tool['path']==restored['path'] and tool['original_sha256']==restored['after_restore'] and restored['same_inode_and_nlink'] is True
 assert restored['observed_after_build']==tool['macro_resource_sha256']
assert result['source_before_after_equal'] is True and result['changed']==[] and result['resource_files_unchanged'] is True
# Import wrapper exact reviews, manifest payloads, archives and member counts.
wrapper=json.loads((G/'docs/execution/goal-graph-integration/C6F6_AND_BUNDLE_REVIEW_IMPORT.json').read_text());base=G/'docs/execution/goal-graph-integration'
for review in wrapper['reviews']:
 assert sha((base/(review['label']+'.md')).read_bytes())==review['review_sha256']
 assert sha((base/(review['label']+'_MANIFEST.json')).read_bytes())==review['manifest_sha256']
 assert sha((base/review['archive']).read_bytes())==review['archive_sha256']
 assert len(index[str((base/review['archive']).relative_to(G))])==review['members']
for key,name in [('Mac','CI_C6F6_MAC'),('Linux','CI_C6F6_LINUX')]:
 x=wrapper[key];archive=x.get('repository_archive',x['archive']);assert sha((base/archive).read_bytes())==x.get('sha256',x.get('archive_sha256'))
 assert len(index[str((base/archive).relative_to(G))])==x.get('members',x.get('regular_members'))
 assert sha((base/(name+'_MANIFEST.json')).read_bytes())==x.get('source_manifest_sha256',x.get('manifest_sha256'))
rootwrapper=wrapper['NativeRoot'];assert sha((base/rootwrapper['archive']).read_bytes())==rootwrapper['sha256'] and len(index[root_arc])==7
# Record exact same archive modes when a manifest names its own local members.
modechecks=[]
def walk(v,origin):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and 'mode' in v and isinstance(v.get('sha256'),str):
   p=v['path'];items=index[origin]
   candidates=[items[p]] if p in items else [e for n,e in items.items() if n.endswith('/'+p) and e['sha256']==v['sha256']]
   candidates=[e for e in candidates if e['sha256']==v['sha256']]
   if candidates:
    val=v['mode'];m=int(val,8) if isinstance(val,str) else val
    # ZIP external attrs may include file type; compare permission bits only for a local tar copy.
    matched=any((int(e['mode'],8)&0o777)==(m&0o777) for e in candidates)
    modechecks.append({'archive':origin,'path':p,'declared_mode':val,'matched_permission_bits':matched,'note':'Full archive/original ZIP modes remain separately inventoried'})
  for x in v.values():walk(x,origin)
 elif isinstance(v,list):
  for x in v:walk(x,origin)
for d in docs:walk(d['document'],d['archive'])
# Mode mismatch may reflect explicit original Git/ZIP versus local capture, do not equate them.
mode_mismatch=[x for x in modechecks if not x['matched_permission_bits']]
refs=rd('REFMAP_INITIAL.json');assert len(refs['unresolved'])==1
ext=refs['unresolved'][0];p=Path(ext['path']);assert p.is_file() and sha(p.read_bytes())==ext['sha256']
save('FINAL_REFMAP.json',{'standard_payload_references_resolved':len(refs['resolved']),'resolved':refs['resolved'],'external_unportable_but_actual_local_file_verified':[{'reference':ext,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'scope':'separate Factory53e review; not a PR16portable payload and no Factory acceptance inferred'}],'unresolved_or_wrong_hash':0,'Root_source_hashes_fixed_4d2_verified':len(rootmap),'retired_921_source_blobs_verified':1239,'mapped_alias_limit':'Absolute/relative references map by exact digest+size; preferred exact same path/archive. Old source paths and nested ZIP entries retained explicitly; not silently rewritten.'})
save('HISTORY_ROOT_CACHE_PROOF.json',{'Root_source':before['source'],'Root_integration':before['integration_head'],'Root_all_source_hashes':rootmap,'commands':result['commands'],'actual_dimension':'Rust check --tests + Owner bin and fmt; no new 10 tests run, no Mac','then_observed_tool_before':before['tools'],'then_observed_restore':result['tool_restoration'],'current_shared_binary_read_or_executed':False,'retired_cache_ref':retire['ref'],'retired_cache_tree':retire['tree'],'retired_files':len(retiremap),'retired_bytes':149922362,'all_original_blob_paths_hashes_match_retained_Git_and_old_manifest':True,'original_generated_DESIGN_VALIDATION_preserved':{'path':str(original_report),'bytes':original_report.stat().st_size,'sha256':sha(original_report.read_bytes())},'old_GIT_SNAPSHOT_retained_sha256':sha(Path('/workspace/.onboarding/pr16-final-921-review/GIT_SNAPSHOT.json').read_bytes()),'retirement_result':retire_result,'wrapper_all_archive_review_manifest_hashes_counts_match':True,'mode_comparisons':modechecks,'mode_mismatch_requires_classification':mode_mismatch})
print(json.dumps({'RootSourceFiles':len(rootmap),'retiredGitFiles':len(retiremap),'payloadrefs':len(refs['resolved']),'externalFactoryLocalHashVerified':1,'modes_checked':len(modechecks),'mode_mismatch':mode_mismatch[:20]}))
