from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,datetime,os,stat,tarfile,io,zipfile,gzip
R=Path(__file__).resolve().parent;G=Path('/workspace/.worktrees/goal-graph-integration')
HEAD='d0c01baa5729fa90bcc0354791f297646019da9a';BASE='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,d):(R/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=G)
def blob(ref,p):return git('show',ref+':'+p)
def state():
 p=G/'DESIGN_VALIDATION.json'
 return {'at':now(),'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain').decode(),'design_report_sha256':sha(p.read_bytes()) if p.exists() else None,'design_report_exists':p.exists()}
before=state();save('BEFORE.json',before);assert before['head']==HEAD and before['status']==''
# Hash all fixed Git blobs and existing tracked bytes, without exporting them.
rows=[];cache={}
for raw in git('ls-tree','-rz',HEAD).split(b'\0'):
 if not raw:continue
 meta,path=raw.split(b'\t',1);mode,kind,obj=meta.decode().split();p=path.decode();assert kind=='blob' and mode in ('100644','100755')
 if obj not in cache:
  b=git('cat-file','blob',obj);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==obj
  cache[obj]=(len(b),sha(b))
 size,digest=cache[obj];f=G/p;assert not f.is_symlink() and f.is_file();assert f.stat().st_size==size and sha(f.read_bytes())==digest
 rows.append({'path':p,'mode':mode,'git_blob':obj,'bytes':size,'sha256':digest,'working_tree_matches':True})
save('GIT_SNAPSHOT.json',{'head':HEAD,'tree':before['tree'],'files':rows,'files_count':len(rows),'bytes':sum(x['bytes'] for x in rows),'full_export_created':False})
# Fresh four statics. The design wrapper redirects its sole output only.
commands=[('bootstrap',['python3','scripts/verify_bootstrap_manifest.py']),('design',['python3',str(R/'design_wrapper.py')]),('infrastructure',['python3','scripts/validate_infrastructure.py']),('diff',['git','diff','--check',BASE,HEAD])]
results=[]
for tag,argv in commands:
 started=now();x=subprocess.run(argv,cwd=G,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True)
 (R/(tag+'.stdout')).write_bytes(x.stdout);(R/(tag+'.stderr')).write_bytes(x.stderr)
 results.append({'tag':tag,'argv':argv,'cwd':str(G),'started_at':started,'completed_at':now(),'exit_code':x.returncode,'stdout_sha256':sha(x.stdout),'stderr_sha256':sha(x.stderr)})
save('STATIC_RESULTS.json',results);assert all(x['exit_code']==0 for x in results),results
# Mechanical composition and protection proofs against the exact old source.
proof=[]
def check(name,value):assert value,name;proof.append({'check':name,'passed':True})
entry='apps/desktop/src-tauri/src/bin/native_owner_dialog_smoke.rs'
b=blob(HEAD,entry);old=blob(BASE,entry)
check('entry exactly two path literals',b.replace(b'../native_owner_dialog_test/controller.rs',b'native_owner_dialog/controller.rs').replace(b'../native_owner_dialog_test/macos.rs',b'native_owner_dialog/macos.rs')==old)
for n in ['controller.rs','macos.rs']:
 oldp='apps/desktop/src-tauri/src/bin/native_owner_dialog/'+n;newp='apps/desktop/src-tauri/src/native_owner_dialog_test/'+n
 check('helper '+n+' unchanged bytes and100644',blob(BASE,oldp)==blob(HEAD,newp) and git('ls-tree',HEAD,newp).startswith(b'100644 '))
check('no helper directory under src/bin',not any(x['path'].startswith('apps/desktop/src-tauri/src/bin/native_owner_dialog/') for x in rows))
workflow='.github/workflows/product.yml';validator='scripts/validate_infrastructure.py'
check('workflow only desktop45to60',blob(HEAD,workflow).replace(b'    timeout-minutes: 60\n',b'    timeout-minutes: 45\n')==blob(BASE,workflow))
check('guard only exact desktop cap45to60',blob(HEAD,validator).replace(b'        maximum = 60\n',b'        maximum = 45\n')==blob(BASE,validator))
boot=json.loads(blob(HEAD,'BOOTSTRAP_MANIFEST.json'));oldboot=json.loads(blob(BASE,'BOOTSTRAP_MANIFEST.json'));fields=next(k for k,v in boot.items() if isinstance(v,dict) and 'docs/execution/STATUS.md' in v)
check('bootstrap exactly93 paths',len(boot[fields])==len(oldboot[fields])==93 and boot[fields].keys()==oldboot[fields].keys())
changed=[p for p in boot[fields] if boot[fields][p]!=oldboot[fields][p]]
check('bootstrap only STATUS and validator hashes',set(changed)=={'docs/execution/STATUS.md',validator})
check('other91 bootstrap entries unchanged',sum(boot[fields][p]==oldboot[fields][p] for p in boot[fields])==91)
for p,digest in boot[fields].items():check('registered actual hash '+p,sha(blob(HEAD,p))==digest)
# All non-record source changes are enumerated, including the two renames.
source_changes=[]
for item in git('diff','--name-status','--find-renames=100%',BASE,HEAD).decode().splitlines():
 cols=item.split('\t');p=cols[-1]
 if p.startswith('docs/') or p=='BOOTSTRAP_MANIFEST.json':continue
 source_changes.append(cols)
check('exact non-record source changes count5',len(source_changes)==5)
expected={workflow,validator,entry,'apps/desktop/src-tauri/src/native_owner_dialog_test/controller.rs','apps/desktop/src-tauri/src/native_owner_dialog_test/macos.rs'}
check('exact non-record source changes paths',set(c[-1] for c in source_changes)==expected)
protected_count=0
for row in rows:
 p=row['path']
 if p.startswith('docs/') or p in expected or p=='BOOTSTRAP_MANIFEST.json':continue
 check('protected product/design unchanged '+p,blob(BASE,p)==blob(HEAD,p));protected_count+=1
reqp='docs/execution/requirements-progress.json';req=json.loads(blob(HEAD,reqp));oldreq=json.loads(blob(BASE,reqp))
# Compare original ID/status/workpackage fields recursively, not exact new evidence text.
def req_projection(d):
 if isinstance(d,list):return [req_projection(v) for v in d]
 if isinstance(d,dict):
  if 'id' in d and str(d['id']).startswith('AB-'):return {k:v for k,v in d.items() if k in ['id','status','work_package']}
  return {k:req_projection(v) for k,v in d.items() if k in ['requirements','schema_version']}
 return d
check('130 progress IDs/status/WP unchanged',req_projection(req)==req_projection(oldreq))
reqs=req['requirements'];check('progress exactly130',len(reqs)==130)
# Exact subject references (new documentation-only heads do not replace reviewed source).
for ref,paths in [('9c3850d40d78d2317142f604043fd0aaaceb2aa7',[entry,*sorted(expected-{entry,workflow,validator})]),('3a0caa9366640aab8a40911fe814fd77d417c60e',[workflow]),('53785196ec166637ca89fd732639888a1048360c',[validator])]:
 for p in paths:check('fixed reviewed source '+ref+':'+p,blob(ref,p)==blob(HEAD,p))
save('SOURCE_PROOF.json',{'head':HEAD,'base':BASE,'source_changes':source_changes,'bootstrap_changed_entries':changed,'protected_file_count':protected_count,'checks':proof,'requirements_count':130})
# Stream new archives into digest inventories without extracting their payloads.
archives=[];payloads=[];jsondocs=[]
changed_paths=git('diff','--name-only',BASE,HEAD).decode().splitlines()
for path in changed_paths:
 if not path.endswith('.tar.gz'):continue
 p=G/path;members=[];seen=set();size=0;limit=150_000_000
 with tarfile.open(p,'r:gz') as tf:
  for item in tf:
   rel=PurePosixPath(item.name);name=str(rel)
   assert item.isreg() and not rel.is_absolute() and '..' not in rel.parts and '\\' not in item.name and name not in ('','.') and name not in seen
   seen.add(name);size+=item.size;assert item.size<=50_000_000 and size<=limit
   data=tf.extractfile(item).read();assert len(data)==item.size
   row={'archive':path,'path':name,'bytes':len(data),'mode':oct(item.mode),'sha256':sha(data)};members.append(row);payloads.append(row)
   if name.endswith('.json'):
    try:jsondocs.append({'archive':path,'path':name,'document':json.loads(data)})
    except (ValueError,UnicodeError):pass
   if name.endswith('.zip'):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
     assert z.testzip() is None;zs=set();ztotal=0
     for zi in z.infolist():
      zr=PurePosixPath(zi.filename);zn=str(zr);zm=zi.external_attr>>16
      assert not zr.is_absolute() and '..' not in zr.parts and '\\' not in zi.filename and zn not in zs and stat.S_IFMT(zm) in (0,stat.S_IFREG,stat.S_IFDIR)
      zs.add(zn);ztotal+=zi.file_size;assert ztotal<=150_000_000
      if zi.is_dir():continue
      zd=z.read(zi);payloads.append({'archive':path,'container':name,'path':zn,'bytes':len(zd),'mode':oct(zm),'sha256':sha(zd),'crc32':f'{zi.CRC:08x}'})
   if name.endswith('.log.gz'):
    zd=gzip.decompress(data);assert len(zd)<=10_000_000;payloads.append({'archive':path,'container':name,'path':name[:-3],'bytes':len(zd),'mode':'derived gzip stream','sha256':sha(zd)})
 archives.append({'archive':path,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':len(members),'uncompressed_bytes':size,'safe_regular_paths_unique':True,'entries':members})
save('ARCHIVE_INVENTORY.json',archives);save('ALL_PAYLOADS.json',payloads);save('ARCHIVE_JSON_DOCUMENTS.json',jsondocs)
save('AFTER.json',state());assert state()['head']==HEAD and state()['status']=='' and state()['tree']==before['tree'] and state()['design_report_sha256']==before['design_report_sha256']
print(json.dumps({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'source_changes':len(source_changes),'protected':protected_count,'checks':len(proof),'archives':len(archives),'archive_regular_members':sum(x['members'] for x in archives),'including_nested_payloads':len(payloads),'static_exits':[x['exit_code'] for x in results]}))
