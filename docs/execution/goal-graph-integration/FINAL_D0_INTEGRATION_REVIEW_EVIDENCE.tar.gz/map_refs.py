from pathlib import Path
from collections import defaultdict
import json,hashlib,re,subprocess
R=Path(__file__).resolve().parent;G=Path('/workspace/.worktrees/goal-graph-integration')
def read(n):return json.loads((R/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
index=defaultdict(list)
for x in read('GIT_SNAPSHOT.json')['files']:index[x['sha256']].append({'kind':'fixed current Git blob','path':x['path'],'bytes':x['bytes'],'git_blob':x['git_blob']})
for x in read('ALL_PAYLOADS.json'):index[x['sha256']].append({'kind':'archived payload','archive':x['archive'],'path':x['path'],'bytes':x['bytes'],**({'container':x['container']} if 'container' in x else {})})
docs=read('ARCHIVE_JSON_DOCUMENTS.json')
# Add standalone newly imported JSON metadata too.
for p in (G/'docs/execution').rglob('*.json'):
 if str(p.relative_to(G)) in subprocess.check_output(['git','diff','--name-only','c6f6b3c2be18ecc339f1cba6a9603657739e4cd4','d0c01baa5729fa90bcc0354791f297646019da9a'],cwd=G,text=True).splitlines():
  docs.append({'archive':None,'path':str(p.relative_to(G)),'document':json.loads(p.read_text())})
refs=[]
def walk(v,where,origin):
 if isinstance(v,dict):
  digest=v.get('sha256')
  path=next((v[k] for k in ['path','file','name'] if isinstance(v.get(k),str)),None)
  if path and isinstance(digest,str) and re.fullmatch('[a-f0-9]{64}',digest):refs.append({'origin':origin,'where':where,'path':path,'sha256':digest,'bytes':next((v[k] for k in ['bytes','size'] if type(v.get(k)) is int),None),'git_blob':v.get('git_blob')})
  for k,x in v.items():walk(x,where+'/'+k,origin)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,where+'/'+str(i),origin)
for d in docs:walk(d['document'],'',{'archive':d['archive'],'path':d['path']})
resolved=[];unknown=[]
for row in refs:
 candidates=index.get(row['sha256'],[])
 if row['bytes'] is not None:candidates=[x for x in candidates if x['bytes']==row['bytes']]
 if not candidates and isinstance(row['git_blob'],str):
  x=subprocess.run(['git','cat-file','blob',row['git_blob']],cwd=G,capture_output=True)
  if x.returncode==0 and sha(x.stdout)==row['sha256'] and (row['bytes'] is None or len(x.stdout)==row['bytes']):
   candidates=[{'kind':'original retained Git object','git_blob':row['git_blob'],'bytes':len(x.stdout),'path':row['path']}]
 if candidates:
  # Favor same-archive exactpath; explicitly record all fallback identity mappings.
  candidates.sort(key=lambda x:(not(x.get('archive')==row['origin']['archive'] and x['path']==row['path']),not(x['path']==row['path']),x['kind']))
  resolved.append({**row,'resolved':candidates[0],'mapping':'exact path' if candidates[0]['path']==row['path'] else 'explicit same digest/size payload mapping; original relative/absolute alias preserved'})
 else:unknown.append(row)
(R/'REFMAP_INITIAL.json').write_text(json.dumps({'resolved':resolved,'unresolved':unknown},indent=2)+'\n')
print('resolved',len(resolved),'unresolved',len(unknown))
for x in unknown[:60]:print(json.dumps(x))
