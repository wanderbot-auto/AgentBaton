"""Run unchanged fixed validator, redirect only its generated report outside frozen tree."""
from pathlib import Path
import runpy,sys
repo=Path('/workspace/.worktrees/goal-graph-integration')
output=Path(__file__).resolve().parent/'DESIGN_VALIDATION.json'
original=Path.write_text

def report_only(self,data,*args,**kwargs):
    if self != repo/'DESIGN_VALIDATION.json':
        raise AssertionError('Validator attempted an unexpected write: '+str(self))
    return original(output,data,*args,**kwargs)
Path.write_text=report_only
sys.argv=[str(repo/'scripts/validate_design.py')]
try:runpy.run_path(sys.argv[0],run_name='__main__')
finally:Path.write_text=original
