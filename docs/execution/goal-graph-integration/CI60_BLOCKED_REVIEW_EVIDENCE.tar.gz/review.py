#!/usr/bin/env python3
"""Independent finite YAML/source/retained-annotation verification; no CI."""
from pathlib import Path
import copy,hashlib,json,subprocess,yaml
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent
HEAD='3a0caa9366640aab8a40911fe814fd77d417c60e';BASE='4d2ab1fbb9c4aa562a86de0dd127b61948fdaa2e'
author=Path('/workspace/.onboarding/native-ci-timeout60');original=Path('/workspace/.onboarding/pr16-c6f6-mac-review')
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
def check(name,value):
 assert value,name;rows.append({'name':name,'status':'passed'})
path='.github/workflows/product.yml';before=git('show',BASE+':'+path);after=git('show',HEAD+':'+path)
(O/'before.yml').write_bytes(before);(O/'after.yml').write_bytes(after)
check('exact source parent',git('rev-parse',HEAD+'^').decode().strip()==BASE)
check('only product workflow changed',git('diff','--name-only',BASE,HEAD).decode().splitlines()==[path])
check('single exact 45-to60 replacement and nothing else',before.count(b'    timeout-minutes: 45\n')==1 and after==before.replace(b'    timeout-minutes: 45\n',b'    timeout-minutes: 60\n'))
check('working workflow still fixedsource',after==(R/path).read_bytes())
a=yaml.safe_load(before);b=yaml.safe_load(after)
check('old/new job limit typed int45/int60',type(a['jobs']['desktop']['timeout-minutes'])is int and type(b['jobs']['desktop']['timeout-minutes'])is int and a['jobs']['desktop']['timeout-minutes']==45 and b['jobs']['desktop']['timeout-minutes']==60)
c=copy.deepcopy(b);c['jobs']['desktop']['timeout-minutes']=45
check('entire parsed workflow unchanged after reversing one limit',a==c)
for key in ['runs-on','strategy','steps']:
 check('desktop '+key+' exactly unchanged',a['jobs']['desktop'][key]==b['jobs']['desktop'][key])
check('same standard hosted macOS matrix and parallel2',b['jobs']['desktop']['strategy']['matrix']=={'os':['macos-15','macos-15-intel']}and b['jobs']['desktop']['strategy']['max-parallel']==2)
check('all job IDs unchanged',list(a['jobs'])==list(b['jobs']))
check('global permissions unchanged',a.get('permissions')==b.get('permissions'))
for name in a['jobs']:
 if name!='desktop':check('all other job fields unchanged '+name,a['jobs'][name]==b['jobs'][name])
check('no skip/per-step/per-test/product changes',a==c and git('diff','--name-only',BASE,HEAD).decode().splitlines()==[path])
annotations=(original/'intel-check-annotations.json').read_bytes()
check('author annotation copy byteidentical original retained API',(author/'intel-check-annotations.json').read_bytes()==annotations)
(O/'intel-annotations.json').write_bytes(annotations)
check('official annotation exactly45m0s for original c6f6 source',any(x['message']=='The job has exceeded the maximum execution time of 45m0s'and'c6f6b3c2be18ecc339f1cba6a9603657739e4cd4'in x['blob_href']for x in json.loads(annotations)))
job=json.loads((original/'intel-job-terminal.json').read_text())
check('Intel actual job123175557621 cancelled original Product run',job['id']==123175557621 and job['run_id']==40790894775 and job['name']=='Product / macos-15-intel'and job['conclusion']=='cancelled')
steps={s['name']:s for s in job['steps']}
check('Intel package and defaultrelease audit not passed',steps['Audit the actual default release application for test controls']['conclusion']=='skipped'and steps['Package development application and evidence']['conclusion']=='skipped')
artifacts=json.loads((original/'intel-artifacts-terminal.json').read_text())['artifacts'];artifact=next(x for x in artifacts if x['id']==12862609620)
raw=original/'intel-native-artifact.zip'
check('retained Intel native artifact exact official size+digest',raw.stat().st_size==artifact['size_in_bytes']and'sha256:'+sha(raw.read_bytes())==artifact['digest'])
check('artifact binds old checkout and is native not new developmentpackage',artifact['name']=='native-webview-macos-15-intel-e963523c04b27d99d44a7893b161b5180b9818e3'and artifact['workflow_run']['head_sha']=='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4')
summary=(original/'SUMMARY.md').read_text()
check('separate ARM missinghelper vs Intel timeout causes preserved','Intel stopped during release desktop/Core compilation without the ARM missing-binary error'in summary and'45m0s'in summary)
check('initial author checker KeyError retained','KeyError: \'rust\''in(author/'initial-check.stderr').read_text())
result={'subject':HEAD,'base':BASE,'status':'limited_source_ready','count':len(rows),'checks':rows,'workflow_sha256_before':sha(before),'workflow_sha256_after':sha(after),'annotation_sha256':sha(annotations),'Intel_original_artifact':{'id':artifact['id'],'digest':artifact['digest'],'bytes':raw.stat().st_size},'scope':'pure YAML/bytes and cached official records/digest, no API or CI actions','not_run':['CI','Cargo/compile/daemon/Nodebuild/GUI','new packages/install/signing'],'authorization_boundary':'Root confirms publicrepo/same approved hostedrunner and existing quotas; no resource/purchase/production authority inferred'}
(O/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(rows),'finite CI60 review controls; no CI or product execution')
