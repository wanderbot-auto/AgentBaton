import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

root = Path('/workspace/.worktrees/goal-graph-integration')
out = Path('/workspace/.onboarding/native-module-path-root')
target = Path('/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


expected = {'batond': '188f1df3b29798e8cdc6735937af688b4e6a14fbdbdf60f0812da225cf051506',
            'baton': '57798c44229c1a7ae7c99b1e1a31b7b8c3549a8f6be5fbfe64df1b0258402468'}
staged = {'batond': 'fc5d33dca48d4b46dc7c5aa8eaf2235be8222f04ea959ba139561c0fa380d77e',
          'baton': '9065fa79d6381b51364d9304eb98aea16cf355d0cb81024134a07fb6ddef7c73'}
tracked = [p for p in subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0') if p]
before = {name: sha(root / name) for name in tracked}
tools = []
for name in ['batond', 'baton']:
    path = target / 'debug' / name
    source = root / 'apps/desktop/src-tauri/binaries' / (name + '-x86_64-unknown-linux-gnu')
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and sha(path) == expected[name]
    assert stat.S_ISREG(source.lstat().st_mode) and sha(source) == staged[name]
    backup = out / 'backup' / name
    assert not backup.exists()
    os.link(path, backup)
    tools.append({'name': name, 'path': str(path), 'backup': str(backup), 'inode': metadata.st_ino,
                  'mode': stat.S_IMODE(metadata.st_mode), 'nlink_before': metadata.st_nlink,
                  'original_sha256': expected[name], 'macro_resource': str(source), 'macro_resource_sha256': staged[name]})
record = {'source': '9c3850d40d78d2317142f604043fd0aaaceb2aa7',
          'integration_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_hashes': before, 'tools': tools,
          'dimension': 'Linux actual Rust check of Native test targets/module paths and format; no test execution/link or current Mac proof. Existing old5541 raw resource files are macro resources, never executed; no AppKit/Core/Provider runtime claim.'}
(out / 'BEFORE.json').write_text(json.dumps(record, indent=2) + '\n')
env = os.environ.copy()
env.update(CARGO_HOME='/workspace/.toolchains/cargo', RUSTUP_HOME='/workspace/.toolchains/rustup',
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2', RUST_TEST_THREADS='1', CARGO_TARGET_DIR=str(target))
env['PATH'] = env['CARGO_HOME'] + '/bin:' + env['PATH']
sysroot = '/workspace/.toolchains/linux-ui/sysroot'
env.update(PKG_CONFIG_SYSROOT_DIR=sysroot,
           PKG_CONFIG_LIBDIR=sysroot + '/usr/lib/x86_64-linux-gnu/pkgconfig:' + sysroot + '/usr/share/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig',
           LD_LIBRARY_PATH=sysroot + '/usr/lib/x86_64-linux-gnu', LIBRARY_PATH=sysroot + '/usr/lib/x86_64-linux-gnu')
commands = [
    ['cargo', 'check', '--locked', '--offline', '--manifest-path', 'apps/desktop/src-tauri/Cargo.toml', '--features', 'native-smoke,custom-protocol', '--tests', '--bin', 'agentbaton-native-owner-dialog-smoke'],
    ['cargo', 'fmt', '--manifest-path', 'apps/desktop/src-tauri/Cargo.toml', '--check'],
]
results = []
restored = []
try:
    for i, command in enumerate(commands):
        log = out / ('native-' + str(i) + '.log')
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with log.open('wb') as stream:
            result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        results.append({'command': command, 'start': start, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'exit_code': result.returncode, 'log': log.name, 'sha256': sha(log)})
        if result.returncode:
            break
finally:
    for item in tools:
        path, backup = Path(item['path']), Path(item['backup'])
        assert sha(backup) == item['original_sha256'] and backup.stat().st_ino == item['inode']
        observed = sha(path)
        assert observed in [item['original_sha256'], item['macro_resource_sha256']], 'Unknown mutation: preserve backup and stop'
        if observed == item['original_sha256'] and path.stat().st_ino == item['inode']:
            backup.unlink()
        else:
            os.replace(backup, path)
        assert sha(path) == item['original_sha256'] and path.stat().st_ino == item['inode']
        assert path.stat().st_nlink == item['nlink_before']
        restored.append({'path': str(path), 'observed_after_build': observed, 'after_restore': sha(path), 'same_inode_and_nlink': True})
    after = {name: sha(root / name) for name in tracked}
    result = {'source': record['source'], 'integration_head': record['integration_head'], 'commands': results,
              'source_before_after_equal': before == after, 'changed': [p for p in tracked if before[p] != after[p]],
              'tool_restoration': restored, 'resource_files_unchanged': all(sha(Path(p['macro_resource'])) == p['macro_resource_sha256'] for p in tools),
              'temporary_links_created': 0, 'dimension': record['dimension']}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['source', 'integration_head', 'commands', 'source_before_after_equal', 'tool_restoration']}), flush=True)
