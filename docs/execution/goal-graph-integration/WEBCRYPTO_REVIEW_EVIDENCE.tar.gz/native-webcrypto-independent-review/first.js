
(async () => {
 const invoke = window.__TAURI_INTERNALS__.invoke;
 const require = (value, message) => { if (!value) throw Error(message); };
 const result = value => { require(!value.error, JSON.stringify(value.error)); return value.result; };
 const webCryptoProof = async checkpoint => {
  require(typeof window.TextEncoder==='function' && typeof window.crypto?.subtle?.digest==='function','real WebView WebCrypto/TextEncoder unavailable');
  const input="{\"text\":\"原文证据🔒\",\"inode\":1152921504606846979,\"u64\":9223372036854775809,\"max\":18446744073709551615}\n";
  const bytes=new window.TextEncoder().encode(input);
  const hashed=await window.crypto.subtle.digest('SHA-256',bytes);
  const sha256=Array.from(new Uint8Array(hashed),byte=>byte.toString(16).padStart(2,'0')).join('');
  return {version:1,checkpoint,available:true,source:'window.crypto.subtle.digest',algorithm:'SHA-256',encoding:'UTF-8',input,input_bytes:bytes.byteLength,sha256};
 };
 try {
  const deadline = Date.now() + 10000;
  while (!document.querySelector('#root')?.children.length) {
   require(Date.now() < deadline, 'actual built frontend did not mount');
   await new Promise(r => setTimeout(r, 25));
  }
  const initial = result(await invoke('system_snapshot'));
  require(initial.tasks.length === 0, 'private runtime must start empty');
  const projects=result(await invoke('projects_list'));
  require(Array.isArray(projects)&&projects.length===1&&projects[0].name==='Native readonly Goal project'&&!projects[0].archived,'generated registered readonly project fixture is absent');
  const fixtureProject=projects[0];
  let projectSelect;
  while(!(projectSelect=document.querySelector('.composer-project select'))||![...projectSelect.options].some(option=>option.value===fixtureProject.id)){require(Date.now()<deadline,'real project composer choice did not load');await new Promise(r=>setTimeout(r,25));}
  Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set.call(projectSelect,fixtureProject.id);
  projectSelect.dispatchEvent(new Event('change',{bubbles:true}));
  const goal='原生 WebView → IPC persistent task';
  const input=document.querySelector('[data-testid="goal-input"],#goal');
  const form=document.querySelector('[data-testid="goal-composer"],form.create-task');
  require(input && form, 'actual product goal composer is absent');
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(input,goal);
  input.dispatchEvent(new Event('input',{bubbles:true}));
  let button=form.querySelector('button[type="submit"]');
  while(button.disabled){require(Date.now()<deadline,'real goal submit never became enabled');await new Promise(r=>setTimeout(r,25));}
  button.click();
  let task;
  while(!task){
   const snapshot=result(await invoke('system_snapshot'));
   task=snapshot.tasks.find(t=>t.goal===goal);
   require(Date.now()<deadline,'actual UI submit did not create persistent task');
   if(!task)await new Promise(r=>setTimeout(r,25));
  }
  require(task.state === 'draft', 'create falsely marked dispatch');
  require(task.project_id===fixtureProject.id,'actual UI task did not bind the chosen registered fixture project');
  const rendered=()=>[...document.querySelectorAll('[data-task-id]')].some(node=>node.dataset.taskId===task.id)
   || [...document.querySelectorAll('.task-list strong,.inspector h2')].some(node=>node.textContent===goal);
  while(!rendered()){require(Date.now()<deadline,'UI did not render the real created task');await new Promise(r=>setTimeout(r,25));}
  const args={goal:'Native IPC idempotency fixture',idempotencyKey:'native-smoke-create'};
  const auxiliary=result(await invoke('tasks_create',args));
  const retry = result(await invoke('tasks_create',args));
  require(retry.id === auxiliary.id, 'idempotent retry duplicated task');
  const bad = await invoke('tasks_create',{goal:'',idempotencyKey:'native-smoke-invalid'});
  require(bad.error?.code === 'INVALID_REQUEST', 'real invalid input did not fail');
  const events = result(await invoke('events_subscribe',{cursor:0,limit:100}));
  require(events.events.some(e=>e.aggregate_id===task.id), 'real journal event absent');
  const beforeData=result(await invoke('system_snapshot')).sequence;
  const dataPolicies=result(await invoke('data_validation_policies_list',{taskId:task.id}));
  const dataRecords=result(await invoke('data_validations_list',{taskId:task.id}));
  require(Array.isArray(dataPolicies)&&dataPolicies.length===0&&Array.isArray(dataRecords)&&dataRecords.length===0,'fresh task must have no fabricated data approvals or receipts');
  const artifacts=document.querySelector('#tab-artifacts');
  require(artifacts,'actual task Artifacts tab missing');artifacts.click();
  let dataPanel;
  while(!(dataPanel=document.querySelector('[data-testid="data-contract-validation"]'))){require(Date.now()<deadline,'actual data contract panel did not mount');await new Promise(r=>setTimeout(r,25));}
  const folded=dataPanel.querySelector('details');
  require(folded&&!folded.open,'data contract controls must start folded');folded.querySelector('summary').click();
  while(dataPanel.querySelector('form>fieldset')?.disabled!==false){require(Date.now()<deadline,'real native data-list read did not reconcile successfully');await new Promise(r=>setTimeout(r,25));}
  require(!dataPanel.querySelector('[role="alert"]'),'real native data-list read failed');
  const approve=dataPanel.querySelector('button[type="submit"]');
  require(approve&&approve.disabled,'draft without stopped session must not enable native data approval');
  require(result(await invoke('system_snapshot')).sequence===beforeData,'read-only data controls unexpectedly mutated history');
  const beforeCommand=result(await invoke('system_snapshot')).sequence;
  const commandPolicies=result(await invoke('command_validation_policies_list',{taskId:task.id}));
  const commandRecords=result(await invoke('command_validations_list',{taskId:task.id}));
  require(Array.isArray(commandPolicies)&&commandPolicies.length===0&&Array.isArray(commandRecords)&&commandRecords.length===0,'fresh task must have no fabricated command approval or execution');
  let commandPanel;
  while(!(commandPanel=document.querySelector('[data-testid="command-validation"]'))){require(Date.now()<deadline,'actual command validation panel did not mount');await new Promise(r=>setTimeout(r,25));}
  const commandFolded=commandPanel.querySelector('details');
  require(commandFolded&&!commandFolded.open,'command validation controls must start folded');commandFolded.querySelector('summary').click();
  while(commandPanel.querySelector('form>fieldset')?.disabled!==false){require(Date.now()<deadline,'real native command-list read did not reconcile successfully');await new Promise(r=>setTimeout(r,25));}
  require(!commandPanel.querySelector('[role="alert"]'),'real native command-list read failed');
  const commandApprove=commandPanel.querySelector('button[type="submit"]');
  require(commandApprove&&commandApprove.disabled,'draft without stopped session must not enable native command approval');
  require(result(await invoke('system_snapshot')).sequence===beforeCommand,'read-only command controls unexpectedly mutated history');
  const beforeGoal=result(await invoke('system_snapshot')).sequence;
  require(typeof task.project_id==='string'&&task.project_id.length>0,'real fixture task lacks its Goal project reference');
  await invoke('native_smoke_report',{result:{ok:true,goalReadonlyCheckpoint:'before',webCrypto:await webCryptoProof('before')}});
  const goalGrants=result(await invoke('grants_list',{projectId:task.project_id}));
  const goalScopes=result(await invoke('goal_scopes_list',{taskId:task.id}));
  require(Array.isArray(goalGrants)&&goalGrants.length===0&&Array.isArray(goalScopes)&&goalScopes.length===0,'fresh task must have no fabricated root grant or Goal scope');
  const detailsTab=document.querySelector('#tab-details');require(detailsTab,'actual task Details tab missing');detailsTab.click();
  let goalPanel;
  while(!(goalPanel=document.querySelector('[data-testid="goal-planning"]'))){require(Date.now()<deadline,'actual Goal panel did not mount');await new Promise(r=>setTimeout(r,25));}
  const goalFolded=goalPanel.querySelector(':scope > details');
  require(goalFolded&&!goalFolded.open,'Goal controls must start folded');goalFolded.querySelector('summary').click();
  while(goalPanel.querySelector('form>fieldset')?.disabled!==false||goalPanel.querySelector('[aria-busy]')?.getAttribute('aria-busy')!=='false'){require(Date.now()<deadline,'real native Goal lists did not reconcile successfully');await new Promise(r=>setTimeout(r,25));}
  require(!goalPanel.querySelector('[role="alert"]'),'real native Goal scope-list read failed');
  require(/尚无独立原生批准的 Goal 范围|No native-approved Goal scope yet/.test(goalPanel.textContent),'actual empty Goal-scope state absent');
  const goalApprove=goalPanel.querySelector('button[type="submit"]');
  require(goalApprove&&goalApprove.matches(':disabled'),'no eligible root grant must not enable native Goal approval');
  const goalActionNames=['保存初始计划提议','保存修订计划提议','读取就绪预览','Store initial plan proposal','Store revised plan proposal','Read readiness preview'];
  require([...goalPanel.querySelectorAll('button')].filter(button=>goalActionNames.includes(button.textContent.trim())).every(button=>button.matches(':disabled')),'empty scope must not enable plan submission or readiness preview');
  require(!goalPanel.querySelector('textarea[spellcheck="false"]')||goalPanel.querySelector('textarea[spellcheck="false"]').matches(':disabled'),'empty scope must not enable plan JSON editing');
  require(!goalPanel.querySelector('[data-testid="goal-execution"]'),'scope-free Goal controls must not mount or activate execution UI');
  const beforeGoalExecution=result(await invoke('system_snapshot')).sequence;
  require(beforeGoalExecution===beforeGoal,'Goal execution reads must start inside the original readonly interval');
  const executionRuns=result(await invoke('goal_runs_list',{taskId:task.id}));
  require(Array.isArray(executionRuns)&&executionRuns.length===0,'fresh task must have no Goal execution runs');
  const absentRunId='native-readonly-missing-goal-run';
  const missingExecutionRun=await invoke('goal_runs_get',{runId:absentRunId});
  require(missingExecutionRun?.error?.code==='NOT_FOUND'&&missingExecutionRun.error.side_effect_state==='not_started'&&!Object.prototype.hasOwnProperty.call(missingExecutionRun,'result'),'a fixed missing run must return the actual Core denial without a fabricated result');
  const afterGoalExecution=result(await invoke('system_snapshot')).sequence;
  require(afterGoalExecution===beforeGoalExecution,'readonly execution list/get unexpectedly mutated history');
  const beforeGoalGraph=result(await invoke('system_snapshot')).sequence;
  require(beforeGoalGraph===beforeGoal&&beforeGoalGraph===beforeGoalExecution,'Graph reads must share the original Goal/execution readonly interval');
  const graphRuns=result(await invoke('goal_graph_runs_list',{taskId:task.id}));
  require(Array.isArray(graphRuns)&&graphRuns.length===0,'fresh task must have no Goal graph runs');
  const absentGraphRunId='native-readonly-missing-goal-graph-run';
  const missingGraphRun=await invoke('goal_graph_runs_get',{runId:absentGraphRunId});
  require(missingGraphRun?.error?.code==='NOT_FOUND'&&missingGraphRun.error.side_effect_state==='not_started'&&!Object.prototype.hasOwnProperty.call(missingGraphRun,'result'),'fixed missing Graph run must return the actual Core denial without a result');
  const afterGoalGraph=result(await invoke('system_snapshot')).sequence;
  require(afterGoalGraph===beforeGoalGraph,'readonly Graph list/get unexpectedly mutated history');
  const afterGoal=result(await invoke('system_snapshot')).sequence;
  require(afterGoal===beforeGoal,'read-only Goal controls unexpectedly mutated history');
  await invoke('native_smoke_report',{result:{ok:true,goalReadonlyCheckpoint:'after',webCrypto:await webCryptoProof('after')}});
  document.querySelector('#tab-conversation').click();
  while(document.querySelector('#tab-conversation')?.getAttribute('aria-selected')!=='true'){require(Date.now()<deadline,'return to conversation did not settle');await new Promise(r=>setTimeout(r,25));}
  await invoke('native_smoke_report',{result:{ok:true,webCrypto:await webCryptoProof('first'),domMounted:true,realComposerSubmitted:true,realTaskRendered:true,taskId:task.id,projectId:task.project_id,idempotent:true,invalidInputRejected:true,journal:true,dataContractLists:true,dataContractEmptyControls:true,readonlyDataNoMutation:true,commandContractLists:true,commandContractEmptyControls:true,readonlyCommandNoMutation:true,goalScopeLists:true,goalScopeEmptyControls:true,readonlyGoalNoMutation:true,goalReadonlySequence:{before:beforeGoal,after:afterGoal},goalExecutionLists:true,goalExecutionMissingRunDenied:true,readonlyGoalExecutionNoMutation:true,goalExecutionReadonlySequence:{before:beforeGoalExecution,after:afterGoalExecution},goalExecutionMissingRun:{run_id:absentRunId,code:missingExecutionRun.error.code,side_effect_state:missingExecutionRun.error.side_effect_state},goalGraphLists:true,goalGraphMissingRunDenied:true,readonlyGoalGraphNoMutation:true,goalGraphReadonlySequence:{before:beforeGoalGraph,after:afterGoalGraph},goalGraphMissingRun:{run_id:absentGraphRunId,code:missingGraphRun.error.code,side_effect_state:missingGraphRun.error.side_effect_state}}});
 } catch (error) { await invoke('native_smoke_report',{result:{ok:false,error:String(error)}}); }
})();
