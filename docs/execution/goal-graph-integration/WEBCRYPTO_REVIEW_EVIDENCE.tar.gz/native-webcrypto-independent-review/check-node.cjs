const fs = require('node:fs');
const assert = require('node:assert/strict');
const directory = '/workspace/.onboarding/native-webcrypto-independent-review';
const expectedHash='d29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892';
const expectedInput='{"text":"原文证据🔒","inode":1152921504606846979,"u64":9223372036854775809,"max":18446744073709551615}\n';
function factory(script, window) {
 const expression=script.match(/const webCryptoProof = (async checkpoint => \{.*?\n \});/s)?.[1];
 assert.ok(expression, 'production injected proof function is present');
 return new Function('window', `const require=(value,message)=>{if(!value)throw Error(message)};return (${expression});`)(window);
}
(async()=>{
 const observations=[];
 for(const [filename,contexts] of [['first.js',['before','after','first']],['second.js',['reopened']]]) {
  const script=fs.readFileSync(`${directory}/${filename}`,'utf8');
  new Function(script);
  assert.ok(!script.includes(expectedHash), 'no prefilled expected digest in actual JS');
  const proof=factory(script,{TextEncoder:globalThis.TextEncoder,crypto:globalThis.crypto});
  for(const context of contexts) {
   const result=await proof(context);
   assert.deepEqual(result,{version:1,checkpoint:context,available:true,source:'window.crypto.subtle.digest',algorithm:'SHA-256',encoding:'UTF-8',input:expectedInput,input_bytes:109,sha256:expectedHash});
   observations.push({script:filename,context,input_bytes:result.input_bytes,sha256:result.sha256});
  }
  const unavailable=factory(script,{TextEncoder:globalThis.TextEncoder});
  await assert.rejects(()=>unavailable('before'),/WebCrypto\/TextEncoder unavailable/);
  const encoderUnavailable=factory(script,{crypto:globalThis.crypto});
  await assert.rejects(()=>encoderUnavailable('before'),/WebCrypto\/TextEncoder unavailable/);
 }
 const rounded=JSON.stringify(JSON.parse(expectedInput))+'\n';
 const roundedHash=Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(rounded))).toString('hex');
 assert.notEqual(roundedHash,expectedHash);
 assert.equal(rounded.endsWith('\n'),true);
 assert.ok(!rounded.includes('18446744073709551615'));
 assert.ok(!rounded.includes('1152921504606846979'));
 const result={dimension:'actual Node global WebCrypto/TextEncoder only; NOT Native WebView/macOS',node:process.version,syntax_scripts:2,real_function_contexts:4,unavailable_negative_checks:4,observations,rounded_json_sha256:roundedHash,rounded_json_changed_original:true};
 console.log(JSON.stringify(result,null,2));
 fs.writeFileSync(`${directory}/node-result.json`,JSON.stringify(result,null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1});
