
(async () => {
 const invoke = window.__TAURI_INTERNALS__.invoke;
 const require = (value,message) => { if(!value) throw Error(message); };
 const result = value => { require(!value.error, JSON.stringify(value.error)); return value.result; };
 const webCryptoProof = async checkpoint => {
  require(typeof window.TextEncoder==='function' && typeof window.crypto?.subtle?.digest==='function','real WebView WebCrypto/TextEncoder unavailable');
  const input="{\"text\":\"原文证据🔒\",\"inode\":1152921504606846979,\"u64\":9223372036854775809,\"max\":18446744073709551615}\n";
  const bytes=new window.TextEncoder().encode(input);
  const hashed=await window.crypto.subtle.digest('SHA-256',bytes);
  const sha256=Array.from(new Uint8Array(hashed),byte=>byte.toString(16).padStart(2,'0')).join('');
  return {version:1,checkpoint,available:true,source:'window.crypto.subtle.digest',algorithm:'SHA-256',encoding:'UTF-8',input,input_bytes:bytes.byteLength,sha256};
 };
 try {
  const deadline=Date.now()+10000;
  while (!document.querySelector('#root')?.children.length) { require(Date.now()<deadline,'reopened frontend did not mount'); await new Promise(r=>setTimeout(r,25)); }
  const snapshot=result(await invoke('system_snapshot'));
  require(snapshot.tasks.length===2,'restart lost/duplicated persisted tasks');
  const task=snapshot.tasks.find(t=>t.goal==='原生 WebView → IPC persistent task'); require(task,'UI-created task absent'); require(task.state==='draft','restart changed task state');
  const cancelled=result(await invoke('tasks_cancel',{taskId:task.id,expectedRevision:task.revision,idempotencyKey:'native-smoke-cancel'}));
  require(cancelled.state==='cancelled','draft cancellation failed');
  const events=result(await invoke('events_subscribe',{cursor:0,limit:100}));
  require(events.events.at(-1)?.payload.stop_evidence==='no_attempt_dispatched','stop evidence absent');
  await invoke('native_smoke_report',{result:{ok:true,webCrypto:await webCryptoProof('reopened'),domMounted:true,taskId:task.id,projectId:task.project_id,restartPersisted:true,draftCancelled:true,stopEvidence:true}});
 } catch(error) { await invoke('native_smoke_report',{result:{ok:false,error:String(error)}}); }
})();
