import ast,hashlib,json,pathlib,re,subprocess,sys
ROOT=pathlib.Path('/workspace/.worktrees/native-webcrypto-smoke')
OUT=pathlib.Path('/workspace/.onboarding/native-webcrypto-independent-review')
BASE='652c5f0'
CANDIDATE='579f4ca9ab07d1fd3039ab71ad506af47ca237aa'
SOURCE=['apps/desktop/src-tauri/src/bin/native_smoke.rs','scripts/native-run.py','apps/desktop/src-tauri/tests/test_native_runner.py']
old={p:subprocess.check_output(['git','show',f'{BASE}:{p}'],cwd=ROOT,text=True) for p in SOURCE}
new={p:(ROOT/p).read_text() for p in SOURCE}
checks={}
checks['candidate_head_exact']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
changed=subprocess.check_output(['git','diff','--name-only',f'{BASE}..{CANDIDATE}'],cwd=ROOT,text=True).splitlines()
checks['scope_only_three_sources_four_docs']=len(changed)==7 and all(p in SOURCE or p.startswith('docs/execution/native-webcrypto-smoke/') for p in changed)
sha={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in changed}
author=json.loads(pathlib.Path('/workspace/.onboarding/native-webcrypto-smoke/manifest.json').read_text())
checks['author_source_hashes_match']=all(sha[p]==digest for p,digest in author['source_sha256'].items())
def raw(source,name):
 return re.search(r'const '+name+r': &str = r#"(.*?)"#;',source,re.S).group(1)
rs=SOURCE[0]
for name in ['GOAL_READONLY_SQL','GOAL_EXECUTION_READONLY_SQL','GOAL_GRAPH_READONLY_SQL']:
 checks[name+'_byte_identical']=raw(old[rs],name)==raw(new[rs],name)
for name in ['FIRST','SECOND']:
 candidate=raw(new[rs],name)
 clean=re.sub(r" const webCryptoProof = async checkpoint => \{.*?\n \};\n",'',candidate,flags=re.S)
 for checkpoint in ['before','after']: clean=clean.replace(",webCrypto:await webCryptoProof('"+checkpoint+"')",'')
 for checkpoint in ['first','reopened']: clean=clean.replace("webCrypto:await webCryptoProof('"+checkpoint+"'),",'')
 checks[name+'_old_script_preserved_except_additive_proof']=clean==raw(old[rs],name)
 checks[name+'_no_static_digest_in_js']='d29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892' not in candidate
 checks[name+'_one_real_digest_call']='await window.crypto.subtle.digest(\'SHA-256\',bytes)' in candidate and candidate.count('subtle.digest(')==1
 (OUT/f'{name.lower()}.js').write_text(candidate)
module_marker='#[cfg(test)]\nmod fixture_tests {'
old_module=old[rs][old[rs].index(module_marker):]
old_module_prefix=old_module[:old_module.rfind('\n}')]
new_module=new[rs][new[rs].index(module_marker):]
checks['all_existing_rust_test_bodies_preserved']=new_module.startswith(old_module_prefix)
old_rust_count=old_module.count('#[test]')
new_rust_count=new_module.count('#[test]')
py=SOURCE[2]
def tests(source):
 tree=ast.parse(source)
 return {f'{cls.name}.{f.name}':ast.dump(f,include_attributes=False) for cls in tree.body if isinstance(cls,ast.ClassDef) for f in cls.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
old_tests,new_tests=tests(old[py]),tests(new[py])
checks['all_existing_python_test_asts_preserved']=all(new_tests.get(name)==body for name,body in old_tests.items())
runner=SOURCE[1]
def named_function(source,name):
 tree=ast.parse(source)
 return next(ast.get_source_segment(source,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
old_validator=named_function(old[runner],'native_report_error')
new_validator=named_function(new[runner],'native_report_error')
removed="    crypto_error = webcrypto_report_error(report)\n    if crypto_error:\n        return crypto_error\n"
checks['old_report_validator_preserved_plus_crypto']=new_validator.replace(removed,'')==old_validator
checks['debug_only_compile_guard']='#\u005bcfg(not(debug_assertions))\u005d\ncompile_error!' in new[rs]
checks['feature_required_native_smoke_binary']='required-features = ["native-smoke"]' in (ROOT/'apps/desktop/src-tauri/Cargo.toml').read_text()
checks['no_production_or_manifest_or_ci_diff']=all(p in SOURCE or p.startswith('docs/execution/native-webcrypto-smoke/') for p in changed)
for p in SOURCE[1:]: compile(new[p],str(ROOT/p),'exec')
report={'baseline':BASE,'candidate':CANDIDATE,'source_sha256':{p:sha[p] for p in SOURCE},'all_changed_sha256':sha,'checks':checks,'existing_rust_tests':old_rust_count,'new_total_rust_test_bodies':new_rust_count,'existing_python_tests':len(old_tests),'new_total_python_tests':len(new_tests)}
(OUT/'preservation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert all(checks.values()),[k for k,v in checks.items() if not v]
