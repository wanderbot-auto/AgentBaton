from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('/workspace/.worktrees/native-webcrypto-smoke')
out=Path('/workspace/.onboarding/native-webcrypto-independent-review')
expected='579f4ca9ab07d1fd3039ab71ad506af47ca237aa'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected
paths=['apps/desktop/src-tauri/src/bin/native_smoke.rs','scripts/native-run.py','apps/desktop/src-tauri/tests/test_native_runner.py']
def source_hashes(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=source_hashes()
(out/'cargo-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
assets={
 'apps/desktop/dist':'/workspace/.worktrees/goal-graph-integration/apps/desktop/dist',
 'apps/desktop/src-tauri/binaries':'/workspace/.worktrees/goal-graph-integration/apps/desktop/src-tauri/binaries',
}
assetmap={}
for dest,target in assets.items():
 destination=root/dest; target=Path(target)
 assert not os.path.lexists(destination),f'Preserve preexisting destination: {destination}'
 assert target.is_dir(),str(target)
 assetmap[dest]={'target':str(target),'files_sha256':{str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in target.rglob('*') if p.is_file()},'purpose':'existing retained assets for exact unit/Clippy compilation only; not newly packaged or native-run artifacts'}
(out/'assetmap.json').write_text(json.dumps(assetmap,indent=2)+'\n')
env=os.environ.copy()
sysroot='/workspace/.toolchains/linux-ui/sysroot'
env.update(CARGO_TARGET_DIR='/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target',CARGO_HOME='/workspace/.toolchains/cargo',RUSTUP_HOME='/workspace/.toolchains/rustup',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1',PKG_CONFIG_SYSROOT_DIR=sysroot,PKG_CONFIG_LIBDIR=f'{sysroot}/usr/lib/x86_64-linux-gnu/pkgconfig:{sysroot}/usr/share/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig',LD_LIBRARY_PATH=f'{sysroot}/usr/lib/x86_64-linux-gnu',LIBRARY_PATH=f'{sysroot}/usr/lib/x86_64-linux-gnu',CARGO_TERM_COLOR='never')
env['PATH']=env['CARGO_HOME']+'/bin:'+env['PATH']
commands=[
 ['rustfmt','--edition','2021','--check','apps/desktop/src-tauri/src/bin/native_smoke.rs'],
 ['cargo','test','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--features','native-smoke,custom-protocol','--bin','agentbaton-native-smoke','--','--test-threads=1'],
 ['cargo','clippy','--locked','--manifest-path','apps/desktop/src-tauri/Cargo.toml','--features','native-smoke,custom-protocol','--bin','agentbaton-native-smoke','--','-D','warnings'],
]
results=[]; created=[]
try:
 for dest,target in assets.items():
  destination=root/dest; destination.symlink_to(target,target_is_directory=True); created.append((destination,target))
 for index,command in enumerate(commands):
  print('RUN',index,' '.join(command),flush=True)
  started=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
  log=out/f'native-lease-{index:02d}.log'
  with log.open('w') as handle: result=subprocess.run(command,cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT)
  item={'command':command,'cwd':str(root),'started_at_utc':started,'duration_seconds':round(time.monotonic()-clock,3),'exit_code':result.returncode,'log':str(log)}
  results.append(item)
  (out/'native-lease-commands.json').write_text(json.dumps(results,indent=2)+'\n')
  print('EXIT',index,result.returncode,'elapsed',item['duration_seconds'],flush=True)
  if result.returncode:
   print(log.read_text()[-12000:],flush=True)
   break
finally:
 for destination,target in reversed(created):
  assert destination.is_symlink() and str(destination.readlink())==target, f'Unexpected destination changed; do not remove: {destination}'
  destination.unlink()
 after=source_hashes();(out/'cargo-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
 status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True)
 result={'candidate':expected,'commands':results,'before_after_sources_identical':before==after,'assetmap':str(out/'assetmap.json'),'own_exact_symlinks_removed':True,'candidate_status':status,'lease_environment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_HOME','RUSTUP_HOME','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','RUST_TEST_THREADS','PKG_CONFIG_SYSROOT_DIR','PKG_CONFIG_LIBDIR','LD_LIBRARY_PATH','LIBRARY_PATH']}}
 (out/'native-lease.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2),flush=True)
 assert before==after and status=='','Unexpected source/status mutation'
if len(results)!=3 or any(item['exit_code'] for item in results): raise SystemExit(1)
