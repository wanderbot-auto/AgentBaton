from pathlib import Path,PurePosixPath
import json,zipfile,hashlib,stat
O=Path(__file__).parent;api=json.loads((O/'artifacts-terminal.json').read_bytes());inv=[]
for a in api['artifacts']:
 if not a['name'].startswith(('frontend-real-ipc-','provider-contract-')):continue
 p=O/(str(a['id'])+'.zip');b=p.read_bytes();assert len(b)==a['size_in_bytes'];assert 'sha256:'+hashlib.sha256(b).hexdigest()==a['digest'];assert a['workflow_run']['id']==40790894775 and a['workflow_run']['head_sha']=='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4'
 dest=O/('ui-artifact' if a['name'].startswith('frontend') else 'provider-artifact');dest.mkdir();rows=[];names=set();total=0
 with zipfile.ZipFile(p) as z:
  assert len(z.infolist())<=4096 and z.testzip() is None
  for m in z.infolist():
   n=PurePosixPath(m.filename);assert not n.is_absolute() and '..' not in n.parts and '\\' not in m.filename and str(n) not in names and str(n) not in ('','.');names.add(str(n));mode=m.external_attr>>16;assert stat.S_IFMT(mode) in [0,stat.S_IFREG,stat.S_IFDIR];total+=m.file_size;assert m.file_size<=50_000_000 and total<=250_000_000
   q=dest.joinpath(*n.parts);assert q.resolve().is_relative_to(dest.resolve())
   if m.is_dir():q.mkdir(parents=True,exist_ok=True);continue
   q.parent.mkdir(parents=True,exist_ok=True);raw=z.read(m);q.write_bytes(raw);rows.append({'path':str(n),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'crc32':f'{m.CRC:08x}'})
 inv.append({'artifact':a,'zip_actual_bytes':len(b),'zip_sha256':hashlib.sha256(b).hexdigest(),'api_size_digest_match':True,'CRC_safe_paths_modes_unique':True,'total_uncompressed_bytes':total,'files':rows});print(a['name'],len(rows),'files',total,'bytes')
(O/'artifact-inventories.json').write_text(json.dumps(inv,indent=2)+'\n')
