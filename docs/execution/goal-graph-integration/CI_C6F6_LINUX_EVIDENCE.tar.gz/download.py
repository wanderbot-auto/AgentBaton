from pathlib import Path
import subprocess,json,datetime,hashlib,stat,zipfile
O=Path(__file__).parent;REPO='repos/wanderbot-auto/AgentBaton';RUN=40790894775;HEAD='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4'
def get(name,endpoint):
 p=O/name;record=O/(name+'.attempt.json');assert not p.exists() and not record.exists(),'No duplicate download'
 r={'endpoint':endpoint,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':['gh','api',endpoint]};record.write_text(json.dumps(r,indent=2)+'\n');v=subprocess.run(r['argv'],capture_output=True,timeout=90);p.write_bytes(v.stdout);(O/(name+'.stderr')).write_bytes(v.stderr);r.update(exit=v.returncode,bytes=len(v.stdout),sha256=hashlib.sha256(v.stdout).hexdigest(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());record.write_text(json.dumps(r,indent=2)+'\n');assert v.returncode==0;return v.stdout
if __name__=='__main__':
 jobs=json.loads(get('product-jobs-terminal.json',f'{REPO}/actions/runs/{RUN}/jobs'));artifacts=json.loads(get('artifacts-terminal.json',f'{REPO}/actions/runs/{RUN}/artifacts'))
 for tag,ident in [('ui',123175557548),('rust',123175557757)]:
  j=next(x for x in jobs['jobs'] if x['id']==ident);assert j['head_sha']==HEAD;print(tag,j['status'],j['conclusion'],flush=True)
  if j['status']=='completed':
   (O/(tag+'-job-terminal.json')).write_text(json.dumps(j,indent=2)+'\n');get(tag+'-job.log',f'{REPO}/actions/jobs/{ident}/logs')
 for a in artifacts['artifacts']:
  if a['name'].startswith(('frontend-real-ipc-','provider-contract-')):
   assert not a['expired'];print('artifact',a['id'],a['name'],a['size_in_bytes'],a['digest'],flush=True);get(str(a['id'])+'.zip',f'{REPO}/actions/artifacts/{a["id"]}/zip')
