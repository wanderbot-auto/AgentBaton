from pathlib import Path
import json,re,hashlib,subprocess,struct
O=Path(__file__).parent;A=O/'ui-artifact';HEAD='c6f6b3c2be18ecc339f1cba6a9603657739e4cd4';MERGE='e963523c04b27d99d44a7893b161b5180b9818e3';TREE='32b2747d4541b7f09d05cf21332f6232b081d8a5';sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(n,b):assert b,n;checks.append(n)
def load(p):return json.loads(p.read_bytes())
pr=load(O/'pr-binding.json');co=load(O/'checkout-candidate-api.json');check('PR feature/base and synthetic merge candidate',pr['head']['sha']==HEAD and pr['base']['sha']=='a1be94d26d10bb245bb35eb50226b82012c967da' and co['sha']==MERGE and co['tree']['sha']==TREE and [x['sha'] for x in co['parents']]==[pr['base']['sha'],HEAD])
for tag in ['rust','ui']:
 j=load(O/(tag+'-job-terminal.json'));check(tag+' terminal success feature sha',j['status']=='completed' and j['conclusion']=='success' and j['head_sha']==HEAD)
 s=(O/(tag+'-job.log')).read_text();check(tag+' actual job checkout by raw git log',re.search(r'git log -1 --format=%H\n[^\n]*Z '+MERGE,s) is not None)
 check(tag+' all executed job steps success',all(x['status']=='completed' and x['conclusion']=='success' for x in j['steps']))
candidate=load(A/'goal-execution-candidate.json');check('UI artifact candidate exact schema12/checkout/tree/clean',type(candidate['schema']) is int and candidate['schema']==12 and candidate['git_head']==MERGE and candidate['git_tree']==TREE and candidate['dirty'] is False)
rows=[];pngs={};assetsets={};sources={};totalchecks=0
paths=[A/'evidence.json',A/'approved-commands/evidence.json']+sorted(A.rglob('report.json'))
for p in paths:
 d=load(p);name=str(p.relative_to(A));check(name+' all checks passed',len(d['checks'])>0 and all(c['status']=='passed' for c in d['checks']))
 if 'status' in d:check(name+' status passed',d['status']=='passed')
 check(name+' same actual daemon hash',d['daemon_sha256']==candidate['binaries']['batond'])
 if 'candidate' in d:check(name+' candidate equality',d['candidate']==candidate)
 if 'manifest_sha256' in d:check(name+' exact original candidate byte SHA',d['manifest_sha256']==sha((A/'goal-execution-candidate.json').read_bytes()))
 if 'frontend_assets_sha256' in d:assetsets[name]=d['frontend_assets_sha256']
 if 'harness_sha256' in d:
  file='apps/desktop/tests/'+('goal-planning-real-ipc.py' if p.parent.name in ['goal-plan-editor','goal-planning'] else 'data-workspace-real-ipc.py' if p.parent.name=='data-workspaces' else 'goal-execution-real-ipc.py' if p.parent.name=='goal-execution' else 'goal-graph-real-ipc.py')
  b=subprocess.check_output(['git','show',HEAD+':'+file],cwd='/workspace/AgentBaton');check(name+' source harness exact c6',sha(b)==d['harness_sha256']);sources[file]=sha(b)
 for x in d['screenshots']:
  old=x['path'] if isinstance(x,dict) else x;relative=old.split('/artifacts/ui-browser/',1)[1];q=A/relative;raw=q.read_bytes();check(relative+' actual PNG signature',raw[:8]==b'\x89PNG\r\n\x1a\n');width,height=struct.unpack('>II',raw[16:24]);digest=sha(raw)
  if isinstance(x,dict):check(relative+' report hash',x['sha256']==digest)
  else:
   hashes=d.get('screenshot_sha256',{});expected=hashes.get(old,hashes.get(relative));check(relative+' screenshot map hash',expected==digest)
  pngs[relative]={'sha256':digest,'width':width,'height':height,'viewed':relative in ['goal-graph-integrity/03-task-accepted-five-node-integrity.png','goal-graph-command-timeout/01-five-node-command-timeout-blocked-before-owner.png','goal-execution/08-timeout-mobile-unknown.png']}
 if p.parent.name.startswith('goal-graph-'):
  clean=d['cleanup'];check(name+' joined server + exact daemon exit0',clean[0]['thread_alive'] is False and clean[1]['active_handlers']==[] and clean[2]['wait_exitcode']==0 and clean[2]['forced_sigkill'] is False and clean[2]['process_not_alive'] is True)
  identities=clean[3:];check(name+' exact generated identities gone no signal',len(identities)>=2 and all(x['original_process_not_alive'] is True and x['pid_exists'] is False and x['signal_sent'] is False for x in identities));check(name+' no unexpected HTTP failures',d['http_unexpected_errors']==[])
  obs=d['observations'];acc=obs.get('accepted')
  if acc:
   g=acc['graph'];task=acc['task'];receipt=g['task_acceptance'];seq,event=obs['durable_acceptance']['event'];check(name+' actual accepted Task/ref/sequence/receipt event binding',g['task_accepted'] is True and g['run']['state']=='accepted' and g['run']['task_accepted'] is True and task['state']=='accepted' and receipt['id']==task['acceptance_ref']==event['payload']['acceptance_ref'] and seq==task['acceptance_sequence']==event['payload']['acceptance_sequence'] and event['kind']=='task.accepted' and event['source']=='baton_goal_acceptance' and obs['durable_acceptance']['receipt_sha256']==event['payload']['receipt_digest'])
  if 'real_validator' in obs:
   v=obs['real_validator'];receipt=v['receipt'];text=v['observation_json'];check(name+' complete original observation UTF8 digest',sha(text.encode())==receipt['result_digest'] and json.loads(text)==receipt['observation']);check(name+' deterministic worker joined no provider session',receipt['io_completion']=='worker_joined' and receipt['stop_confirmed'] is True and v['provider_session_created_for_validator'] is False)
 rows.append({'path':name,'checks':len(d['checks']),'screenshots':len(d['screenshots']),'daemon_sha256':d['daemon_sha256'],'cleanup_dimension':'explicit exact owned identity inspection' if 'cleanup'in d else 'reported assertions and available exit/observation fields; no whole-system leak claim'});totalchecks+=len(d['checks'])
check('12 actual report flows /114 passed checks/70 unique PNG',len(rows)==12 and totalchecks==114 and len(pngs)==70 and len(list(A.rglob('*.png')))==70)
check('all reported frontend asset maps coherent',len({json.dumps(v,sort_keys=True) for v in assetsets.values()})==1)
g=load(A/'goal-execution/report.json')['observations'];check('Goal seven owned-stop chains and retained cleanup diagnostics',len(g['owned_stop_receipt_chains'])==7 and g['failure_cleanup']==[] and g['page_errors']==[]);f=g['same_plan_frontier'];check('frontier actual12+13/25B and zero additional advance',sorted(x['bytes'] for x in f['outputs'].values())==[12,13] and f['additional_advance_requests']==0)
s=(O/'ui-job.log').read_text();check('UI full564/37',bool(re.search(r'37 passed',re.sub(r'\x1b\[[0-9;]*m','',s))) and '564 passed' in re.sub(r'\x1b\[[0-9;]*m','',s));lookup=s.split('##[endgroup]')[-1] # Full log scanned below; warning absence does not prove all errors impossible.
patterns=['Event loop is closed','Task exception was never retrieved','coroutine .* was never awaited','PlaywrightContextManager.*_playwright'];warning_counts={p:len(re.findall(p,s)) for p in patterns};check('prior lookup runtime warnings absent in entire original UI log',all(x==0 for x in warning_counts.values()))
summary={'feature':HEAD,'actual_checkout':MERGE,'actual_checkout_tree':TREE,'schema':12,'daemon_sha256':candidate['binaries']['batond'],'report_flows':rows,'passed_report_checks':totalchecks,'PNGs':pngs,'actually_viewed_PNGs':3,'unviewed_PNGs_hash_only':67,'frontend_assets':next(iter(assetsets.values())),'frontend_bytes_in_artifact':False,'raw_daemon_binary_in_artifact':False,'source_harness_hashes':sources,'lookup_warning_counts':warning_counts,'auditor_controls':len(checks),'controls':checks}
(O/'audit-results.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS',len(checks),'artifact/log/projection evidence checks;12flows114checks70PNGs/3viewed')
