from pathlib import Path
import json,hashlib,datetime,tarfile,io,os
R=Path(__file__).resolve().parent
H='bb343be5bb0403e995a97441ce16670c03bd0f33';C='1a7682e60354d4a80200ea487725edfc99068a4c';T='f85f9e19513d1ecfd85a058e5f6fd14ba4ed1123'
def read(n):return json.loads((R/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def entry(p):
 assert p.is_file() and not p.is_symlink();b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b),'mode':oct(p.stat().st_mode&0o777)}
def save(n,d):
 p=R/n;assert not p.exists(),n;p.write_text(json.dumps(d,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Preserve original parser failure; it is not a product/CI failure.
save('OFFLINE_PARSER_CORRECTION.json',{'at':now,'original_script':'audit_package_initial.py','original_script_sha256':sha((R/'audit_package_initial.py').read_bytes()),'corrected_script':'audit_package.py','corrected_script_sha256':sha((R/'audit_package.py').read_bytes()),'original_intel_stderr':'intel-audit_package.stderr','stderr_sha256':sha((R/'intel-audit_package.stderr').read_bytes()),'original_exit':1,'correction':'Generic own filename regex accidentally excluded x86_64 underscore; now requires the exact expected architecture+commit filename. Original artifact bytes and original SHA256SUMS were correct.','corrected_intel_exit':0,'product_source_artifact_test_changed_or_rerun':False})
try:os.kill(read('monitor-started.json')['pid'],0)
except ProcessLookupError:exited=True
else:exited=False
assert exited and read('product-run-final.json')['conclusion']=='success'
for m in ['source-manifest.json','product-source-manifest.json']:
 prefix='source-snapshot' if m=='source-manifest.json' else 'product-source-snapshot'
 for row in read(m)['files']:
  b=(R/prefix/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
for row in read('ENVIRONMENT_MANIFEST.json')['files']:
 p=R/row['path'];assert entry(p)==row
# New exact artifacts only, all prior Env seal bytes stay fixed.
arch_data={}
for arch,label,host,smoke,owner,checkout_line,audit_line in [('arm','ARM',3291,3359,3387,103,3700),('intel','Intel',3417,3485,3513,161,3826)]:
 j=read(arch+'-job-terminal.json');p=read(arch+'-offline-package-audit.json');a=read(arch+'-offline-page-audit.json');n=read(arch+'-offline-native-audit.json');v=read(arch+'-visual-review.json')
 assert j['conclusion']=='success' and len(v['images'])==25 and v['all_individually_viewed'] is True
 assert a['errors']==[] and a['approved_validator_error'] is None and len(a['page_records'])==24 and n['strict_pinned_native_report_error'] is None
 native=read(arch+'-native-artifact-inventory.json');dev=read(arch+'-development-artifact-inventory.json')
 for inv in [native,dev]:
  assert inv['api']['workflow_run']['head_sha']==H and inv['api']['workflow_run']['id']==40799957452 and inv['api_digest_matches'] is True and inv['crc']=='passed'
 assert len(native['entries'])==115 and len(dev['entries'])==4
 after=read(arch+'-native-artifact/owner-dialog/after.json');grant=after['grants'][0]
 assert after['schema_version']==12 and after['sequence']==10 and len(after['grants'])==1 and len(after['counts'])==19 and all(type(x) is int and x==0 for x in after['counts'].values())
 assert a['app-cleanup.json']['ok'] is True and a['daemon-cleanup.json']['ok'] is True
 sign='ad hoc linker signature; TeamIdentifier not set; Info.plist not bound and resources unsealed in original inspection' if arch=='arm' else 'not signed at all in original codesign inspection'
 text=f'''# {label} actual Mac and development artifact review — bb343

Sealed {now}. Feature `{H}`, Product40799957452 attempt1, {label} job{j['id']}. Original {arch}-job.log:{checkout_line} confirms actual checkout `{C}`. Signed Git commit API binds tree `{T}`, parents a1be94d26d10bb245bb35eb50226b82012c967da+bb343. Actual job concluded **success**,{j['completed_at']}. This new run supplies actual post-helper-relocation macOS evidence; earlier c6f6 failures remain historical and were not refetched or re-viewed.

Core/workspace/nativehost stage passed. Host62tests(log{host}), native-smoke26({smoke}), Ownercontroller10({owner}) passed with0failed/ignored. Actual readonly WebView and real native Owner stages passed. Default desktop release build, test-control audit, developmentDMG packaging and official upload all succeeded; the audit logs at:{audit_line} `PASS no native harness identifiers in default application executable`. This is the existing finite3marker strings audit on the actual default release binary, distinct from testharness checks and not a claim of exhaustive binary verification.

## Actual Owner text/authority and owned lifecycle

Independent offline parsing reports0errors across11data pages+Final in cancel and approve phases:24ready observations/24before-click readonlyDB snapshots/24permits/24PNGs.84L rows in order decode exactly to{a['presentation_roundtrip']['original_utf8_bytes']}originalUTF8bytes,SHA{a['presentation_roundtrip']['original_sha256']}; continuous byte intervals,40encoded-byte row bound/8rowsperpage, exact fixed production formatter and Final total agree. No whitespace normalization/JSON reserialization replaces original text. Every record binds exact phase/proposal/revision/page/count/fullprompt; parent/visible/fullcell flags and realbutton enabled/visible controls match. Existing compiled observers preserve attachedparent/screen/fullcell/500msstability,4scapture/75snative/85sPython gates; no independent per-gate timing telemetry is invented.

Before every click schema12/sequence8, unconsumedproposal/revision1,zeroGrants and all19original attempt/session/Goal counters0 are preserved. Exactpermits precede native NSControl.performClick. Real FinalCancel after all11data pages returns PERMISSION_DENIED/not_started/noresult; nextphase snapshots still show no Grant/finalize. Real FinalOK after rereading all11pages commits exactly oneGrant, sequence10,proposalconsumedtrue/revision2, all19counters0. Response.result/proposal_result/persistentGrant and typed scope/enforcement/workspace/connection bindings match exactly; event9 execution_grant.approved binds Grant's server approvalUUID, event10 approval.confirmed binds proposalID. Current pinned approved_error returnsNone. Grant.id={grant['id']}; approvalUUID={grant['approval_id']}; proposalID={after['proposal']['id']}. This fixture does not dispatch a Provider session or validate private Graph/Factory OS approvals.

All24newOwnerPNGs plus currentreadonlytask screenshot were individually opened with tools.view_image. Everypage/Final and both controls fit within visible app/desktop; page11/Final use narrower centeredwrapped layouts without observed clipping. {arch}-visual-review records original25hashes. These are automated fixture actions, not humanowner approvals; screenshots are from the Native harness, not a mounted packageddefaultDMG. Original result.json's visual_pending status is retained, and subsequent reviewer inspection is separate.

Actual readonlyreport binds {C},architecture{n['architecture']}, strictschema12/sequence3, zeroGoal/execution/all6Graphcounts, exact readonly missing-run denials and productinvoke/taskpersistence/close-survival/secondwriterrejection/restart/reopen/draftcancel/stopevidence. All4actual WebViewcrypto.subtle.digest/TextEncoder contexts preserve original109B Chinese/emoji/unsafe-u64literal input and SHAd29817e7338bcd0db0c7f22a98e3faa82802bb73f11d67ad2c65e789d1dd2892. Native readonlydialognotrun remains its separate fixture dimension; the separate Grantfixture above provides realOwner evidence. This is schema12/original19, not Factory13/28.

Owner apppid{a['app-cleanup.json']['pid']} and daemonpid{a['daemon-cleanup.json']['pid']} both exited0 with ownedgroupsquiescent/noerrors; daemonreceivedSIGTERM. Native readonlyrunner also reports exit0/notimeout/ownedcleanup. Bootstrap privatepath/mode/socket evidence and generatedversion-onlyconnection transcript are original. Hostbootstrap cannotprivately finalize the targetGrant. No realProvider calls or privatecredentials were used by the fixture/reviewer.

## Actual development package and signature limits

Official nativeZIP artifact{native['api']['id']},SHA{native['zip_sha256']},115payloads. Official developmentZIP artifact{dev['api']['id']},SHA{dev['zip_sha256']},4payloads. Each rawlog/ZIP downloadedonce after terminal; allAPI digests/CRCs/safe normalizedunique paths/permittedmodes/bounds/memberhashes pass. ZIP and extractedlocalmodes remain separate inventory dimensions.

DMG `{p['dmg']['path']}` is {p['dmg']['bytes']}bytes,SHA256 `{p['dmg']['sha256']}`. It matches originalSHA256SUMS, expected architecture+checkout filename and UDIFkolytrailer. build-record commits to exactcheckout/{p['architecture']},macOS15.7.9,Xcode16.4,Rust1.99.1 with recordedNodeversion. The included DEVELOPMENT_ACCEPTANCE checklist matches fixedsource. Original signatureinspection: **{sign}**. No DeveloperIDsigning or notarization configured, no trustedpublisher is established. The reviewer did notmount/install/launch theDMG or perform codesignverification on Linux. Signaturepresence/inspection is distinct from verification, minimumsupportedOS and humaninstallationacceptance, all unrun here. Do not bypassGatekeeper; checklist requires recording denials.

Official development artifact: https://github.com/wanderbot-auto/AgentBaton/actions/runs/40799957452/artifacts/{dev['api']['id']}. This is a developmentbuild of an incomplete Designv0.2 implementation, not productionrelease or fullrequirement acceptance. Realmodels/remotehosts/privateidentities/fullorchestration/retention/Factory13/complete desktop/manualinstall remain outside this actualfixture. Otherolderfailures are not relabeled.

**Required Environment checks for this same feature still allfail** on the stale45/46 policytest contract. Productsuccess/defaultaudit/packages do notoverride thatPRgate. ENVIRONMENT_REVIEW/MANIFEST retain exact34tests/2failures perarchitecture and laterNode/Rust_envnotrun. Root/configowns a correctedcandidate; no futureCI is preaccepted. This reviewer changed nosource/STATUS/timeouts/authority and ran noCargo/browser/productdaemon/Provider/remote mutation/Approve/merge/workflowtrigger orsubagent. OwnofflineIntel filenameparser initially omittedunderscore in x86_64; originalfailure/script retained, corrected toexact expectedfilename and onlythat offlineparser rerun. It was not a product/artifactfailure or weakenedpredicate.
'''
 (R/(label.upper()+'_REVIEW.md')).write_text(text)
 paths=[R/(label.upper()+'_REVIEW.md'),R/'product-source-manifest.json',R/'checkout-candidate-api.json',R/'product-run-final.json',R/'OFFLINE_COMMANDS.json',R/'OFFLINE_PARSER_CORRECTION.json']+[x for x in R.rglob('*') if x.is_file() and (x.relative_to(R).parts[0].startswith(arch+'-') or x.relative_to(R).parts[0]=='product-source-snapshot')]
 files=[entry(x) for x in sorted(set(paths))]
 save(label.upper()+'_MANIFEST.json',{'schema':1,'sealed_at_utc':now,'feature':H,'checkout':C,'tree':T,'run':40799957452,'job':j['id'],'job_conclusion':'success','tests':{'host':62,'native_smoke':26,'Owner_controller':10},'actual_readonly_four_originalWebCrypto':'passed','actual_Owner':{'data_pages':11,'Final':1,'bothphases_total':24,'page_errors':0,'strict_schema':12,'originalzero_tables':19,'sequence':[8,10],'single_Grant_CAS_result_events':'typed exact match'},'new25images_individually_viewed':True,'defaultrelease_build_audit_packaging_upload':'passed originalCI evidence; audit finite3markers','development_DMG':p['dmg'],'signature_original_inspection':sign,'DeveloperID_notarization_humaninstallation':'not_run/not configured','DMG_independent_mount_binaryinspection':'not_run','same_feature_Environment':'all3failure; no fullPRacceptance','no_source_Cargo_browser_Provider_remote_workflow_authority_mutations':True,'formal_approval':False,'files':files})
 arch_data[arch]={'job':j['id'],'conclusion':'success','DMG':p['dmg'],'signature':sign,'native_artifact':native['api']['id'],'development_artifact':dev['api']['id']}
# Verify single-download acquisition and no live monitor before final wrapping.
api=read('monitor-api-attempts.json')
for arch in ['arm','intel']:
 for suffix in ['-job.log','-native-artifact.zip','-development-artifact.zip']:assert sum(x['file']==arch+suffix for x in api)==1
assert all(x['exit_code']==0 for x in api)
summary=f'''# bb343 exact CI independent review

Sealed {now}. Feature `{H}`, actualmerge `{C}`, tree `{T}`. Product40799957452 is success, all4jobs; Environment40799957732 is failure, all3jobs. **PR acceptance remains blocked by required Environment failures. No formalApprove/merge or fullDesigncompletion is claimed.**

Both realMacjobs complete62host/26native-smoke/10Ownercontrollertests, actualreadonly/fourWebCrypto,24Ownerprompts perarchitecture/fulltypedGrantCAS/result/events/original19zero,ownedapp-daemonexit0,defaultreleasebundle,actualfinite test-controlaudit anddevelopmentDMGpackaging/upload. All50newNativePNGs were individually viewed. The default release audit inspects its actualbinary; Nativeharness screenshots are not presented as installeddefaultapp screenshots. No oldc6evidence was refetched/reviewed as new.

ARM job123205408492 ended01:52:20; DMG8577813B/SHA d1e479eb701efa13ea7d62e9d5f6496f0877764aa09e1dbfe2ad0feca25af0d8,adhoch/linker-signed/noTeamID (noDeveloperID/notarization). Intel job123205408803 ended01:56:59; DMG8984245B/SHA c23937dd321e890cd881f9a10097d4ff15b53ab8840a9d2f95b4b6dc7624bf25,not signed at all. Both match officialSHA256SUMS/exactcheckout/architecture and contain buildrecords/manualacceptancelist. Linuxreviewer did notmount/install/launcheitherDMG, inspect itsfilesystem/binarycontents or perform codesignverification; manualinstallation/Gatekeeper/minimumsupportedOS/productionrelease remain notrun. AppleSilicon/Intel have different actualsignaturestates, not one invented uniformlabel.

CurrentrequiredEnvironmentfailed independently on all3hosts:34Pythontests/2failures each, still45expected versus actual60 and negative46versus bound60. Earlierbootstrap93/design130/staticinfra2workflows15pins passed; subsequentnpmtest/Rust_env/clippy didnotrun after set-e/pipefail. Originalfailures/logs/officialZIPs, the earlier integrationreview omission and required testcontract60/61+registeredhash/completeEnvironmentvalidation are preserved in ENVIRONMENT_REVIEW. Root/configowns thatfix; successfulProduct doesnotbypass thegate orpreapprove a newcandidate. No Productcancellation happened in this run: bothMacjobs actuallycompleted success.

Each of2Product rawjoblogs,2nativeZIPs,2developmentZIPs and3EnvironmentZIPs was downloadedonce andhash/API digest/CRC/safepath/mode/size/memberinventoryverified. TwoEnvironmentMaclogs downloadedonce; LinuxEnvlog locallyreused Root originalSHA b4ce1b15... withoutredownload. LinuxProductrawlogs/artifacts are ownedbyRoot andnotdownloadedbythisreviewer. CurrentofficialdevelopmentZIP URLs are in thearchitecture reports; localDMGbytes remain present. Sourcefixed snapshots/protocolchecks/recordedactualcommands are retained. OwnofflineIntel filenameparser's x86_64regexbug was corrected toexactfilename after preservingoriginalstderr/script; no productsource/assertion/artifact changed and no actualCI/test rerun occurred.

This is an actual schema12/original19 Grant/readonly/packaging slice. It is notFactory13/28/privateGraphOwnerOSflow/realProvideridentity/models/production/signingkeys/extraquota/full130requirements acceptance. BothNative anddevelopmentartifacts are bound to actual1a7682 checkout, not future correctedEnvironment commits. The boundedmonitor hasexited. No source/STATUS/timeout/target/Cargo/browser/product/Provider/remote mutation/workflowtrigger/retry/cancel/Approve/merge/push/paidresource/subagent action was performed by thisreviewer. Allpreviousfailedruns andthe separatelysealedEnvironmentpacket remainunchanged.
'''
(R/'SUMMARY.md').write_text(summary)
save('FINAL_INTEGRITY.json',{'at':now,'monitor_exited':True,'feature':H,'actualcheckout':C,'tree':T,'all_product_jobs':'4success','all_Environment_jobs':'3failure','formal_approval':False,'original_Envseal_hashes':{'review':sha((R/'ENVIRONMENT_REVIEW.md').read_bytes()),'manifest':sha((R/'ENVIRONMENT_MANIFEST.json').read_bytes())},'actual_new_Native_images':50,'all_individually_viewed':True,'Product_log_native_development_eacharch_download_once':True,'official_EnvironmentZIPs_eachonce':True,'source_snapshots_unchanged':20,'local_offline_parser_initialfailure_preserved':True,'DMG_mount_install_runtime_on_reviewer':'not_run','architectures':arch_data})
files=[entry(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name not in {'MANIFEST.json','EVIDENCE.tar.gz','EVIDENCE_IMPORT.json'}]
save('MANIFEST.json',{'schema':1,'sealed_at_utc':now,'feature':H,'actualcheckout':C,'tree':T,'Product_run':40799957452,'Environment_run':40799957732,'Product':'4success','Environment':'3failure','PR_acceptance':'blocked by requiredEnvironment; noformalApprove','actual_native_Owner_and_defaultbuild_audit_developmentpackages':'botharchitecturespassed actualCI dimensions','new_Native_images_individually_viewed':50,'architecture_delivery':arch_data,'all_official_ZIP_APIdigest_CRC_paths_modes_sizes_hashes':'passed singleacquisitioneach','humaninstall_signatureverification_minimumOS_fullgoal':'not_run/notaccepted','source_STATUS_timeout_Cargo_target_browser_product_Provider_remote_CI_permissions_mutated':False,'monitor_exited':True,'reports':['ENVIRONMENT_REVIEW.md','ARM_REVIEW.md','INTEL_REVIEW.md','SUMMARY.md'],'files':files})
# Self-contained original evidence, including both original development ZIPs and DMGs.
paths=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name not in {'EVIDENCE.tar.gz','EVIDENCE_IMPORT.json'}]
with tarfile.open(R/'EVIDENCE.tar.gz','w:gz') as tf:
 for p in paths:
  e=entry(p);t=tarfile.TarInfo(e['path']);t.size=e['bytes'];t.mode=int(e['mode'],8);t.mtime=0;tf.addfile(t,io.BytesIO(p.read_bytes()))
with tarfile.open(R/'EVIDENCE.tar.gz','r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(paths)
 for t in members:
  p=R/t.name;assert t.isreg() and tf.extractfile(t).read()==p.read_bytes() and t.size==p.stat().st_size and t.mode==(p.stat().st_mode&0o777)
b=(R/'EVIDENCE.tar.gz').read_bytes();save('EVIDENCE_IMPORT.json',{'schema':1,'file':'EVIDENCE.tar.gz','bytes':len(b),'sha256':sha(b),'regular_members':len(paths),'allpayloads_bytes_modes_sizes_roundtrip_verified':True,'feature':H,'actualcheckout':C,'scope':'actual4Productsuccess+3Envfailure; includesrealDMGs, noformalapproval/nohumaninstall'})
for n in ['ARM_REVIEW.md','ARM_MANIFEST.json','INTEL_REVIEW.md','INTEL_MANIFEST.json','SUMMARY.md','MANIFEST.json','EVIDENCE.tar.gz','EVIDENCE_IMPORT.json']:print(json.dumps(entry(R/n)))
