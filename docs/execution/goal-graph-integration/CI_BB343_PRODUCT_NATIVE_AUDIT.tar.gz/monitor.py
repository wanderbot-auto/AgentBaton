"""Read-only CI monitor. Five-minute API cadence; no reruns or retries.

Log/ZIP downloads are attempted at most once per architecture/artifact. This
process records evidence only; image inspection and review remain human/model work.
"""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, stat, subprocess, time, zipfile

ROOT = Path(__file__).resolve().parent
REPO = 'repos/wanderbot-auto/AgentBaton'
HEAD = 'bb343be5bb0403e995a97441ce16670c03bd0f33'
RUN = 40799957452
ARCH = {'arm': 123205408492, 'intel': 123205408803}
ATTEMPTS = json.loads((ROOT / 'monitor-api-attempts.json').read_text()) if (ROOT / 'monitor-api-attempts.json').exists() else []

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def get(name, endpoint):
    path = ROOT / name
    assert not path.exists(), f'Never redownload existing evidence: {name}'
    record = {'file': name, 'endpoint': endpoint, 'started_at': now(), 'attempted': True}
    ATTEMPTS.append(record)
    save('monitor-api-attempts.json', ATTEMPTS)
    result = subprocess.run(['gh', 'api', endpoint], capture_output=True, timeout=60)
    path.write_bytes(result.stdout)
    record.update(completed_at=now(), exit_code=result.returncode, bytes=len(result.stdout),
                  sha256=hashlib.sha256(result.stdout).hexdigest(), stderr=result.stderr.decode())
    save('monitor-api-attempts.json', ATTEMPTS)
    assert result.returncode == 0, record
    return result.stdout

def extract(name, metadata):
    data = get(name + '.zip', f'{REPO}/actions/artifacts/{metadata["id"]}/zip')
    digest = hashlib.sha256(data).hexdigest()
    assert metadata['digest'] == 'sha256:' + digest
    dest = ROOT / name
    dest.mkdir()
    entries, seen, total = [], set(), 0
    with zipfile.ZipFile(ROOT / (name + '.zip')) as archive:
        assert len(archive.infolist()) <= 4096
        assert archive.testzip() is None
        for item in archive.infolist():
            rel = PurePosixPath(item.filename)
            assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in item.filename
            assert not stat.S_ISLNK(item.external_attr >> 16)
            normalized = str(rel)
            assert normalized not in seen and normalized not in ('', '.')
            seen.add(normalized)
            mode = item.external_attr >> 16
            assert stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR), f'Unsafe archive mode: {mode:o}'
            total += item.file_size
            assert item.file_size <= 1_000_000_000 and total <= 2_000_000_000
            out = dest.joinpath(*rel.parts)
            assert out.resolve().is_relative_to(dest.resolve())
            if item.is_dir():
                out.mkdir(parents=True, exist_ok=True)
                continue
            out.parent.mkdir(parents=True, exist_ok=True)
            content = archive.read(item)
            out.write_bytes(content)
            entries.append({'path': item.filename, 'bytes': len(content),
                            'sha256': hashlib.sha256(content).hexdigest(),
                            'crc32': f'{item.CRC:08x}', 'original_zip_mode': oct(item.external_attr >> 16)})
    save(name + '-inventory.json', {'at': now(), 'api': metadata, 'zip_sha256': digest,
                                  'api_digest_matches': True, 'crc': 'passed',
                                  'safe_paths_no_symlinks_duplicates': True, 'entries': entries})

def wait_until(deadline):
    while time.monotonic() < deadline:
        time.sleep(min(30, deadline - time.monotonic()))

def main():
    first = json.loads((ROOT / 'initial-api-reads.json').read_text())[0]['at']
    first = datetime.datetime.fromisoformat(first).timestamp()
    save('monitor-started.json', {'at': now(), 'pid': __import__('os').getpid(), 'poll_cadence_seconds': 300, 'sleep_chunk_max_seconds': 30, 'scope': 'two Mac jobs only; Linux terminal stages shared to Root; no remote mutations'})
    wait_until(time.monotonic() + max(0, first + 300 - time.time()))
    finished = set()
    deadline = time.monotonic() + 55 * 60
    iteration = 0
    while finished != set(ARCH):
        assert time.monotonic() < deadline, 'Bounded monitor elapsed; do not imply continuation'
        iteration += 1
        snapshot = json.loads(get(f'product-jobs-stage-{iteration:02}.json', f'{REPO}/actions/runs/{RUN}/jobs'))
        assert all(j['head_sha'] == HEAD for j in snapshot['jobs'])
        summary = [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'],
                    'current_steps': [s['name'] for s in j['steps'] if s['status'] == 'in_progress']}
                   for j in snapshot['jobs']]
        print(json.dumps({'at': now(), 'jobs': summary}), flush=True)
        for arch, ident in ARCH.items():
            job = next(j for j in snapshot['jobs'] if j['id'] == ident)
            if arch in finished or job['status'] != 'completed':
                continue
            save(arch + '-job-terminal.json', job)
            get(arch + '-job.log', f'{REPO}/actions/jobs/{ident}/logs')
            artifacts = json.loads(get(arch + '-artifacts-terminal.json', f'{REPO}/actions/runs/{RUN}/artifacts'))
            os_label = 'macos-15' if arch == 'arm' else 'macos-15-intel'
            for prefix, kind in [('native-webview-', 'native-artifact'), ('development-', 'development-artifact')]:
                matches = [a for a in artifacts['artifacts'] if a['name'].startswith(prefix + os_label + '-')
                           and (os_label.endswith('-intel') or '-intel-' not in a['name'])]
                assert len(matches) <= 1
                if matches:
                    assert not matches[0]['expired']
                    extract(arch + '-' + kind, matches[0])
            finished.add(arch)
            save('monitor-state.json', {'at': now(), 'completed_arches': sorted(finished),
                                        'remaining_arches': sorted(set(ARCH) - finished)})
            print(json.dumps({'at': now(), 'downloaded_terminal_arch': arch, 'conclusion': job['conclusion']}), flush=True)
        if finished != set(ARCH):
            wait_until(time.monotonic() + 300)
    save('monitor-complete.json', {'at': now(), 'status': 'download_complete_review_pending', 'actual_images_reviewed': False})
    print('DOWNLOAD_COMPLETE_REVIEW_PENDING', flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('monitor-failure.json', {'at': now(), 'type': type(error).__name__, 'message': str(error),
                                     'no_automatic_retry': True})
        raise
