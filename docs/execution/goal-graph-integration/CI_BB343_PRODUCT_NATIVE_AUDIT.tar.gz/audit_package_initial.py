"""Offline validation of one downloaded official development ZIP; no mounts/execution."""
from pathlib import Path
import hashlib,json,re,sys,datetime
ROOT=Path(__file__).resolve().parent
CHECKOUT='1a7682e60354d4a80200ea487725edfc99068a4c'

def main(arch):
 root=ROOT/(arch+'-development-artifact')
 inv=json.loads((ROOT/(arch+'-development-artifact-inventory.json')).read_text())
 files={e['path']:e for e in inv['entries']}
 assert set(files)=={'build-record.txt','SHA256SUMS','DEVELOPMENT_ACCEPTANCE.md',f'AgentBaton-{"arm64" if arch=="arm" else "x86_64"}-{CHECKOUT}-development.dmg'},files
 record=(root/'build-record.txt').read_text()
 expected_arch='arm64' if arch=='arm' else 'x86_64'
 assert record.splitlines()[:3]==[f'commit={CHECKOUT}',f'architecture={expected_arch}','channel=development; no Developer ID signing or notarization configured']
 lines=(root/'SHA256SUMS').read_text().splitlines();assert len(lines)==1
 match=re.fullmatch(r'([a-f0-9]{64})  (\./)?(AgentBaton-[A-Za-z0-9-]+\.dmg)',lines[0]);assert match,lines
 path=root/match[3];assert path.is_file()
 digest=hashlib.sha256(path.read_bytes()).hexdigest();assert digest==match[1]
 with path.open('rb') as f:f.seek(-512,2);trailer=f.read(512)
 assert trailer[:4]==b'koly','Not a UDIF disk image trailer'
 original=(ROOT/'product-source-snapshot/docs/execution/DEVELOPMENT_ACCEPTANCE.md').read_bytes()
 assert (root/'DEVELOPMENT_ACCEPTANCE.md').read_bytes()==original
 observed=[]
 for line in record.splitlines():
  if any(s in line for s in ['Signature=','Authority=','TeamIdentifier=','Runtime Version','not signed','Format=','CodeDirectory','Identifier=']):observed.append(line)
 out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'arch':arch,'dimension':'offline original official ZIP bytes only; no mount/install/launch/codesign on reviewer Linux','checkout':CHECKOUT,'architecture':expected_arch,'exact_four_files':True,'api_digest_crc_safepaths':'verified by acquisition inventory','dmg':{'path':path.name,'bytes':path.stat().st_size,'sha256':digest,'matches_original_SHA256SUMS':True,'UDIF_koly_trailer':True},'acceptance_checklist_matches_fixed_source':True,'signature_inspection_original_build_record':observed,'developer_ID_signing_and_notarization':'not configured per original build record; no trusted publisher claimed','human_installation_acceptance':'not_run','binary_contents_independent_mount_inspection':'not_run','formal_approval':False}
 (ROOT/(arch+'-offline-package-audit.json')).write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main(sys.argv[1])
