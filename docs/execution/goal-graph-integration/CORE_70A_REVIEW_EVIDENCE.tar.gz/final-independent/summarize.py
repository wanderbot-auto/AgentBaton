import re,json,hashlib
from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'workspace.log').read_text()
sections=[];current=None
for line in s.splitlines():
 if line.startswith('     Running ') or line.startswith('   Doc-tests '):
  if current:sections.append(current)
  current={'header':line.strip(),'summaries':[]}
 m=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
 if m and current:current['summaries'].append({'status':m[1],'passed':int(m[2]),'failed':int(m[3]),'ignored':int(m[4])})
if current:sections.append(current)
for v in sections:
 v['outer_summary']=v['summaries'][-1] if v['summaries'] else None
 v['nested_summaries']=v['summaries'][:-1]
unit=[v for v in sections if not v['header'].startswith('Doc-tests')]
docs=[v for v in sections if v['header'].startswith('Doc-tests')]
def total(vs,key):return sum(v['outer_summary'][key] for v in vs if v['outer_summary'])
r={'method':'Last summary per Cargo Running/Doc-tests section is outer suite; earlier nested subprocess summaries excluded from unique count','outer_tests':{key:total(unit,key) for key in ['passed','failed','ignored']},'doctests':{key:total(docs,key) for key in ['passed','failed','ignored']},'nested_subprocess_summaries':sum(len(v['nested_summaries']) for v in sections),'sections':sections,'workspace_log_sha256':hashlib.sha256((b/'workspace.log').read_bytes()).hexdigest()}
(b/'test-counts.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='sections'}))
