#!/usr/bin/env python3
"""Read-only verification of fixed source and sealed command evidence. No reruns."""
from pathlib import Path,PurePosixPath
import gzip,hashlib,json,subprocess,tarfile
R=Path('/workspace/.worktrees/native-bundle-discovery');O=Path(__file__).parent
LEAF='9d11a6d0723144a245994a5e7531c282cc60702e';ROOT='3a91bcec76a34f21edf800df16709b5e958b8012'
docs=R/'docs/execution/native-bundle-discovery/ci-timeout/guard/infrastructure-suite'
data=Path('/workspace/.onboarding/native-ci-timeout60-infra-suite');rust=data/'rust-root3a91'
checks=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def gitblob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=R)
def check(name,value):
 assert value,name;checks.append({'name':name,'status':'passed'})
archive=(docs/'EVIDENCE.tar.gz').read_bytes();manifest_raw=(docs/'EVIDENCE_ARCHIVE_MANIFEST.json').read_bytes();manifest=json.loads(manifest_raw)
check('exact final archive digest',sha(archive)=='4fca863655d141f3085e4ec94c34369a0270b8890387e52e2f17ca27c3594f6f')
check('exact final archive manifest digest',sha(manifest_raw)=='f22f8cacf35fca18cbf48ecf3a541e18176554c80b4ef50e2c4777ca5e053350')
expected={r['path']:r for r in manifest['members']};expected[manifest['internal_manifest']['path']]=manifest['internal_manifest']
with tarfile.open(docs/'EVIDENCE.tar.gz','r:gz')as tar:
 members=tar.getmembers();check('exact40 regular unique members',len(members)==len({m.name for m in members})==40 and{m.name for m in members}==set(expected))
 for m in members:
  assert m.isfile()and not PurePosixPath(m.name).is_absolute()and'..'not in PurePosixPath(m.name).parts
  raw=tar.extractfile(m).read();row=expected[m.name];assert len(raw)==row['bytes']and sha(raw)==row['sha256']
  if 'mode'in row:assert m.mode==int(row['mode'],8)
check('all40 payloads sizes hashes modes safe, no extraction',True)
commands=json.loads((rust/'commands.json').read_text())
check('exact Rust commands and no skips/filters',len(commands)==2 and commands[0]['argv']==['cargo','test','--locked','--manifest-path','tools/environment-smoke/Cargo.toml']and commands[1]['argv']==['cargo','clippy','--locked','--manifest-path','tools/environment-smoke/Cargo.toml','--all-targets','--','-D','warnings'])
for command in commands:
 tag=command['tag'];check(tag+' actual exit0/cwd/root timestamp bound',command['exit']==0 and command['cwd']=='/workspace/.worktrees/goal-graph-integration'and command['utc'].startswith('2026-10-29T01:38:40'))
 check(tag+' raw stdoutstderr hashes match command',(sha((rust/(tag+'.stdout')).read_bytes())==command['stdout_sha256']and sha((rust/(tag+'.stderr')).read_bytes())==command['stderr_sha256']))
test=(rust/'test.stdout').read_text();stderr=(rust/'test.stderr').read_text()
check('actual Rust2 passed0failed0ignored0filtered',all(x in test for x in ['running 2 tests','2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out','tests::executable_is_available ... ok','tests::utf8_workspace_roundtrip ... ok']))
check('test actually compiled and ran only env fixture','Compiling agentbaton-environment-smoke'in stderr and'/rust-root3a91/target/debug/deps/agentbaton_environment_smoke-'in stderr)
check('Clippy checked only env fixture and finished','Checking agentbaton-environment-smoke'in(rust/'clippy.stderr').read_text()and'Finished'in(rust/'clippy.stderr').read_text())
env=json.loads((rust/'environment.json').read_text());target=str(rust/'target')
check('exact source/offline independent target environment',env['commit']==ROOT and env['selected_env']['CARGO_TARGET_DIR']==target and env['selected_env']['CARGO_NET_OFFLINE']=='true'and env['selected_env']['CARGO_HOME']=='/workspace/.toolchains/cargo'and env['selected_env']['RUSTUP_HOME']=='/workspace/.toolchains/rustup')
versions=json.loads((rust/'versions.json').read_text());check('all recorded compiler/version probes succeeded',len(versions)==3 and all(x['exit']==0 for x in versions))
before=json.loads((rust/'before-tracked.json').read_text());after=json.loads((rust/'after-tracked.json').read_text())
check('1296 complete tracked snapshots commit/status/hash/mode/bytes identical',before==after and before['commit']==ROOT and before['status_porcelain']==''and len(before['files'])==1296)
chain=json.loads((data/'integration-chain.json').read_text());inputs=chain['identical_validation_input_files']
check('exact21 source-equivalent Environment inputs',len(inputs)==21 and chain['python_node_static_source']==LEAF and chain['Rust_root_source']==ROOT)
for row in inputs:
 a=gitblob(LEAF,row['path']);b=gitblob(ROOT,row['path']);assert a==b and len(a)==row['bytes']and sha(a)==row['sha256']
check('fixed Git bytes for all21 inputs independently match',True)
leaf_manifest=json.loads(gitblob(LEAF,'BOOTSTRAP_MANIFEST.json'));root_manifest=json.loads(gitblob(ROOT,'BOOTSTRAP_MANIFEST.json'))
check('same93 paths only separate STATUS value differs',set(leaf_manifest['files'])==set(root_manifest['files'])and len(root_manifest['files'])==93 and[p for p in root_manifest['files']if root_manifest['files'][p]!=leaf_manifest['files'][p]]==['docs/execution/STATUS.md'])
snapshot={r['path']:r for r in before['files']}
check('Root93 registered values match actual preRust snapshot',all(snapshot[p]['sha256']==h for p,h in root_manifest['files'].items()))
check('separate STATUS actual Git hashes truthful',sha(gitblob(ROOT,'docs/execution/STATUS.md'))==chain['Root_STATUS_hash']and sha(gitblob(LEAF,'docs/execution/STATUS.md'))==chain['own_STATUS_hash'])
inventory=json.loads((rust/'target-inventory.json').read_text())
check('retained only own small Environment target inventory',inventory['target']==target and inventory['total_bytes']==8477180 and inventory['archive_excluded']is True and len(inventory['test_executables'])==1)
old=gzip.decompress((data/'original-environment-linux.log.gz').read_bytes());check('bb original34/2FAIL preserved exactdigest',sha(old)=='b4ce1b1523df1b7a174a954145780b6cca4c8efc122c6b0b28cffc2a7dfa6e9e'and b'FAILED (failures=2)'in old)
nonrust=Path('/workspace/.onboarding/native-env-policy60-review');check('previous nonRust manifest checkpoint unchanged',sha((nonrust/'MANIFEST_NON_RUST.json').read_bytes())=='380f5fa59e59c660fbae43cca78952ff7121e105a77efeba409566ba9e536fc5')
own=json.loads((nonrust/'verified-format/results.json').read_text());check('independent earlier required nonRust chain all0',own['subject']==LEAF and len(own['commands'])==7 and all(c['exitcode']==0 for c in own['commands']))
for c in own['commands']:
 for kind in ['stdout','stderr']:assert sha((nonrust/'verified-format'/(c['name']+'.'+kind)).read_bytes())==c[kind+'_sha256']
check('previous actual Python34 Node4/static raw logs still hash bound',own['python_cases']==34 and own['root_Node_cases']==4)
(O/'results.json').write_text(json.dumps({'status':'local_Environment_validation_chain_ready','leaf_source':LEAF,'Root_Rust_source':ROOT,'checks':checks,'finite_evidence_checks':len(checks),'counts_separate':{'Python':34,'Node':4,'Rust_environment_fixture':2},'commands_reexecuted':False,'scope':'read-only sealed archive/source/command audit; not remoteCI/Mac/product','old_CI':'bb originalfailed unchanged'},indent=2)+'\n')
print('PASS',len(checks),'sealed full-chain evidence checks; no test/Cargo rerun')
