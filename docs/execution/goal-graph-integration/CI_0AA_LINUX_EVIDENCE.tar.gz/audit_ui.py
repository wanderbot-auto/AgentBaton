from pathlib import Path
import json,hashlib,subprocess,re,struct
D=Path(__file__).resolve().parent;A=D/'ui-artifact';R=Path('/workspace/.worktrees/goal-graph-integration')
HEAD='0aa20c968d493cad895e4a3853bdf106d6b54acf';CO='5caecb5f9945b5fdb548f0e071a78e2d97537403';TREE='1943596e0bd12177d852117dab86c81ca30e6858'
def sha(b):return hashlib.sha256(b).hexdigest()
def show(path,rev=HEAD):return subprocess.check_output(['git','show',rev+':'+path],cwd=R)
job=json.loads((D/'ui-job.json').read_text());assert(job['id'],job['run_id'],job['head_sha'],job['status'],job['conclusion'])==(123075459595,40761824261,HEAD,'completed','success')
log=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(D/'product-ui.log').read_text());assert'HEAD is now at 5caecb5 Merge '+HEAD+' into a1be94d26d10bb245bb35eb50226b82012c967da'in log and re.search(r'^.*Z '+CO+'$',log,re.M)
assert'Test Files  37 passed (37)'in log and'Tests  564 passed (564)'in log
candidate=json.loads((A/'goal-execution-candidate.json').read_text());assert candidate['schema']==12 and candidate['git_head']==CO and candidate['git_tree']==TREE and candidate['dirty']is False
assert subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=R,text=True).strip()==TREE
B=candidate['binaries']['batond'];assert B=='a07b00de7eb58128f2dde32397e9c49b3918ff0413195c574f9eb8feae4208c3'
sources={};reports=[];images=[];assetmaps=[]
source_paths=['apps/desktop/tests/'+n+'-real-ipc.py'for n in ['quiet-canvas','command-validation','goal-planning','data-workspace','goal-execution','goal-graph']]
for path in source_paths:
 raw=show(path);p=D/'exact-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);sources[path]=sha(raw)
for p in sorted(A.rglob('*.json')):
 d=json.loads(p.read_text())
 if not isinstance(d,dict)or'checks'not in d:continue
 assert d.get('status','passed')=='passed'and all(c['status']=='passed'for c in d['checks'])and d['daemon_sha256']==B
 part=p.parent.name;harness='goal-graph'if part.startswith('goal-graph-')else'goal-planning'if part in ['goal-planning','goal-plan-editor']else'data-workspace'if part=='data-workspaces'else'goal-execution'if part=='goal-execution'else None
 if harness:assert d['harness_sha256']==sources['apps/desktop/tests/'+harness+'-real-ipc.py']
 if'candidate'in d:assert d['candidate']==candidate and d['manifest_sha256']==sha((A/'goal-execution-candidate.json').read_bytes())
 if'frontend_assets_sha256'in d:assetmaps.append({'report':str(p.relative_to(A)),'map':d['frontend_assets_sha256']})
 for entry in d['screenshots']:
  name=Path(entry['path']if isinstance(entry,dict)else entry).name;f=p.parent/name;b=f.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n'and b[12:16]==b'IHDR';digest=sha(b)
  declared=entry.get('sha256')if isinstance(entry,dict)else d.get('screenshot_sha256',{}).get(name)
  if declared is not None:assert digest==declared
  images.append({'path':str(f.relative_to(A)),'sha256':digest,'bytes':len(b),'width':int.from_bytes(b[16:20],'big'),'height':int.from_bytes(b[20:24],'big'),'declared_digest_checked':declared is not None})
 reports.append({'path':str(p.relative_to(A)),'sha256':sha(p.read_bytes()),'checks':len(d['checks']),'screenshots':len(d['screenshots']),'harness_sha256':d.get('harness_sha256'),'check_names':[c.get('name',c.get('id'))for c in d['checks']]})
assert len(reports)==12 and sum(r['checks']for r in reports)==114 and len(images)==70==len(list(A.rglob('*.png')))
assert len({i['path']for i in images})==70 and all(m['map']==assetmaps[0]['map']for m in assetmaps)
# Detailed same-current-artifact data-copy receipt and cancellation boundaries.
data=json.loads((A/'data-workspaces/report.json').read_text());o=data['observations'];j=o['normal_journal_commitments'];assert j['sequences']==sorted(set(j['sequences']))and len(j['sequences'])==3
assert[e['kind']for e in j['events']]==['approval.confirmed','data_workspace.copy_prepared','data_workspace.copy_finished']
assert[e['source']for e in j['events']]==['local_owner_confirmation','data_workspace_core','data_workspace_core']
assert j['events'][0]['payload']['snapshot_digest']==j['owner_snapshot_digest']
assert j['events'][1]['payload']['snapshot_digest']==j['stored_snapshot_digest']
assert j['events'][2]['payload']['contract_digest']==j['contract_digest']
normal=o['normal_completion_receipt'];assert normal['io_completion']=='worker_joined'and normal['owned_copy_worker_join_observed']is True and normal['general_filesystem_quiescence_claimed']is False
cancel=o['copy_cancel'];assert cancel['terminal']['state']=='cancelled'and cancel['terminal']['io_completion']=='worker_joined'and cancel['completion_receipt']['cancelled_owned_worker_join_observed']is True
assert cancel['no_join_unknown_case_exercised']is False and cancel['ready_race_exercised']is False
assert not o['browser_page_errors']and data['unrun']==[]
# Original raw observation is hashed, never reserialized to claim its digest.
def large(v,p=''):
 if type(v)is int and abs(v)>9007199254740991:yield{'path':p,'value_decimal':str(v)}
 if isinstance(v,dict):
  for k,x in v.items():yield from large(x,p+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from large(x,p+'/'+str(i))
sourceproof={};fixtures={}
for path in ['apps/desktop/src/'+n for n in ['goal-graph-api.ts','goal-graph-guards.ts','goal-graph-observation-text.test.ts','GoalGraphExecution.lossless-observation.test.tsx','goal-graph-actual-lossless-command-fixture.json','goal-graph-actual-lossless-data-fixture.json','goal-graph-types.ts','GoalGraphExecution.tsx']]:
 raw=show(path);assert raw==show(path,'4fab558fe126543c23b1410949e6fcd922b770d6');p=D/'exact-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);sourceproof[path]=sha(raw)
for kind in ['command','data']:
 value=json.loads(show('apps/desktop/src/goal-graph-actual-lossless-'+kind+'-fixture.json'));found=[]
 def visit(v,p=''):
  if isinstance(v,dict):
   if'observation_json'in v:
    text=v['observation_json'];assert sha(text.encode())==v['result_digest'];found.append({'path':p,'raw_bytes':len(text.encode()),'sha256':sha(text.encode()),'unsafe_integer_values':list(large(json.loads(text)))})
   for k,x in v.items():visit(x,p+'/'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):visit(x,p+'/'+str(i))
 visit(value);assert found;fixtures[kind]=found
current={}
for kind in ['command','command-timeout']:
 v=json.loads((A/('goal-graph-'+kind)/'report.json').read_text())['observations']['real_validator'];raw=v['observation_json'].encode();assert sha(raw)==v['receipt']['result_digest'];current[kind]={'raw_bytes':len(raw),'sha256':sha(raw),'unsafe_integer_values':list(large(v['receipt']['observation']))}
assert all(not x['unsafe_integer_values']for x in current.values())
out={'status':'passed','feature':HEAD,'Product_actual_checkout':CO,'tree':TREE,'candidate':candidate,'reports':reports,'checks':114,'PNG_count':70,'PNG_hashes':images,'frontend_assets_per_report':assetmaps,'quiet_asset_attribution':'quiet report has no per-run asset map; shared CI dist source/config attribution only','Node':{'tests':564,'files':37},'harness_sources':sources,'unchanged_lossless_UI_sources':sourceproof,'saved_original_packet_lossless_controls':fixtures,'current_real_Command_observations':current,'data_cancel_actual_stage':cancel['cancellation_stage'],'data_copy_known_unexercised':['no-join unknown','ready-wins-cancel race'],'Rust':'not yet audited; no PASS claim','limits':'No daemon binary uploaded for direct rehash; candidate digest crossbound to all reports. No original temporary runtime DB/files uploaded: retained SQL/event/receipt crosschecks do not reread that DB. No actual Provider/Mac/Owner dialog/new installer proof.'}
(D/'ui-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','reports':12,'checks':114,'PNGs':70,'Node':'564/37','data_cancel_stage':cancel['cancellation_stage']}))
