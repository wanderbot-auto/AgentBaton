from pathlib import Path
import json,re,hashlib,subprocess,ast
D=Path(__file__).resolve().parent;R=Path('/workspace/.worktrees/goal-graph-integration');HEAD='0aa20c968d493cad895e4a3853bdf106d6b54acf';CO='5caecb5f9945b5fdb548f0e071a78e2d97537403'
job=json.loads((D/'rust-job.json').read_text());assert(job['id'],job['run_id'],job['head_sha'],job['status'],job['conclusion'])==(123075460170,40761824261,HEAD,'completed','success')
rust=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(D/'product-rust.log').read_text());assert'HEAD is now at 5caecb5 Merge '+HEAD+' into a1be94d26d10bb245bb35eb50226b82012c967da'in rust and re.search(r'^.*Z '+CO+'$',rust,re.M)
phase='rust';outer=docs=nested=0;rows=[]
for line in rust.splitlines():
 if'Doc-tests 'in line:phase='docs'
 m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.* (\d+) filtered out;',line)
 if not m:continue
 passed,failed,ignored,filtered=map(int,m.groups());assert failed==ignored==0
 if filtered:nested+=passed
 elif phase=='docs':docs+=passed
 else:outer+=passed
 rows.append({'passed':passed,'failed':failed,'ignored':ignored,'filtered':filtered,'phase':phase,'excluded_from_unique_outer':bool(filtered),'log':line})
assert(outer,docs,nested)==(593,7,2),(outer,docs,nested)
assert'Ran 29 tests'in rust and'Ran 15 tests'in rust and'PASS real local daemon/CLI: Unicode create, idempotency, evidenced draft cancellation, journal, SIGKILL/restart persistence'in rust
assert'cargo clippy --workspace --all-targets --locked -- -D warnings'in rust and'Finished `dev` profile'in rust
assert'AGENTBATON_OWNER_FIXTURE_DAEMON: /home/runner/work/AgentBaton/AgentBaton/target/debug/batond'in rust
sources={};counts={}
for path in ['crates/providers/tests/validate-native-schema.py','apps/desktop/src-tauri/tests/test_native_runner.py','apps/desktop/src-tauri/tests/test_native_owner_dialog.py','.github/workflows/product.yml']:
 b=subprocess.check_output(['git','show',HEAD+':'+path],cwd=R);p=D/'exact-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);sources[path]=hashlib.sha256(b).hexdigest()
 if path.endswith('test_native_runner.py')or path.endswith('test_native_owner_dialog.py'):
  counts[path]=sum(isinstance(n,ast.FunctionDef)and n.name.startswith('test_')for n in ast.walk(ast.parse(b)))
assert sorted(counts.values())==[15,29]
art=json.loads((D/'artifacts-api-after-rust.json').read_text());a=next(a for a in art['artifacts']if a['id']==12849725875)
assert a['workflow_run']['id']==40761824261 and a['workflow_run']['head_sha']==HEAD and a['name']=='provider-contract-'+CO
wire=(D/'provider-artifact/wire.ndjson').read_text();frames=[json.loads(line)for line in wire.splitlines()];assert len(frames)==9
proof={'status':'passed','feature':HEAD,'actual_Product_Rust_checkout':CO,'Rust_outer_unique':outer,'compile_fail_docs':docs,'excluded_nested_pass_summaries':nested,'summaries':rows,'Python_CI':{'native_runner':29,'owner_runner_with_actual_Core':15,'same_coverage_as_source_counts':counts},'local_product_smoke':'actual CI daemon/CLI Unicode/idempotency/draftcancel/journal/SIGKILLrestart passed; reviewer did not rerun product','Clippy':'actual CI workspace all targets -Dwarnings passed; reviewer no Cargo','source_hashes':sources,'provider_frames':len(frames),'provider_schema_scope':'captured generated-child native contract; not live compatibility','schema_source_commit':'970111f6cb62cc02fe36a82ea7d71b37a2889c97','schema_sha256':hashlib.sha256((D/'provider-artifact/schema.json').read_bytes()).hexdigest(),'wire_sha256':hashlib.sha256((D/'provider-artifact/wire.ndjson').read_bytes()).hexdigest()}
(D/'rust-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in ['status','Rust_outer_unique','compile_fail_docs','excluded_nested_pass_summaries','provider_frames','schema_sha256']}))
