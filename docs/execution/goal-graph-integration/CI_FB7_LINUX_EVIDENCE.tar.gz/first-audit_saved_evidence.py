from pathlib import Path
import json,hashlib,re,subprocess
R=Path(__file__).parent;HEAD='fb7ff7d861872eec18e010f7b64a0ead63740faa';CHECKOUT='613166104190bedb3730a7510743137422ab05fa';TREE='bcfd8e5aaa3f06b63b88608e6b7ba05e9d5ca262';sha=lambda b:hashlib.sha256(b).hexdigest();out={'feature':HEAD,'checkout':CHECKOUT,'tree':TREE,'review_mode':'independent saved-evidence decode; no product/browser/daemon run'}
api=json.loads((R/'actual-checkout-commit-api.json').read_text());assert api['sha']==CHECKOUT and api['tree']['sha']==TREE;assert [x['sha'] for x in api['parents']]==['a1be94d26d10bb245bb35eb50226b82012c967da',HEAD];assert subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd='/workspace/.worktrees/goal-graph-integration').decode().strip()==TREE
out['checkout_log_binding']=[]
for name in ['ui-job.log','rust-job.log','environment-linux.log']:
 raw=(R/name).read_bytes();lines=raw.decode().splitlines();proof=[{'line':i+1,'raw_line':x} for i,x in enumerate(lines) if CHECKOUT in x and ('git log' not in x) and ('fetch' not in x) and ('[new ref]' not in x) and not any(z in x for z in ['name:','Artifact'])];assert any(re.search(r'Z '+CHECKOUT+r'$',x) for x in lines);assert any('Merge '+HEAD+' into a1be94d' in x for x in lines);out['checkout_log_binding'].append({'file':name,'sha256':sha(raw),'lines':proof})
prod=json.loads((R/'product-jobs.json').read_text())['jobs'];env=json.loads((R/'environment-jobs.json').read_text())['jobs'];assert len(env)==3 and all(x['conclusion']=='success' and x['head_sha']==HEAD for x in env);assert all(next(x for x in prod if x['id']==i)['conclusion']=='success' for i in [123137412097,123137412129]);out['API_scope']={'product_snapshot':[{'id':x['id'],'name':x['name'],'conclusion':x['conclusion'],'status':x['status']} for x in prod],'environment':[{k:x[k] for k in ['id','name','conclusion']} for x in env],'no_polling_other_platforms':True}
rust=(R/'rust-job.log').read_text();phase='outer';rows=[]
for i,line in enumerate(rust.splitlines()):
 if 'Doc-tests ' in line:phase='docs'
 m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',line)
 if m:
  passed,failed,ignored,measured,filtered=map(int,m.groups());assert failed==ignored==0;rows.append({'line':i+1,'raw_line':line,'passed':passed,'dimension':'nested_excluded' if filtered else phase})
counts={x:sum(row['passed'] for row in rows if row['dimension']==x) for x in ['outer','docs','nested_excluded']};assert counts=={'outer':593,'docs':7,'nested_excluded':2};out['Rust']={'counts':counts,'raw_summaries':rows}
ui=(R/'ui-job.log').read_text();clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',ui);nf=int(re.search(r'Test Files\s+(\d+) passed',clean)[1]);nt=int(re.search(r'Tests\s+(\d+) passed',clean)[1]);assert(nf,nt)==(37,564);py=[int(x) for x in re.findall(r'Ran (\d+) tests in',rust)];assert py==[29,20];out['Node']={'files':nf,'passed':nt};out['Python_CI']={'runner':py[0],'Owner':py[1]}
paths=['ui/evidence.json','ui/approved-commands/evidence.json','ui/goal-planning/report.json','ui/goal-plan-editor/report.json','ui/data-workspaces/report.json','ui/goal-execution/report.json']+[f'ui/goal-graph-{m}/report.json' for m in ['owner','integrity','data','command','data-range','command-timeout']];reports=[];candidate=json.loads((R/'ui/goal-execution-candidate.json').read_text());assert candidate['schema']==12 and candidate['git_head']==CHECKOUT and candidate['git_tree']==TREE and candidate['dirty']==False;daemon=candidate['binaries']['batond'];frontend=set()
for name in paths:
 p=R/name;d=json.loads(p.read_text());assert all(x['status']=='passed' for x in d['checks']);assert d.get('status','passed')=='passed' and not d.get('failure');assert d['daemon_sha256']==daemon
 if 'candidate' in d:assert d['candidate']==candidate and d['manifest_sha256']==sha((R/'ui/goal-execution-candidate.json').read_bytes())
 if 'frontend_assets_sha256' in d:frontend.add(d['frontend_assets_sha256'])
 if 'cleanup' in d:cleanup={'kind':'structured Graph cleanup','records':d['cleanup']}
 elif 'daemon_exit_code' in d:assert d['daemon_exit_code']==0;cleanup={'kind':'daemon_exit_code only','daemon_exit_code':0}
 elif name=='ui/goal-execution/report.json':cleanup={'kind':'no top-level cleanup; owned_stop_receipt_chains and failure_cleanup observation only','failure_cleanup':d['observations']['failure_cleanup']}
 else:cleanup={'kind':'no structured top-level cleanup record; do not infer total process/browser quiescence'}
 reports.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'checks':len(d['checks']),'cleanup_evidence':cleanup})
assert len(frontend)==1 and sum(x['checks'] for x in reports)==114;out['browser']={'reports':reports,'flows':12,'checks':114,'frontend_assets_sha256':next(iter(frontend)),'daemon_sha256':daemon,'candidate':candidate}
pngs=list((R/'ui').rglob('*.png'));assert len(pngs)==70;out['PNGs']=70
schema=(R/'provider/schema.json').read_bytes();assert sha(schema)=='f50e158c34ac55c5cc67c5493df539f1c07b603bd5dd2100a7393eefb62a3e20';sd=json.loads(schema)
def no_external(x):
 if isinstance(x,dict):
  if '$ref' in x:assert x['$ref'].startswith('#/')
  for v in x.values():no_external(v)
 elif isinstance(x,list):
  for v in x:no_external(v)
no_external(sd);wire=[json.loads(x) for x in (R/'provider/wire.ndjson').read_text().splitlines()];assert len(wire)==9;assert any('"validated_messages": 8' in x and sha(schema) in x for x in rust.splitlines());out['provider_contract']={'schema_sha256':sha(schema),'schema_pinned_ref':'970111f6cb62cc02fe36a82ea7d71b37a2889c97','wire_sha256':sha((R/'provider/wire.ndjson').read_bytes()),'captured_records':9,'CI_schema_validated_messages':8,'initialized_exact_notification_not_counted':True,'external_schema_refs':False,'real_provider_model_or_account':'not_run'}
imgs=[]
for name in ['ui/goal-graph-command/03-task-accepted-five-node-command.png','ui/goal-graph-command-timeout/01-five-node-command-timeout-blocked-before-owner.png']:
 b=(R/name).read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';imgs.append({'path':name,'sha256':sha(b),'width':int.from_bytes(b[16:20],'big'),'height':int.from_bytes(b[20:24],'big'),'opened_with_view_image':True})
out['images_actually_viewed']=imgs;out['remaining_images']='68 hash/CRC only; not visually inspected'
(R/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print('Saved-evidence auditPASS: exact3logs+API/tree/parents;Rust593+7 (nested2excluded);Node564/37;Python29+20;12flows114checks70PNG;2imagesviewed;schema8messages;no product rerun.')
