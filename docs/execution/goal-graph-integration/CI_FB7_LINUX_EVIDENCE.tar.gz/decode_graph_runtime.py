import pathlib,json,hashlib,shutil
D=pathlib.Path(__file__).resolve().parent;W=pathlib.Path('/workspace/.onboarding');rows=[]
S160='9b1bc1c5127b795c9a86fce85998b30f9a4cd36562c43439d9f7dca323ebc452';SA='4bc91fde76a61c4fdb829f3844f06cca20f94238add92d5b60bedb0edd00adc5'
base={'schema_version','kind','goal','node','run_id','plan_revision','plan_digest','workspace','inputs','outputs','policy','lineage','budget','idempotency_key','return_location'}
def sha(b):return hashlib.sha256(b).hexdigest()
def equal(a,b):
 if type(a)is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys()and all(equal(a[k],b[k])for k in a)
 if isinstance(a,list):return len(a)==len(b)and all(equal(x,y)for x,y in zip(a,b))
 if isinstance(a,float):return a.hex()==b.hex()
 return a==b
inputs=[(m,D/'ui'/('goal-graph-'+m),SA)for m in ['integrity','data','command','data-range','command-timeout','owner']]
for mode,src,subject in inputs:
 dest=src
 p=dest/'report.json';d=json.loads(p.read_text());o=d['observations'];negative=mode in('data-range','command-timeout');owner=mode=='owner'
 assert d['status']=='passed' and 'failure'not in d and d['harness_sha256']==subject
 assert len(d['checks'])==(5 if negative else 6)and all(c['status']=='passed'for c in d['checks'])
 assert not d['http_unexpected_errors']
 assert set(o['http_owner_denied'])=={'goal_graph_run_approve','goal_node_approve','goal_node_reject','approvals_finalize','approvals_decline','generic_ipc'}
 assert len(o['owned_task_requests'])==(2 if negative or owner else 3)
 request_summary=[]
 for r in o['owned_task_requests']:
  raw=r['raw_utf8'].encode();q=json.loads(raw);legacy=r.get('origin')=='real_legacy_bootstrap'
  assert len(raw)==r['utf8_bytes']and sha(raw)==r['sha256']and equal(q,r['request'])
  assert set(q)==(base if legacy else base|{'validation_contracts','task_binding'})
  assert r['owned_process_gone']is True
  if not legacy:
   a=r['candidate'];assert q['lineage']['attempt_id']==a['attempt_id']and q['run_id']==a['run_id']
   if not negative:
    assert r['reserved'][0]<r['intent_stopped'][0]<r['stop'][0]<r['capture'][0]
    assert r['stop'][1]['payload']['process_reaped']is True and r['capture'][1]['payload']['io_completion']=='worker_joined'
    assert r['stop'][0]==a['stop_receipt_sequence']and r['capture'][0]==a['capture_receipt_sequence']
   else:
    capture=o['negative_capture_event'];assert a['stop_receipt_sequence']<a['capture_receipt_sequence']==capture[0]
    assert capture[1]['payload']['candidate_id']==a['id']and capture[1]['payload']['io_completion']=='worker_joined'
   assert q['inputs'][0]['candidate']==a['consumed_inputs'][0]['candidate']
   assert q['task_binding']=={'task_id':a['task_id'],'attempt_id':a['attempt_id'],'spec_revision':a['spec_revision'],'input_revision':a['input_revision']}
  request_summary.append({'bytes':len(raw),'sha256':sha(raw),'legacy':legacy,'attempt_id':q['lineage']['attempt_id']})
 graph=o['blocked_graph']if negative else o['accepted']['graph'];taskid=graph['run']['task_id'];root='root:'+taskid;project='project:'+graph['run']['project_id'];budgets=o['observed_budgets'];expected=3 if negative else 2 if owner else 4
 assert budgets[root]==budgets[project]=={'consumed':expected,'active':0}
 if not owner:assert sorted(v['consumed']for k,v in budgets.items()if k.startswith('root:'))==[1,expected]
 validator=None
 if not owner:
  v=o['real_validator'];r=v['receipt'];raw=v['observation_json'].encode();assert sha(raw)==r['result_digest']and equal(json.loads(raw),r['observation'])
  assert r['source']=='baton_goal_validator'and r['task_acceptance']=='not_established'and r['passed']is(not negative)
  assert r['stop_confirmed']is True and r['io_completion']=='worker_joined'and v['node']['session_id']is None
  assert r['attempt_id']==v['node']['attempt_id']and r['actual_runtime_ms']==v['node']['actual_runtime_ms']and r['actual_runtime_ms']>0
  assert v['prepared'][0]<v['worker_started'][0]<v['attempt_stopped'][0]<v['settled'][0]
  assert v['worker_started'][1]['payload']['owned_thread_started']is True
  assert v['settled'][1]['payload']['result_digest']==sha(raw)and v['settled'][1]['payload']['receipt_digest']==v['receipt_sha256']
  assert v['provider_session_created_for_validator']is False and v['old_policy_executions']==0
  io=r['observation']['goal_io'];assert io['checked_candidate_bytes']==sum(a['bytes']for a in r['candidate_refs'])
  assert io['new_declared_artifact_bytes']==0 and io['total_filesystem_write_bytes']is None and io['total_filesystem_write_enforcement']=='not_enforced'
  assert v['new_output_bytes']==io['retained_stdout_bytes']+io['retained_stderr_bytes']==v['node']['actual_output_bytes']
  if mode=='command':assert v['new_output_bytes']==22 and r['observation']['stdout']['sha256_of_captured']==sha(b'fixed command observed')
  validator={'raw_observation_bytes':len(raw),'raw_observation_sha256':sha(raw),'original_receipt_digest_crossbound':v['receipt_sha256'],'events':[v[k][0]for k in ['prepared','worker_started','attempt_stopped','settled']],'actual_runtime_ms':r['actual_runtime_ms'],'new_output_bytes':v['new_output_bytes'],'passed':r['passed']}
 if negative:
  assert graph['task_accepted']is False and graph['task_acceptance']is None and not graph['owner_decisions']
  assert len(graph['candidates'])==1 and len(graph['validations'])==1
  assert all(n['session_id']is None for n in graph['nodes']if n['node']['id']!='produce-report')
  assert all(n['state']=='not_started'for n in graph['nodes']if n['node']['kind']=='owner_approval' or n['node']['id'].startswith('independent-'))
  if mode=='command-timeout':
   a=o['owned_command_child'];assert a['argv']==['/usr/bin/sleep','3']and a['pid']==a['pgid']and a['parent_pid']>0 and a['start_ticks']
   cr=[x for x in d['cleanup']if x['action']=='actual owned Command original identity not alive'];assert len(cr)==1 and cr[0]['expected_identity']==a and cr[0]['original_process_not_alive']is True and cr[0]['signal_sent']is False
   obs=o['real_validator']['receipt']['observation'];assert obs['contract']['wall_time_ms']==1500 and obs['contract']['cleanup_time_ms']==500
 else:
  assert graph['task_accepted']is True and graph['run']['state']=='accepted'and len(graph['owner_decisions'])==2
  for key in ['before_first_owner','before_final_owner']:assert o[key]['task_accepted']is False
  for index,ownerkey in enumerate(['owner-report','owner-summary']):
   detail=o['before_first_owner'if index==0 else'before_final_owner'];row=o['private_owner_decisions'][index];proposal=row['proposal'];snap=proposal['snapshot']
   assert proposal['kind']=='goal_node_acceptance'and row['decision']==row['replay']and row['recovered_proposal']['snapshot']==snap
   assert row['opposite_error']['code']=='CONFIG_CONFLICT'and row['opposite_error']['side_effect_state']=='not_started'
   node=next(n for n in detail['nodes']if n['node']['id']==ownerkey);assert snap['node']==node['node']
   expectedrefs=[]
   for req in node['node']['required_inputs']:
    matches=[a for c in detail['candidates']if c['node_id']==req['source']['node_id']for a in c['artifacts']if a['artifact_id']==req['artifact_id']and a['contract_id']==req['contract_id']];assert len(matches)==1;expectedrefs.extend(matches)
   assert equal(snap['candidate_refs'],expectedrefs)
   receipts=[c for c in detail['candidates']if c['id']in{a['candidate_id']for a in expectedrefs}];assert equal(snap['candidate_receipts'],receipts)
   vals=[{k:v for k,v in rec.items()if k!='observation_json'}for rec in detail['validations']if any(a in expectedrefs for a in rec['candidate_refs'])]
   assert equal(snap['validation_refs'],vals)and bool(vals)==(not owner and index==0)
  a=graph['task_acceptance'];event=o['durable_acceptance']['event'];assert event[0]==a['sequence']and event[1]['source']=='baton_goal_acceptance'
  assert event[1]['payload']['receipt_digest']==o['durable_acceptance']['receipt_sha256']and event[1]['payload']['acceptance_ref']==a['id']
  assert a['source']=='baton_goal_acceptance'and len(a['owner_decision_ids'])==2 and len(a['validation_ids'])==(0 if owner else 1)
  assert o['accepted']['task']['acceptance_ref']==a['id']and o['accepted']['task']['state']=='accepted'
  assert len(a['artifact_refs'])==(4 if mode=='data'else 2)
  for r in o['durable_owner_decisions']:
   assert r['event'][1]['payload']['receipt_digest']==r['receipt_sha256']and r['event'][1]['payload']['owner_decision_id']==r['decision']['id']
  produced=sum(a['bytes']for c in graph['candidates']for a in c['artifacts']);output=produced+(0 if owner else o['bootstrap']['output_bytes']+o['real_validator']['new_output_bytes'])
  for key in [project,'root-grant:'+a['root_grant_id']]:assert o['durable_acceptance']['ledgers'][key]['observed_attempts']==expected and o['durable_acceptance']['ledgers'][key]['output_bytes']==output
  for n in graph['nodes']:
   candidates=[c for c in graph['candidates']if c['node_id']==n['node']['id']]
   if candidates:assert n['actual_output_bytes']==sum(a['bytes']for c in candidates for a in c['artifacts'])
 for s in d['screenshots']:
  image=dest/pathlib.Path(s['path']).name;assert sha(image.read_bytes())==s['sha256']
  for control in s['owner_controls']:assert control['unobscured']is True and control['rect']['y']+control['rect']['height']<=s['viewport']['height']
 clean=d['cleanup'];assert any(x.get('thread_alive')is False for x in clean)and any(x.get('active_handlers')==[]for x in clean)
 daemon=[x for x in clean if x['action']=='owned daemon wait completed'];assert len(daemon)==1 and daemon[0]['wait_exitcode']==0 and daemon[0]['forced_sigkill']is False and daemon[0]['process_not_alive']is True
 owned=[x for x in clean if x['action']=='generated process original identity not alive'];assert len(owned)==len(o['owned_task_requests'])and all(x['original_process_not_alive']is True and x['matched_real_task_request']is True and x['signal_sent']is False for x in owned)
 rows.append({'mode':mode,'report_sha256':sha(p.read_bytes()),'harness_sha256':subject,'checks':len(d['checks']),'screenshots':len(d['screenshots']),'requests':request_summary,'budgets':budgets,'validator':validator,'cleanup':'HTTP thread/handlers joined, daemon exit0/no kill, exact generated identities gone','status':'passed'})
report={'status':'passed','dimension':'Independent retained report decoder + current raw reports/PNGs, not rerunning Core/Chrome; CI temporary DB/output files not included in artifacts, SQL original-byte SHA only crossbound to retained event/receipt hashes, not reserialized','modes':rows}
(D/'runtime-decoder.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','modes':len(rows),'checks':sum(x['checks']for x in rows),'screenshots':sum(x['screenshots']for x in rows)}))
