from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,datetime,tarfile,zipfile,stat
R=Path(__file__).parent;REPO='repos/wanderbot-auto/AgentBaton';HEAD='fb7ff7d861872eec18e010f7b64a0ead63740faa';attempts=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
def get(n,url):
 assert not (R/n).exists(),f'Already exists, no redownload: {n}'
 rec={'file':n,'endpoint':url,'start':now(),'attempted_once':True};attempts.append(rec);save('download-attempts.json',attempts)
 p=subprocess.run(['gh','api',url],capture_output=True,timeout=150);(R/n).write_bytes(p.stdout);rec.update(end=now(),exit=p.returncode,bytes=len(p.stdout),sha256=hashlib.sha256(p.stdout).hexdigest(),stderr=p.stderr.decode());save('download-attempts.json',attempts);assert p.returncode==0,(n,rec);print(n,len(p.stdout),flush=True);return p.stdout
products=json.loads(get('product-jobs.json',f'{REPO}/actions/runs/40779542803/jobs'));env=json.loads(get('environment-jobs.json',f'{REPO}/actions/runs/40779542808/jobs'));arts=json.loads(get('artifacts.json',f'{REPO}/actions/runs/40779542803/artifacts'))
assert all(x['head_sha']==HEAD for x in products['jobs']+env['jobs'])
for role,ident in [('ui',123137412097),('rust',123137412129)]:
 job=next(j for j in products['jobs'] if j['id']==ident);assert job['conclusion']=='success';get(role+'-job.log',f'{REPO}/actions/jobs/{ident}/logs')
job=next(j for j in env['jobs'] if 'linux' in j['name'].lower() or 'ubuntu' in j['name'].lower());assert job['conclusion']=='success';get('environment-linux.log',f'{REPO}/actions/jobs/{job["id"]}/logs')
print('artifact choices',[(a['id'],a['name']) for a in arts['artifacts']],flush=True)
for role in ['ui','provider']:
 matches=[a for a in arts['artifacts'] if ('ui' in a['name'].lower() if role=='ui' else 'provider' in a['name'].lower())];assert len(matches)==1,(role,matches);a=matches[0];assert not a['expired'];raw=get(role+'.zip',f'{REPO}/actions/artifacts/{a["id"]}/zip');assert hashlib.sha256(raw).hexdigest()==a['digest'].removeprefix('sha256:');assert len(raw)==a['size_in_bytes'],(role,len(raw),a['size_in_bytes'])
 dest=R/role;dest.mkdir();seen=set();items=[];total=0
 with zipfile.ZipFile(R/(role+'.zip')) as z:
  assert len(z.infolist())<=4096;assert z.testzip() is None
  for m in z.infolist():
   p=PurePosixPath(m.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in m.filename;assert m.filename not in seen;seen.add(m.filename);assert not stat.S_ISLNK(m.external_attr>>16);total+=m.file_size;assert total<=2000000000 and m.file_size<=1000000000
   q=dest.joinpath(*p.parts);assert q.resolve().is_relative_to(dest.resolve())
   if m.is_dir():q.mkdir(parents=True,exist_ok=True);continue
   b=z.read(m);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);items.append({'path':m.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'original_zip_mode':oct(m.external_attr>>16),'CRC32':f'{m.CRC:08x}'})
 save(role+'-inventory.json',{'api':a,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'official_digest_size_match':True,'CRC_paths_modes_nosymlink_duplicates_pass':True,'files':items})
print('READONLY_DOWNLOADS_COMPLETE',flush=True)
