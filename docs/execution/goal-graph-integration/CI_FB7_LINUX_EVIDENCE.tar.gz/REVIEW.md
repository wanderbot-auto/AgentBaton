# Independent exact-CI Linux evidence review — PR16 fb7ff7d

**Result:** the saved exact-head UI, Rust and three Environment job API results are successful, and the downloaded Linux artifacts support the stated test/Graph evidence. A Playwright teardown warning remains in the successful UI job; it is preserved and is not interpreted as a warning-free or universally quiescent browser exit. No product tests were rerun and no formal approval or overall PR/product acceptance is issued.

Feature `fb7ff7d861872eec18e010f7b64a0ead63740faa`; Product run **40779542803**, UI job **123137412097**, Rust job **123137412129**; Environment run **40779542808**. The saved API snapshot reports those two Product jobs and all three Environment jobs successful. Mac Product jobs were still in progress at this snapshot; this reviewer did not poll, download or assess them.

## Actual checkout binding

All **three downloaded raw logs** independently show both checkout's `HEAD is now` merge message and the full output of `git log -1 --format=%H`:

- UI log:121/124; Rust:120/123; Environment Linux:121/124.
- Actual checkout **`613166104190bedb3730a7510743137422ab05fa`**.
- Saved commit API parents: `a1be94d26d10bb245bb35eb50226b82012c967da` + feature fb7ff7d…; tree **`bcfd8e5aaa3f06b63b88608e6b7ba05e9d5ca262`**, matching the local fixed feature Git tree.

The API did not replace the actual checkout log evidence. The UI candidate manifest independently records the same checkout/tree, schema12 and debug daemon SHA **`a07b00de7eb58128f2dde32397e9c49b3918ff0413195c574f9eb8feae4208c3`**; all twelve reports bind that daemon, and all asset-bearing reports agree on the complete frontend hash map. Candidate `dirty=false` is a fixture manifest field, not a separately measured source-before/after audit by this reviewer. Four supporting fixed source files are saved under `source/` with hashes, including the exact Graph harness and pinned-schema validator.

## Once-only downloads and artifact integrity

The review directory did not exist at the initial check. UI/Rust/Environment-Linux raw logs were each downloaded once; each ZIP was requested once. `download-attempts.json` retains endpoints, timestamps, exits, raw sizes/hashes and stderr. A separate one-time commit API read is recorded. Existing configured `gh` access was used; no login, identity switching or credential reading occurred.

| Artifact | API ID | ZIP bytes | SHA-256 | Regular files |
| --- | ---: | ---: | --- | ---: |
| frontend-real-ipc-613166… |12857315069|9110342|`9066194d6b2df1f69a6250a0195ac04da534399f6b8d0a2360856c32dc5572d5`|95|
| provider-contract-613166… |12857580188|74557|`189c9c46e2fe0fa7b977b8731aca90de6e794a135c0325f8ba3e00579fe14485`|2|

Both archives exactly match GitHub's official digest and compressed size. CRC reads, bounded extraction, safe relative paths, duplicate checks and ZIP-mode symlink checks pass. `ui-inventory.json` and `provider-inventory.json` retain every original member mode, CRC, byte size and SHA. These are test evidence archives, not installers or signed release artifacts.

## Actual results, without repeated/nested inflation

Raw Rust result summaries independently total **593 unique outer cases +7 compile-fail documentation cases**. The two filtered nested subprocess cases are separately excluded rather than added to the total. All successful summary rows have zero failed and ignored cases. Node reports **564 passed /37 files**. The Rust job's actual Python suites are **29 +20**, with elapsed times2.514s/6.838s; the older19/15 counts are not substituted. Those20 Owner tests include the added bidi control regression and original generated local bootstrap/SQLite controls; they are not macOS OS-dialog execution.

Environment Linux independently records bootstrap93 files, design130 requirements/27 answered questions and infrastructure15 pinned references passing. The other two Environment successes are API observations only in this review; their logs were not downloaded. No current AppKit, native GUI, real Provider account/model, package or minimum-macOS conclusion follows from this Linux evidence.

The Provider ZIP contains nine captured generated-child frames (eight schema-validated messages plus the exact `initialized` notification). CI records **8 validated messages** against official schema SHA **`f50e158c34ac55c5cc67c5493df539f1c07b603bd5dd2100a7393eefb62a3e20`**, pinned ref `970111f6cb62cc02fe36a82ea7d71b37a2889c97`. The reviewer rehashed the raw schema, checked internal-only refs and parsed the captured wire; no account/model or vendor executable was run. CI's schema-validation result is not relabeled an independently rerun protocol test.

## Twelve flows and exact Graph evidence

All **12 saved browser/UnixIPC reports contain114 passed checks**, with **70 PNGs**. Each report's bytes and image hashes are retained; no generated/mocked data were substituted during review. A reused decoder was first inspected against the saved schema and exact Graph harness hash **`4bc91fde76a61c4fdb829f3844f06cca20f94238add92d5b60bedb0edd00adc5`**. Its assertions were not relaxed; the only label change identifies this independent retained-report review. It reads reports/images only and invokes no product, browser, socket, validator process or model.

For the six Graph modes (owner, integrity, data, command, data-range and command-timeout), its independent decode passes **34 checks /14 screenshots** and verifies:

- Original UTF-8 TaskRequest byte lengths/digests and type-preserving decoded objects; exact modern/legacy field sets, task/attempt/spec/input bindings and consumed candidate references.
- Reservation → stop intent → actual reaped-process receipt → capture/worker-joined ordering and exact sequence identities. Negative modes retain failed validation, no TaskAccepted and unstarted Owner/independent nodes.
- Original validator `observation_json` bytes, result digests, retained receipt/event digests, declared validator lineage, actual runtime/output measurements and absence of Provider sessions for the validator. Unknown total filesystem-write accounting remains unknown, never silently zero.
- Two genuine outside-HTTP fixture Owner decisions on positive modes, exact candidate/validation references, idempotent replay, opposite-decision conflict and durable acceptance lineage. HTTP approval/finalize/generic bypass routes remain denied. These generated local Owner fixtures are not human macOS native confirmation.
- Root/project cumulative consumed budgets with active0; acceptance ledger output bytes equal the recorded produced/validator output bytes. No cross-root or repeated acceptance is fabricated from a UI label alone.
- Structured Graph cleanup records: HTTP worker joined/handlers empty, owned daemon waited exit0 without forced kill, and each generated process's original identity no longer alive with no cleanup signal falsely attributed to a different PID. Timeout mode retains the exact owned `/usr/bin/sleep 3` identity and original1500ms/500ms command limits.

Original temporary SQLite databases and runtime files are not included in these CI artifacts. Accordingly this checks saved raw observation bytes and event/receipt digest crossbindings, not an independent database re-query or re-execution of the commands.

Resource evidence differs across the other six reports, explicitly recorded per report in `AUDIT.json`: approved-commands records `daemon_exit_code=0`; Goal execution records owned-stop chains and empty `failure_cleanup`; baseline UI, planning, editor and Data reports have no top-level structured cleanup record. None of those omissions is filled in by assumption. Data copy cancellation in this run records **before_destination_reservation** plus cancellation-specific `worker_joined`; it does not establish partial-output interruption, no-join uncertainty or the Ready race matrix.

## Existing unresolved Playwright teardown warning

Current raw UI log:746–750, immediately **after** the final (12th) command-timeout passed report at:745 and **before** artifact upload:751, retains:

- `Task was destroyed but it is pending!` for a cancelling Playwright `Connection.run.<locals>.init()` task.
- `Future exception was never retrieved` and `TargetClosedError: Target page, context or browser has been closed`.

The already-downloaded e3cc UI log contains the same warning pattern at:729/731/733, also after its final command-timeout passed report and before upload. `playwright-warning-comparison.json` preserves exact lines, surrounding context and both raw-log hashes. This establishes that the warning pattern/stage was already present; it does **not** establish a common root cause, identify which lifecycle created the asynchronous future, prove a daemon/process leak, or show the warning fixed. CI marked the job successful, while its stderr remains meaningful evidence. The structured owned-resource receipts above do not certify every Playwright internal task was awaited.

No additional source-correctness blocker is established by this warning alone within this read-only evidence task. It remains an unresolved harness lifecycle observation, not a false all-clean exit claim.

## Two images actually inspected

Opened with `view_image`, both1488×1400 full-page PNGs:

- `ui/goal-graph-command/03-task-accepted-five-node-command.png`, SHA **`a4121744f3769b0c32e324f18b4979108a10a4dcde68eb2fe84b4a4fdf50f0b5`**: accepted Graph, two Owner decisions, one validation and two candidate results, with the UI's separate semantic-acceptance warning. The image agrees with the positively bound receipt history.
- `ui/goal-graph-command-timeout/01-five-node-command-timeout-blocked-before-owner.png`, SHA **`0aacc76a4ffd15f41af4c668639ad7d1808b1f0eac626f24538937b80b2f3b82`**: blocked run, failed validation, acceptance pending, Owner and dependent nodes not started; no fabricated acceptance.

These are browser screenshots, not native window or OS Owner evidence. Full-page height is not a claim that all content fit a physical viewport. The other **68 PNGs** received hash/CRC validation only and were not visually inspected by this reviewer.

## Review execution and retained failures

`audit-command.json` and `graph-decoder-command.json` record exact local commands, exit0 and raw stdout/stderr hashes. Both are saved-evidence parsing only. No Cargo/product/browser test was run, source/CI/remote/STATUS changed, or approval issued.

Reviewer-side failures were retained and distinguished from product failures: the first artifact selector searched for `ui` although the actual artifact is `frontend-real-ipc`, so it stopped **before any ZIP request**; existing downloaded logs/API were not fetched again. The first audit assumed frontend hashes were a scalar but they are a dictionary; its TypeError/script/log remain as `first-*`, and the corrected parser compares the full canonical map. A supporting Git path discovery error was corrected using fixed `git ls-tree`; no source mutation or relaxed semantic assertion followed. All original CI warnings, raw logs, source maps and downloaded archive bytes remain unchanged.

This review establishes the named Linux dimensions for the exact fb7 candidate. New Mac/Owner native presentation, complete package delivery, real Provider models and whole Design acceptance remain separate. The runtime skill was used only to inspect current network readiness; existing access remained in place.
