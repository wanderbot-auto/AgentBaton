from pathlib import Path
import importlib.util,sys,json,unittest
R=Path(__file__).parent;s=importlib.util.spec_from_file_location('scalar_fixture',R/'source/apps/desktop/src-tauri/tests/test_native_owner_dialog.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
class ScalarNegative(unittest.TestCase):
 def test_same_class_scalar_types_remain_exact(self):
  for case in ['confirmation_revision','pending_schema','approved_schema']:
   with self.subTest(case=case):
    proposal,after,response=m.approved();after=json.loads(json.dumps(after));response=json.loads(json.dumps(response))
    if case=='confirmation_revision':after['events'][1]['revision']=2.0;result=m.runner.approved_error(after,proposal,9,response)
    elif case=='approved_schema':after['schema_version']=12.0;result=m.runner.approved_error(after,proposal,9,response)
    else:
     proposal,pending=m.pending();pending=json.loads(json.dumps(pending));pending['schema_version']=12.0;result=m.runner.pending_error(pending,proposal,9)
    self.assertIsNotNone(result,'CAS/schema scalars must retain exact JSON integer type')
if __name__=='__main__':unittest.main(verbosity=2)
