from pathlib import Path
import importlib.util,sys,json,unittest
R=Path(__file__).parent;P=R/'source/apps/desktop/src-tauri/tests/test_native_owner_dialog.py';spec=importlib.util.spec_from_file_location('typed_record_fixture',P);fixture=importlib.util.module_from_spec(spec);sys.modules[spec.name]=fixture;spec.loader.exec_module(fixture)
class TypedRecordNegative(unittest.TestCase):
 def test_independently_decoded_records_reject_numeric_boolean_type_substitution(self):
  for label,layer,container,field,value in [('event limit bool','event','scope','max_attempts',True),('event enforcement int','event','enforcement','baton_mediated_scope',1),('response limit bool','response','scope','max_attempts',True),('stored proposal_result limit bool','proposal_result','scope','max_attempts',True)]:
   with self.subTest(case=label):
    proposal,after,response=fixture.approved();after=json.loads(json.dumps(after));response=json.loads(json.dumps(response));target=after['events'][0]['payload'] if layer=='event' else response['result'] if layer=='response' else after['proposal_result'];target[container][field]=value
    self.assertIsNotNone(fixture.runner.approved_error(after,proposal,9,response),'Isolated JSON types must match the original Grant exactly')
if __name__=='__main__':unittest.main(verbosity=2)
