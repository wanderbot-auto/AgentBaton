from pathlib import Path
import json,hashlib,subprocess,ast,importlib.util,sys
R=Path(__file__).parent;A=Path('/workspace/AgentBaton/.onboarding/native-grant-contract/typed-json');OLD=Path('/workspace/.onboarding/native-grant-fbfd-review');repo=Path('/workspace/.worktrees/native-grant-contract');rev='1839c6c8ca82319ad18cd6c5dd3825b19dde5ee7';base='fbfd66e0bac5f167592adf9bc75a5e6c70a0655a';sha=lambda b:hashlib.sha256(b).hexdigest();E=R/'evidence';E.mkdir(exist_ok=True);mb=(A/'MANIFEST.json').read_bytes();assert sha(mb)=='82633948722ad6d1de99262020606ed4842a4c24dd91fd20fd72310832d2c430';m=json.loads(mb);(E/'author-MANIFEST.json').write_bytes(mb)
for n,h in m['evidence_sha256'].items():
 b=(A/n).read_bytes();assert sha(b)==h;(E/n).write_bytes(b)
for row in json.loads((R/'source-manifest.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{rev}:{row["path"]}'],cwd=repo);assert b==(R/'source'/row['path']).read_bytes() and sha(b)==row['sha256']
for p,h in m['unchanged_rust_source_sha256'].items():assert sha((R/'source'/p).read_bytes())==h and (R/'source'/p).read_bytes()==subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo)
p='apps/desktop/src-tauri/tests/test_native_owner_dialog.py';oldtest=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newtest=(R/'source'/p).read_text()
def tests(s):return {c.name+'.'+f.name:ast.dump(f,include_attributes=False) for c in ast.parse(s).body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
a,b=tests(oldtest),tests(newtest);assert len(a)==24 and len(b)==28 and all(b[k]==v for k,v in a.items())
p='scripts/native-owner-dialog-smoke.py';oldrunner=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo).decode();newrunner=(R/'source'/p).read_text()
def nodes(s):return {f.name:ast.get_source_segment(s,f) for f in ast.parse(s).body if isinstance(f,(ast.FunctionDef,ast.ClassDef))}
a,b=nodes(oldrunner),nodes(newrunner)
for n in ['run','database','NativeCoreClient','expected_message','presentation_prompts','opaque_id','grant_scope','grant_enforcement']:assert a[n]==b[n],n
for name,expected in [('REVIEW.md','3890ff0bd15eac6d0ad5339910420dc464d3d3d9d5995453adc603d0ed627e97'),('REVIEW_MANIFEST.json','98a3f10e0a26f20330880f6a32fdbb9ede28bc43a916da46f702d4dfa9b4b20c')]:assert sha((OLD/name).read_bytes())==expected
for n in ['typed-negative.stderr','typed-negative-command.json']:(E/('old-fbfd-'+n)).write_bytes((OLD/n).read_bytes())
spec=importlib.util.spec_from_file_location('typed_1839_guard',R/'source/scripts/native-owner-dialog-smoke.py');runner=importlib.util.module_from_spec(spec);sys.modules[spec.name]=runner;spec.loader.exec_module(runner);mac=[]
for arch in ['arm','intel']:
 d=Path('/workspace/.onboarding/pr16-fb7-mac-review')/(arch+'-native-artifact/owner-dialog');vals={}
 for n in ['fixture.json','after.json','approve-reply.json']:
  raw=(d/n).read_bytes();p=E/arch/n;p.parent.mkdir(exist_ok=True);p.write_bytes(raw);vals[n]=json.loads(raw)
 fixture=vals['fixture.json'];assert runner.approved_error(vals['after.json'],fixture['proposal'],fixture['baseline_sequence'],vals['approve-reply.json']) is None;mac.append({'arch':arch,'new_typed_predicate_saved_original_packet_pass':True,'offline_not_new_OS':True,'hashes':{n:sha((d/n).read_bytes()) for n in vals}})
out={'revision':rev,'baseline':base,'author_manifest_sha256':sha(mb),'author_evidence_count':len(m['evidence_sha256']),'old24_AST_unchanged':True,'new_test_count':28,'Rust_two_byte_identical_to_fbfd':True,'full_OS_run_bytes_unchanged':True,'other_host_mechanics_bytes_unchanged':True,'old_fbfd_report_seal_intact':True,'original_twoMac_packets':mac,'scope':'originalfourP2repros nowPASS;newscalarconfirmation/schema3negativeFAIL;independent28PASS;noCargo/browser'};(R/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('Verifiedauthor826/logs;8fixedfiles;old24AST/Rust2/fullOSrununchanged;oldfbfdsealintact;original2MacofflinePASS;3scalarnegative remainsopen.')
