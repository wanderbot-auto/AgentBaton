# Intermediate independent typed-contract review — fixed1839

**Disposition: NG-FBFD-01 original four cross-record cases are repaired, but the same scalar type class remains open.** Root authorized a final bounded scalar enumeration in a subsequent revision. This fixed report preserves actual28-test success and the newly failing cases; it is not a final closure or Mac acceptance.

Source `1839c6c8ca82319ad18cd6c5dd3825b19dde5ee7`, baseline `fbfd66e0bac5f167592adf9bc75a5e6c70a0655a`. Eight fixed Git files are exported. The old fbfd review/manifest remain unchanged (`3890ff…` /`98a3f1…`). Factory CI's separate five-file WIP was paused before this review.

## Repaired scope

`json_exact` distinguishes boolean/integer/float types recursively, verifies JSON object keys and rejects nonfinite floats. It is applied to response/proposal-result/Grant association, complete scope/enforcement/bindings, proposal snapshots and both event payloads. Presentation index/count/revision comparison also uses it. The original four independently parsed-record tests are replayed using the exact previous independent script: **one test/four subcases PASS** rather than the old fbfd four failures. No original counterexample was deleted or normalized.

The exact old24 test ASTs are unchanged, and four tests were added (total28). The two Rust files are byte-identical to fbfd. Full host OS runner, bootstrap client, raw database reader, prompt encoding, opaque ID checks and scope/enforcement constructors are unchanged. No layout, capture, click, permit, deadline, scope or authority boundary changes.

## Same-class residual scalar findings

`approved_error`'s confirmation branch still uses ordinary numeric equality for `approval.confirmed.revision`; pending/approved schema checks still use ordinary `schema_version !=12`. Independently parsed JSON controls find:

- Confirmation event revision **2.0** is accepted against consumed proposal integer2.
- Pending schema version **12.0** is accepted.
- Approved schema version **12.0** is accepted.

`scalar_negative.py` executes one finite test with these three subcases. All three fail the required refusal assertion, **exit1 /failures3**, with original stdout/stderr. This is the same bool/int/float scalar issue, not an expanded architecture audit. No Core/browser execution is involved. Root and author acknowledged and authorized a final tiny typed-scalar correction; the old source and author826 manifest stay frozen.

The independently observed approved-Grant revision/depth fields already have explicit integer guards; they must remain so. No production authorization bypass, real malformed Core output or changed OS consent was demonstrated by these evidence-validator negatives.

## Actual execution and evidence

Root explicitly returned the short CPU window after its separate unknown-flow observation. This reviewer independently ran the entire fixed source suite: **28PASS /7.162s**, including the original three and added one generated real Core bootstrap/SQLite cases. The selected frozen `40322bff82aa8ec0f1c019e5d723f42694a6266bcaa27b153f535d0d21dbadcd` daemon hash is unchanged before/after. Original stdout/stderr, argv/cwd/timestamps and exit0 are preserved. The window was immediately returned. No Cargo/browser/Provider account/model operation occurred.

Author manifest SHA **`82633948722ad6d1de99262020606ed4842a4c24dd91fd20fd72310832d2c430`** and every listed evidence hash verify. Its author28PASS6.823s is separate from this independent run; repeated cases are not summed. Old four-failure and fixed-four-pass logs remain. All8 exported files match fixed Git and Rust2 hashes match the prior Root10 controller compilation source; no new Rust test execution is borrowed for Python changes or described as this reviewer's Cargo.

The two original arm/intel after/response/fixture packet sets were byte-read from the sealed fb7 Mac artifacts and pass the new typed predicate offline. This demonstrates compatibility with the saved actual valid outputs only. It does not rerun the original24 per-page OS interactions, reverse failed CI status, prove new Mac success or produce packages. The original snapshot/19zero/CAS/sequence/frame/page/visibility/75s/85s/4s/500ms gates remain.

This report closes the original four concrete reproductions at1839 but leaves NG-FBFD-01's identified scalar family open pending one final fixed revision. The original fbfd report and this intermediate28/failure evidence must remain immutable. No source, target, CI, STATUS, remote or formal approval was changed by this reviewer.
