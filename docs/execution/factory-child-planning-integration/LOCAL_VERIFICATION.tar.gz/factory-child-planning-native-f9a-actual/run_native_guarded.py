#!/usr/bin/env python3
"""PREPARED ONLY. Default is read-only plan; execute only after Root's exclusive lease.
No Provider, browser, AppKit, or normal-product executable is invoked by this runner.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import time

ROOT = Path('/workspace/.worktrees/factory-runtime-integration')
HEAD = 'f9a7e0cd81c2e106e723c083e8c9b0a16fa33e2b'
TARGET = Path('/workspace/.worktrees/validation-integration/apps/desktop/src-tauri/target')
TOOLS = Path('/workspace/.onboarding/factory-child-planning-root-postlint-tools/frozen')
OUT = Path(__file__).resolve().parent
CARGO = '/workspace/.toolchains/cargo/bin/cargo'
FEATURES = ['--features', 'native-smoke,custom-protocol']
BASE = [CARGO, 'test', '--offline', '--locked', '--manifest-path', 'apps/desktop/src-tauri/Cargo.toml', *FEATURES]
COMMANDS = [BASE + ['--lib', '--bin', 'agentbaton-native-smoke', '--', '--show-output'],
            BASE + ['--bin', 'agentbaton-native-owner-dialog-smoke', '--', '--show-output']]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def regular(path):
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode):
        raise ValueError('Expected non-symlink regular file: ' + str(path))
    return {'dev': s.st_dev, 'inode': s.st_ino, 'nlink': s.st_nlink,
            'mode': stat.S_IMODE(s.st_mode), 'size': s.st_size, 'sha256': sha(path)}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def tracked():
    entries = subprocess.check_output(['git', 'ls-files', '-v', '-z'], cwd=ROOT).decode().split('\0')
    result = {}
    for entry in entries:
        if not entry:
            continue
        flag, value = entry[0], entry[2:]
        p = ROOT / value
        if p.exists():
            result[value] = sha(p)
        elif flag == 'S':
            result[value] = None  # explicit sparse-absent tracked file, not a missing source success
        else:
            raise ValueError('Non-sparse tracked file missing: ' + value)
    return result

def inventory(debug):
    original = {n: regular(debug / n) for n in ('baton', 'batond')}
    aliases = {n: [] for n in original}
    for base, dirs, files in os.walk(debug, followlinks=False):
        dirs[:] = [d for d in dirs if not (Path(base) / d).is_symlink()]
        for f in files:
            p = Path(base) / f
            s = p.lstat()
            for name, before in original.items():
                if (s.st_dev, s.st_ino) == (before['dev'], before['inode']):
                    aliases[name].append(str(p))
    for name, before in original.items():
        if len(aliases[name]) != before['nlink']:
            raise ValueError('Unaccounted hardlink outside scanned target: ' + name)
    return original, aliases

def validate_aliases(original, aliases, moved):
    for name, before in original.items():
        for value in aliases[name]:
            p = Path(value)
            if p == TARGET / 'debug' / name:
                p = moved[name]
            if regular(p) != before:
                raise ValueError('Original inode/alias changed; retain all backups: ' + str(p))

def restore(original, aliases, moved, hashes, debug):
    # Preflight ALL known paths before removing ANY stage; no overwrite of unknown bytes.
    for name, backup in moved.items():
        if regular(backup) != original[name]:
            raise ValueError('Changed backup; retain it: ' + str(backup))
        p = debug / name
        if os.path.lexists(p) and regular(p)['sha256'] != hashes[name]:
            raise ValueError('Unknown shared target content; retain backups and stop: ' + str(p))
        for value in aliases[name]:
            if value != str(p) and regular(Path(value)) != original[name]:
                raise ValueError('Known original alias changed; retain backups: ' + value)
    for name, backup in moved.items():
        p = debug / name
        if os.path.lexists(p):
            p.unlink()
        backup.rename(p)
        if regular(p) != original[name]:
            raise ValueError('Original inode restoration mismatch: ' + name)

def preflight(staged=False):
    if git('rev-parse', 'HEAD') != HEAD or git('status', '--porcelain', '--untracked-files=no'):
        raise ValueError('Root HEAD or tracked content changed')
    m = json.loads((TOOLS / 'manifest.json').read_text())
    if m['git_head'] != HEAD or m['git_tree'] != git('rev-parse', 'HEAD^{tree}') or m['schema'] != 14:
        raise ValueError('Not exact-head schema14 prepared tools')
    probe = m['probe']
    if len(probe['zero_tables']) != 11 or any(type(v) is not int or v != 0 for v in probe['zero_tables'].values()) or probe['schema'] != 14 or probe['original_daemon_SIGTERM_wait_exit'] != 0 or probe['forced_kill']:
        raise ValueError('Prepared-tool probe incomplete')
    for name, expected in m['binaries'].items():
        if regular(TOOLS / name)['sha256'] != expected:
            raise ValueError('Prepared-tool drift')
    config = json.loads((ROOT / 'apps/desktop/src-tauri/tauri.conf.json').read_text())
    if config['bundle']['externalBin'] != ['binaries/batond', 'binaries/baton']:
        raise ValueError('Unexpected extra Tauri sidecar')
    if not (ROOT / 'apps/desktop/dist/index.html').is_file():
        raise ValueError('Missing existing frontend build; do not borrow old dist automatically')
    for name in m['binaries']:
        p = ROOT / 'apps/desktop/src-tauri/binaries' / (name + '-x86_64-unknown-linux-gnu')
        if os.path.lexists(p):
            if not staged or not p.is_symlink() or p.readlink() != TOOLS / name:
                raise ValueError('Existing sidecar path; refuse unknown path: ' + str(p))
        elif staged:
            raise ValueError('Staged sidecar missing: ' + str(p))
    return m

def execute():
    m = preflight()
    run = OUT / 'actual-run'
    run.mkdir(mode=0o700)  # never reuse a partially completed attempt
    backups = run / 'original-inodes'
    backups.mkdir(mode=0o700)
    debug = TARGET / 'debug'
    if backups.stat().st_dev != debug.stat().st_dev:
        raise ValueError('Backup must be same filesystem for inode-preserving rename')
    before, aliases = inventory(debug)
    source_before = tracked()
    (run / 'BEFORE.json').write_text(json.dumps({'head': HEAD, 'prepared_tools': m, 'tracked': source_before, 'tools': before, 'aliases': aliases}, indent=2) + '\n')
    if shutil.disk_usage(debug).free < 350 * 1024 * 1024:
        raise ValueError('Insufficient space for bounded Native test compilation; stop without cleanup')
    moved = {}
    links = []
    results = []
    failure = None
    restored = False
    try:
        for name in before:
            p = debug / name
            if regular(p) != before[name]:
                raise ValueError('Tool changed before backup')
            p.rename(backups / name)
            moved[name] = backups / name
            shutil.copyfile(TOOLS / name, p)
            p.chmod(0o755)
            if sha(p) != m['binaries'][name]:
                raise ValueError('Stage mismatch')
            link = ROOT / 'apps/desktop/src-tauri/binaries' / (name + '-x86_64-unknown-linux-gnu')
            link.parent.mkdir(exist_ok=True)
            link.symlink_to(TOOLS / name)
            links.append(link)
        env = os.environ.copy()
        for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_PROFILE_DEV_DEBUG'):
            if key in env:
                raise ValueError('Unexpected inherited compilation override: ' + key)
        env.update(CARGO_HOME='/workspace/.toolchains/cargo', RUSTUP_HOME='/workspace/.toolchains/rustup', CARGO_TARGET_DIR=str(TARGET), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2', RUST_TEST_THREADS='1', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
        sysroot = '/workspace/.toolchains/linux-ui/sysroot'
        env.update(PATH='/workspace/.toolchains/cargo/bin:' + env['PATH'], PKG_CONFIG_SYSROOT_DIR=sysroot, PKG_CONFIG_LIBDIR=sysroot + '/usr/lib/x86_64-linux-gnu/pkgconfig:' + sysroot + '/usr/share/pkgconfig:/usr/lib/x86_64-linux-gnu/pkgconfig:/usr/share/pkgconfig', LD_LIBRARY_PATH=sysroot + '/usr/lib/x86_64-linux-gnu', LIBRARY_PATH=sysroot + '/usr/lib/x86_64-linux-gnu')
        (run / 'ENVIRONMENT.json').write_text(json.dumps({k: env[k] for k in ('CARGO_HOME', 'RUSTUP_HOME', 'CARGO_TARGET_DIR', 'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_NET_OFFLINE', 'PKG_CONFIG_SYSROOT_DIR', 'PKG_CONFIG_LIBDIR', 'LD_LIBRARY_PATH', 'LIBRARY_PATH')}, indent=2) + '\n')
        for i, command in enumerate(COMMANDS):
            preflight(staged=True)
            log = run / ('native-' + str(i) + '.log')
            started = time.monotonic()
            stop = None
            with log.open('xb') as stream:
                process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    while process.poll() is None:
                        if shutil.disk_usage(debug).free < 200 * 1024 * 1024:
                            stop = 'Own process stopped at 200MiB disk guard; no cache deletion'
                            os.killpg(process.pid, signal.SIGTERM)
                            try:
                                process.wait(timeout=15)
                            except subprocess.TimeoutExpired:
                                os.killpg(process.pid, signal.SIGKILL)
                                process.wait()
                            break
                        time.sleep(1)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=15)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
            results.append({'argv': command, 'exit': process.returncode, 'elapsed_seconds': time.monotonic() - started, 'log': str(log), 'sha256': sha(log), 'interruption': stop})
            (run / 'COMMANDS.json').write_text(json.dumps(results, indent=2) + '\n')
            for name in before:
                if regular(debug / name)['sha256'] != m['binaries'][name]:
                    raise ValueError('Unknown target tool after macro; retain original backups')
            validate_aliases(before, aliases, moved)
            if process.returncode or stop:
                break
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            restore(before, aliases, moved, m['binaries'], debug)
            restored = True
        except BaseException as error:
            failure = (failure or '') + '; RESTORE STOP: ' + repr(error)
        for link in links:
            name = link.name.removesuffix('-x86_64-unknown-linux-gnu')
            if link.is_symlink() and link.readlink() == TOOLS / name:
                link.unlink()
            else:
                failure = (failure or '') + '; unknown sidecar path retained: ' + str(link)
        after = tracked()
        (run / 'RESULT.json').write_text(json.dumps({'head': HEAD, 'commands': results, 'failure': failure, 'original_inode_mode_nlink_sha_restored': restored, 'tracked_before_after_equal': source_before == after, 'changed': [p for p in source_before if source_before[p] != after[p]], 'dimension': 'Linux Rust tests only; no AppKit/GUI/real Provider/Mac claim'}, indent=2) + '\n')
    if failure or not restored or source_before != after or len(results) != len(COMMANDS) or any(r['exit'] for r in results):
        raise SystemExit(1)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--exclusive-lease-confirmed', action='store_true')
    args = parser.parse_args()
    if args.execute:
        if not args.exclusive_lease_confirmed:
            parser.error('Root must confirm exclusive Cargo/target/tool lease first')
        execute()
    else:
        print(json.dumps({'status': 'PREPARED_NOT_RUN', 'head': HEAD, 'commands': COMMANDS, 'required': 'Rootfull session complete; Root exclusive lease; same-head prepared tools; original aliases accounted; disk guard', 'expected_source_markers': {'library': 83, 'native_smoke': 30, 'owner_controller': 10}, 'planning_new_8_already_in_library': True}, indent=2))
