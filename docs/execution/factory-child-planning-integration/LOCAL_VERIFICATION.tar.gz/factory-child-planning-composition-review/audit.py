from pathlib import Path
import subprocess,hashlib,json,re,collections
O=Path(__file__).parent;R='/workspace/.worktrees/factory-runtime-integration';S='f9a7e0cd81c2e106e723c083e8c9b0a16fa33e2b';N='ea6ca3b0b6e30782b66decd78f0d4c3d435ba634';C='92658e4cecd74517371aaf47c5ce0f7de38e0eb0';W='68940d76e07da13bc4845a7a962c4fab836809d3';P=Path('/workspace/.onboarding');H=lambda b:hashlib.sha256(b).hexdigest();G=lambda *a:subprocess.check_output(['git',*a],cwd=R);F=lambda c,p:G('show',c+':'+p)
assert G('rev-parse','HEAD').decode().strip()==N and G('status','--porcelain')==b''
# Fixed Git exports only; no test/runtime execution.
paths=['crates/core/src/factory_child_plan.rs','crates/core/src/factory.rs','crates/core/src/factory_companion.rs','crates/core/src/ipc.rs','crates/core/src/factory_reads.rs','crates/core/tests/factory_child_plan_migration.rs','apps/desktop/src/factory-types.ts','apps/desktop/src/factory-api.ts','apps/desktop/src/factory-guards.ts','apps/desktop/src/factory-child-plan.ts','apps/desktop/src/FactoryChildPlans.tsx','apps/desktop/src/FactoryChildPlanEditor.tsx','apps/desktop/src/factory-form.ts','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/bin/native_smoke.rs','scripts/native-run.py','scripts/native-macos-smoke.sh','scripts/native-owner-dialog-smoke.py','scripts/prepare-factory-test-tools.py','.github/workflows/product.yml']
rows=[]
for p in paths:
 b=F(N,p);d=O/'subject'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);rows.append({'path':p,'sha256':H(b),'bytes':len(b)})
(O/'source-map.json').write_text(json.dumps({'initial_subject':S,'final_subject':N,'files':rows},indent=2)+'\n')
for name,base,head,selection in [('composition.patch',C,S,['crates','apps/desktop/src','apps/desktop/src-tauri/src','scripts','.github/workflows/product.yml']),('post-review.patch',S,N,[])]:
 (O/name).write_bytes(G('diff',base,head,'--',*selection))
# The Core alias is exactly the old tuple after substitution; SQL and behavior bytes unchanged.
p='crates/core/src/factory_child_plan.rs';b=F(S,p).decode();a=F(C,p).decode();m=re.search(r'    type StoredPlanRow = \([\s\S]*?\n    \);\n',b);assert m
normalized=(b[:m.start()]+b[m.end():]).replace('Option<StoredPlanRow>','Option<(Option<String>,Option<String>,String,String,String,i64,String,String)>');assert normalized==a
assert G('diff','--name-only',W,S).decode().splitlines()==[p]
assert not G('diff','da38259175afa1cd0b25fd47135a3e0ecf716f01',N,'--','apps/desktop/src')
assert not G('diff','a9baaa49b2b259be1e93d1e9894441be02b3095b',S,'--','apps/desktop/src-tauri/src/approval.rs','apps/desktop/src-tauri/src/lib.rs','apps/desktop/src-tauri/src/bin/native_smoke.rs')
assert not G('diff','745baac3fbdd664c35279585dca6a72edb1febdf',N,'--','scripts/native-run.py','scripts/native-macos-smoke.sh','scripts/native-owner-dialog-smoke.py')
assert not G('diff','6ab36d95c46d59725938d2ef233ecf71a47c5d40',N,'--','.github/workflows/product.yml','scripts/prepare-factory-test-tools.py')
# Historical migration13/14 rich fixture is byte-identical to independently reviewed926.
assert F(C,'crates/core/tests/factory_child_plan_migration.rs')==F(N,'crates/core/tests/factory_child_plan_migration.rs')
# New positive schema assertion fix: one number only, no alteration of old negative13 controls.
p='apps/desktop/src-tauri/src/bin/native_smoke.rs';old=F(S,p);new=F(N,p);needle=b'goal_execution_database_snapshot(&runtime).unwrap()["schema_version"],\n            13\n';assert old.count(needle)==1;assert old.replace(needle,needle.replace(b'13\n',b'14\n'))==new
current_changes=G('diff','--name-only',S,N).decode().splitlines();assert set(current_changes)=={p,'apps/desktop/tests/factory-child-planning-real-ipc.py',*['docs/execution/factory-child-planning-browser/'+n for n in ['PLAN.md','PROGRESS.md','CHECKPOINT.md','EVIDENCE.json']]}
assert F(N,'apps/desktop/tests/factory-child-planning-real-ipc.py')==F('0e1a4145e33f9cadf9f4da9095690b2fe293e578','apps/desktop/tests/factory-child-planning-real-ipc.py')
# Root-run records decoded, not rerun. Source map hashes checked for this audit's critical paths.
D=P/'factory-child-planning-root-full14-schema-fixed';bef=json.loads((D/'BEFORE.json').read_text());aft=json.loads((D/'AFTER.json').read_text());res=json.loads((D/'RESULT.json').read_text());assert bef['head']==aft['head']==res['source']==W and aft['changed_source']==[]
checked=[]
for p in paths:
 if p in bef['tracked_materialized_files']:
  assert H(F(W,p))==bef['tracked_materialized_files'][p];checked.append(p)
assert sum(x['passed']for x in aft['outer'])==659 and sum(x['failed']for x in aft['outer'])==0 and sum(x['passed']for x in aft['docs'])==7 and len(aft['nested_not_added'])==5
summaries=re.findall(r'^test result:.*$',(D/'workspace-tests.log').read_text(),re.M);assert collections.Counter(summaries)==collections.Counter(v['summary']for group in ['outer','docs','nested_not_added']for v in aft[group])
for cmd in res['commands']:
 log=D/(cmd['name']+'.log');assert H(log.read_bytes())==cmd['log_sha256']
assert next(c for c in res['commands']if c['name']=='workspace-tests')['exit_code']==0 and next(c for c in res['commands']if c['name']=='workspace-clippy')['exit_code']==101
cl=P/'factory-child-planning-root-clippy-fix';cv=json.loads((cl/'RESULTS.json').read_text());assert cv['source']==S and cv['source_unchanged']is True
for c in cv['commands']:assert c['exit_code']==0 and H((cl/(c['name']+'.log')).read_bytes())==c['log_sha256']
ui=P/'factory-child-planning-root-ui-build';uv=json.loads((ui/'RESULTS.json').read_text());assert uv['source']==S
for c in uv['commands']:
 prefix='typecheck'if c['command'][-1]=='typecheck'else'build';assert c['exit_code']==0
 for stream in ['stdout','stderr']:assert H((ui/(prefix+'.'+stream)).read_bytes())==c[stream+'_sha256']
for v in uv['dist']:
 d=Path(R)/v['path'];assert d.stat().st_size==v['bytes']and H(d.read_bytes())==v['sha256']
# Initial Native attempt aborted while compiling. No test-pass attribution.
nd=P/'factory-child-planning-native-f9a-actual/actual-run';nr=json.loads((nd/'RESULT.json').read_text());assert nr['head']==S and nr['commands'][0]['exit']==-15 and nr['original_inode_mode_nlink_sha_restored']is True and nr['tracked_before_after_equal']is True
nl=Path(nr['commands'][0]['log']);assert H(nl.read_bytes())==nr['commands'][0]['sha256'];assert not re.search(r'^running \d+ tests$',nl.read_text(),re.M)
refs={}
for d in [D,cl,ui,P/'factory-child-planning-root-postlint-tools',nd]:
 for q in d.iterdir():
  if q.is_file()and q.suffix in ['.log','.json','.stdout','.stderr']and q.name not in ['FAILED_ELF.json']:
   refs[str(q)]={'sha256':H(q.read_bytes()),'bytes':q.stat().st_size}
(O/'REFERENCES.json').write_text(json.dumps({'external_persistent_evidence':refs,'no_private_DB_or_token_copied':True},indent=2)+'\n')
(O/'AUDIT.json').write_text(json.dumps({'initial_subject':S,'final_subject':N,'core_alias_restored_bytes_exact926':True,'UI_exact_da382':True,'Native_approval_lib_smoke_exact_a9_at_initial_subject':True,'Native_runner_scripts_exact745':True,'CIprebuild_exact6ab':True,'historical_rich_migration_exact926':True,'schema_positive_fix_exact_one_literal13to14':True,'new_browser_harness_exact_separately_reviewed0e_not_executed_here':True,'workspace_evidence_source':W,'critical_map_paths_checked':checked,'workspace_outer':659,'docs':7,'nested_not_added':5,'strict_clippy_fmt_f9_exit0':True,'UI_type_build_f9_exit0':True,'Native_f9_exit':-15,'Native_tests_run':0,'Native_retry_new_head_not_run':True,'reviewer_only_static_and_hashes_no_products_executed':True},indent=2)+'\n')
print('PASS fixed composition source, alias byte-equivalence, leaf identity, schema repair, 659+7 evidence count/hashes, f9 lint/UI evidence; Native -15/0 tests retained, new retry unverified')
