# PR17 short temporary-fixture correction review

**PASS — may commit the reviewed test-only change.** Baseline `9ac06f78b107aa812fcec00f3b0c584911a88274`; reviewed uncommitted test SHA `99e92062c303d39d860312d84f50c1e040af5f0a0314ddec8626986dddba0f04`. No must-fix found. Actual new macOS CI verification remains pending.

Only test setUp changes its private TemporaryDirectory to explicit dir=/tmp, with one new rejection case. Removing that exact comment/argument and new test block reproduces the entire original test source bytes. All15 old test bodies/negative assertions are unchanged; forced kill, missing SIGTERM and nonzero exit remain rejected. No tests, subcases, cleanup waits or acceptance conditions are removed or softened.

The production prepare-factory-test-tools.py is byte-identical to baseline. Its real probe still creates its own /tmp directory, resolves the canonical path, chmods0700, and refuses socket UTF-8 length>103 or wrong mode before Popen. The old two cleanup-negative methods replace the probe's TempDir with their self.root/runtime. Their original default-based setUp could therefore inject a long macOS default-temp parent, reaching the path guard before the intended cleanup checks. Fixing the test-owned root lets those mock cleanup controls reach their original failure assertions; it does not relax the real probe path guard. The new test supplies an actual canonical over103-byte runtime, confirms refusal before mocked Popen, and confirms mode0700 remains.

Independent checks:

- Source/inverse/AST/production-byte checks: exit0.
- Focused complete FactoryTestToolTests: **16 PASS in0.034s**, old15+one new case. The source guard/SQLite/copy controls use declared synthetic files/tables and mock probe results; one existing readiness negative uses only its real own sleeping Python child and verifies reap. No Core daemon/runtime success is claimed.
- Independent portable replay: a real controlled canonical default parent is exactly100 UTF-8 bytes on this Linux host. With only gettempdir patched to that real directory, the old two methods produce3 guard errors,0 assertion failures; the fixed two methods pass under the same default parent. Before/after raw logs and REPLAY.json retain this expected failing-control dimension. New overlong rejection is also covered in the16-pass run.

Original Environment run40834973097's two Mac logs each show49 tests/3 errors at the guard in those methods and are referenced by hash, without another download. Public logs do **not** preserve their actual input path/length/mode. Source analysis plus the portable reproduction supports this fixture correction; it is not proof that the old CI path was exactly100 bytes or that path rather than any other guard term was directly observed there. The old Mac failure remains failed. New50-test discovery was Root-reported separately; this reviewer ran focused16, not a new full50 or a Mac job.

No production source/CI/gate, toolchain, timeout, permission, provider/account/credential or target change was made by reviewer. No Cargo/Node/browser/Core/daemon/remote/approval action ran. Own review files contain the exact old/current test, unchanged helper, original failed-control logs and local replay. This source-ready result does not authorize cancelling old Product jobs, borrowing old greens, or claiming new CI/Mac/product completion.
