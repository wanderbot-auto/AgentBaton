from pathlib import Path
import subprocess,re,json,hashlib
R=Path('/workspace/.worktrees/schema16-test-adaptation'); P=Path(__file__).resolve().parent; B='121218c80ac089d96a2902984f23e281e75f7782'; S='e57a99f6f5fc15bfd10f2ba577ee15f0aa836f75'
def blob(c,p):return subprocess.check_output(['git','-C',str(R),'show',c+':'+p]).decode()
checks=[]
def check(n,c):assert c,n;checks.append(n)
hp='crates/core/tests/fixtures/pre_factory_schema.rs';tp='crates/core/tests/command_validation_migration.rs';mp='crates/core/tests/migration_v7.rs'
h=blob(S,hp);t=blob(S,tp);m=blob(S,mp);old=blob(B,tp)
check('helper inverse exact except explicit object requirement',h.replace('!value.is_object() || ','',1)==blob(B,hp))
check('non-object gate occurs before typed Task parsing',h.index('!value.is_object()')<h.index('let task: agentbaton_core::storage::Task'))
check('future function name only difference',m.replace('fn future_v17_database','fn future_v16_database')==blob(B,mp))
start=t.index('            "task_complete_current_array" => {');end=t.index('            "task_foreign_id" =>',start)
check('all original 30 variants and every original test byte preserved', (t[:start]+t[end:]).replace('        "task_complete_current_array",\n','',1)==old)
body=blob(S,'crates/core/src/storage.rs').split('pub struct Task {',1)[1].split('\n}',1)[0]
fields=re.findall(r'^    pub (\w+):',body,re.M)
array=re.search(r'let fields = \[(.*?)\];',t[start:end],re.S).group(1)
check('array exactly matches actual current 11 Task fields in declaration order',fields==re.findall(r'"([a-z_]+)"',array) and len(fields)==11 and fields[8]=='code_workspace_binding')
check('new Rust source explicitly proves complete current array decodes before inverse rejection','let decoded: agentbaton_core::storage::Task = serde_json::from_str(&raw).unwrap();'in t[start:end] and 'assert!(array[8].is_null())'in t[start:end])
check('old empty-array and binding-null controls remain','"task_nonobject_json"'in t and '"task_binding_null"'in t)
paths=subprocess.check_output(['git','-C',str(R),'diff','--name-only',B,S]).decode().splitlines()
check('only the three authorized test files changed',set(paths)=={hp,tp,mp})
records=[{'path':p,'sha256':hashlib.sha256(blob(S,p).encode()).hexdigest()} for p in paths]
(P/'RESULTS.json').write_text(json.dumps({'source':S,'parent':B,'checks':checks,'passed':len(checks),'source_files':records,'dimension':'static declaration/order/byte preservation only; no serde/Rust execution','new_Rust_negative_variant_count':31},indent=2)+'\n')
print(json.dumps({'passed':len(checks),'failed':0,'dimension':'static only','Rust':'NOT_RUN'}))
