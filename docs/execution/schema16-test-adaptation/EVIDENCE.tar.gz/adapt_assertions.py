from pathlib import Path
import re,json
root=Path('/workspace/.worktrees/schema16-test-adaptation'); changes=[]
for p in sorted((root/'crates/core/tests').glob('*.rs')):
 s=p.read_text();original=s
 pattern=r'(pragma_query_value[^\n]*"user_version"[^\n]*\)\s*\.unwrap\(\),\s*)15\b'
 s,n=re.subn(pattern,lambda m:m[1]+'16',s)
 if n:changes.append({'path':str(p.relative_to(root)),'kind':'currentStore_assert','count':n,'why':'Store now completes semantic schema16; no historical fixture version touched'})
 if p.name=='factory_child_goal_legacy_migration.rs':
  assert 'assert_eq!(version(&after), 15);'in s
  s=s.replace('assert_eq!(version(&after), 15);','assert_eq!(version(&after), 16);')
  s=s.replace('actual_nonempty_native_and_factory14_history_survives_store15_and_private_backup','actual_nonempty_native_and_factory14_history_survives_store16_and_private_backups')
  changes.append({'path':str(p.relative_to(root)),'kind':'genuine14_consumer_current_target','count':1,'why':'Authentic14 source/build/bytes unchanged; target Store16 includes unchanged production15 DDL and semantic16'})
 if p.name=='sessions_ipc.rs':
  assert 'version, 15,'in s;s=s.replace('version, 15,','version, 16,',1);s=s.replace('must link exact schema15','must link exact schema16',1)
  changes.append({'path':str(p.relative_to(root)),'kind':'currentStore_variable_assert','count':1,'why':'Factory fixture requires currentStore16'})
 if p.name=='command_validation.rs':s=s.replace('CI fixture must link exact schema15 source','CI fixture must link exact schema16 source')
 if p.name=='factory_runtime_ipc.rs':s=s.replace('Do not use an old schema14 daemon as evidence for current Core15 tests','Do not use an old schema15 daemon as evidence for current Core16 tests')
 if p.name=='factory_child_plan_migration.rs':s=s.replace('followed by current15','followed by current16')
 if p.name=='command_validation_migration.rs':s=s.replace('fresh-schema15.sqlite3','fresh-schema16.sqlite3')
 # Only explicit future-test function bodies; never blanket-replace numeric assertions.
 matches=list(re.finditer(r'(?m)^fn ([\w]*future[\w]*)\(',s))
 for m in reversed(matches):
  end=s.find('\n#[test]',m.end());end=len(s)if end<0 else end
  body=s[m.start():end]
  if 'user_version=16'in body:
   updated=body.replace('user_version=16','user_version=17').replace('future_schema16','future_schema17').replace('relabeled_future16','relabeled_future17').replace('Future16','Future17').replace('version(&db), 16','version(&db), 17')
   changes.append({'path':str(p.relative_to(root)),'kind':'future_negative','function':m[1],'count':1,'why':'16 is supported; reject next version17 before mutation/backup, preserving genuine14 input for its one deliberate negative-copy relabel'})
   s=s[:m.start()]+updated+s[end:]
 if s!=original:p.write_text(s)
# Explicitly expanded by Root for this one assertion only.
p=root/'crates/core/tests/fixtures/factory_child_goal_runtime.rs';s=p.read_text();pattern=r'(pragma_query_value[^\n]*"user_version"[^\n]*\)\s*\.unwrap\(\),\s*)15\b';s,n=re.subn(pattern,lambda m:m[1]+'16',s);assert n==1;p.write_text(s);changes.append({'path':str(p.relative_to(root)),'kind':'authorized_fixture_current_assert','count':1,'why':'Actual joined runtime target Store16; all other fixture bytes retained'})
Path('/workspace/.onboarding/schema16-test-adaptation/ASSERTION_CHANGES.json').write_text(json.dumps(changes,indent=2)+'\n');print(json.dumps({'entries':len(changes),'current_assertions':sum(x['count']for x in changes if 'assert' in x['kind']or x['kind']=='genuine14_consumer_current_target'),'future_functions':sum(x['count']for x in changes if x['kind']=='future_negative'),'changed_top_level_test_files':len(list({x['path']for x in changes if '/fixtures/'not in x['path']}))}))
