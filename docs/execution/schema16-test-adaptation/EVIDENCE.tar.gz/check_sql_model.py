#!/usr/bin/env python3
"""Own generated SQLite/WAL DDL model. NOT Rust/helper/Store or historical input."""
import json,pathlib,re,sqlite3,tempfile
R=pathlib.Path('/workspace/.worktrees/schema16-test-adaptation');P=pathlib.Path(__file__).resolve().parent
helper=(R/'crates/core/tests/fixtures/pre_factory_schema.rs').read_text()
tables=re.findall(r'^    "(factory_[a-z_]+)",$',helper,re.M)[:12]
sources=[(R/'crates/core/src'/p).read_text()for p in ['factory_store.rs','factory_child_plan.rs','factory_child_goal.rs']]
def table_sql(name):
 for s in sources:
  start=s.find('CREATE TABLE '+name+'(')
  if start>=0:return s[start:].split(';',1)[0]
 raise AssertionError(name)
expected={name:table_sql(name)for name in tables}
indexes={name:set()for name in tables}
for s in sources:
 for sql in re.findall(r'CREATE (?:UNIQUE )?INDEX [^;]+',s):
  for name in tables:
   if ' ON '+name+'('in sql:indexes[name].add(sql)
constants={name:re.search(r'const '+name+r': &str =\s*"([^"\n]+)"',helper).group(1)for name in ['SCOPE15','RUN15','SCOPE_INDEX','RUN_INDEX']}
rebuild=re.search(r'transaction.execute_batch\("(CREATE TABLE goal_scopes_pre_factory.*?PRAGMA user_version=14;)"',helper,re.S).group(1)
remove=re.search(r'"(DROP TABLE factory_child_plan_heads;.*?PRAGMA user_version=12;)"',helper,re.S).group(1)
tasksql='CREATE TABLE tasks(id TEXT PRIMARY KEY, document TEXT NOT NULL)'
results=[]
def run_sql(c,sql):
 buf=''
 for line in sql.splitlines(True):
  buf+=line
  # All exact helper DDL statements are one line each; no trigger bodies.
  if sqlite3.complete_statement(buf):c.execute(buf);buf=''
 assert not buf.strip(),repr(buf)
def task(id='task'):
 return {'id':id,'project_id':'project','goal':'own synthetic DDL only','spec_revision':1,'state':'draft','revision':1,'created_at':'2020-01-01T00:00:00Z','updated_at':'2020-01-01T00:00:00Z'}
def snapshot(c):
 schema=c.execute('SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name').fetchall()
 rows=[(n,c.execute('SELECT rowid,* FROM "'+n.replace('"','""')+'" ORDER BY rowid').fetchall())for typ,n,_,_ in schema if typ=='table']
 pragmas=[(p,c.execute('PRAGMA '+p).fetchone())for p in ['user_version','schema_version','application_id','foreign_keys','journal_mode','defer_foreign_keys','query_only','synchronous']]
 return schema,rows,pragmas,c.in_transaction

def fixture(path,native=False):
 c=sqlite3.connect(path,isolation_level=None);c.create_function('octet_length',1,lambda s:len(s.encode()if isinstance(s,str)else s),deterministic=True)
 c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA foreign_keys=ON');c.execute(tasksql)
 ext=set()
 for sql in expected.values():ext.update(re.findall(r'REFERENCES ([a-z_]+)\(',sql))
 ext-=(set(tables)|{'tasks','events','goal_runs','goal_scopes'})
 for name in sorted(ext):c.execute('CREATE TABLE '+name+'(id TEXT PRIMARY KEY)')
 if 'approval_proposals'not in ext:c.execute('CREATE TABLE approval_proposals(id TEXT PRIMARY KEY)')
 c.execute('CREATE TABLE events(sequence INTEGER PRIMARY KEY AUTOINCREMENT,document TEXT NOT NULL)')
 for name in ['SCOPE15','RUN15','SCOPE_INDEX','RUN_INDEX']:c.execute(constants[name])
 for sql in expected.values():c.execute(sql)
 for ix in indexes.values():
  for sql in ix:c.execute(sql)
 raw=json.dumps(task(),ensure_ascii=False,indent=2)+'\n';c.execute('INSERT INTO tasks VALUES(?,?)',('task',raw))
 c.execute('CREATE TABLE own_unknown(blob BLOB,txt TEXT,whole INTEGER,real_value REAL,nothing_value TEXT)');c.execute('INSERT INTO own_unknown VALUES(?,?,?,?,?)',(b'\x00\xff\xde\xad','keep raw text',37,1.25,None));c.execute('INSERT INTO events(document) VALUES(?)',('{"synthetic":true}',))
 if native:
  c.execute('INSERT INTO projects VALUES(?)',('project',));c.execute('INSERT INTO execution_grants VALUES(?)',('grant',));c.executemany('INSERT INTO approval_proposals VALUES(?)',[('scope',),('run',)])
  c.execute('INSERT INTO goal_scopes(rowid,id,task_id,root_grant_id,revision,revoked,document) VALUES(?,?,?,?,?,?,?)',(41,'scope','task','grant',1,0,'{}'))
  c.execute('INSERT INTO goal_runs(rowid,id,scope_id,project_id,task_id,revision,state,document) VALUES(?,?,?,?,?,?,?,?)',(53,'run','scope','project','task',1,'completed','{}'))
 c.execute('PRAGMA user_version=16');assert not c.execute('PRAGMA foreign_key_check').fetchall();return c

def unique(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate JSON')
  d[k]=v
 return d
def validate(c):
 if not c.in_transaction or c.execute('PRAGMA user_version').fetchone()[0]!=16:raise ValueError('version/transaction')
 if c.execute('SELECT sql FROM sqlite_master WHERE type="table" AND name="tasks"').fetchone()!=(tasksql,):raise ValueError('tasks schema')
 if c.execute("SELECT count(*) FROM sqlite_master WHERE tbl_name='tasks'AND type IN('index','trigger')AND sql IS NOT NULL").fetchone()[0]:raise ValueError('task objects')
 for id,raw in c.execute('SELECT id,document FROM tasks'):
  if type(raw)is not str or not 0<len(raw.encode())<=262144:raise ValueError('size/type')
  d=json.loads(raw,object_pairs_hook=unique)
  if type(d)is not dict or 'code_workspace_binding'in d:raise ValueError('binding/shape')
  required={'id','project_id','goal','state','revision','created_at','updated_at'};allowed=required|{'spec_revision','acceptance_ref','acceptance_sequence'}
  if not required<=d.keys()or set(d)-allowed or d['id']!=id:raise ValueError('old Task')
  if any(type(d[k])is not str for k in ['id','project_id','goal','state','created_at','updated_at']):raise ValueError('string')
  if d['state']not in ['draft','running','cancel_requested','cancelled','outcome_unknown','accepted']:raise ValueError('state')
  if any(type(v)is not int or not 0<v<=2**64-1 for v in [d['revision'],d.get('spec_revision',1)]):raise ValueError('revision')
 for name in tables:
  if c.execute('SELECT count(*) FROM '+name).fetchone()[0]:raise ValueError('nonempty')
  if c.execute("SELECT sql FROM sqlite_master WHERE type='table'AND name=?",(name,)).fetchone()!=(expected[name],):raise ValueError('schema')
  actual={r[0]for r in c.execute("SELECT sql FROM sqlite_master WHERE tbl_name=?AND type IN('index','trigger')AND sql IS NOT NULL",(name,))}
  if actual!=indexes[name]:raise ValueError('indexes')
 for name,sql in zip(['goal_scopes','goal_runs','goal_one_active_scope_per_task','goal_one_running_scope'],constants.values()):
  actual=c.execute('SELECT sql FROM sqlite_master WHERE name=?',(name,)).fetchone()[0].replace('CREATE TABLE "'+name+'"','CREATE TABLE '+name)
  if actual!=sql:raise ValueError('native schema')
 if c.execute('PRAGMA foreign_keys').fetchone()[0]or c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('FK')
def inverse(c,target=14,late=False):
 if c.in_transaction:raise ValueError('nested')
 fk=c.execute('PRAGMA foreign_keys').fetchone()[0];c.execute('PRAGMA foreign_keys=OFF')
 try:
  c.execute('BEGIN');validate(c);run_sql(c,rebuild)
  if target==12:run_sql(c,remove)
  if late:c.execute('CREATE TABLE own_unknown(sentinel TEXT)')
  if c.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('restored FK')
  c.execute('COMMIT')
 except BaseException:
  if c.in_transaction:c.execute('ROLLBACK')
  raise
 finally:c.execute('PRAGMA foreign_keys='+str(fk))
with tempfile.TemporaryDirectory(prefix='schema16-inert-')as tmp:
 for target in [14,12]:
  c=fixture(pathlib.Path(tmp)/('positive'+str(target)),native=True);before=snapshot(c)
  inverse(c,target);after=snapshot(c)
  assert after[2][0]==('user_version',(target,))
  kept=[r for r in before[1]if r[0]not in (tables if target==12 else ['factory_child_goal_runs'])]
  assert after[1]==kept and not c.execute('PRAGMA foreign_key_check').fetchall()
  results.append({'case':'positive exact DDL target'+str(target),'result':'passed','source':'generated model, NOT historical/Core'});c.close()
 cases=['version15','version17','missing_factory','missing_index','extra_index','task_null_binding','task_object_binding','task_false_binding','task_invalid_json','task_array','task_unknown','task_bad_id','task_zero_revision','task_zero_spec','task_duplicate','task_oversize','task_blob','task_extra_column','task_extra_index','late_caller_collision']
 for i,case in enumerate(cases):
  c=fixture(pathlib.Path(tmp)/('negative'+str(i)))
  if case.startswith('version'):c.execute('PRAGMA user_version='+case[7:])
  elif case=='missing_factory':c.execute('DROP TABLE factory_scoped_handles')
  elif case=='missing_index':c.execute('DROP INDEX factory_child_goal_tasks')
  elif case=='extra_index':c.execute('CREATE INDEX own_extra ON factory_runs(state)')
  elif case=='task_extra_column':c.execute('ALTER TABLE tasks ADD COLUMN future TEXT')
  elif case=='task_extra_index':c.execute('CREATE INDEX own_extra ON tasks(id)')
  elif case!='late_caller_collision':
   d=task()
   if case=='task_null_binding':d['code_workspace_binding']=None
   if case=='task_object_binding':d['code_workspace_binding']={}
   if case=='task_false_binding':d['code_workspace_binding']=False
   if case=='task_unknown':d['unrecognized']='retain raw'
   if case=='task_bad_id':d['id']='foreign'
   if case=='task_zero_revision':d['revision']=0
   if case=='task_zero_spec':d['spec_revision']=0
   raw=json.dumps(d)
   if case=='task_invalid_json':raw='{'
   if case=='task_array':raw='[]'
   if case=='task_duplicate':raw='{"id":"duplicate",'+raw[1:]
   if case=='task_oversize':raw=' '*262145
   if case=='task_blob':raw=b'{}'
   c.execute('UPDATE tasks SET document=?',(raw,))
  before=snapshot(c)
  try:inverse(c,late=case=='late_caller_collision')
  except (ValueError,sqlite3.Error):pass
  else:raise AssertionError('negative accepted '+case)
  assert snapshot(c)==before,case
  results.append({'case':case,'result':'passed','complete_WAL_snapshot_equal':True});c.close()
(P/'SQL_MODEL_RESULTS.json').write_text(json.dumps({'scope':'Own synthetic SQLite/WAL model of source DDL and shape checks, not execution of Rust/helper/Store, not genuine14 fixture or migration proof','cases':results,'count':len(results)},indent=2)+'\n');print(json.dumps({'passed':len(results),'failed':0,'scope':'inert synthetic SQL model only'}))
