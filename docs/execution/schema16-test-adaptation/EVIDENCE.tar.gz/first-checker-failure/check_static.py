#!/usr/bin/env python3
import pathlib,subprocess,re,json,hashlib
R=pathlib.Path('/workspace/.worktrees/schema16-test-adaptation');P=pathlib.Path(__file__).resolve().parent;B='61c730ba4fdb5bdd0858cb4fc52ee07d29dce6c8';checks=[]
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def check(n,c):assert c,n;checks.append({'name':n,'result':'passed'})
changed=git('diff','--name-only',B).decode().splitlines()
allowed=lambda p:p.startswith('crates/core/tests/')and(p.count('/')==3 and p.endswith('.rs')or p in ['crates/core/tests/fixtures/pre_factory_schema.rs','crates/core/tests/fixtures/factory_child_goal_runtime.rs'])
check('only explicitly allowed test paths changed',len(changed)==19 and all(allowed(p)for p in changed))
check('Core src schema Cargo locks CI and harness untouched',not git('diff','--name-only',B,'--','crates/core/src','Cargo.toml','Cargo.lock','.github','apps').strip())
check('genuine14 fixture directory all bytes unchanged',not git('diff','--name-only',B,'--','crates/core/tests/fixtures/child_goal_legacy_migration').strip())
fixture='crates/core/tests/fixtures/factory_child_goal_runtime.rs';old=git('show',B+':'+fixture).decode();new=(R/fixture).read_text();check('runtime fixture only authorized current number changed',new.replace('            .unwrap(),\n        16\n    );','            .unwrap(),\n        15\n    );',1)==old)
entries=json.loads((P/'ASSERTION_CHANGES.json').read_text());check('actual inventory ten future functions',sum(x['count']for x in entries if x['kind']=='future_negative')==10)
check('actual inventory eighteen current assertions including one extra fixture',sum(x['count']for x in entries if 'assert'in x['kind']or x['kind']=='genuine14_consumer_current_target')==18)
check('actual seventeen top level targets',len({x['path']for x in entries if '/fixtures/'not in x['path']})==17)
for p in (R/'crates/core/tests').glob('*.rs'):
 s=p.read_text()
 assert 'PRAGMA user_version=16'not in s,p
check('no leftover literal future16 negative in current tests',True)
sessions=(R/'crates/core/tests/sessions_ipc.rs').read_text();old_sessions=git('show',B+':crates/core/tests/sessions_ipc.rs').decode()
for literal in ['assert_eq!(nodes[1]["actual_output_bytes"], 15);','assert_eq!(second["nodes"][1]["actual_output_bytes"], 15);','let sources: [(&str, &[u8]); 15]']:
 check('unrelated literal preserved '+literal[:45],literal in sessions and literal in old_sessions)
h=(R/'crates/core/tests/fixtures/pre_factory_schema.rs').read_text();before=git('show',B+':crates/core/tests/fixtures/pre_factory_schema.rs').decode()
for name in ['SCOPE15','RUN15','SCOPE_INDEX','RUN_INDEX']:
 pat=r'const '+name+r': &str =\s*"([^"\n]+)"';check('unchanged known physical DDL '+name,re.search(pat,h).group(1)==re.search(pat,before).group(1))
check('strict16 inverse not range','if version != 16'in h and 'if version != 15'not in h)
check('twelve complete named factory table set unchanged',re.findall(r'^    "(factory_[a-z_]+)",$',h,re.M)==re.findall(r'^    "(factory_[a-z_]+)",$',before,re.M))
check('Task binding root field including null rejected before typed decode',h.index('value.get("code_workspace_binding").is_some()')<h.index('let task: agentbaton_core::storage::Task'))
check('bounded typed old Task semantics without JSON writes','262144 THEN document'in h and 'serde_json::from_str(&raw)'in h and 'task.id != id'in h and 'task.spec_revision == 0'in h and 'serde_json::to_string'in h is False)
check('complete named index set including missing-index failclosed','actual_indexes != expected_indexes'in h)
check('outer autocommit and inner active TX guards','if !connection.is_autocommit()'in h and 'if transaction.is_autocommit()'in h)
cmd=(R/'crates/core/tests/command_validation_migration.rs').read_text();orig=git('show',B+':crates/core/tests/command_validation_migration.rs').decode()
for text in ['schema','rows','pragmas','autocommit','SELECT rowid,*','rusqlite::types::Value','"schema_version"','"application_id"','"journal_mode"','"defer_foreign_keys"','"query_only"','"synchronous"']:
 assert text in cmd and text in orig
check('WAL full logical snapshot and typed rowid schema/pragma fields retained',True)
for text in ['CREATE TABLE fixture_caller_collision(sentinel TEXT);','must test the caller\'s late failure, not an early guard','Some(14)','expected the fixed caller DDL collision','logical_after == logical_before']:
 check('fixed caller fault/assertion retained '+text[:45],text in cmd and text in orig)
negative=cmd.split('fn fixture_inverse_refuses_nonempty_missing_or_wrong_version',1)[1].split('let (_directory, database, connection)',1)[0]
oldnegative=orig.split('fn fixture_inverse_refuses_nonempty_missing_or_wrong_version',1)[1].split('let (_directory, database, connection)',1)[0]
variants=re.findall(r'"([a-z_0-9]+)"',negative);oldvariants=re.findall(r'"([a-z_0-9]+)"',oldnegative)
check('all original inverse negative variants retained',set(oldvariants)<=set(variants))
check('null object typedbinding false malformed duplicate and state boundaries added',all(x in variants for x in ['old_current15','future17','factory_missing_index','task_binding_null','task_binding_object','task_binding_typed_pending','task_binding_false','task_invalid_json','task_duplicate_id','task_foreign_id','task_zero_revision','task_zero_spec_revision','task_oversize']))
check('late restored native FK fixture has valid Task not early semantic rejection','A valid, old-representable Task must pass the new semantic'in cmd)
check('positive full remaining row bytes and rowid comparison added','fixture_logical_snapshot(&connection).rows == remaining_rows'in cmd and 'old raw JSON must not be rewritten'in cmd)
genuine=(R/'crates/core/tests/factory_child_goal_legacy_migration.rs').read_text();oldg=git('show',B+':crates/core/tests/factory_child_goal_legacy_migration.rs').decode()
check('genuine14 original build identities/sources untouched',genuine[:genuine.index('fn task_workspace_backups')].replace('fn task_workspace_backups','')[:oldg.index('fn schema(db:')]==oldg[:oldg.index('fn schema(db:')])
check('genuine14 consumer still tests original pre-v15 backup', 'Pre-v15 backup must retain original14 rows'in genuine and 'contains("pre-v15-")'in genuine)
check('new semantic16 backup bound to original14 raw/FK/reopen','contains("pre-v16-")'in genuine and 'version(&semantic_backup), 14'in genuine and 'Pre-v16 backup must preserve genuine original14 raw rows'in genuine and 'Current16 reopen cannot create another semantic migration backup'in genuine)
check('actual14 supported target16 and strict future17 negative','assert_eq!(version(&after), 16)'in genuine and 'PRAGMA user_version=17'in genuine)
(P/'STATIC_RESULTS.json').write_text(json.dumps({'base':B,'scope':'Static source/assertion preservation only; no Rust/helper/Store execution','count':len(checks),'checks':checks,'inverse_negative_variants':variants,'original_inverse_negative_variants':oldvariants,'changed_paths':changed},indent=2)+'\n');print(json.dumps({'passed':len(checks),'failed':0,'negative_variants':len(variants),'dimension':'static only'}))
