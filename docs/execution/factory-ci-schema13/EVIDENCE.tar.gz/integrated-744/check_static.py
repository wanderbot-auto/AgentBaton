from pathlib import Path
import ast,subprocess,json,hashlib,copy,yaml,importlib.util,sys,tempfile,types,sqlite3,re
R=Path('/workspace/.worktrees/factory-ci-schema13');O=Path(__file__).parent;BASE='435ac7b6dfc8810646109c414c244cb403a12954';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def check(label,condition):
 assert condition,label
 rows.append({'name':label,'status':'passed'})
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
workflow=R/'.github/workflows/product.yml';oldraw=subprocess.check_output(['git','show',BASE+':.github/workflows/product.yml'],cwd=R).decode();old=yaml.safe_load(oldraw);new=yaml.safe_load(workflow.read_text());before=copy.deepcopy(old);after=copy.deepcopy(new)
def named(d,name):return next(x for x in d['jobs']['frontend']['steps'] if x.get('name')==name)
for name in ['Real daemon and browser test dependencies','Actual frontend with real Unix IPC and responsive screenshots']:
 del named(before,name)['run'];del named(after,name)['run']
check('all YAML except authorized frontend build/runtime runs unchanged',before==after)
build=named(new,'Real daemon and browser test dependencies')['run'];check('both actual tools built', 'cargo build --locked --bin batond --bin baton' in build)
run=named(new,'Actual frontend with real Unix IPC and responsive screenshots')['run'];marker="artifacts/browser-venv/bin/python - <<'PY'\n";body=run.split(marker,1)[1].rsplit('\nPY',1)[0]+'\n';oldbody=named(old,'Actual frontend with real Unix IPC and responsive screenshots')['run'].split(marker,1)[1].rsplit('\nPY',1)[0]+'\n';tree=ast.parse(body);compile(tree,'actual-factory-ci-parent.py','exec');(O/'actual-parent.py').write_text(body)
def calls(t):return [n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess' and n.func.attr=='run']
a,b=calls(ast.parse(oldbody)),calls(tree);check('three existing subprocess ASTs unchanged;one additionalFactory callsite',len(b)==4 and all(ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False) for x,y in zip(a,b[:3])))
check('all subprocesses fail on child nonzero',all(any(k.arg=='check' and isinstance(k.value,ast.Constant) and k.value.value is True for k in n.keywords) for n in b))
factory_loop=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.iter,ast.List) and [x.value for x in n.iter.elts]==['normal','cancel','unknown']);check('Factorycases explicit/separateoutputs/no inventedCLIflag', 'factory-real-ipc.py' in ast.unparse(factory_loop) and "'artifacts/ui-browser/factory-' + case" in ast.unparse(factory_loop) and '--baton' not in [n.value for n in ast.walk(factory_loop) if isinstance(n,ast.Constant) and isinstance(n.value,str)])
# Execute only the exact new aggregate-call AST with a recording fake subprocess.
aggregate=ast.Module(body=[next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='factory_failures' for t in n.targets)),factory_loop,next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=='factory_failures')],type_ignores=[])
for failures in [set(),{'normal'},{'cancel','unknown'}]:
 seen=[]
 class Recorder:
  CalledProcessError=subprocess.CalledProcessError
  @staticmethod
  def run(argv,check):
   assert check is True;case=argv[argv.index('--case')+1];seen.append(case)
   if case in failures:raise subprocess.CalledProcessError(2,argv)
 env={'subprocess':Recorder,'sys':types.SimpleNamespace(executable='generated-python-not-executed'),'chromium':'generated-browser-not-executed','json':json}
 try:exec(compile(aggregate,'actual-factory-only-call-AST','exec'),env);failed=False
 except SystemExit:failed=True
 check('three independentcase calls retain nonzero '+str(sorted(failures)),seen==['normal','cancel','unknown'] and failed is bool(failures))
check('candidate13 and both raw tool names',"'schema': 13" in body and "for name in ['batond', 'baton']" in body and "git('rev-parse', 'HEAD')" in body and "git('rev-parse', 'HEAD^{tree}')" in body)
check('approved publicasync lookup retained','asyncio.run(chromium_executable_path())' in body and 'async with async_playwright()' in body)
for p in ['apps/desktop/tests/goal-execution-real-ipc.py','apps/desktop/tests/goal-graph-real-ipc.py','apps/desktop/tests/data-workspace-real-ipc.py']:
 source=(R/p).read_text();ast.parse(source);compile(source,p,'exec');check(p+' compiles/strictlive13','fetchone()[0] == 13' in source and 'fetchone()[0] == 12' not in source)
# Actual SQLite version assertions, evaluated on empty generated in-memory SQLite only.
for file in ['goal-execution-real-ipc.py','goal-graph-real-ipc.py','data-workspace-real-ipc.py']:
 tree=ast.parse((R/'apps/desktop/tests'/file).read_text())
 for guard in [n for n in ast.walk(tree) if isinstance(n,ast.Assert) and 'PRAGMA user_version' in ast.unparse(n.test)]:
  expr=compile(ast.Expression(guard.test),file,'eval')
  for version in [12,13,14]:
   with sqlite3.connect(':memory:') as db:
    db.execute('PRAGMA user_version='+str(version));db.execute('PRAGMA query_only=ON');check(file+' actualSQLiteassertline'+str(guard.lineno)+' version'+str(version),bool(eval(expr,{'db':db,'store':db})) is (version==13))
# Actual guard ASTs evaluated only; no process/token/listener path executes.
for file in ['goal-execution-real-ipc.py','data-workspace-real-ipc.py']:
 p=R/'apps/desktop/tests'/file;t=ast.parse(p.read_text());guard=next(n for n in ast.walk(t) if isinstance(n,ast.Assert) and "manifest" in ast.unparse(n.test) and "schema" in ast.unparse(n.test));expr=compile(ast.Expression(guard.test),file,'eval')
 class Binary:
  def read_bytes(self):return b'generated-guard-bytes'
 for schema in [12,14,13.0,True,'13',None,13]:
  env={'manifest':{'schema':schema},'expected_binary':sha(b'generated-guard-bytes'),'binary':Binary(),'sha':sha,'report':{'daemon_sha256':sha(b'generated-guard-bytes')}}
  check(file+' exact typed schema '+repr(schema),bool(eval(expr,env)) is (type(schema) is int and schema==13))
# Graph's actual helper, synthetic bytes only; never execute a binary.
graph=load('schema13_graph',R/'apps/desktop/tests/goal-graph-real-ipc.py');factory=load('schema13_factory',R/'apps/desktop/tests/factory-real-ipc.py');native=load('schema13_native_runner',R/'scripts/native-run.py');known=[]
with tempfile.TemporaryDirectory(prefix='ab-static-schema13-') as tmp:
 p=Path(tmp);daemon=p/'batond';companion=p/'baton';daemon.write_bytes(b'generated-daemon-not-executed');companion.write_bytes(b'generated-cli-not-executed');daemon.chmod(0o700);companion.chmod(0o700);front=p/'frontend';front.mkdir();(front/'index.html').write_text('generated unrendered fixture');manifest=p/'candidate.json'
 for schema in [12,14,13.0,True,'13',None,13]:
  value={'schema':schema,'git_head':'a'*40,'git_tree':'b'*40,'binaries':{'batond':sha(daemon.read_bytes()),'baton':sha(companion.read_bytes())}};raw=json.dumps(value).encode();manifest.write_bytes(raw)
  try:graph.verify_candidate(daemon,raw);accepted=True
  except AssertionError:accepted=False
  check('Graphhelper strict schema '+repr(schema),accepted is (type(schema) is int and schema==13))
  args=types.SimpleNamespace(batond=daemon,candidate_manifest=manifest,frontend=front)
  try:factory.preflight(args);fac=True
  except (AssertionError,ValueError,KeyError,OSError):fac=False
  if type(schema) is int:check('Factoryexistingdriver schema '+repr(schema),fac is (schema==13))
  elif fac:known.append({'existing_dependency':'factory-real-ipc.py preflight','case':repr(schema),'accepted':True,'required_rejection':True,'owner_fix_pending':'Rootassigned original author; not modified by CIleaf'})
  else:check('Factory typedinvalid schema '+repr(schema)+' refused',not fac)
 value['schema']=13
 for tool in ['batond','baton']:
  good={'schema':13,'binaries':{'batond':sha(daemon.read_bytes()),'baton':sha(companion.read_bytes())}};good['binaries'][tool]='0'*64;manifest.write_text(json.dumps(good))
  try:factory.preflight(args);accepted=True
  except AssertionError:accepted=False
  check('Factory raw SHA mismatch refused '+tool,not accepted)
# Cross-check existing named nine-field contract against actual NativeSmoke source.
src=(R/'apps/desktop/src-tauri/src/bin/native_smoke.rs').read_text();chunk=src.split('const FACTORY_COUNT_FIELDS: [&str; 9] = [',1)[1].split('];',1)[0];names=re.findall('"([a-z_]+)"',chunk);check('NativeSmoke actual9fields match existingrunner',tuple(names)==native.FACTORY_COUNT_FIELDS and len(names)==9)
counts={'schema_version':13,'sequence':2,**{n:0 for n in names}};flags={n:True for n in ['factoryScopeLists','factoryMissingScopeDenied','factoryMissingRunDenied','readonlyFactoryNoMutation']};flags.update(factoryReadonlySequence={'before':2,'after':2},factoryMissingScope={'scope_id':'native-readonly-missing-factory-scope','code':'NOT_FOUND','side_effect_state':'not_started'},factoryMissingRun={'scope_id':'native-readonly-missing-factory-scope','code':'NOT_FOUND','side_effect_state':'not_started'})
for n in ['goalReadonlySequence','goalExecutionReadonlySequence','goalGraphReadonlySequence']:flags[n]={'before':2,'after':2}
record={'factory_readonly_database':{'read_only':True,'unchanged':True,'before':copy.deepcopy(counts),'after':copy.deepcopy(counts)},'first_webview':flags}
for n in ['goal_readonly_database','goal_execution_readonly_database','goal_graph_readonly_database']:record[n]={'before':{'sequence':2},'after':{'sequence':2}}
check('actualexisting Native runnerFactory contract positivefixture',native.factory_report_error(record) is None)
for n in names:
 bad=copy.deepcopy(record);bad['factory_readonly_database']['before'][n]=1;check('each independentFactorycount refuses '+n,native.factory_report_error(bad) is not None)
for n in names:
 bad=copy.deepcopy(record);bad['factory_readonly_database']['before'][n]=False;check('typedzeroFactorycount refuses boolean '+n,native.factory_report_error(bad) is not None)
for schema in [12,14,13.0,True,'13']:
 bad=copy.deepcopy(record);bad['factory_readonly_database']['before']['schema_version']=schema;check('Factoryreadonly strictschema '+repr(schema),native.factory_report_error(bad) is not None)
shell=(R/'scripts/native-macos-smoke.sh').read_text();inline=shell.split("python3 - \"$output/native-smoke.json\" <<'PY'\n",1)[1].rsplit('\nPY',1)[0];compile(inline,'actual-native-shell-postcheck.py','exec');check('native postcheck uses existingstrictFactorycontract','factory_report_error(record)' in inline)
out={'base_after_lookup':BASE,'passed_controls':len(rows),'controls':rows,'known_dependency_failures':known,'no_Core_browser_Cargo_execution':True,'source_hashes':{str(p.relative_to(R)):sha(p.read_bytes()) for p in [workflow,R/'apps/desktop/tests/goal-execution-real-ipc.py',R/'apps/desktop/tests/goal-graph-real-ipc.py',R/'apps/desktop/tests/data-workspace-real-ipc.py',R/'scripts/native-macos-smoke.sh']}};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'passed_controls':len(rows),'known_dependency_failures':known,'scope':'finite Python/AST/read-synthetic-bytes only;no product execution'},indent=2))

if known:raise SystemExit(1)  # Required dependency guard unresolved; never report overall green.
