import asyncio, hashlib, json, pathlib, subprocess, sys
from playwright.async_api import async_playwright
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
assert not git('status', '--porcelain', '--untracked-files=no'), 'Tracked source changed during CI build'
candidate = {
    'schema': 13,
    'git_head': git('rev-parse', 'HEAD'),
    'git_tree': git('rev-parse', 'HEAD^{tree}'),
    'dirty': False,
    'binaries': {name: hashlib.sha256(pathlib.Path('target/debug', name).read_bytes()).hexdigest() for name in ['batond', 'baton']},
    'scope': 'CI-built Linux debug candidate; actual schema checked by read-only SQLite in the harness; acceptance pending',
}
pathlib.Path('artifacts/ui-browser/goal-execution-candidate.json').write_text(json.dumps(candidate, indent=2) + '\n')
async def chromium_executable_path():
    async with async_playwright() as playwright:
        return playwright.chromium.executable_path
chromium = asyncio.run(chromium_executable_path())
subprocess.run([
    sys.executable, 'apps/desktop/tests/goal-execution-real-ipc.py',
    '--batond', 'target/debug/batond',
    '--candidate-manifest', 'artifacts/ui-browser/goal-execution-candidate.json',
    '--frontend', 'apps/desktop/dist',
    '--output', 'artifacts/ui-browser/goal-execution',
    '--chromium', chromium,
], check=True)
graph_base = [
    sys.executable, 'apps/desktop/tests/goal-graph-real-ipc.py',
    '--batond', 'target/debug/batond',
    '--candidate-manifest', 'artifacts/ui-browser/goal-execution-candidate.json',
    '--frontend', 'apps/desktop/dist', '--chromium', chromium,
]
subprocess.run(graph_base + [
    '--owner-only', '--output', 'artifacts/ui-browser/goal-graph-owner',
], check=True)
for case in ['integrity', 'data', 'command', 'data-range', 'command-timeout']:
    subprocess.run(graph_base + [
        '--validation-case', case,
        '--output', 'artifacts/ui-browser/goal-graph-' + case,
    ], check=True)
factory_failures = []
for case in ['normal', 'cancel', 'unknown']:
    try:
        subprocess.run([
            sys.executable, 'apps/desktop/tests/factory-real-ipc.py',
            '--case', case, '--batond', 'target/debug/batond',
            '--candidate-manifest', 'artifacts/ui-browser/goal-execution-candidate.json',
            '--frontend', 'apps/desktop/dist', '--chromium', chromium,
            '--output', 'artifacts/ui-browser/factory-' + case,
        ], check=True)
    except subprocess.CalledProcessError as failure:
        factory_failures.append({'case': case, 'exit_code': failure.returncode})
if factory_failures:
    raise SystemExit('Factory runtime checks failed: ' + json.dumps(factory_failures))
