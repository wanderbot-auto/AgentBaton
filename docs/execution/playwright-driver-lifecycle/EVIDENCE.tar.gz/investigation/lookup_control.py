"""Authorized driver-only diagnostic: no browser launch, request or network API.

Inspect existing task state without cancel/drain/exception-retrieval/forced GC.
Only context-manager lifecycle controls the existing local Playwright driver.
"""
import sys,json,asyncio,importlib.metadata,os

def inspect_state(where,connection):
 task=connection._init_task
 return {'where':where,'pid':os.getpid(),'playwright_version':importlib.metadata.version('playwright'),'init_task_exists':task is not None,'init_task_done':None if task is None else task.done(),'init_task_cancelled':None if task is None else task.cancelled(),'init_task_cancelling':None if task is None else task.cancelling(),'init_task_stack':[] if task is None else [{'file':f.f_code.co_filename,'function':f.f_code.co_name,'line':f.f_lineno} for f in task.get_stack()],'playwright_future_done':connection.playwright_future.done(),'loop_closed':connection._loop.is_closed(),'callback_count':len(connection._callbacks),'closed_error_type':None if connection._closed_error is None else type(connection._closed_error).__name__}

mode=sys.argv[1];states=[]
if mode=='old_sync':
 from playwright.sync_api import sync_playwright
 with sync_playwright() as p:
  executable=p.chromium.executable_path
  connection=p._impl_obj._connection
  states.append(inspect_state('after_property_before_context_exit',connection))
 states.append(inspect_state('after_context_exit',connection))
elif mode=='new_async':
 from playwright.async_api import async_playwright
 async def lookup():
  async with async_playwright() as p:
   executable=p.chromium.executable_path
   connection=p._impl_obj._connection
   states.append(inspect_state('after_property_before_context_exit',connection))
  states.append(inspect_state('after_context_exit',connection))
  return executable,connection
 executable,connection=asyncio.run(lookup())
 states.append(inspect_state('after_asyncio_run',connection))
else:raise ValueError('only fixed old_sync/new_async modes')
print(json.dumps({'mode':mode,'executable_path':executable,'states':states,'scope':'local Playwright driver metadata only; no launch/browser/Core/network calls; no forced GC or exception retrieval'}),flush=True)
