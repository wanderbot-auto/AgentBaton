# Finite Playwright driver lifecycle investigation

**Finding:** a metadata-only `sync_playwright` context in the Linux UI workflow reproduces the exact pending-init/Future warning without launching a browser or Core. The candidate public async lifecycle completes initialization before returning the same executable path and was clean in two local controls. This supports a narrowly scoped workflow fix; it does not prove unique attribution of the two original CI stderr blocks or certify the next CI run.

Original evidence directories/manifests are unchanged. This directory contains copies of the relevant raw e3cc/fb7 UI logs, warning comparison, fixed fb7 workflow/Graph harness/lock, inspected Playwright sources and all four permitted controls. No repository source/CI/STATUS/remote mutation, package installation, browser launch or Core invocation occurred during the investigation. Root explicitly authorized exactly two old and two new driver-only subprocesses after the initial static proposal; no further repetitions were run.

## Source mechanism and attribution limits

The warning in fb7 UI log:746/748/750 follows the final command-timeout passed report:745 and precedes upload:751. The earlier e3cc log:729/731/733 has the same pattern after its final report. Neither stderr block has a process PID, so its position alone cannot identify the last Graph subprocess versus its parent Python process.

Fixed fb7 `.github/workflows/product.yml:103` starts a separate Playwright session in the parent solely to read `chromium.executable_path`, closes it immediately, then executes Goal and six Graph child processes. That parent's natural shutdown occurs after the final child returns, matching the observed warning position. This is distinct from the Graph harness's real-browser session: the latter launches Chromium, makes many protocol calls, closes its browser in `finally` at `goal-graph-real-ipc.py:1734` and exits the Playwright context before HTTP/daemon cleanup and its final result print. The raw logs alone do not establish a daemon leak or browser subprocess survival.

The inspected installed version is **Playwright1.62.0**, matching the CI lock/version. Eight relevant package files were hashed against their installed distribution RECORD; their source hashes are retained. CI's wheel is pinned to `ba33bae6a13b3d9d354c751cb618af357d20fe1d57767cbcce52079bbef17ad3`. No wheel was downloaded/reinstalled for this analysis, so installed RECORD equality is not represented as an independently verified hash of CI's complete wheel. Original Apache license/header notices are retained with copied third-party source.

Relevant implementation:

- `sync_api/_context_manager.py:66–79`: `__enter__` registers a callback for creation of the Playwright object and switches the calling greenlet back from that callback. This can return before the initialization reply finishes.
- `_impl/_browser_type.py:69`: `executable_path` is only `self._initializer['executablePath']`; reading it supplies no protocol roundtrip to advance initialization.
- `_impl/_connection.py:343–347`: `init()` awaits root initialization; its future is set only afterward. Its line344 matches the actual warning frame.
- `_impl/_connection.py:350–378`: synchronous stop waits for transport shutdown, then cleanup cancels a still-running init task and sets TargetClosedError on remaining reply futures.
- `sync_api/_context_manager.py:93–98`: owned-loop teardown cancels remaining tasks and closes the loop without explicitly gathering their completion. The original log's pending cancellation/unretrieved exception is consistent with this path.
- `async_api/_context_manager.py:39–47`: async entry awaits the initialization `playwright_future`; async exit awaits stop. Using `asyncio.run` additionally supplies the standard asyncio runner lifecycle. No private task API is needed in the proposed production workflow fix.

## Four actual controls, no browser

`lookup_control.py` uses only the permitted executable-path accessor. Private state reads are **diagnostic only**: `.done()`, `.cancelled()`, `.cancelling()`, stack file/function/line, loop closed status and callback count. They do not retrieve exceptions, cancel/drain tasks, advance the event loop, force GC, filter stderr, launch Chromium or make HTTP/Core calls. Context-manager lifecycle remains responsible for the local Playwright driver. Both modes return exactly the same executable path.

| Mode | Actual processes | Exit | Warning | Initialization state |
| --- | ---: | --- | --- | --- |
| old sync |2|0,0|Both reproduce pending Task-3 `init():344` + unhandled Future TargetClosedError|Before exit: init not done, initialization future not done,1 callback. After exit: loop closed, init still not done/cancelling2.|
| candidate async |2|0,0|Both captured stderr empty|Before exit: init and initialization future done,0 callbacks. After `asyncio.run`: loop closed, init done, no cancellation.|

These are genuine local driver subprocesses, not mocked Task state. All four exact argv/start/end/exit/stdout/stderr hashes and observed states are in `control-results.json`. Parent and child scripts are retained. Parent stdout is explicitly labeled as a lossless reconstruction of the exact four emitted tool-output lines from the saved child records, rather than a second execution. The original per-child stdout/stderr are direct subprocess captures.

The controls establish a concrete reproducible warning source and the expected initialization difference. Two clean processes cannot establish all-platform stability, complete Playwright correctness or absence of every future teardown issue. They also do not retroactively add PID attribution to old CI logs.

## Minimal candidate

`CANDIDATE_MINIMAL.diff` changes only the Linux UI parent's path lookup:

1. Import stdlib asyncio and public `playwright.async_api.async_playwright`.
2. Resolve the same `chromium.executable_path` inside `async with async_playwright()`.
3. Call the helper with `asyncio.run` before the unchanged child subprocess calls.

It neither adds a browser launch nor changes the child harness, dependencies, paths, test arguments/order, check names, artifacts, permissions, timeout or process limits. No sleeps, retry loops, stderr filters, exception swallowing or permissive timeout are proposed. Explicit browser-context close changes in the Graph harness are not required to address this demonstrated parent initialization path and are outside this candidate.

Root subsequently authorized an isolated implementation leaf and static preservation checks. Its implementation/evidence belongs to a separate worktree; this investigation is frozen. The leaf still needs independent code review and a new exact CI observation. Real-browser replay is not required for the initial minimal fix and was not authorized or run here.
