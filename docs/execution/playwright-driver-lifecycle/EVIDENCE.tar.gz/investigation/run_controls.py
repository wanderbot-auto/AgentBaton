from pathlib import Path
import subprocess,sys,os,json,hashlib,datetime
R=Path(__file__).parent;records=[]
for mode in ['old_sync','new_async']:
 for n in [1,2]:
  tag=f'{mode}-{n}';cmd=[sys.executable,str(R/'lookup_control.py'),mode];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  p=subprocess.run(cmd,capture_output=True,timeout=20,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},start_new_session=True)
  (R/(tag+'.stdout')).write_bytes(p.stdout);(R/(tag+'.stderr')).write_bytes(p.stderr)
  record={'tag':tag,'argv':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'stdout':tag+'.stdout','stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':tag+'.stderr','stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'pending_task_warning':b'Task was destroyed but it is pending!' in p.stderr,'future_warning':b'Future exception was never retrieved' in p.stderr,'target_closed_error':b'TargetClosedError' in p.stderr,'states':json.loads(p.stdout)['states'] if p.returncode==0 else None}
  records.append(record);(R/'control-results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['tag','exit','pending_task_warning','future_warning','target_closed_error']}),flush=True)
