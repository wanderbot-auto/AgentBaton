from pathlib import Path
import importlib.util,unittest,json,sys,subprocess
from unittest import mock
R=Path('/workspace/.worktrees/schema16-runner-adaptation');P=Path(__file__).resolve().parent
plan=[('apps/desktop/src-tauri/tests/test_native_runner.py',lambda c,n:c not in {'NativeRunnerTests','NativeArtifactAuditTests'}),('apps/desktop/src-tauri/tests/test_native_owner_dialog.py',lambda c,n:c!='BootstrapPathControls' and not any(w in n for w in ['real_core','real_readonly','cleanup_preserves','exited_app_live','observation_failure_still_reaps'])),('tests/infrastructure/test_factory_test_tools.py',lambda c,n:n!='test_owned_process_readiness_failure_reaps_original_child'),('tests/infrastructure/test_child_goal_ci_evidence.py',lambda c,n:n!='test_fifo_and_unix_socket_are_rejected_without_waiting_for_a_writer')]
suite=unittest.TestSuite();selected=[];excluded=[]
for index,(path,select)in enumerate(plan):
 spec=importlib.util.spec_from_file_location('owned_pure_'+str(index),R/path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
 for cname,c in vars(m).items():
  if isinstance(c,type)and issubclass(c,unittest.TestCase):
   for name in unittest.defaultTestLoader.getTestCaseNames(c):
    record={'path':path,'class':cname,'method':name}
    if select(cname,name):suite.addTest(c(name));selected.append(record)
    else:excluded.append(record)
(P/'PURE_SELECTION.json').write_text(json.dumps({'selected':selected,'not_run':excluded,'reason':'No actual Core/Native/process-lifecycle or audit-shell execution in this pure source-adaptation window. No tests removed or marked skipped in source.'},indent=2)+'\n')
def denied(*a,**k):raise AssertionError('No real subprocess permitted by source-only test lease')
with mock.patch.object(subprocess,'Popen',side_effect=denied),mock.patch.object(subprocess,'run',side_effect=denied),mock.patch.object(subprocess,'check_output',side_effect=denied):
 result=unittest.TextTestRunner(verbosity=2).run(suite)
(P/'PURE_RESULTS.json').write_text(json.dumps({'selected':len(selected),'ran':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'scope':'Synthetic/file/SQLite fixtures and mocked protocol only; not real daemon/migration/Native/browser/CI','exit':0 if result.wasSuccessful()else 1},indent=2)+'\n')
raise SystemExit(0 if result.wasSuccessful()else 1)
