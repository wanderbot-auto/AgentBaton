from pathlib import Path
import importlib.util,sys,json,subprocess
from unittest import mock
R=Path('/workspace/.worktrees/schema16-runner-adaptation');P=Path(__file__).resolve().parent
p=R/'apps/desktop/tests/goal-graph-real-ipc.py';spec=importlib.util.spec_from_file_location('current_graph_guards',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def denied(*a,**k):raise AssertionError('No subprocess in pure guard window')
class Binary:
 def __init__(self):self.reads=0
 def read_bytes(self):self.reads+=1;return b'own inert bytes, not executable'
checks=[]
with mock.patch.object(subprocess,'Popen',side_effect=denied),mock.patch.object(subprocess,'run',side_effect=denied),mock.patch.object(subprocess,'check_output',side_effect=denied):
 value=m.driver_self_check();checks.append({'name':'existing Graph driver pure checks','result':value})
 b=Binary();manifest={'schema':16,'source_head':'a'*40,'binaries':{'batond':m.sha(b.read_bytes())}}
 assert m.verify_candidate(b,json.dumps(manifest).encode())==manifest
 for version in [12,13,14,15,17,16.0,True,'16',None]:
  before=b.reads
  try:m.verify_candidate(b,json.dumps({**manifest,'schema':version}).encode())
  except AssertionError:pass
  else:raise AssertionError(version)
  assert b.reads==before
 checks.append({'name':'exact16 permits inert binary hash; all9 old/future/type negatives refuse before binary access','passed':True})
 # The two separately owned support files remain version15 at this source.
 # Observe their mismatch explicitly instead of patching them for apparent green.
 p=R/'apps/desktop/tests/factory-real-ipc.py';s=importlib.util.spec_from_file_location('root_owned_factory_support',p);f=importlib.util.module_from_spec(s);sys.modules[s.name]=f;s.loader.exec_module(f)
 b=Binary();before=b.reads
 try:f.verify_candidate(b,json.dumps(manifest).encode())
 except AssertionError:assert b.reads==before;dependency='Root-owned factory-real support still rejects16 before binary access: pending separate authorized integration'
 else:raise AssertionError('Expected baseline15 dependency changed')
(P/'GRAPH_GUARD_RESULTS.json').write_text(json.dumps({'checks':checks,'dependency':dependency,'scope':'Pure guards/generated own file pins only; no browser/daemon/Core/Provider'},indent=2)+'\n')
print(json.dumps({'graph':value,'strict_manifest_controls':10,'dependency':dependency}))
