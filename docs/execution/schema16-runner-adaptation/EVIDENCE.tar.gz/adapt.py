from pathlib import Path
import json
R=Path('/workspace/.worktrees/schema16-runner-adaptation'); changes=[]
def edit(path,pairs,text15=True):
 p=R/path;s=p.read_text();old=s
 for a,b in pairs:
  assert a in s,(path,a);s=s.replace(a,b)
 if text15:s=s.replace('schema15','schema16').replace('Graph15 execution evidence','Graph16 execution evidence')
 assert s!=old,path;p.write_text(s);changes.append({'path':path,'changes':[{'before':a,'after':b}for a,b in pairs],'schema15_labels_updated':text15})
edit('scripts/native-run.py',[("['schema_version'] != 15","['schema_version'] != 16")])
edit('scripts/native-owner-dialog-smoke.py',[("json_exact(value.get('schema_version'), 15)","json_exact(value.get('schema_version'), 16)")])
edit('scripts/native-macos-smoke.sh',[("['schema_version'] == 15","['schema_version'] == 16")])
edit('scripts/prepare-factory-test-tools.py',[("schema != 15","schema != 16"),("'schema': 15","'schema': 16"),("record['schema'] != 15","record['schema'] != 16")])
edit('scripts/record-child-goal-ci-evidence.py',[("m['schema']==15","m['schema']==16"),("'schema':15","'schema':16")])
edit('apps/desktop/tests/goal-execution-real-ipc.py',[("manifest['schema'] == 15","manifest['schema'] == 16"),("execute('PRAGMA user_version').fetchone()[0] == 15","execute('PRAGMA user_version').fetchone()[0] == 16")])
edit('apps/desktop/tests/data-workspace-real-ipc.py',[("manifest['schema'] == 15","manifest['schema'] == 16"),("execute('PRAGMA user_version').fetchone()[0] == 15","execute('PRAGMA user_version').fetchone()[0] == 16")])
edit('apps/desktop/tests/goal-graph-real-ipc.py',[("schema == 15","schema == 16"),("manifest.get('schema') == 15","manifest.get('schema') == 16"),("execute('PRAGMA user_version').fetchone()[0] == 15","execute('PRAGMA user_version').fetchone()[0] == 16"),("'schema_required': 15","'schema_required': 16"),("manifest.get('schema') != 15","manifest.get('schema') != 16"),("report['manifest_schema'] = 15","report['manifest_schema'] = 16"),("[11, 12, 13, 14, 16, 13.0, 14.0, 15.0, True, '13', '14', '15', None]","[11, 12, 13, 14, 15, 17, 13.0, 14.0, 15.0, 16.0, True, '13', '14', '15', '16', None]")])
edit('apps/desktop/tests/factory-child-goal-real-ipc.py',[("'schema':15","'schema':16"),("schema=15","schema=16"),("['schema']==15","['schema']==16"),("schema_required=15","schema_required=16"),("integer15-manifest-positive","integer16-manifest-positive"),("[12,13,14,16,True,15.0,'15',None]","[12,13,14,15,17,True,15.0,16.0,'15','16',None]"),("[12,13,14,16,15.0,True,'15',None]","[12,13,14,15,17,15.0,16.0,True,'15','16',None]")])
edit('apps/desktop/src-tauri/tests/test_native_runner.py',[("schema_version=15","schema_version=16"),("[10,11,12,13,14,16,13.0,14.0,15.0,True,'13','14','15',None]","[10,11,12,13,14,15,17,13.0,14.0,15.0,16.0,True,'13','14','15','16',None]"),("[0, 11, 12, 13, 14, 16, 13.0, 14.0, 15.0, True, '13', '14', '15', None]","[0, 11, 12, 13, 14, 15, 17, 13.0, 14.0, 15.0, 16.0, True, '13', '14', '15', '16', None]")])
edit('apps/desktop/src-tauri/tests/test_native_owner_dialog.py',[("'schema_version': 15","'schema_version': 16"),("PRAGMA user_version=16","PRAGMA user_version=17"),("PRAGMA user_version=15","PRAGMA user_version=16"),("same-head15 tools","same-head16 tools"),("[11, 12, 13, 14, 16, 13.0, 14.0, 15.0, True, '13', '14', '15', None]","[11, 12, 13, 14, 15, 17, 13.0, 14.0, 15.0, 16.0, True, '13', '14', '15', '16', None]"),("[12, 13, 14, 16, 14.0, 15.0]","[12, 13, 14, 15, 17, 14.0, 15.0, 16.0]")])
edit('tests/infrastructure/test_factory_test_tools.py',[("schema=15","schema=16"),("observed['schema'], 15","observed['schema'], 16"),("(13, 14, 16)","(13, 14, 15, 17)"),("('schema', 16), ('schema', 14.0)","('schema', 15), ('schema', 17), ('schema', 14.0)"),("('schema', 15.0), ('schema', True)","('schema', 15.0), ('schema', 16.0), ('schema', '16'), ('schema', True)")])
edit('tests/infrastructure/test_child_goal_ci_evidence.py',[("'schema':15","'schema':16"),("[('schema',15.0),('dirty',0),('schema',True)]","[('schema',15),('schema',17),('schema',15.0),('schema',16.0),('schema','16'),('dirty',0),('schema',True)]")])
(Path(__file__).parent/'CHANGES.json').write_text(json.dumps(changes,indent=2)+'\n');print(json.dumps({'files':len(changes)}))
