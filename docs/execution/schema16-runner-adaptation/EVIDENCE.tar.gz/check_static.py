from pathlib import Path
import subprocess,json,ast,hashlib,re
R=Path('/workspace/.worktrees/schema16-runner-adaptation');P=Path(__file__).resolve().parent;B='7d7b7016295a93a4f7ba5fe0e4e320f197e3b530'; checks=[]
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def check(n,b):assert b,n;checks.append(n)
changes=json.loads((P/'CHANGES.json').read_text());paths=[x['path']for x in changes]
check('exact approved thirteen files only',sorted(paths)==sorted(git('diff','--name-only',B).decode().splitlines()))
for item in changes:
 p=item['path'];old=git('show',B+':'+p).decode();expected=old
 for pair in item['changes']:expected=expected.replace(pair['before'],pair['after'])
 if item['schema15_labels_updated']:expected=expected.replace('schema15','schema16').replace('Graph15 execution evidence','Graph16 execution evidence')
 if p.endswith('factory-child-goal-real-ipc.py'):expected=expected.replace('Core15 exact lifecycle','Core16 exact lifecycle').replace('Fresh immutable Core15 tools','Fresh immutable Core16 tools').replace('Schema15 real child-Goal','Schema16 real child-Goal').replace('supplied real Core15','supplied real Core16')
 check('only enumerated schema contract changes: '+p,expected==(R/p).read_text())
 if p.endswith('.py'):compile((R/p).read_bytes(),p,'exec')
check('twelve Python sources compile without execution',sum(x.endswith('.py')for x in paths)==12)
check('production/Rust/Cargo/locks/CI and historical fixtures untouched',not git('diff','--name-only',B,'--','crates','Cargo.toml','Cargo.lock','.github','tests/fixtures','scripts/prepare-schema15-migration-fixture.py').strip())
check('two Root-owned Factory support scripts untouched',not git('diff','--name-only',B,'--','apps/desktop/tests/factory-real-ipc.py','apps/desktop/tests/factory-child-planning-real-ipc.py').strip())
for p in ['apps/desktop/tests/goal-execution-real-ipc.py','apps/desktop/tests/goal-graph-real-ipc.py','apps/desktop/tests/data-workspace-real-ipc.py','apps/desktop/tests/factory-child-goal-real-ipc.py']:
 old=ast.parse(git('show',B+':'+p));new=ast.parse((R/p).read_text())
 # Exact existing generated ACP code must not change with metadata/schema adaptation.
 strings=lambda tree:[n.value for n in ast.walk(tree)if isinstance(n,ast.Constant)and isinstance(n.value,str)and ('jsonrpc'in n.value or '#!/usr/bin/env python'in n.value)and len(n.value)>500]
 check('generated ACP long strings preserved: '+p,strings(old)==strings(new))
p='scripts/prepare-factory-test-tools.py';old=ast.parse(git('show',B+':'+p));new=ast.parse((R/p).read_text())
def funcs(t):return {n.name:ast.dump(n,include_attributes=False)for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
for n in ['verify_private_tool','probe','sha256','source_identity']:
 check('tool guard/lifecycle function unchanged: '+n,funcs(old)[n]==funcs(new)[n])
check('12 Factory table names exact unchanged',next(ast.dump(n)for n in old.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='FACTORY_TABLES'for t in n.targets))==next(ast.dump(n)for n in new.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='FACTORY_TABLES'for t in n.targets)))
sh=(R/'scripts/native-macos-smoke.sh').read_text();block=sh.split("<<'PY'\n",1)[1].split('\nPY',1)[0];compile(block,'<mac shell embedded assertions>','exec');check('native shell embedded Python syntax',True)
# Explicitly retain unrelated output bytes, waits and aggregate capture/resource constants.
for p,literal in [('apps/desktop/tests/goal-execution-real-ipc.py',"second['nodes'][1]['actual_output_bytes'] == 15"),('apps/desktop/tests/factory-child-goal-real-ipc.py','threading.Barrier(16)'),('apps/desktop/tests/factory-child-goal-real-ipc.py','self._bytes+base.MAX_RESPONSE_BYTES<=16*1024*1024'),('apps/desktop/tests/data-workspace-real-ipc.py',"seconds == 15")]:
 check('non-schema boundary preserved: '+literal,literal in (R/p).read_text() and literal in git('show',B+':'+p).decode())
protected=[]
for p in git('ls-tree','-r','--name-only',B,'--','scripts/prepare-schema15-migration-fixture.py','crates/core/tests/fixtures').decode().splitlines():
 b=git('show',B+':'+p);assert b==git('show','HEAD:'+p);protected.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
(P/'PROTECTED_FIXTURES.json').write_text(json.dumps(protected,indent=2)+'\n')
(P/'STATIC_RESULTS.json').write_text(json.dumps({'base':B,'passed':len(checks),'checks':checks,'scope':'Source/AST/compile preservation only; no Core or Native execution'},indent=2)+'\n')
print(json.dumps({'passed':len(checks),'failed':0,'scope':'static only'}))
