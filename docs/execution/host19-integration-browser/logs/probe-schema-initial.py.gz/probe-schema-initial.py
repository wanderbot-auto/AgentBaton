import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sqlite3
import stat
import subprocess
import sys
import tempfile
import traceback

work = Path("artifacts/host19-integration-browser").resolve()
mode = sys.argv[1]
assert mode in {"baseline", "candidate"}
folder = work / mode
folder.mkdir(mode=0o700)
filename = Path("apps/desktop/tests/integration-real-ipc.py").resolve()
spec = importlib.util.spec_from_file_location("schema_probe_driver", filename)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sql_probe(path):
    before = sha(path / "baton.sqlite3")
    observed = dict(database_sha256_before=before, accepted=False)
    try:
        with driver.database(path) as db:
            observed["query_only"] = db.execute("PRAGMA query_only").fetchone()[0]
            observed["active_transaction"] = db.in_transaction
            observed["version"] = db.execute("PRAGMA user_version").fetchone()[0]
            observed["counts"] = [
                db.execute("SELECT count(*) FROM " + table).fetchone()[0]
                for table in ("integration_policies", "integrations", "integration_attempts", "integration_ref_fences")
            ]
            try:
                db.execute("CREATE TABLE read_only_probe (x INTEGER)")
            except sqlite3.OperationalError as error:
                observed["write_refusal"] = str(error)
            else:
                raise AssertionError("readonly connection permitted a write")
        observed["accepted"] = True
    except driver.Refusal:
        observed["refused_at"] = traceback.extract_tb(sys.exc_info()[2])[-2].line
        traceback.print_exc()
    observed["database_sha256_after"] = sha(path / "baton.sqlite3")
    assert before == observed["database_sha256_after"]
    return observed

class ReachedProjectImport(Exception):
    pass

class SchemaGateHost(driver.Host):
    def result(self, method, params, *args, **kwargs):
        if method == "projects.import":
            # Observe the point immediately after the real bootstrap schema guard.
            # This boundary keeps the probe limited to schema and read-only SQL.
            raise ReachedProjectImport
        assert method == "system.snapshot"
        return super().result(method, params, *args, **kwargs)

data = {
    "mode": mode,
    "head": subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
    "driver_sha256": sha(filename),
    "tools": {name:sha(work/"tools"/name) for name in ("baton","batond")},
    "bootstrap_boundary": "real driver bootstrap, real Host result, stopped before project import",
}
with tempfile.TemporaryDirectory(prefix="ab-integ-schema-", dir="/tmp") as directory:
    root = Path(directory).resolve()
    runtime = root / "r"
    runtime.mkdir(mode=0o700)
    with (folder / "daemon.log").open("xb") as log:
        daemon = subprocess.Popen([str(work/"tools"/"batond")],env={**os.environ,"BATON_RUNTIME_DIR":str(runtime)},stdout=log,stderr=subprocess.STDOUT)
        try:
            driver.observe(lambda: (daemon.poll(),(runtime/"session.token").is_file(),(runtime/"batond.sock").exists()),lambda ready: ready==(None,True,True),seconds=10)
            assert stat.S_IMODE((runtime/"session.token").stat().st_mode) == 0o600
            assert stat.S_ISSOCK((runtime/"batond.sock").lstat().st_mode)
            assert stat.S_IMODE((runtime/"batond.sock").lstat().st_mode) == 0o600
            host = SchemaGateHost(runtime)
            try:
                driver.bootstrap(host,root,False)
            except ReachedProjectImport:
                data["bootstrap_status"] = "passed_schema_guard"
            except driver.Refusal:
                data["bootstrap_status"] = "refused"
                data["bootstrap_refused_at"] = traceback.extract_tb(sys.exc_info()[2])[-2].line
                traceback.print_exc()
            else:
                raise AssertionError("schema probe ran beyond the intended boundary")
            assert [entry["method"] for entry in host.audit] == ["system.snapshot"]
            snapshot = host.audit[0]["response"]["result"]
            assert type(snapshot["database_schema_version"]) is int and snapshot["database_schema_version"]==19
            data["snapshot"] = dict(api_version=snapshot["api_version"],database_schema_version=snapshot["database_schema_version"],sequence=snapshot["sequence"])
            data["database"] = {"19": sql_probe(runtime)}
            for number in (18,20):
                fixture = root / f"schema{number}"
                fixture.mkdir(mode=0o700)
                with sqlite3.connect((runtime/"baton.sqlite3").as_uri()+"?mode=ro",uri=True) as original:
                    with sqlite3.connect(fixture/"baton.sqlite3") as copy:
                        original.backup(copy)
                        copy.execute(f"PRAGMA user_version={number}")
                # Each version label is independently read on a real, isolated database.
                with sqlite3.connect((fixture/"baton.sqlite3").as_uri()+"?mode=ro",uri=True) as db:
                    assert db.execute("PRAGMA user_version").fetchone()==(number,)
                data["database"][str(number)] = sql_probe(fixture)
            assert host.result("system.snapshot",{})["sequence"]==snapshot["sequence"]
            data["sequence_unchanged"] = True
        finally:
            forced = False
            if daemon.poll() is None:
                daemon.send_signal(signal.SIGTERM)
                try:
                    daemon.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    forced = True
                    daemon.kill()
                    daemon.wait(timeout=5)
            data["cleanup"] = dict(daemon_pid=daemon.pid,exit=daemon.returncode,joined=True,forced_kill=forced)
assert data["cleanup"]["exit"] == 0 and not data["cleanup"]["forced_kill"]
data["cleanup"]["private_runtime_removed"] = not root.exists()
assert data["cleanup"]["private_runtime_removed"]
assert data["bootstrap_status"] == ("refused" if mode=="baseline" else "passed_schema_guard")
assert {version for version,result in data["database"].items() if result["accepted"]} == ({"18"} if mode=="baseline" else {"19"})
for key, result in data["database"].items():
    if result["accepted"]:
        assert result["query_only"] == 1 and result["active_transaction"]
        assert result["version"] == int(key) and result["counts"] == [0,0,0,0]
        assert "readonly" in result["write_refusal"]
(folder/"receipt.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(data,indent=2))
