from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('/workspace/.worktrees/task-workspace-ci-evidence');P=Path(__file__).resolve().parent;B='6c0908e598381a387a3e5b3207f3a7115905d73c';S='bf241a3cc690a073d7422f57367eaa1621449aef';checks=[]
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def check(n,v):assert v,n;checks.append(n)
paths=git('diff','--name-only',B,S).decode().splitlines();check('exact two authorized new paths',paths==['scripts/record-task-workspace-ci-evidence.py','tests/infrastructure/test_task_workspace_ci_evidence.py'])
check('both files additions only',all(line.startswith('A\t')for line in git('diff','--name-status',B,S).decode().splitlines()))
check('all production/schema/Cargo/CI/harness and old collectors unchanged',not git('diff','--name-only',B,S,'--','crates','apps','.github','Cargo.toml','Cargo.lock','scripts/record-child-goal-ci-evidence.py','scripts/record-legacy-migration-ci-evidence.py').strip())
sources=[]
for path in paths:
 raw=git('show',S+':'+path);check('working source matches frozen blob: '+path,raw==(R/path).read_bytes());compile(raw,path,'exec');sources.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
source=(R/paths[0]).read_text();tree=ast.parse(source)
check('no subprocess/network/database/provider import',not any(isinstance(n,(ast.Import,ast.ImportFrom))and any(s in ast.unparse(n)for s in ['subprocess','socket','sqlite3','urllib','requests','playwright'])for n in ast.walk(tree)))
check('no recursive file copy/glob/archive helper',all(x not in source for x in ['copytree(','.rglob(','os.walk(','shutil.copy','tarfile','zipfile']))
check('exact final serialized bytes budget including newline',"json.dumps(value, indent=2, allow_nan=False) + '\\n'"in source and 'len(raw) <= MAX_PUBLIC_SUMMARY'in source)
check('argparse error fixed with no raw message interpolation',"raise Refused('Fixed projection arguments refused')"in source and 'str(error)'not in source and 'repr(error)'not in source)
check('no forced result/IPC/test-control endpoint',all(x not in source for x in ['approvals.finalize','sessions.create','BATON_RUNTIME_DIR','HTTPServer']))
check('driver asserted name distinguishes metadata from DB proof','driver_asserted_no_execution'in source and "'metadata_only': True"in source)
check('all external paths are descriptor walked before file access','os.O_DIRECTORY | os.O_NOFOLLOW'in source and 'dir_fd=descriptor'in source and 'same_directory(private, fd)'in source)
(P/'SOURCE_SNAPSHOT.json').write_text(json.dumps({'base':B,'source':S,'files':sources},indent=2)+'\n');(P/'SCOPE_RESULTS.json').write_text(json.dumps({'count':len(checks),'checks':checks,'scope':'Static source/scope/compile only, not product execution'},indent=2)+'\n');print(json.dumps({'passed':len(checks),'failed':0,'scope':'static only'}))
