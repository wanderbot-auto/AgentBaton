"""Read-only existing Root corpus compatibility; no browser or public image copy."""
from pathlib import Path
import importlib.util,os,json
R=Path('/workspace/.worktrees/task-workspace-ci-evidence');O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixed_task_projection',R/'scripts/record-task-workspace-ci-evidence.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
root=Path('/workspace/.onboarding/task-bound-session-browser-five-actual-evidence1');fd=p.directory(root,private=True);result=[]
try:
 for name in p.PNG_NAMES:
  before=p.pin(os.stat(name,dir_fd=fd,follow_symlinks=False));raw=p.regular_bytes(fd,name,p.MAX_PNG)
  expected=(390,844)if'mobile'in name else(1440,1100)
  row={'sha256':p.sha(raw),'viewport':{'width':expected[0],'height':expected[1]}}
  public=p.png_bytes(raw,row,name);after=p.pin(os.stat(name,dir_fd=fd,follow_symlinks=False));assert before==after
  result.append({**public,'source_bytes_and_metadata_unchanged':True})
 p.same_directory(root,fd)
finally:os.close(fd)
(O/'EXISTING_PNG_FORMAT.json').write_text(json.dumps({'scope':'Read-only six previously completed Root Chromium files only; syntax compatibility, not a fresh browser run or actual collector publication. No images/raw report copied.','passed':len(result),'files':result},indent=2)+'\n')
print(json.dumps({'passed':len(result),'scope':'read-only preexisting PNG syntax compatibility only'}))
