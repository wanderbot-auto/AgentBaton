
set -euo pipefail
export PLAYWRIGHT_BROWSERS_PATH=/opt/goal/browser
/task/browser/bin/python -m playwright install --with-deps chromium
