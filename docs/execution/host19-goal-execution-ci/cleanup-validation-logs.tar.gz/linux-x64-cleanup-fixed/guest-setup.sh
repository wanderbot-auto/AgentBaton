
set -euo pipefail
test "$(uname -s):$(uname -m)" = Linux:x86_64
test "$(python -c 'import sys; print("%d.%d" % sys.version_info[:2])')" = 3.12
mkdir -p /task /evidence /opt/goal
useradd -u 10001 -m evidence
chmod 0700 /home/evidence
chown evidence:evidence /task /evidence
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl git gcc g++ make pkg-config libssl-dev xz-utils file
cd /opt/goal
node_asset=node-v22.19.0-linux-x64.tar.xz
curl --fail --silent --show-error --retry 1 -O "https://nodejs.org/dist/v22.19.0/$node_asset"
curl --fail --silent --show-error --retry 1 -O https://nodejs.org/dist/v22.19.0/SHASUMS256.txt
awk -v asset="$node_asset" '$2 == asset {print}' SHASUMS256.txt > node.sha256
sha256sum --check node.sha256
tar -xJf "$node_asset" -C /usr/local --strip-components=1
rustup_url=https://static.rust-lang.org/rustup/archive/1.28.2/x86_64-unknown-linux-gnu/rustup-init
curl --fail --silent --show-error --retry 1 -o rustup-init "$rustup_url"
curl --fail --silent --show-error --retry 1 -o rustup-init.sha "$rustup_url.sha256"
digest=$(awk '{print $1}' rustup-init.sha)
printf '%s  rustup-init\n' "$digest" | sha256sum --check
install -o evidence -g evidence -m 0500 rustup-init /task/rustup-init
node --version
npm --version
python --version
