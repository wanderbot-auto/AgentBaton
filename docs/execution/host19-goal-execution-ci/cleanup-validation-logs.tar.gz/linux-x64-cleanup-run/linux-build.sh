
set -euo pipefail
test "$HOME" = "$(getent passwd "$(id -u)" | cut -d: -f6)"
export PATH="$HOME/.cargo/bin:$PATH"
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
git -c advice.detachedHead=false clone --no-checkout /input/source.bundle /task/repository
cd /task/repository
git -c advice.detachedHead=false checkout --detach "$1"
test "$1" = "$(git rev-parse HEAD)"
test -z "$(git status --porcelain --untracked-files=no)"
/task/rustup-init -y --no-modify-path --profile minimal --default-toolchain 1.91.1
rustc -vV
CARGO_BUILD_JOBS=3 CARGO_PROFILE_DEV_DEBUG=0 cargo build --locked --bin batond --bin baton --features agentbaton-core/preview-evidence
npm --prefix apps/desktop ci --no-audit --no-fund
npm --prefix apps/desktop run build
python -m venv /task/browser
/task/browser/bin/python -m pip install --only-binary=:all: --require-hashes -r requirements-browser.txt
