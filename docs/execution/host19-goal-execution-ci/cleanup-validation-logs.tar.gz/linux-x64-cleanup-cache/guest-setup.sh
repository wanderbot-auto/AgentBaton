
set -euo pipefail
test "$(uname -s):$(uname -m)" = Linux:x86_64
test "$(python -c 'import sys; print("%d.%d" % sys.version_info[:2])')" = 3.12
mkdir -p /task /evidence /opt/goal
useradd -u 10001 -m evidence
chmod 0700 /home/evidence
chown evidence:evidence /task /evidence
apt-get -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 -o Acquire::Retries=1 update
apt-get -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 -o Acquire::Retries=1 install -y --no-install-recommends ca-certificates curl git gcc g++ make pkg-config libssl-dev xz-utils file
cd /tmp/goal-tool-inputs
sha256sum --check --strict <<'SHA'
2023ed689529516d7bd5533738ca6d205b2561f8d51947dabeeb39dd51a024c9  2023ed689529516d7bd5533738ca6d205b2561f8d51947dabeeb39dd51a024c9
4b4c596fc5268435c310a79c2e231a5a3567572c930ac0740ef9e147e83baf4e  4b4c596fc5268435c310a79c2e231a5a3567572c930ac0740ef9e147e83baf4e
8d17d5a4734e684228adee4ea4a75da94eb7f71993804adf29f344709e65fe09  8d17d5a4734e684228adee4ea4a75da94eb7f71993804adf29f344709e65fe09
c0649af18e6a24f6fe5535a3e86b341dd49a8e71117c8b68bde973ef834f16f2  node-v22.19.0-linux-x64.tar.xz
SHA
tar -xJf node-v22.19.0-linux-x64.tar.xz -C /usr/local --strip-components=1
mkdir -p /opt/goal/rust-stage /opt/goal/rust
tar -xJf 4b4c596fc5268435c310a79c2e231a5a3567572c930ac0740ef9e147e83baf4e -C /opt/goal/rust-stage
/opt/goal/rust-stage/rustc-1.91.1-x86_64-unknown-linux-gnu/install.sh --prefix=/opt/goal/rust --disable-ldconfig
tar -xJf 2023ed689529516d7bd5533738ca6d205b2561f8d51947dabeeb39dd51a024c9 -C /opt/goal/rust-stage
/opt/goal/rust-stage/rust-std-1.91.1-x86_64-unknown-linux-gnu/install.sh --prefix=/opt/goal/rust --disable-ldconfig
tar -xJf 8d17d5a4734e684228adee4ea4a75da94eb7f71993804adf29f344709e65fe09 -C /opt/goal/rust-stage
/opt/goal/rust-stage/cargo-1.91.1-x86_64-unknown-linux-gnu/install.sh --prefix=/opt/goal/rust --disable-ldconfig
node --version
npm --version
python --version
