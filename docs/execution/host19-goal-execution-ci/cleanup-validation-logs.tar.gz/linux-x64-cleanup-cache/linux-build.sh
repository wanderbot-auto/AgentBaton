
set -euo pipefail
umask 077
umask
test "$HOME" = "$(getent passwd "$(id -u)" | cut -d: -f6)"
export PATH="/opt/goal/rust/bin:$PATH"
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
git -c advice.detachedHead=false clone --no-checkout /input/source.bundle /task/repository
cd /task/repository
git -c advice.detachedHead=false checkout --detach "$1"
test "$1" = "$(git rev-parse HEAD)"
test -z "$(git status --porcelain --untracked-files=no)"
rustc -vV
CARGO_HTTP_TIMEOUT=45 CARGO_NET_RETRY=1 CARGO_BUILD_JOBS=3 CARGO_PROFILE_DEV_DEBUG=0 cargo build --locked --bin batond --bin baton --features agentbaton-core/preview-evidence
npm --prefix apps/desktop ci --fetch-retries=1 --fetch-timeout=45000 --no-audit --no-fund
npm --prefix apps/desktop run build
python -m venv /task/browser
/task/browser/bin/python -m pip install --timeout 30 --retries 1 --only-binary=:all: --require-hashes -r requirements-browser.txt
