
set -euo pipefail
printf '%s\n' 'Acquire::http::Timeout "20";' 'Acquire::https::Timeout "20";' 'Acquire::Retries "1";' >/tmp/goal-apt-timeouts.conf
export APT_CONFIG=/tmp/goal-apt-timeouts.conf
export PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT=35000
export PLAYWRIGHT_BROWSERS_PATH=/opt/goal/browser
/task/browser/bin/python -m playwright install --with-deps chromium
