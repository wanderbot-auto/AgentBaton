
set -euo pipefail
test "$HOME" = "$(getent passwd "$(id -u)" | cut -d: -f6)"
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null
export PLAYWRIGHT_BROWSERS_PATH=/opt/goal/browser
cd /task/repository
test "$1" = "$(git rev-parse HEAD)"
test -z "$(git status --porcelain --untracked-files=no)"
/task/browser/bin/python - <<'PY'
import hashlib,json,os,platform,stat,subprocess
from pathlib import Path
def git(*argv):
    return subprocess.check_output(['git',*argv],text=True).strip()
manifest={'schema':19, 'git_head':git('rev-parse','HEAD'), 'git_tree':git('rev-parse','HEAD^{tree}'),
  'dirty':False, 'cargo_features':['agentbaton-core/preview-evidence'],
  'binaries':{k:hashlib.sha256((Path('target/debug')/k).read_bytes()).hexdigest() for k in ('baton','batond')},
  'scope':'Task-owned local Linux x86_64 Docker candidate, no shared workflow, account or model'}
root=Path('/evidence')
(root/'candidate.json').write_text(json.dumps(manifest,indent=2)+'\n')

tool_metadata={}
for name,expected in manifest['binaries'].items():
    path=Path('target/debug')/name
    mode=path.lstat()
    raw=path.read_bytes()
    report={'uid': mode.st_uid,'effective_uid':os.geteuid(),'mode':oct(stat.S_IMODE(mode.st_mode)),
       'regular':stat.S_ISREG(mode.st_mode),'bytes':mode.st_size,'sha256':hashlib.sha256(raw).hexdigest()}
    assert report['uid']==report['effective_uid'] and report['regular']
    assert mode.st_mode&0o111 and not mode.st_mode&0o022 and 0<mode.st_size<=268435456
    assert report['sha256']==expected and len(raw)==report['bytes']
    tool_metadata[name]=report
(root/'tool-metadata.json').write_text(json.dumps(tool_metadata,indent=2)+'\n')
executable='/opt/goal/browser/chromium-1234/chrome-linux64/chrome'
current={'platform':platform.platform(), 'machine':platform.machine(),
    'binary_kind':{t:subprocess.check_output(['file','-b',Path('target/debug')/t],text=True).strip() for t in ('baton','batond')},
    'browser_path':executable,'browser_sha256':hashlib.sha256(Path(executable).read_bytes()).hexdigest(),
    'path_probe_started_playwright':False}
assert current['browser_sha256']=='0b20b130e7edd9dd51873be867761295fe0cfad490c2b9a64f95bd3cfc08fa71'
(root/'platform.json').write_text(json.dumps(current,indent=2)+'\n')
driver=['/task/browser/bin/python','apps/desktop/tests/goal-execution-real-ipc.py','--batond','target/debug/batond',
        '--candidate-manifest','/evidence/candidate.json','--frontend','apps/desktop/dist',
        '--output','/evidence/goal-execution','--chromium',executable]
(root/'driver-command.json').write_text(json.dumps(driver,indent=2)+'\n')
raise SystemExit(subprocess.run(driver).returncode)
PY
