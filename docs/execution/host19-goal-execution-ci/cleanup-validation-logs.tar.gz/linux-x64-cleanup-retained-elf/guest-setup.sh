
set -euo pipefail
test "$(uname -s):$(uname -m)" = Linux:x86_64
test "$(python -c 'import sys; print("%d.%d" % sys.version_info[:2])')" = 3.12
mkdir -p /task /evidence /opt/goal
useradd -u 10001 -m evidence
chmod 0700 /home/evidence
chown evidence:evidence /task /evidence
sed -i 's@http://deb.debian.org/@https://deb.debian.org/@g' /etc/apt/sources.list.d/debian.sources
cat >/tmp/goal-apt-timeouts.conf <<'APT'
Acquire::http::Timeout "25";
Acquire::https::Timeout "25";
Acquire::Retries "2";
APT
export APT_CONFIG=/tmp/goal-apt-timeouts.conf
apt-get update
apt-get install -y --no-install-recommends ca-certificates git xz-utils file
cd /tmp/goal-tool-inputs
sha256sum --check --strict <<'SHA'
fb0d8ec9bd1f5b843f7cf7e0c395fdee8d3d9ff4734ed68cdfc194d64df0e044  baton
47ca4e83773212ae58acfca0696633c3f1738f4d430c4288113111110c24b696  batond
c0649af18e6a24f6fe5535a3e86b341dd49a8e71117c8b68bde973ef834f16f2  node-v22.19.0-linux-x64.tar.xz
SHA
tar -xJf node-v22.19.0-linux-x64.tar.xz -C /usr/local --strip-components=1
install -d -m0700 -o evidence -g evidence /task/retained-tools
for role in baton batond; do
    install -m0700 -o evidence -g evidence "$role" "/task/retained-tools/$role"
    file -b "/task/retained-tools/$role"
done
node --version
npm --version
python --version
