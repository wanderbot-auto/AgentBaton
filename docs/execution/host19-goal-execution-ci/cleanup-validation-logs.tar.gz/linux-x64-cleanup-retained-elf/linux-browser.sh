
set -euo pipefail
export APT_CONFIG=/tmp/goal-apt-timeouts.conf
export PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT=35000
export PLAYWRIGHT_BROWSERS_PATH=/opt/goal/browser
/task/browser/bin/python -m playwright install --with-deps chromium
