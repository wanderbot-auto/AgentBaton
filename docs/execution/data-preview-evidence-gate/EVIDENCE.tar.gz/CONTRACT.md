# Preview evidence seam v1 (test only)

Source dcf5e24601455a95f5c23de72720211698fb6c19, base3ae9160, schema15. This is opt-in `agentbaton-core/preview-evidence`, not default configuration or authority. A release build with the feature must fail compilation. The normal default build does not compile this module, its fixture filenames, marker, state or reads.

At DataWorkspaceWorkers construction only, read the fixed `.agentbaton-preview-evidence-v1.json` relative to the already-held private runtime directory FD. Missing is off; malformed/unsafe input refuses this test instance. Requirements: actual canonical owned mode0700 parent; config nofollow/nonblock regular owned single-link0600, nonempty≤8192 bytes, stable descriptor metadata during bounded read, strict JSON with no unknown/duplicate fields. No environment/HTTP/renderer/Agent enabling switch and no hot reload.

Exact config keys:

```
{schema_version:1, nonce:<32..64 lowercase hex>,
 source:{canonical_root:<literal canonical absolute path>,device:<canonical u64 decimal STRING>,inode:<same>},
 files:[{artifact_id,relative_path,max_bytes,expected_sha256}],
 limits:{max_file_bytes,max_total_bytes,max_files}}
```

`files` is the complete original Vec<ArtifactRequirement>, relative-path sorted, with unique IDs; no external source is opened from the descriptor. The exact original preview fixture remains large.bin/file-1/32MiB with its real expected SHA, max_bytes67108864, limits67108864/67108864/4. Config validation never enlarges those limits. Match only an already host-validated `ApprovedDataSelection.contract_view`: source canonical root/device/inode plus exact files/limits and format1. Device/inode comparisons keep native u64→decimal text precision.

Only the first exact match consumes the gate. In the actual preview worker, after source-root identity validation but **before scanning file bytes**, CREATE_NEW/no-follow private `.agentbaton-preview-evidence-ready-v1.json`, mode0600, with exactly seven fields:

```
{schema_version:1, gate:"agentbaton_preview_evidence_gate_v1",stage:"before_scan",
 nonce:<exact config>,descriptor_sha256:<SHA256 of config raw bytes>,
 preview_id:<actual server preview UUID>,project_id:<actual server project UUID>}
```

Do not overwrite an existing marker. A short partial JSON can be visible while the newly-created regular file is written/fsynced; the driver may wait for missing/partial marker inside its existing15s observation bound, then must require all exact fields/permissions/identity before UI Cancel. A complete mismatched marker fails. No marker is success, scan proof, new permission or stop proof.

The worker then polls only its **original** cancel AtomicBool and original spawn deadline; the original IO_BUDGET remains30s. It cannot be released to success by time delay, a flag/file, or an external message. Cancel returns original data_error(CancelRequested)/CANCEL_REQUESTED; original timeout returns data_error(DeadlineExceeded)/DEADLINE_EXCEEDED, with the same timeout-first checkpoint order as CopyControl. Actor never waits on the gate. The existing worker is_finished→join→finish_data_preview path alone records the original final receipt. DataWorkspacePreview gets no new public fields. A matching cancelled fixture proves cooperative **pre-scan** cancellation, not mid-read cancellation, OS process stop, Native GUI or real Provider behavior.

No-match, missing config, already-consumed gate and all copy/other data operations follow the original implementation. The descriptor never supplies an opening capability, approval, Grant, destination or task assignment. Same-user hostile mutation and blocking kernel I/O are not an OS sandbox or hard interrupt guarantee.

Root owns actual feature builds, no-feature release binaries/audits, private tool manifests and exact-source runtime runs. A possible feature build is `cargo build --locked --bin batond --features agentbaton-core/preview-evidence`; the command is NOT_RUN here and needs Root's exclusive lease. No Daemon feature-forwarder, dependency or lock change is added.
