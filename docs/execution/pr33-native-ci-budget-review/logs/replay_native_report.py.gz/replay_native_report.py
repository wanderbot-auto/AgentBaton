from argparse import ArgumentParser
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ZIP = Path('/private/tmp/ab-pr33-ae-macos-red.5XKuoKXB/native.zip')
PIN = '4c4882c14436d8b11cc680fdec8cbe444bbfbd9c03482c789398b6f93cb58f70'
CASES = ('goal_execution_readonly_database', 'goal_graph_readonly_database',
         'factory_readonly_database', 'integration_readonly_database')
parser = ArgumentParser()
parser.add_argument('expectation', choices=['red','green'])
args = parser.parse_args()
assert hashlib.sha256(ZIP.read_bytes()).hexdigest() == PIN
with zipfile.ZipFile(ZIP) as archive:
    assert archive.namelist().count('native-smoke-before-runner.json') == 1
    original = archive.read('native-smoke-before-runner.json')
    hosted = json.loads(archive.read('native-runner.json'))
report = json.loads(original)
assert report['status'] == 'passed' and hosted['exit_code'] == 0 and not hosted['timeout']
assert hosted['owned_group_cleanup']
assert report['commit'] == 'eb2783beb2bee0cff165663b2d0da20f15d69e64'
assert all(type(report[domain][phase]['schema_version']) is int
           and report[domain][phase]['schema_version'] == 19
           for domain in CASES for phase in ('before','after'))
shell = Path('scripts/native-macos-smoke.sh').read_text()
anchor = 'python3 - "$output/native-smoke.json" <<\'PY\'\n'
assert shell.count(anchor)==1
checks, trailing = shell.split(anchor)[1].rsplit('\nPY\n',1)
assert not trailing
with tempfile.TemporaryDirectory(prefix='ab-native-replay-') as tmp:
    root = Path(tmp)
    source = root/'exact-original.json'
    source.write_bytes(original)
    out = root/'replay'
    out.mkdir()
    command = [sys.executable, '-B', 'scripts/native-run.py', '--output', str(out), '--',
               sys.executable, '-c', 'from pathlib import Path;import sys;Path(sys.argv[2]).write_bytes(Path(sys.argv[1]).read_bytes())',
               str(source), str(out/'native-smoke.json')]
    run = subprocess.run(command, capture_output=True, timeout=25)
    replay = json.loads((out/'native-runner.json').read_text())
    final = (out/'native-smoke.json').read_bytes()
    assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(original).digest()
    shell_check = subprocess.run([sys.executable, '-B', '-', str(source)], input=checks.encode(),
                                 capture_output=True, timeout=10)
    if args.expectation == 'red':
        assert run.returncode == 1 and replay['evidence_error'] == hosted['evidence_error']
        assert (out/'native-smoke-before-runner.json').read_bytes() == original
        assert shell_check.returncode == 1 and b'native Factory schema18' in shell_check.stderr
    else:
        assert run.returncode == 0 and 'evidence_error' not in replay and replay['status'] == 'passed'
        assert final == original and shell_check.returncode == 0
    print(json.dumps({
        'replay':args.expectation,
        'dimension':'offline replay of original hosted report; no GUI launched',
        'zip_sha256':PIN,
        'input_sha256':hashlib.sha256(original).hexdigest(),
        'report_sections_store19':len(CASES),
        'native_runner_exit':run.returncode,
        'replay_child_exit':replay['exit_code'],
        'replay_owned_group_cleanup':replay['owned_group_cleanup'],
        'evidence_error':replay.get('evidence_error'),
        'shell_assertions_exit':shell_check.returncode,
        'shell_error':shell_check.stderr.decode().splitlines()[-1:] if shell_check.stderr else [],
        'accepted_bytes_match_original':final == original,
    }, indent=2))
