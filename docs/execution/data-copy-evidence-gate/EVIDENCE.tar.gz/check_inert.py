#!/usr/bin/env python3
"""Only source/inverse checks and strings on own inert text; no Rust/product."""
import ast,hashlib,json,os,pathlib,subprocess,tempfile,unittest
ROOT=pathlib.Path('/workspace/.worktrees/data-copy-evidence-gate');OUT=pathlib.Path(__file__).resolve().parent
BASE='7d1566566a4c20c00c76c4d6a98eea35a101af95'
class Inert(unittest.TestCase):
 def audit(self,raw,extra=None):
  with tempfile.TemporaryDirectory(prefix='preview-audit-')as d:
   p=pathlib.Path(d);binary=p/'inert-text';binary.write_bytes(raw)
   env=os.environ.copy()
   if extra:
    for name,body in extra.items():
     f=p/name;f.write_text('#!/bin/sh\n'+body+'\n');f.chmod(0o700)
    env['PATH']=str(p)+':/usr/bin:/bin'
   r=subprocess.run(['bash',str(ROOT/'scripts/native-audit-release.sh'),str(binary)],env=env,capture_output=True)
   return r
 def test_clean_inert_text_passes(self):self.assertEqual(self.audit(b'ordinary fixed fixture bytes\n').returncode,0)
 def test_all_old_and_new_control_markers_refuse(self):
  for x in ['native_smoke_report','native-smoke-create','AGENTBATON_SMOKE_COMMIT','owner_dialog_report','native_factory_planning_os_dialog_fixture','agentbaton_preview_evidence_gate_v1','.agentbaton-preview-evidence-v1.json','.agentbaton-preview-evidence-ready-v1.json','agentbaton_copy_evidence_gate_v1','.agentbaton-copy-evidence-v1.json','.agentbaton-copy-evidence-ready-v1.json']:
   with self.subTest(marker=x):self.assertNotEqual(self.audit(x.encode()).returncode,0)
 def test_strings_failure_not_success(self):self.assertEqual(self.audit(b'fixture',{'strings':'exit 7'}).returncode,7)
 def test_grep_failure_not_success(self):self.assertEqual(self.audit(b'fixture',{'grep':'exit 2'}).returncode,2)
 def test_nonexistent_binary_refused(self):
  r=subprocess.run(['bash',str(ROOT/'scripts/native-audit-release.sh'),str(OUT/'never-created-binary')],capture_output=True);self.assertNotEqual(r.returncode,0)
 def test_feature_nondefault_release_guard_and_scoped_paths(self):
  manifest=(ROOT/'crates/core/Cargo.toml').read_text();workers=(ROOT/'crates/core/src/data_workspace_workers.rs').read_text()
  self.assertIn('preview-evidence = []',manifest);self.assertNotIn('default = ["preview-evidence"]',manifest)
  self.assertIn('#[cfg(all(feature = "preview-evidence", not(debug_assertions)))]\ncompile_error!',workers)
  self.assertIn('#[cfg(feature = "preview-evidence")]\n#[path = "copy_evidence_gate.rs"]',workers)
  self.assertNotIn('.agentbaton-preview-evidence',workers)
  self.assertEqual(workers.count('CopyEvidenceGate::load('),1)
  self.assertIn('const IO_BUDGET: Duration = Duration::from_secs(30);',workers)
 def test_core_unchanged_algorithms_and_public_boundary(self):
  changed=subprocess.check_output(['git','-C',str(ROOT),'diff','--name-only',BASE,'HEAD','--','crates','scripts','apps']).decode().splitlines()
  self.assertEqual(set(changed),{'crates/core/src/data_workspace_workers.rs','crates/core/src/copy_evidence_gate.rs','crates/core/src/copy_evidence_gate_tests.rs','scripts/native-audit-release.sh'})
  patch=subprocess.check_output(['git','-C',str(ROOT),'diff','--unified=0',BASE,'--','crates/core/src/data_workspace_workers.rs']).decode()
  self.assertFalse(any(x.startswith('-')and not x.startswith('---')for x in patch.splitlines()))
  workers=(ROOT/'crates/core/src/data_workspace_workers.rs').read_text()
  self.assertLess(workers.rindex('if root.view() != record.managed_root'),workers.rindex('gate.wait('))
  self.assertLess(workers.rindex('gate.wait('),workers.index('create_data_workspace_controlled(&snapshot, &root, &record.id, &control)'))
 def test_gate_only_fixed_parent_io_and_original_control(self):
  gate=(ROOT/'crates/core/src/copy_evidence_gate.rs').read_text()
  self.assertNotIn('std::env::var',gate);self.assertNotIn('std::process',gate)
  self.assertNotIn('open(&d.source',gate);self.assertNotIn('File::open',gate)
  for x in ['OFlags::NOFOLLOW','OFlags::NONBLOCK','OFlags::EXCL','m.nlink() == 1','before.ctime_nsec()','check_parent(path, parent)?','d.files == contract.files','d.limits == contract.limits','DataWorkspaceError::CancelRequested','DataWorkspaceError::DeadlineExceeded']:
   self.assertIn(x,gate)
  self.assertNotIn('deadline =',gate)
  self.assertIn('compare_exchange(false, true',gate)
  self.assertIn('control(cancel, deadline)?;\n            std::thread::sleep',gate)
 def test_ready_shape_is_exact_and_before_copy(self):
  gate=(ROOT/'crates/core/src/copy_evidence_gate.rs').read_text();part=gate.split("struct Ready<'a> {",1)[1].split('}',1)[0]
  fields=[line.strip().split(':')[0]for line in part.splitlines()if ':'in line]
  self.assertEqual(fields,['schema_version','gate','stage','nonce','descriptor_sha256','creation_id','project_id'])
  self.assertIn('stage: "before_copy"',gate)
 def test_eight_rust_gate_tests_remain_unrun_source(self):
  s=(ROOT/'crates/core/src/copy_evidence_gate_tests.rs').read_text();self.assertEqual(s.count('#[test]'),8);self.assertNotIn('#[ignore',s)
if __name__=='__main__':unittest.main(verbosity=2)
