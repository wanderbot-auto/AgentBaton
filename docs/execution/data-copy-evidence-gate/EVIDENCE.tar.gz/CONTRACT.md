# Independent before-copy evidence seam v1

Fixed source2c5ffcc5b26e44c5f4dd2c85b4ca25a3616756e0, base7d1566566a4c20c00c76c4d6a98eea35a101af95/schema15. The existing non-default `agentbaton-core/preview-evidence` debug feature now also contains an independent copy-specific startup gate. Default/release policy is unchanged: default compiles no gate/config reads, feature+release compile_error; real artifact audits still require Root evidence. Existing preview module and eight test bytes are unchanged.

Copy config fixed filename `.agentbaton-copy-evidence-v1.json`, read once at DataWorkspaceWorkers construction relative to its held owned/canonical0700 runtime FD. Missing is off; malformed/unsafe config refuses this test instance. Same nofollow/nonblock/regular/nlink1/owner0600/8KiB/metadata-stability/strictJSON checks as preview. No new environment, HTTP, renderer, Agent, public IPC or hot reload enabling path.

Exact config keys:

```
{schema_version:1,nonce:<32..64lowerhex>,
 source:{canonical_root:<literalcanonical>,device:<canonicalu64decimalSTRING>,inode:<same>},
 files:[{artifact_id,relative_path,max_bytes,expected_sha256}],
 limits:{max_file_bytes,max_total_bytes,max_files}}
```

Copy fixture uses the independent generated `copy-cancel` source32MiB large.bin/file-1/actualexpectedSHA, original64MiB/64MiB/four-file policy. Paths in descriptors are never opened. Match only the original validated snapshot contract's exact source root/u64 identity/files/limits/format1. It grants no source, destination, approval, Grant or workspace capability.

In the real copy worker, the existing Owner-bound creation record and full authorization context first pass; actual source bytes are re-verified against the saved snapshot; managed root identity is checked. Only then, before `create_data_workspace_controlled`, the first matching copy waits. Original deadline includes all prior preparation/scanning and is not reset; Actor never waits. Gate only observes original cancel/deadline with original CopyControl precedence/data_error mapping. No release-to-success, result override, skipped validation or fake stopped state.

Ready fixed filename `.agentbaton-copy-evidence-ready-v1.json`, private CREATE_NEW/no-follow0600, exact seven keys:

```
{schema_version:1,gate:"agentbaton_copy_evidence_gate_v1",stage:"before_copy",
 nonce:<exactconfig>,descriptor_sha256:<configrawbytesSHA256>,
 creation_id:<actualauthorizedrecordID>,project_id:<actualrecordproject>}
```

The snapshot contract's approval_reference remains the original verified preview ID, not the new creation UUID. Copy ready IDs come only from the existing authorized server record/callsite. Driver compares actual finalize response IDs plus full marker identity; the marker is observational and never itself authority. Missing/short partial marker can be awaited only inside the original15s phase; complete mismatch refuses. Existing markers are never overwritten. No external release flag exists.

Original cancellation is sent through UI/public production method; original worker returns CANCEL_REQUESTED or original DEADLINE_EXCEEDED. Existing join→finish_data_copy emits the only terminal copy_finished and io_completion. A pre-copy cancelled copy has no verified destination contract/partial-write observation; workspace metadata remains its existing outcome_unknown/unverified state. `worker_joined` is a thread receipt, not OS process/group stop.

Claim only cooperative **before-copy** cancellation and the real original receipt/join chain. Do not claim partial writes, mid-copy cancellation, atomic filesystem freeze, hard kernel interruption, OS dialog, real Provider or full-product acceptance. Original ready-wins race stays honest and does not meet the new cancelled-specific check.
