

/// Same existing integration runtime and authenticated Core records. Only the
/// external CI observation/source approval below are internal test fixtures.
#[test]
fn ci_repair_review_overlay_observes_real_store_candidate_and_refuses_incomplete_cas() {
    use agentbaton_core::{
        integration::ci_repair::*,
        storage::Store,
    };
    let mut f = RuntimeFixture::new();
    let ready = f.owner_ready();
    let definition = f.command_definition(&ready["candidates"][0]);
    let _accepted = f.accept();
    let policy_row = f.approve_integration(&definition);
    let terminal = terminal(&f);
    let run_id = terminal["run"]["id"].as_str().unwrap();
    let policy_id = policy_row["id"].as_str().unwrap();
    f.server.finish();
    let db_path = f.server.runtime.join("baton.sqlite3");
    let mut store = Store::open(&db_path).unwrap();
    let record = store.get_integration(run_id).unwrap();
    let policy = store.get_integration_policy(policy_id).unwrap();
    let legacy = store.reconcile_integration(run_id, record.run.revision, "internal-ci-witness-reconcile").unwrap();
    assert!(legacy.historical_cas_confirmed);
    assert_eq!(legacy.observed_target_head, None);
    assert_eq!(legacy.observation_scope, "recorded_private_intent_and_owned_receipts_only_no_ref_replay");
    let candidate = CiCandidate {
        project_id: policy.bindings.project_id.clone(),
        project_revision: policy.bindings.project_revision,
        root_task_id: policy.bindings.root_task_id.clone(),
        task_id: record.run.task_id.clone(),
        spec_revision: record.run.spec_revision,
        integration_id: record.run.id.clone(),
        integration_revision: record.run.revision,
        repository_digest: policy.bindings.repository_digest,
        target_ref: record.run.target_ref,
        commit: record.run.integration_commit.unwrap(),
    };
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as i64;
    let source = ApprovedCiSource {
        approval_ref: "internal-ci-source-approval".into(),
        source: CiSource {
            service_id: "internal-ci".into(),
            repository_id: "stable-internal-repo".into(),
            workflow_id: "fixture-workflow".into(),
        },
        current_candidate: candidate.clone(),
        expires_at_ms: now + 60_000,
    };
    let run = CiRunIdentity {
        source: source.source.clone(),
        run_id: "fixture-run".into(),
        attempt: 1,
    };
    let mut observation = CiObservation {
        candidate: candidate.clone(),
        run: run.clone(),
        current_run: run,
        status: CiStatus::Failed,
        observed_at_ms: now - 1000,
        finished_at_ms: Some(now - 2000),
        expires_at_ms: now + 60_000,
        report_ref: Some("internal-report-proof".into()),
    };
    let evaluate = |observation: &CiObservation| {
        store.decide_ci_repair(run_id, CiRepairInputs {
            source: Some(&source), observation: Some(observation), rule: None, history: None,
        }).unwrap()
    };
    let observe_events = || events(&readonly(&f));
    let before = observe_events();
    let exact = evaluate(&observation);
    assert_eq!(exact.decision, CiRepairDecision::ContinueRequired);
    assert_eq!(exact, evaluate(&observation));
    assert_eq!(observe_events(), before);
    let mut foreign = observation.clone();
    foreign.candidate.commit = if candidate.commit.starts_with('a') { "b" } else { "a" }.repeat(40);
    assert_eq!(evaluate(&foreign).decision, CiRepairDecision::Blocked { reason: CiRepairBlock::ObservationMismatch });
    assert_eq!(observe_events(), before);
    let cas_seq = unique_event(&before, "integration.cas_observed", &terminal["run"]["id"]).0;

    // Fault control only: remove one authentic receipt from the disposable
    // database, after the normal-path assertion. No success/authority is seeded.
    let writer = Connection::open(&db_path).unwrap();
    assert_eq!(writer.execute("DELETE FROM events WHERE sequence=?1", [i64::try_from(cas_seq).unwrap()]).unwrap(), 1);
    assert_eq!(evaluate(&observation).decision, CiRepairDecision::Blocked { reason: CiRepairBlock::CandidateNotCurrent });
    observation.status = CiStatus::Passed;
    assert_eq!(evaluate(&observation).decision, CiRepairDecision::Blocked { reason: CiRepairBlock::CandidateNotCurrent });
    assert_eq!(store.reconcile_integration(run_id, candidate.integration_revision, "internal-ci-witness-missing-cas").unwrap_err().code, "INPUT_CHANGED");
    println!("CI_REPAIR_STORE_WITNESS confirmed_ref={}, matched_continue_required=true wrong_snapshot_refused=true missing_cas_refused=true seq={} no_decision_history_writes=true old_reconcile_retains_true_and_missing_error=true", candidate.commit, exact.as_of_sequence);
}
